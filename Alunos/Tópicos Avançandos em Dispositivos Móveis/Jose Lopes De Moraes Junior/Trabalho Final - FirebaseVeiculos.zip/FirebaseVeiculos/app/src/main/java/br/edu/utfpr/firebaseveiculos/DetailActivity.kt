package br.edu.utfpr.firebaseveiculos

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.utfpr.firebaseveiculos.databinding.ActivityDetailBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class DetailActivity : AppCompatActivity() {
    lateinit var binding: ActivityDetailBinding
    val db = Firebase.firestore
    private val db_name = "Veiculo"

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityDetailBinding.inflate(layoutInflater)
            setContentView(binding.root)

            //Carregas os editTexts
            binding.codigo.setText(intent.getStringExtra("cod"))
            binding.marca.setText(intent.getStringExtra("marca"))
            binding.modelo.setText(intent.getStringExtra("modelo"))
            binding.ano.setText(intent.getStringExtra("ano"))
            binding.condicao.setText(intent.getStringExtra("condicao"))

            //BOTOES
            binding.editar.setOnClickListener {
                val pessoa = hashMapOf(
                    "cod" to binding.codigo.text.toString(),
                    "marca" to binding.marca.text.toString(),
                    "modelo" to binding.modelo.text.toString(),
                    "ano" to binding.ano.text.toString(),
                    "condicao" to binding.condicao.text.toString()
                )

                db.collection(db_name)
                    .document(binding.codigo.text.toString())
                    .set(pessoa)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Alterado no banco", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                    }
                finish()
            }

            binding.excluir.setOnClickListener {
                db.collection(db_name)
                    .document(binding.codigo.text.toString())
                    .delete()
                    .addOnSuccessListener {
                        Toast.makeText(this, "Excluido no banco", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                    }
                finish()
            }
            //FIM BOTOES
        }//ON CREATE
}