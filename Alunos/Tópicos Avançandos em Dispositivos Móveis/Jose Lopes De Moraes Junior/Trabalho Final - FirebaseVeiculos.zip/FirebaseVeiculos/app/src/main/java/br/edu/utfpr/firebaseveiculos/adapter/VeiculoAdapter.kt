package br.edu.utfpr.firebaseveiculos.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import br.edu.utfpr.firebaseveiculos.R
import br.edu.utfpr.firebaseveiculos.model.Veiculo

class VeiculoAdapter(private val veiculos: List<Veiculo>) : RecyclerView.Adapter<VeiculoAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val codEditText: EditText = itemView.findViewById(R.id.codigo)
        val marcaEditText: EditText = itemView.findViewById(R.id.marca)
        val modeloEditText: EditText = itemView.findViewById(R.id.modelo)
        val anoEditText: EditText = itemView.findViewById(R.id.ano)
        val condicaoEditText: EditText = itemView.findViewById(R.id.condicao)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_veiculo, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val veiculo = veiculos[position]
        holder.codEditText.setText(veiculo.cod)
        holder.marcaEditText.setText(veiculo.marca)
        holder.modeloEditText.setText(veiculo.modelo)
        holder.anoEditText.setText(veiculo.ano)
        holder.condicaoEditText.setText(veiculo.condicao)
    }

    override fun getItemCount(): Int {
        return veiculos.size
    }
}