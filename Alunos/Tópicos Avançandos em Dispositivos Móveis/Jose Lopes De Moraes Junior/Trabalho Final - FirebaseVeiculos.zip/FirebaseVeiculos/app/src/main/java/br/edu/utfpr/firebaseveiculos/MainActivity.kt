package br.edu.utfpr.firebaseveiculos

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.edu.utfpr.firebaseveiculos.databinding.ActivityMainBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    val db = Firebase.firestore
    private val db_name = "Veiculo"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.entradaButton.setOnClickListener {
            startActivity(Intent(this, ControlActivity::class.java))
            finish()
        }

        binding.cancelarButton.setOnClickListener {
            finishAffinity()
        }
    }
}