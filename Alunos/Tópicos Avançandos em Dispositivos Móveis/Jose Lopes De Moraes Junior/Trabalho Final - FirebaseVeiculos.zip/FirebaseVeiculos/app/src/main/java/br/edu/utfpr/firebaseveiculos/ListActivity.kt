package br.edu.utfpr.firebaseveiculos

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import br.edu.utfpr.firebaseveiculos.adapter.VeiculoAdapter
import br.edu.utfpr.firebaseveiculos.databinding.ActivityListBinding
import br.edu.utfpr.firebaseveiculos.model.Veiculo
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    private val db = Firebase.firestore
    private val db_name = "Veiculo"
    private val veiculos = mutableListOf<Veiculo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = VeiculoAdapter(veiculos)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        db.collection(db_name)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val veiculo = document.toObject(Veiculo::class.java)
                    veiculos.add(veiculo)
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Falha: $it", Toast.LENGTH_SHORT).show()
            }
    }
}