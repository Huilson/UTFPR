package br.edu.utfpr.firebaseveiculos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.edu.utfpr.firebaseveiculos.databinding.ActivityControlBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class ControlActivity : AppCompatActivity() {
    lateinit var binding: ActivityControlBinding
    val db = Firebase.firestore
    private val db_name = "Veiculo"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControlBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.registrar.setOnClickListener {
            startActivity(Intent(this, RegActivity::class.java))
        }

        binding.listar.setOnClickListener {
            val intent = Intent(this, ListActivity::class.java)
            startActivity(intent)
        }

        binding.pesquisar.setOnClickListener {
            val dialogView = layoutInflater.inflate(R.layout.dialog_pesquisa, null)
            val etPesquisa = dialogView.findViewById<EditText>(R.id.codigopesquisa)
            val btnConfirmar = dialogView.findViewById<Button>(R.id.confirmar)
            val btnCancelar = dialogView.findViewById<Button>(R.id.cancelar)

            val dialog = AlertDialog.Builder(this)
                .setView(dialogView)
                .create()

            btnConfirmar.setOnClickListener {
                val searchCode = etPesquisa.text.toString()
                if (searchCode.isNotEmpty()) {
                    db.collection(db_name)
                        .whereEqualTo("cod", searchCode)
                        .get()
                        .addOnSuccessListener { document ->
                            if (!document.isEmpty) {
                                val result = document.elementAt(0).data
                                val intent = Intent(this, DetailActivity::class.java)
                                intent.putExtra("cod", result["cod"].toString())
                                intent.putExtra("marca", result["marca"].toString())
                                intent.putExtra("modelo", result["modelo"].toString())
                                intent.putExtra("ano", result["ano"].toString())
                                intent.putExtra("condicao", result["condicao"].toString())

                                startActivity(intent)
                                dialog.dismiss()
                            } else {
                                Toast.makeText(this, "Código não encontrado", Toast.LENGTH_SHORT).show()
                            }
                        }
                } else {
                    Toast.makeText(this, "Por favor, insira um código", Toast.LENGTH_SHORT).show()
                }
            }

            btnCancelar.setOnClickListener {
                dialog.dismiss()
            }

            dialog.show()
        }

    }
}