package br.edu.utfpr.firebaseveiculos

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.utfpr.firebaseveiculos.databinding.ActivityRegBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class RegActivity : AppCompatActivity() {
    lateinit var binding: ActivityRegBinding
    val db = Firebase.firestore
    private val db_name = "Veiculo"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //BOTOES
        binding.salvar.setOnClickListener {

            val veiculo = hashMapOf(
                "cod" to binding.codigo.text.toString(),
                "marca" to binding.marca.text.toString(),
                "modelo" to binding.modelo.text.toString(),
                "ano" to binding.ano.text.toString(),
                "condicao" to binding.condicao.text.toString()
            )

            db.collection(db_name)
                .document(binding.codigo.text.toString())
                .set(veiculo)
                .addOnSuccessListener {
                    Toast.makeText(this, "Salvo no banco", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                }
            binding.codigo.text.clear()
            binding.marca.text.clear()
            binding.modelo.text.clear()
            binding.ano.text.clear()
            binding.condicao.text.clear()
        }

        /*binding.pesquisar.setOnClickListener {
            db.collection(db_name)
                .whereEqualTo("cod", binding.codigo.text.toString())
                .get()
                .addOnSuccessListener { document ->
                    if(!document.isEmpty){
                        val result = document.elementAt(0).data
                        val intent = Intent(this, DetailActivity::class.java)
                        intent.putExtra("cod", result.get("cod").toString())
                        intent.putExtra("marca", result.get("marca").toString())
                        intent.putExtra("modelo", result.get("modelo").toString())
                        intent.putExtra("ano", result.get("ano").toString())
                        intent.putExtra("condicao", result.get("condicao").toString())

                        startActivity(intent)
                    }
                }
        }*/
        //FIM BOTOES
    }//ONCREATE
}