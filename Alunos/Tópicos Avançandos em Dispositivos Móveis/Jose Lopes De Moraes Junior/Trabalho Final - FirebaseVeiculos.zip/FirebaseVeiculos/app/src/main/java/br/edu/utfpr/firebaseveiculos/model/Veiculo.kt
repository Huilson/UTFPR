package br.edu.utfpr.firebaseveiculos.model

data class Veiculo(
    val cod: String = "",
    val marca: String = "",
    val modelo: String = "",
    val ano: String = "",
    val condicao: String = ""
)
