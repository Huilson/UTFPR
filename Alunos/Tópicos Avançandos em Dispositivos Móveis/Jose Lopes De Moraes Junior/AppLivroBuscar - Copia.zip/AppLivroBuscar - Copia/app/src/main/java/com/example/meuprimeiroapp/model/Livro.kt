package com.example.meuprimeiroapp.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Livro (
    @PrimaryKey(autoGenerate = true) var id : Long = 0L,
    val nome : String,
    val autor : String,
    val genero : String,
    val volume : Int,
    val quantpag : Int,
    var leitura: Leitura?=null
)