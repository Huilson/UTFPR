package com.example.meuprimeiroapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.meuprimeiroapp.MainActivity
import com.example.meuprimeiroapp.databinding.ActivityEntradaBinding

class EntradaActivity : AppCompatActivity() {
    lateinit var binding: ActivityEntradaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEntradaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.entradaButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        binding.cancelarButton.setOnClickListener {
            finishAffinity()
        }
    }
}