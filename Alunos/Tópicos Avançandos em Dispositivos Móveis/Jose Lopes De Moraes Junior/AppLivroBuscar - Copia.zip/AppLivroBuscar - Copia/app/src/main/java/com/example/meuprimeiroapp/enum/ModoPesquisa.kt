package com.example.meuprimeiroapp.enum

enum class ModoPesquisa {
    POR_NOME,
    POR_GENERO
}