package com.example.meuprimeiroapp.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.meuprimeiroapp.MainActivity
import com.example.meuprimeiroapp.converter.LeituraTypeConverter
import com.example.meuprimeiroapp.dao.DaoLivro
import com.example.meuprimeiroapp.model.Livro

@Database(entities = [Livro::class], version = 20)
@TypeConverters(LeituraTypeConverter::class)
abstract class DatabaseLivro : RoomDatabase() {
    abstract fun daoLivro(): DaoLivro

    companion object {
        @Volatile
        private var INSTANCE: DatabaseLivro? = null

        fun getDatabase(context: Context): DatabaseLivro {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DatabaseLivro::class.java,
                    "my_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}