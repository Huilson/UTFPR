package com.example.meuprimeiroapp.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.meuprimeiroapp.EditarActivity
import com.example.meuprimeiroapp.databinding.LivroListaBinding
import com.example.meuprimeiroapp.model.Livro
import com.example.meuprimeiroapp.model.Leitura

class AdapterLivro(
    val context: Context,
    livros: List<Livro>)
    : RecyclerView.Adapter<AdapterLivro.ViewHolderLivro>(){

    private var livros =  livros.toMutableList()

    inner class ViewHolderLivro(val binding: LivroListaBinding, val context: Context)
        : RecyclerView.ViewHolder(binding.root){
        private lateinit var livro: Livro

        init {
            Log.i("AdapterLivro","entrou no init")
            itemView.setOnClickListener {
                Log.i("AdapterLivro","entrou no clique")
                if(::livro.isInitialized) {
                    Log.i("ItemView", "Livro: ${livro.id}")
                    val intent = Intent(context, EditarActivity::class.java)
                        .apply { putExtra("KEY_ID", livro.id) }
                    context.startActivity(intent)
                }
            }
        }

        fun vincula(livro: Livro){
            this.livro = livro
            val leitura = livro.leitura
            binding.nome.setText(livro.nome)
            binding.autor.setText(livro.autor)
            binding.genero.setText(livro.genero)
            binding.volume.setText(livro.volume.toString())
            binding.quantpag.setText(livro.quantpag.toString())
            binding.status.setText(leitura?.status.toString())
            binding.nota.setText(leitura?.nota.toString())
            binding.diasLidos.setText(leitura?.diasLidos.toString())
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderLivro {
        val layout = LayoutInflater.from(context)
        val binding = LivroListaBinding.inflate(layout, parent, false)
        return ViewHolderLivro(binding, context)
    }

    override fun getItemCount(): Int {
        return livros.size
    }

    override fun onBindViewHolder(holder: ViewHolderLivro, position: Int) {
        val livro = livros[position]
        holder.vincula(livro)
    }

    fun atualizarLista(novaLista: List<Livro>) {
        livros.clear()
        livros.addAll(novaLista)
        notifyDataSetChanged()
    }

}