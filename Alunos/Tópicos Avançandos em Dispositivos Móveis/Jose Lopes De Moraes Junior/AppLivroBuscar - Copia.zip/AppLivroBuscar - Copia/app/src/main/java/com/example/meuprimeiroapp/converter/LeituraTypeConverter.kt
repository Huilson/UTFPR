package com.example.meuprimeiroapp.converter

import androidx.room.TypeConverter
import com.example.meuprimeiroapp.model.Leitura
import com.google.gson.Gson

class LeituraTypeConverter {
    private val gson = Gson()

    @TypeConverter
    fun fromLeitura(leitura: Leitura?): String? {
        return gson.toJson(leitura)
    }

    @TypeConverter
    fun toLeitura(value: String?): Leitura? {
        return gson.fromJson(value, Leitura::class.java)
}
}