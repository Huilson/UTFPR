package com.example.meuprimeiroapp

import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.example.meuprimeiroapp.database.DatabaseLivro
import com.example.meuprimeiroapp.databinding.ActivityEditarBinding
import com.example.meuprimeiroapp.enum.StatusLeitura
import com.example.meuprimeiroapp.model.Leitura
import com.example.meuprimeiroapp.model.Livro

class EditarActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditarBinding
    private lateinit var livro: Livro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id: Long = intent.getLongExtra("KEY_ID", 0L)

        val db = Room.databaseBuilder(
            this,
            DatabaseLivro::class.java,
            "livro.db"
        ).allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao = db.daoLivro()

        livro = dao.buscarId(id)

        binding.nomeEdit.setText(livro.nome)
        binding.autorEdit.setText(livro.autor)
        binding.generoEdit.setText(livro.genero)
        binding.volumeEdit.setText(livro.volume.toString())
        binding.quantpagEdit.setText(livro.quantpag.toString())
        binding.notaEdit.setText(livro.leitura?.nota.toString())
        binding.diasLidosEdit.setText(livro.leitura?.diasLidos.toString())

        val statusLeituraArray = arrayOf(
            StatusLeitura.LIDO,
            StatusLeitura.LENDO,
            StatusLeitura.AGUARDANDO,
            StatusLeitura.NAO_ADQUIRIDO
        )

        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, statusLeituraArray)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.statusSpinner.adapter = adapter

        binding.statusSpinner.setSelection(statusLeituraArray.indexOf(livro.leitura?.status ?: StatusLeitura.NAO_ADQUIRIDO))

        binding.edit.setOnClickListener {
            val nomeLivro = binding.nomeEdit.text.toString()
            val autorLivro = binding.autorEdit.text.toString()
            val generoLivro = binding.generoEdit.text.toString()
            val volumeLivro = binding.volumeEdit.text.toString().toInt()
            val quantpagLivro = binding.quantpagEdit.text.toString().toInt()
            val nota = binding.notaEdit.text.toString().toInt()
            val diasLidos = binding.diasLidosEdit.text.toString().toInt()

            val statusLeitura = binding.statusSpinner.selectedItem as StatusLeitura

            dao.editar(
                Livro(
                    id = id,
                    nome = nomeLivro,
                    autor = autorLivro,
                    genero = generoLivro,
                    volume = volumeLivro,
                    quantpag = quantpagLivro,
                    leitura = Leitura(
                        status = statusLeitura,
                        nota = nota,
                        diasLidos = diasLidos
                    )
                )
            )

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        binding.delete.setOnClickListener {
            dao.excluir(livro)

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}