package com.example.meuprimeiroapp

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.example.meuprimeiroapp.dao.DaoLivro
import com.example.meuprimeiroapp.database.DatabaseLivro
import com.example.meuprimeiroapp.databinding.ActivityCadastrarBinding
import com.example.meuprimeiroapp.enum.StatusLeitura
import com.example.meuprimeiroapp.model.Leitura
import com.example.meuprimeiroapp.model.Livro


class CadastrarActivity : AppCompatActivity() {
    lateinit var binding : ActivityCadastrarBinding
    private lateinit var livro: Livro
    private lateinit var dao: DaoLivro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastrarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = Room.databaseBuilder(
            this,
            DatabaseLivro::class.java,
            "livro.db"
        ).allowMainThreadQueries().fallbackToDestructiveMigration().build()
        dao = db.daoLivro()

        binding.button.setOnClickListener {
            val nome = binding.nomeEdit.text.toString()
            val autor = binding.autorEdit.text.toString()
            val genero = binding.generoEdit.text.toString()
            val volume = binding.volumeEdit.text.toString().toInt()
            val quantpag = binding.quantpagEdit.text.toString().toInt()

            livro = Livro(
                nome = nome,
                autor = autor,
                genero = genero,
                volume = volume,
                quantpag = quantpag
            )
            exibirDialogoLeitura()
        }
    }

    private fun exibirDialogoLeitura() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Gerenciar Leitura")

        val statusLeituraArray = arrayOf(
            "Lido",
            "Lendo",
            "Aguardando",
            "Não Adquirido"
        )

        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, statusLeituraArray)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        builder.setView(spinner)

        builder.setPositiveButton("OK") { dialog, _ ->
            val selectedStatusIndex = spinner.selectedItemPosition
            val statusLeitura = when (selectedStatusIndex) {
                0 -> StatusLeitura.LIDO
                1 -> StatusLeitura.LENDO
                2 -> StatusLeitura.AGUARDANDO
                else -> StatusLeitura.NAO_ADQUIRIDO
            }

            if (statusLeitura == StatusLeitura.LIDO) {
                exibirDialogoNotaEDiasLidos()
            } else {
                salvarLeitura(statusLeitura, 0, 0)
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }

            dialog.dismiss()
        }

        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

        private fun exibirDialogoNotaEDiasLidos() {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Detalhes da Leitura")

            val view = layoutInflater.inflate(R.layout.dialog_nota_dias, null)
            val notaEdit = view.findViewById<EditText>(R.id.notaEdit)
            val diasLidosEdit = view.findViewById<EditText>(R.id.diasLidosEdit)

            builder.setView(view)

            builder.setPositiveButton("Salvar") { dialog, _ ->

                val nota = notaEdit.text.toString().toInt()
                val diasLidos = diasLidosEdit.text.toString().toInt()

                salvarLeitura(StatusLeitura.LIDO, nota, diasLidos)

                dialog.dismiss()
            }

            builder.setNegativeButton("Cancelar") { dialog, _ ->

                dialog.dismiss()
            }

            builder.show()
        }

    private fun salvarLeitura(statusLeitura: StatusLeitura, nota: Int, diasLidos: Int) {
        val leitura = Leitura(
            status = statusLeitura,
            nota = nota,
            diasLidos = diasLidos
        )

        livro.leitura = leitura

        if (livro.id == 0L) {
            dao.salvar(livro)
        } else {
            dao.editar(livro)
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}