package com.example.meuprimeiroapp.enum

enum class StatusLeitura {
    LIDO,
    LENDO,
    AGUARDANDO,
    NAO_ADQUIRIDO
}