package com.example.meuprimeiroapp.model

import androidx.room.Entity
import com.example.meuprimeiroapp.enum.StatusLeitura

@Entity
data class Leitura(
    val status: StatusLeitura,
    val nota: Int,
    val diasLidos: Int?
)