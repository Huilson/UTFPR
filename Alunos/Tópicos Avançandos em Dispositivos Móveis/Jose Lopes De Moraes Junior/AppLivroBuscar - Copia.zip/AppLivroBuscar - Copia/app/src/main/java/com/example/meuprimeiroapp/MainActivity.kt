package com.example.meuprimeiroapp

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.room.Room
import com.example.meuprimeiroapp.adapter.AdapterLivro
import com.example.meuprimeiroapp.database.DatabaseLivro
import com.example.meuprimeiroapp.databinding.ActivityMainBinding
import com.example.meuprimeiroapp.enum.ModoPesquisa

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private var modoPesquisa = ModoPesquisa.POR_NOME

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = Room.databaseBuilder(
            this,
            DatabaseLivro::class.java,
            "livro.db"
        ).allowMainThreadQueries().fallbackToDestructiveMigration().build()
        val dao = db.daoLivro()

        val listaLivros = dao.buscarTodos()

        if (listaLivros.isEmpty()) {
            binding.mensagemVazia.visibility = View.VISIBLE
        } else {
            binding.mensagemVazia.visibility = View.GONE
            val rv = binding.recyclerView
            rv.adapter = AdapterLivro(this, listaLivros)
        }

        //EVENTO DE CLIQUE DE BOTÃO
        binding.fab.setOnClickListener {
            intent = Intent(this, CadastrarActivity::class.java)
            startActivity(intent)
        }

        binding.fabPesquisa.setOnClickListener {
            when (modoPesquisa) {
                ModoPesquisa.POR_NOME -> {
                    binding.pesquisa.hint = "Buscar um livro por gênero..."
                    binding.fabPesquisa.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#DFDC00"))
                    modoPesquisa = ModoPesquisa.POR_GENERO
                }

                ModoPesquisa.POR_GENERO -> {
                    binding.pesquisa.hint = "Buscar um livro por nome..."
                    binding.fabPesquisa.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#06C582"))
                    modoPesquisa = ModoPesquisa.POR_NOME
                }

            }
        }

        binding.pesquisa.addTextChangedListener { text ->
            val query = text.toString().lowercase()

            when (modoPesquisa) {
                ModoPesquisa.POR_NOME -> {
                    val livrosEncontrados = dao.buscarPorNome(query)
                    (binding.recyclerView.adapter as? AdapterLivro)?.atualizarLista(
                        livrosEncontrados
                    )
                }

                ModoPesquisa.POR_GENERO -> {
                    val livrosEncontrados = dao.buscarPorGenero(query)
                    (binding.recyclerView.adapter as? AdapterLivro)?.atualizarLista(
                        livrosEncontrados
                    )
                }

            }
        }
    }
}