package com.example.meuprimeiroapp.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.meuprimeiroapp.model.Livro

@Dao
interface DaoLivro {
    @Query("SELECT * FROM Livro")
    fun buscarTodos() : List<Livro>

    @Query("SELECT * FROM Livro WHERE id = :id")
    fun buscarId(id : Long) : Livro

    @Insert
    fun salvar(livro: Livro)
    //não pode passar o ID, pois ele é gerado automaticamente

    @Update
    fun editar(livro: Livro)
    //Quando for editar, precisa passar tudo!

    @Delete
    fun excluir(livro: Livro)

    @Query("SELECT * FROM Livro WHERE nome LIKE '%' || :nome || '%'")
    fun buscarPorNome(nome: String): List<Livro>

    @Query("SELECT * FROM Livro WHERE genero LIKE :genero")
    fun buscarPorGenero(genero: String): List<Livro>

}