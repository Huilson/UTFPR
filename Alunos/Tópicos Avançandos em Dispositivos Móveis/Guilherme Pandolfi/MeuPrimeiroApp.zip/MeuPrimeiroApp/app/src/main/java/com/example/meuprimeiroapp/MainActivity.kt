package com.example.meuprimeiroapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var editIdade: EditText = findViewById(R.id.idadeEdit)
        var editPeso: EditText = findViewById(R.id.pesoEdit)
        var editAltura: EditText = findViewById(R.id.alturaEdit)
        var botao: Button = findViewById(R.id.button)

        botao.setOnClickListener {
            var idade: Int = editIdade.text.toString().toInt()
            //Sempre que trabalhar com questões de arredondamentos, use o BIGDECIMAL
            var peso: Double = editPeso.text.toString().toDouble()
            var altura: Double = editAltura.text.toString().toDouble()

            var imc : Double = peso / (altura*altura)
            var resultado: String = "Resultado"

            if(imc < 18.5)
            {
                resultado = "MAGREZA"
            }
            if(18.5 <= imc && imc <= 29.9)
            {
                resultado = "NORMAL"
            }
            if(30.0 <= imc && imc <= 39.9)
            {
                resultado = "SOBREPESO"
            }
            else
            {
                resultado = "OBESIDADE 1"
            }

            var viewImc: TextView = findViewById(R.id.imc)
            viewImc.text = imc.toString()
            var viewResultado: TextView = findViewById(R.id.resultado)
            viewResultado.text = resultado
        }
    }
}