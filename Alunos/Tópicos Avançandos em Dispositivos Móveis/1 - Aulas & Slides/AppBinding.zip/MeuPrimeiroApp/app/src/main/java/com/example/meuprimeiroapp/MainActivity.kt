package com.example.meuprimeiroapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.meuprimeiroapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Declarção do Layout com BINDING
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //Declaração das VIEWS
        var botao = binding.button

        botao.setOnClickListener {
            var idade: Int = binding.idadeEdit.text.toString().toInt()
            //Sempre que trabalhar com questões de arredondamentos, use o BIGDECIMAL
            var peso: Double = binding.pesoEdit.text.toString().toDouble()
            var altura: Double = binding.alturaEdit.text.toString().toDouble()

            var imc : Double = peso / (altura*altura)
            //var texto = binding.textImc

            when(imc){
                in 1.0..<18.5 -> binding.textImc.text = "Você tá magrinho"
                in 18.5..<24.99 -> binding.textImc.text = "Você tá bem"
                in 24.99..29.99 -> binding.textImc.text = "Você tá gordinho"
                else -> binding.textImc.text = "Você tá beeeeem gordinho"
            }

            var viewImc = binding.imc
            viewImc.text = imc.toString()
        }
    }
}