package com.example.meuprimeiroapp.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.meuprimeiroapp.EditarActivity
import com.example.meuprimeiroapp.databinding.PessoaListaBinding
import com.example.meuprimeiroapp.model.Pessoa

/*
Posso passar os componentes (views) por paramentro, dentro da minha classe Adapter
Sobreescrevo o método Adapter da classe abstrada RecyclerView
*/
class AdapterPessoa(
    val context: Context,
    pessoas: List<Pessoa>)//aponta para uma lista
    : RecyclerView.Adapter<AdapterPessoa.ViewHolderPessoa>(){

    private var pessoas =  pessoas.toMutableList()

    //Método principal, necessário para fazer a vinculação dos elementos da lista com as views
    //É também para inflar a tela
    inner class ViewHolderPessoa(val binding: PessoaListaBinding, val context: Context)
        : RecyclerView.ViewHolder(binding.root){
        private lateinit var pessoa: Pessoa

        init {
            Log.i("AdapterPessoa","entrou no init")
            itemView.setOnClickListener {
                Log.i("AdapterPessoa","entrou no clique")
                if(::pessoa.isInitialized) {
                    Log.i("ItemView", "Pessoa: ${pessoa.id}")
                    val intent = Intent(context, EditarActivity::class.java)
                        .apply { putExtra("KEY_ID", pessoa.id) }
                    context.startActivity(intent)
                }
            }
        }

        fun vincula(pessoa: Pessoa){//Método de vinculação VIEW -> ELEMENTO DA LISTA
            this.pessoa = pessoa
            binding.nome.setText(pessoa.nome)
            binding.altura.setText(pessoa.altura.toString())
            binding.peso.setText(pessoa.peso.toString())
            binding.imc.setText(pessoa.imc.toString())
        }
    }

    //Depois que todas as VIEWS forem processadas, basta inflar
    //INFLAR é o nome que se dá para mostrar as coisas na tela
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderPessoa {
        val layout = LayoutInflater.from(context)
        val binding = PessoaListaBinding.inflate(layout, parent, false)
        return ViewHolderPessoa(binding, context)/*Para poder inflar na tela é preciso passar pelo
        método VIEWHOLDERPESSOA*/
    }

    //Numero de iterações por VIEW/ELEMENTO DA LISTA
    override fun getItemCount(): Int {
        return pessoas.size
    }

    //Guarda a VIEW atual e processa de acordo com o que foi implementado
    //Neste caso a VIEW SEGURADA irá para no método VINCULA
    override fun onBindViewHolder(holder: ViewHolderPessoa, position: Int) {
        val pessoa = pessoas[position]
        holder.vincula(pessoa)
    }
}