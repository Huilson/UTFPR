package com.example.meuprimeiroapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.example.meuprimeiroapp.database.DatabasePessoa
import com.example.meuprimeiroapp.databinding.ActivityEditarBinding
import com.example.meuprimeiroapp.model.Pessoa

class EditarActivity : AppCompatActivity() {

    private lateinit var binding : ActivityEditarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //RECEBE VIA CHAVE "KEY_ID", ATRAVÉS DE UMA INTENT
        val id : Long = intent.getLongExtra("KEY_ID", 0L)

        //INSTÂNCIA DO BANCO
        val db = Room.databaseBuilder(
            this,
            DatabasePessoa::class.java,
            "pessoa.db"
        ).allowMainThreadQueries().build()
        val dao = db.daoPessoa()
        //FIM INSTÂNCIA

        //BUSCA PESSOA POR ID
        val pessoa: Pessoa = dao.buscarId(id)

        //CARREGA PESSOA BUCADA DO BANCO NAS VIEWS
        binding.nomeEdit.setText(pessoa.nome)
        binding.alturaEdit.setText(pessoa.altura.toString())
        binding.pesoEdit.setText(pessoa.peso.toString())
        binding.imcEdit.setText(pessoa.imc.toString())

        //EVENTO DE CLIQUE DE BOTÃO
        binding.edit.setOnClickListener {
            val idPessoa = id
            val nomePessoa = binding.nomeEdit.text.toString()
            val pesoPessoa = binding.pesoEdit.text.toString().toDouble()
            val alturaPessoa = binding.alturaEdit.text.toString().toDouble()
            val imcPessoa = pesoPessoa / (alturaPessoa * alturaPessoa)

            dao.editar(
                Pessoa(
                id = idPessoa,
                nome = nomePessoa,
                peso = pesoPessoa,
                altura = alturaPessoa,
                imc = imcPessoa
                )
            )
            //TROCA DE TELA
            finish()
        }//FIM BOTÃO EDITAR

        binding.delete.setOnClickListener {
            dao.excluir(pessoa)
            finish()
        }//FIM BOTÃO EXCLUIR
    }
}