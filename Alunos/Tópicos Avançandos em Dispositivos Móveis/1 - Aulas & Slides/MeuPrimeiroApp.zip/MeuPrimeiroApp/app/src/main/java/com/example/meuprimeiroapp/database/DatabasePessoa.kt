package com.example.meuprimeiroapp.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.meuprimeiroapp.dao.DaoPessoa
import com.example.meuprimeiroapp.model.Pessoa

@Database(entities = [Pessoa::class], version = 1)
abstract class DatabasePessoa : RoomDatabase(){
    abstract fun daoPessoa() : DaoPessoa
}