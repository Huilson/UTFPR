package com.example.meuprimeiroapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.room.Room
import com.example.meuprimeiroapp.adapter.AdapterPessoa
import com.example.meuprimeiroapp.dao.DaoPessoa
import com.example.meuprimeiroapp.database.DatabasePessoa
import com.example.meuprimeiroapp.databinding.ActivityMainBinding
import com.example.meuprimeiroapp.model.Pessoa
import java.util.Locale


class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding
    lateinit var db: DatabasePessoa
    lateinit var dao : DaoPessoa
    private var listaPessoa = ArrayList<Pessoa>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Declarção do Layout com BINDING
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //INSTÂNCIA O BANCO
        db = Room.databaseBuilder(
            this,
            DatabasePessoa::class.java,
            "pessoa.db"
        ).allowMainThreadQueries().build()


        //EVENTO DE CLIQUE DE BOTÃO
        binding.fab.setOnClickListener {
            //TROCA DE TELA
            intent = Intent(this, CadastrarActivity::class.java)
            startActivity(intent)
        }
    }//FIM do ONCREATE

    override fun onResume() {
        super.onResume()
        dao = db.daoPessoa()
        //Listar elementos do banco
        binding.recyclerView.adapter = AdapterPessoa(this, dao.buscarTodos())

        //Carrega os dados do banco em uma lista não-encadeada
        listaPessoa = dao.buscarTodos() as ArrayList<Pessoa>

        //listar elementos da busca
        binding.buscaView.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            android.widget.SearchView.OnQueryTextListener {
                //Retorna false para aquele que não quer usar, e verdadeiro para o que quer usar
            //Essa função retorna a busca somente depois do ENTER
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            //Essa função retorna a busca toda vez que um caracter for digitado
            override fun onQueryTextChange(newText: String?): Boolean {
                listaDaBusca(newText.toString())
                return true
            }
        })
    }

    private fun listaDaBusca(query: String) {
        if(query != null){//Verifica se a query
            val listaFiltrada = ArrayList<Pessoa>()
            for ( i in listaPessoa){
                if (i.nome.lowercase(Locale.ROOT).contains(query)){
                    listaFiltrada.add(i)
                }
            }//FIM DO FOR
            if (listaFiltrada.isEmpty()){
                Toast.makeText(this, "Sem resultado", Toast.LENGTH_SHORT).show()
            }else{
                binding.recyclerView.adapter = AdapterPessoa(this, listaFiltrada)
            }
        }
    }
}