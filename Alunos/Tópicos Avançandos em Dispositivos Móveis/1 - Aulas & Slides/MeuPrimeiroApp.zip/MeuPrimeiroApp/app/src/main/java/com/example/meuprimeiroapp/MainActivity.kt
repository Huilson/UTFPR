package com.example.meuprimeiroapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.meuprimeiroapp.adapter.AdapterPessoa
import com.example.meuprimeiroapp.database.DatabasePessoa
import com.example.meuprimeiroapp.databinding.ActivityMainBinding
import com.example.meuprimeiroapp.model.Pessoa

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Declarção do Layout com BINDING
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //INSTÂNCIA O BANCO
        val db = Room.databaseBuilder(
            this,
            DatabasePessoa::class.java,
            "pessoa.db"
        ).allowMainThreadQueries().build()
        val dao = db.daoPessoa()
        //FIM DA INSTÂNCIA

        //CARREGA O ADAPTER COM AS INFORMAÇÕES DO BANCO
        val rv = binding.recyclerView
        rv.adapter = AdapterPessoa(this, dao.buscarTodos())

        //EVENTO DE CLIQUE DE BOTÃO
        binding.fab.setOnClickListener {
            //TROCA DE TELA
            intent = Intent(this, CadastrarActivity::class.java)
            startActivity(intent)
        }
    }
}