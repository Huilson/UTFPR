package com.example.meuprimeiroapp.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.meuprimeiroapp.model.Pessoa

@Dao
interface DaoPessoa {
    @Query("SELECT * FROM Pessoa")
    fun buscarTodos() : List<Pessoa>

    @Query("SELECT * FROM Pessoa WHERE id = :id")
    fun buscarId(id : Long) : Pessoa

    @Insert
    fun salvar(pessoa: Pessoa)
    //não pode passar o ID, pois ele é gerado automaticamente

    @Update
    fun editar(pessoa: Pessoa)
    //Quando for editar, precisa passar tudo!

    @Delete
    fun excluir(pessoa: Pessoa)
}