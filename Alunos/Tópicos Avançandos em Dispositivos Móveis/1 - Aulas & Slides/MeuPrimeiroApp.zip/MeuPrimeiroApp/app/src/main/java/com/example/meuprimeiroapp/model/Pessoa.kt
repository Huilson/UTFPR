package com.example.meuprimeiroapp.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Pessoa (
    @PrimaryKey(autoGenerate = true) var id : Long = 0L,
    val nome : String,
    val altura : Double,
    val peso : Double,
    val imc : Double
)