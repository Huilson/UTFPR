package com.example.meuprimeiroapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.example.meuprimeiroapp.database.DatabasePessoa
import com.example.meuprimeiroapp.databinding.ActivityCadastrarBinding
import com.example.meuprimeiroapp.model.Pessoa


class CadastrarActivity : AppCompatActivity() {
    lateinit var binding : ActivityCadastrarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =  ActivityCadastrarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = Room.databaseBuilder(
            this,
            DatabasePessoa::class.java,
            "pessoa.db"
        ).allowMainThreadQueries().build()
        val dao = db.daoPessoa()

        binding.button.setOnClickListener {
            val altura =  binding.alturaEdit.text.toString().toDouble()
            val peso = binding.pesoEdit.text.toString().toDouble()
            val nome = binding.nomeEdit.text.toString()
            val imc = peso / (altura * altura)

            dao.salvar(Pessoa(
                nome = nome,
                altura = altura,
                peso = peso,
                imc = imc
            ))
            finish()
        }//Fim do clique do Botão
    }
}