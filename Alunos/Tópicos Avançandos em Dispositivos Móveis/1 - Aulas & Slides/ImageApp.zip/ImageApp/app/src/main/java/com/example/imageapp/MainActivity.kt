package com.example.imageapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.example.imageapp.databinding.ActivityMainBinding
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var url: String

    lateinit var dialogView : View
    lateinit var textoUrl : TextInputEditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //Incialização das variavéis
        //É preciso inflar o dialog_url dentro da Main, fora de uma View Group
        //Mesmo inflado essa view não será exibida na tela (por causa do .from)
        dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_url, null)
        //Depois de inflar a o dialog_url podemos chamar os elementos (views) contidos neles
        textoUrl = dialogView.findViewById(R.id.textUrl)

        binding.carregaUrl.setOnClickListener {
            criarDialog()
        }

        binding.telaCheia.setOnClickListener {
                val intent = Intent(this, FullSizeActivity::class.java)
                    .apply {
                        putExtra("CHAVE_URL", textoUrl.text.toString())
                    }
                startActivity(intent)
        }
    }

    private fun criarDialog() {
        //incializa um caixa de Dialog
        AlertDialog.Builder(this)
            //Muda a view padrão do dialog pela view criada por nós
            .setView(dialogView)
            //titulo da janela (dialog)
            .setTitle("Cole sua URL aqui")
            //Listener do botão de Positivo
            .setPositiveButton("Ok") { _, _ ->
                if (textoUrl.text.toString() != "")//Validação reduntate
                    url = textoUrl.text.toString()//pego a url e armazeno em uma variavel
                binding.imageBox.load(url)//com o COIL posso carrega a url direto no ImageView
                val view = dialogView.parent as ViewGroup?//seta o layout da view como ViewGroup
                view?.removeAllViews()//Destroi a view, somente uma View Group pode ser destruída
            }
            //Listener do botão de Positivo
            .setNegativeButton("Cancelar") { _, _ ->
                val view = dialogView.parent as ViewGroup?//seta o layout da view como ViewGroup
                view?.removeAllViews()//Destroi a view
            }
            .show()//Exibe o dialog
    }
}