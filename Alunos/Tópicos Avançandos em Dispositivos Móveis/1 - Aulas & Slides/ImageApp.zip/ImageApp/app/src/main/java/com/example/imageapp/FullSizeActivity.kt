package com.example.imageapp

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.example.imageapp.databinding.ActivityFullSizeBinding

class FullSizeActivity : AppCompatActivity() {
    lateinit var binding: ActivityFullSizeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullSizeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageUrl : String? = intent.getStringExtra("CHAVE_URL")
        Log.i("Chave Url", "Chave: $imageUrl")
        binding.fullImg.load(imageUrl)
    }
}