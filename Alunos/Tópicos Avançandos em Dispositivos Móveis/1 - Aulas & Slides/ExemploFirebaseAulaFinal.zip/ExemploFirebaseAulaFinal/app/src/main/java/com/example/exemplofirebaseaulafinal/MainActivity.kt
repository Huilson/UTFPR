package com.example.exemplofirebaseaulafinal

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.exemplofirebaseaulafinal.databinding.ActivityMainBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    val db = Firebase.firestore
    private val db_name = "Pessoa"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //BOTOES
        binding.salvar.setOnClickListener {

            val pessoa = hashMapOf(
                "cod" to binding.codigo.text.toString(),
                "nome" to binding.nome.text.toString(),
                "contato" to binding.contato.text.toString()
            )

            db.collection(db_name)
                .document(binding.codigo.text.toString())
                .set(pessoa)
                .addOnSuccessListener {
                    Toast.makeText(this, "Salvo no banco", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                }
            binding.nome.text.clear()
            binding.codigo.text.clear()
            binding.contato.text.clear()
        }

        binding.listar.setOnClickListener { }

        binding.pesquisar.setOnClickListener {
            db.collection(db_name)
                .whereEqualTo("cod", binding.codigo.text.toString())
                .get()
                .addOnSuccessListener { document ->
                    if(!document.isEmpty){
                        val result = document.elementAt(0).data
                        val intent = Intent(this, DetailActivity::class.java)
                        intent.putExtra("cod", result.get("cod").toString())
                        intent.putExtra("nome", result.get("nome").toString())
                        intent.putExtra("contato", result.get("contato").toString())
                        startActivity(intent)
                    }
                }
        }
        //FIM BOTOES
    }
}