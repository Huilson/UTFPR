package com.example.exemplofirebaseaulafinal

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.exemplofirebaseaulafinal.databinding.ActivityDetailBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    val db = Firebase.firestore
    private val db_name = "Pessoa"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Carregas os editTexts
        binding.codigo.setText(intent.getStringExtra("cod"))
        binding.nome.setText(intent.getStringExtra("nome"))
        binding.contato.setText(intent.getStringExtra("contato"))

        //BOTOES
        binding.editar.setOnClickListener {
            val pessoa = hashMapOf(
                "cod" to binding.codigo.text.toString(),
                "nome" to binding.nome.text.toString(),
                "contato" to binding.contato.text.toString()
            )

            db.collection(db_name)
                .document(binding.codigo.text.toString())
                .set(pessoa)
                .addOnSuccessListener {
                    Toast.makeText(this, "Alterado no banco", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                }
            finish()
        }

        binding.excluir.setOnClickListener {
            db.collection(db_name)
                .document(binding.codigo.text.toString())
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Exclui", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                }
            finish()
        }
        //FIM BOTOES
    }
}