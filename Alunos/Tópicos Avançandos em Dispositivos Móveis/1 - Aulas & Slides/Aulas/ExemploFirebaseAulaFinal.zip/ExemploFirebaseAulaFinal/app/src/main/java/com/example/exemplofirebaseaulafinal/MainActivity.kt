package com.example.exemplofirebaseaulafinal

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.exemplofirebaseaulafinal.databinding.ActivityMainBinding
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    val db = Firebase.firestore
    private val db_name = "Pessoa"
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(), {
            isGranted: Boolean ->
            if(isGranted){
             //TODO
            }
        }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        askNotificationPermission()

        manageToken()

        //BOTOES
        binding.salvar.setOnClickListener {

            val pessoa = hashMapOf(
                "cod" to binding.codigo.text.toString(),
                "nome" to binding.nome.text.toString(),
                "contato" to binding.contato.text.toString()
            )

            db.collection(db_name)
                .document(binding.codigo.text.toString())
                .set(pessoa)
                .addOnSuccessListener {
                    Toast.makeText(this, "Salvo no banco", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
                }
            binding.nome.text.clear()
            binding.codigo.text.clear()
            binding.contato.text.clear()
        }

        binding.listar.setOnClickListener {
            val intent = Intent(this, ListActivity::class.java)
            startActivity(intent)
        }

        binding.pesquisar.setOnClickListener {
            db.collection(db_name)
                .whereEqualTo("cod", binding.codigo.text.toString())
                .get()
                .addOnSuccessListener { document ->
                    if(!document.isEmpty){
                        val result = document.elementAt(0).data
                        val intent = Intent(this, DetailActivity::class.java)
                        intent.putExtra("cod", result.get("cod").toString())
                        intent.putExtra("nome", result.get("nome").toString())
                        intent.putExtra("contato", result.get("contato").toString())
                        startActivity(intent)
                    }
                }
        }
        //FIM BOTOES
    }//OnCreate

    private fun manageToken() {
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener(OnCompleteListener {
                task ->
                if(!task.isSuccessful){
                    Toast.makeText(this, "ok", Toast.LENGTH_SHORT)
                    return@OnCompleteListener
                }
                val token = task.result
                Toast.makeText(this, "Token: $token", Toast.LENGTH_LONG)
            })
    }

    fun askNotificationPermission(){
        if (ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED){
            //TODO
        }else if(shouldShowRequestPermissionRationale(android.Manifest.permission.POST_NOTIFICATIONS)){
            //TODO
        }else{
            requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}