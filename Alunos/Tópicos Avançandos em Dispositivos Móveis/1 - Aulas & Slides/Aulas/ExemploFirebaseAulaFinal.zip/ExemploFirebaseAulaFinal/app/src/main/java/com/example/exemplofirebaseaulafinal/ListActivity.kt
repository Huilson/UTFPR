package com.example.exemplofirebaseaulafinal

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.exemplofirebaseaulafinal.databinding.ActivityListBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import android.R

class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    val db = Firebase.firestore
    private val db_name = "Pessoa"
    var nomes = mutableListOf<String>()
    var exemplo = arrayListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db.collection(db_name)
            .get()
            .addOnSuccessListener {documents ->
                for(document in documents){
                    nomes.add(document.data.get("nome").toString())
                }
                val adapter =  ArrayAdapter(
                    this, //layout da apresentação
                    R.layout.simple_list_item_1, //tipo de exibiçao da lista
                    nomes) //conteudo da lista, precisa estar em um veto não-encadeado, ex: array
                binding.lista.adapter = adapter //com o adapter criado, basta mostra no listView
            }
            .addOnFailureListener {
                Toast.makeText(this, "Fu: $it", Toast.LENGTH_SHORT).show()
            }

    }
}