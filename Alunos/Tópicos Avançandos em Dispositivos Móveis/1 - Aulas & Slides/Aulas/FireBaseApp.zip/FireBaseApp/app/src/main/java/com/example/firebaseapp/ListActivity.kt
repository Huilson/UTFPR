package com.example.firebaseapp

import android.R
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseapp.databinding.ActivityListBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    val db = Firebase.firestore
    var nomes = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db.collection("Pessoa")
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents){
                    nomes.add(document.data.get("nome").toString())
                    val adapter = ArrayAdapter(this, R.layout.simple_list_item_1, nomes)
                    binding.listFirebase.adapter = adapter
                }
            }

            .addOnFailureListener {
                Toast.makeText(this, "Fudeu: $it", Toast.LENGTH_LONG).show()
            }
    }
}