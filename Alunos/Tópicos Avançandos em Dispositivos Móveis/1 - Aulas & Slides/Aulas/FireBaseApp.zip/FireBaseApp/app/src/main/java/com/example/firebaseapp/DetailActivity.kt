package com.example.firebaseapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseapp.databinding.ActivityDetailBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val cod = intent.getStringExtra("cod")
        val nome = intent.getStringExtra("nome")
        val contato = intent.getStringExtra("contato")

        binding.cod.setText(cod)
        binding.nome.setText(nome)
        binding.contato.setText(contato)

        binding.edit.setOnClickListener {
            val pessoa = hashMapOf(
                "cod" to binding.cod.text.toString(),
                "nome" to binding.nome.text.toString(),
                "contato" to binding.contato.text.toString()
            )
            db.collection("Pessoa")
                .document(binding.cod.text.toString())
                .set(pessoa)
                .addOnSuccessListener {
                    Toast.makeText(this, "Sucesso!", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fudeu: $it", Toast.LENGTH_LONG).show()
                }
            finish()
        }

        binding.delete.setOnClickListener {
            db.collection("Pessoa")
                .document(binding.cod.text.toString())
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Excluido!", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fudeu: $it", Toast.LENGTH_LONG).show()
                }
            finish()
        }
    }
}