package com.example.firebaseapp

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.firebaseapp.databinding.ActivityMainBinding
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    val db = Firebase.firestore
    val db_name: String = "Pessoa"

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(), { isGranted: Boolean ->
            if (isGranted) {

            }
        }
    )

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        askNotificationPermission()

        manageToken()

        //BOTOES
        binding.save.setOnClickListener {
            val pessoa = hashMapOf(
                "cod" to binding.cod.text.toString(),
                "nome" to binding.nome.text.toString(),
                "contato" to binding.contato.text.toString()
            )
            db.collection(db_name)
                .document(binding.cod.text.toString())
                .set(pessoa)
                .addOnSuccessListener {
                    Toast.makeText(this, "Sucesso!", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fudeu: $it", Toast.LENGTH_LONG).show()
                }
            binding.cod.text.clear()
            binding.nome.text.clear()
            binding.contato.text.clear()
        }

        binding.list.setOnClickListener {
            val intent = Intent(this, ListActivity::class.java)
            startActivity(intent)
        }

        binding.search.setOnClickListener {
            db.collection(db_name).whereEqualTo("cod", binding.cod.text.toString())
                .get()
                .addOnSuccessListener { document ->
                    if (!document.isEmpty) {
                        val result = document.elementAt(0).data
                        val intent = Intent(this, DetailActivity::class.java)
                        intent.putExtra("cod", result.get("cod").toString())
                        intent.putExtra("nome", result.get("nome").toString())
                        intent.putExtra("contato", result.get("contato").toString())
                        startActivity(intent)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fudeu: $it", Toast.LENGTH_LONG).show()
                }
        }
    }

    private fun manageToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(
            OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Toast.makeText(this, "Ok!", Toast.LENGTH_SHORT).show()
                    return@OnCompleteListener
                }

            val token = task.result
            Toast.makeText(this, token, Toast.LENGTH_LONG).show()
        })
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun askNotificationPermission() {
        if (ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            )
            == PackageManager.PERMISSION_GRANTED
        ) {

        } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.POST_NOTIFICATIONS)) {

        } else {
            requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}