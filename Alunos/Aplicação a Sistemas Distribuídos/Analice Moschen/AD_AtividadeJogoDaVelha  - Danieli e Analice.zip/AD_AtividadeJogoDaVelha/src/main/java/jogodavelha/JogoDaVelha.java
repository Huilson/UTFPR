package jogodavelha;

import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class JogoDaVelha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Jogo FrameJogo = new Jogo();
        FrameJogo.setVisible(true);
    }
    
}
