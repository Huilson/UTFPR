package br.edu.utfpr.chat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    //Variável de conexão
    ServerSocket serversocket;

    //Construtor
    public Server(ServerSocket serversocket) {
        this.serversocket = serversocket;
    }

    public void start() throws IOException {
        try {
            while (!serversocket.isClosed()) {
                System.out.println("Cliente foi conectado");
                //aceita a requisição de conexão de um cliente
                Socket socket = serversocket.accept();
                GerenciadorClientes gc = new GerenciadorClientes(socket);

                //Uama thread dá o direito a um cliente de ser ouvido e ouvir
                Thread thread = new Thread(gc);
                thread.start();
            }//fim while
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeServer() {
        try {
            if (serversocket != null) {
                serversocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }//fim método close server
    }

    public static void main(String[] args) throws IOException{
        ServerSocket serverSocket = new ServerSocket (1286);//porta que o servidor 
        Server server = new Server(serverSocket);//construtor de acesso ao servidor
        server.start();//tenho cliente? Sim
    }
   
}
