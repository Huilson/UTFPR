package br.edu.utfpr.chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

public class GerenciadorClientes implements Runnable {

    public static ArrayList<GerenciadorClientes> clientes = new ArrayList<>();
    private Socket socket;
    private String nomeCliente;
    private BufferedWriter bw;
    private BufferedReader br;

    public GerenciadorClientes(Socket socket) {
        try {
            this.socket = socket;
            //instancio um novo buffer sempre que enviar uma mensagem atraves do socket
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            //instancio um novo buffer sempre que alguém enviar uma mensagem
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //envio o nome do cliente atraves da conexao com o servidor
            this.nomeCliente = br.readLine();
            clientes.add(this);
            broadcast("Servidor: " + nomeCliente + " entrou no chat!");
        } catch (IOException e) {
            encerraTudo(socket, bw, br);//se der tudo errado fecha tudo!
        }//fim construtor
    }

    @Override
    public void run() {
        String msgCliente;
        while (socket.isConnected()) {
            try {
                msgCliente = br.readLine();
                broadcast("Servidor: " + msgCliente);
            } catch (IOException e) {
                encerraTudo(socket, bw, br);
                break;
            }//fim catch
        }//fim do while
    }//fim run

    public void broadcast(String msg) {
        for (GerenciadorClientes gc : clientes) {
            try {
                if (!gc.nomeCliente.equals(nomeCliente)) {
                    gc.bw.write(msg);//recebe a mensagem escrita pelo cliente que não escreveram a mensagem,
                    //terão o bloco abaixo executado
                    gc.bw.newLine();//pula de linha depois de receber a mensagem
                    gc.bw.flush();//limpa o buffer
                }
            } catch (IOException e) {
                encerraTudo(socket, bw, br);
            }
        }
    }

    public void remove() {
        clientes.remove(this);
        broadcast("Servidor: " + nomeCliente + " saiu do chat");
    }//fim remove

    public void encerraTudo(Socket socket, BufferedWriter bw, BufferedReader br) {
        remove();
        try {
            if (br != null) {
                br.close();//enquanto tiver leitura não encerra
            }
            if (bw != null) {
                bw.close();//enquanto tiver escrita não encerra
            }

            if (socket != null) {
                socket.close();//enquanto enviando ou recebendo não encerra
            }
        } catch (IOException e) {
            e.printStackTrace();
        }//fim do catch
    }//fim do encerrar
}
