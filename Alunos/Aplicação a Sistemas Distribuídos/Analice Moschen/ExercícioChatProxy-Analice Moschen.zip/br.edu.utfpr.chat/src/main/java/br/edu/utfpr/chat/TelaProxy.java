package br.edu.utfpr.chat;

/**
 *
 * @author Analice
 */
public class TelaProxy implements TelaUser {

    private TelaUser telaInterface;

    public TelaProxy() {
        telaInterface = new Client();
    }

    public String analisarPalavras(String teste) throws Exception {
        String str = null;
        //algumas palavras para usar no teste
        String palavras[] = {"Burro", "burro", "cu", "Cu", "Caralho", "Diabo", 
            "Escroto","Foda", "fdp", "filho da puta", "Merda"};
        for (int i = 0; i < palavras.length; i++) {
            //if(palavras.equals(c)) {//equalsIgnoreCase
           if (teste.contains(palavras[i])) {
               //se encontrar alguma palavra de baixo calão isso abaixo retornará
                str = "PALAVRAS DE BAIXO CALÃO";
                break;
            } else {
                 //str = palavras;
                str = palavras[i];
            }
        }
        return str;
    }

}
