package br.edu.utfpr.chat;

/**
 *
 * @author Analice
 */
public interface TelaUser {
    public String analisarPalavras(String palavras) throws Exception;

}
