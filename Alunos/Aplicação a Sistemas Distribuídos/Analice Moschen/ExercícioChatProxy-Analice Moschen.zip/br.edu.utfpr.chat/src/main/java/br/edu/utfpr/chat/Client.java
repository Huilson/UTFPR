package br.edu.utfpr.chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client implements TelaUser {

    private Socket socket;
    private BufferedReader br;
    private BufferedWriter bw;
    private String nomeUser;

    public Client(Socket socket, String nomeUser) {
        try {
            this.socket = socket;
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.nomeUser = nomeUser;
        } catch (IOException e) {
            encerraTudo(socket, bw, br);
        }
    }//contrutor

    Client() {
    }

    @Override
    public String analisarPalavras(String palavras) throws Exception {
        System.out.println(palavras + " foi acessada na classe original!");
        return null;
    }

    public void ouvir() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String broadcast;
                while (socket.isConnected()) {
                    try {
                        broadcast = br.readLine();
                        System.out.println(broadcast);
                    } catch (IOException e) {
                        encerraTudo(socket, bw, br);
                    }
                }//fim do while
            }//fim run
        }).start();//fim Runnable
    }//fim ouvir

    
    public void enviar() {
        String str;
        try {
            bw.write(nomeUser);
            bw.newLine();
            bw.flush();

            Scanner scan = new Scanner(System.in);
            TelaProxy proxy = new TelaProxy();
            while (socket.isConnected()) {
                String enviar = scan.nextLine();
                str = proxy.analisarPalavras(enviar);
                //se palavras de baixo calão foram digitadas e/ou encontradas em frases
                //apresentará a mensagem abaixo e não será enviado mensagem
                if (str.equals("PALAVRAS DE BAIXO CALÃO")) {
                    System.out.println(str + "\nTipo de linguagem inaceitável, mude o seu linguajar!");
                } else {
                    bw.write(nomeUser + ":" + enviar);
                }
                bw.newLine();
                bw.flush();
            }//fim do while
        } catch (Exception e) {
            encerraTudo(socket, bw, br);
        }
    }

    public void encerraTudo(Socket socket, BufferedWriter bw, BufferedReader br) {
        try {
            if (br != null) {
                br.close();//enquanto tiver leitura não encerra
            }
            if (bw != null) {
                bw.close();//enquanto tiver escrita não encerra
            }

            if (socket != null) {
                socket.close();//enquanto enviando ou recebendo não encerra
            }
        } catch (IOException e) {
            e.printStackTrace();
        }//fim do catch
    }//fim do encerrar

    public static void main(String args[]) throws IOException {
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite seu nome de usuário: ");
        String nomeUser = scan.nextLine();
        Socket socket = new Socket("localhost", 1286);
        Client client = new Client(socket, nomeUser);
        client.ouvir();
        client.enviar();
    }
}
