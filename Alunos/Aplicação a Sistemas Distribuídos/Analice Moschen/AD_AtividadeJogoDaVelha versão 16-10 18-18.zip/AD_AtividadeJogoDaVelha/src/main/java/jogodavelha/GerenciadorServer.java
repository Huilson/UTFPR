/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jogodavelha;

import java.io.IOException;
import java.net.ServerSocket;

/**
 *
 * @author danie
 */
public class GerenciadorServer implements Runnable{
    private ServidorJogo servidor;
    private int porta = 1234;

    @Override
    public void run() {
//        try{
            servidor = new ServidorJogo();
//        } catch(IOException e){
//            e.printStackTrace();
//        }
    }
    
    
}
