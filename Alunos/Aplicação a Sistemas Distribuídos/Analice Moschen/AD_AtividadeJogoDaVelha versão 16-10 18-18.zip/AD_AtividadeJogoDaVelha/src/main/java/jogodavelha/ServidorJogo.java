package jogodavelha;

/**
 *
 * @author danie
 */
public class ServidorJogo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Jogo FrameJogo = new Jogo();
        FrameJogo.setVisible(true);
        FrameJogo.setTitle("Servidor Jogo");
    }
    
}
