package jogodavelha;

import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */

/*Para iniciar o jogo, é necessário informar os nomes para saber quem usará o X e O
Iniciando com jogador que usará o X*/
public class Jogo extends javax.swing.JFrame {

    String jogador1 = JOptionPane.showInputDialog(null, "Informe o nome do jogador 1 que usará X: ");
    String jogador2 = JOptionPane.showInputDialog(null, "Informe o nome do jogador 2 que usará O: ");
    public boolean jogo1 = true;
    public boolean jogo2 = true;
    public int posicao = 0, cnt = 0;
    public int k = 0, i = 0;
    int aux;
    int auxX = 1, auxO = 1, placarX = 0, placarO = 0;
    public String l1, l2, l3, c1, c2, c3, d1, d2;
    String campos[][] = new String[3][3];

    /**
     * Creates new form Jogo
     */
    public Jogo() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnUm = new javax.swing.JButton();
        btnDois = new javax.swing.JButton();
        btnTres = new javax.swing.JButton();
        btnQuatro = new javax.swing.JButton();
        btnCinco = new javax.swing.JButton();
        btnSeis = new javax.swing.JButton();
        btnSete = new javax.swing.JButton();
        btnOito = new javax.swing.JButton();
        btnNove = new javax.swing.JButton();
        txtPlacar = new javax.swing.JTextField();
        btnJogarNovamente = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtPlacarJog1 = new javax.swing.JTextField();
        txtPlacarJog2 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnUm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUmActionPerformed(evt);
            }
        });

        btnDois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoisActionPerformed(evt);
            }
        });

        btnTres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTresActionPerformed(evt);
            }
        });

        btnQuatro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuatroActionPerformed(evt);
            }
        });

        btnCinco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCincoActionPerformed(evt);
            }
        });

        btnSeis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeisActionPerformed(evt);
            }
        });

        btnSete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeteActionPerformed(evt);
            }
        });

        btnOito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOitoActionPerformed(evt);
            }
        });

        btnNove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNoveActionPerformed(evt);
            }
        });

        btnJogarNovamente.setText("Jogar Novamente");
        btnJogarNovamente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJogarNovamenteActionPerformed(evt);
            }
        });

        jLabel1.setText("Placar:");

        jLabel2.setText("X");

        txtPlacarJog1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPlacarJog1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Informações do Jogo");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnSete, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(btnQuatro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnDois, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(btnCinco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnOito, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnTres, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(btnSeis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(101, 101, 101))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnJogarNovamente)
                                .addGap(61, 61, 61))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(68, 68, 68))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPlacar)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtPlacarJog1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                                .addComponent(txtPlacarJog2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtPlacar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(btnJogarNovamente)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnUm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnDois, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnTres, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnQuatro, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                            .addComponent(btnCinco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSeis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnOito, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnNove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSete, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtPlacarJog1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(txtPlacarJog2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /*Esse método verifica de quem é a vez, se é o jogador 1 ou o jogador 2 */
    public void verificaJogada() {
        //Verificando a vez e apresentando o símbolo (X ou O) do jogador
        if (jogo1 == true && jogo2 == true) {
            this.aux = 1;
            jogo1 = false;//desativado
            jogo2 = true;
            //Vez do jogador com o símbolo O, podendo escolher o botão
            txtPlacar.setText("Vez do jogador O " + jogador2);
        } else if (jogo1 == true && jogo2 == false) {
            this.aux = 1;
            jogo1 = false;//desativado
            jogo2 = true;
            txtPlacar.setText("Vez do jogador O " + jogador2);
        } else {
            this.aux = 2;
            jogo1 = true;
            jogo2 = false;//desativado
            //Vez do jogador com o símbolo X, podendo escolher o botão
            txtPlacar.setText("Vez do jogador X " + jogador1);
        }
    }

    //Se "X" e "O" não estão ocupando 3 linhas, ou 3 colunas ou 3 diagonais, 
    //será verificado assim dará velha
    public void deuVelha() {
        cnt = 0;

        for (i = 0; i < 3; i++) {
            for (k = 0; k < 3; k++) {
                if (campos[i][k] == "X" || campos[i][k] == "O") {
                    cnt++;
                }
            }
        }
    }

    /*Esse método é utilizado para encontrar o ganhador, verificando em quais botões foram
      atribuídos o símbolo "X" e "O" e mostrar o resultado*/
    public void encontraGanhador() {
        /*Abaixo está sendo apresentado em qual posição os botões são considerados 
        diagonais, linhas e colunas, no caso 3 posições para cada*/
        d1 = campos[0][0] + campos[1][1] + campos[2][2];
        d2 = campos[0][2] + campos[1][1] + campos[2][0];

        l1 = campos[0][0] + campos[0][1] + campos[0][2];
        l2 = campos[1][0] + campos[1][1] + campos[1][2];
        l3 = campos[2][0] + campos[2][1] + campos[2][2];

        c1 = campos[0][0] + campos[1][0] + campos[2][0];
        c2 = campos[0][1] + campos[1][1] + campos[2][1];
        c3 = campos[0][2] + campos[1][2] + campos[2][2];

        //se tiver três X nas linhas, ou nas colunas ou nas diagonais quem ganhou essa rodada foi Jogador 1
        //com isso, chama o método bloqueiaJogadas e apresenta o ganhador
        if (l1.equals("XXX") || l2.equals("XXX") || l3.equals("XXX") || c1.equals("XXX") || c2.equals("XXX") || c3.equals("XXX") || d1.equals("XXX") || d2.equals("XXX")) {
            txtPlacar.setText("Quem ganhou está rodada foi " + jogador1);
            bloqueiaJogadas();//chama o método bloqueiaJogadas
            //Então se o jogador 1 ganhou essa rodada, será somado com o placar, apresentando o placar atual 
            placarX = placarX + auxX;
            txtPlacarJog1.setText(jogador1 + ": " + placarX);
            //se tiver três O nas linhas, ou nas colunas ou nas diagonais quem ganhou essa rodada foi Jogador 2
            //com isso, chama o método bloqueiaJogadas e apresenta o ganhador
        } else if (l1.equals("OOO") || l2.equals("OOO") || l3.equals("OOO") || c1.equals("OOO") || c2.equals("OOO") || c3.equals("OOO") || d1.equals("OOO") || d2.equals("OOO")) {
            txtPlacar.setText("Quem ganhou está rodada foi " + jogador2);
            bloqueiaJogadas();
            //Então se o jogador 2 ganhou essa rodada, será somado com o placar, apresentando o placar atual 
            placarO = placarO + auxO;
            txtPlacarJog2.setText(jogador2 + ": " + placarO);
            /*Se nenhum dos símbolos fecha 3, não sendo igual ao que atribuimos nas linhas,
            colunas e diagonais, dará velha*/
        } else if (cnt == 9) {
            txtPlacar.setText("Deu velha! Ninguém ganhou a rodada!");
        }
    }

    //Após o jogador clicar no botão, o botão será bloqueado mostrando o símbolo de X ou O
    public void bloqueiaJogadas() {
        btnUm.setEnabled(false);
        btnDois.setEnabled(false);
        btnTres.setEnabled(false);
        btnQuatro.setEnabled(false);
        btnCinco.setEnabled(false);
        btnSeis.setEnabled(false);
        btnSete.setEnabled(false);
        btnOito.setEnabled(false);
        btnNove.setEnabled(false);
    }

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão UM, fixará e apresentará o mesmo
    private void btnUmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUmActionPerformed
        // botãoum
        verificaJogada();
        if (aux == 1) {
            btnUm.setText("X");
            campos[0][0] = "X";
        } else {
            btnUm.setText("O");
            campos[0][0] = "O";
        }

        btnUm.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnUmActionPerformed

    //Aqui habilitará tudo novamente, chamando o método limpaCampos 
    private void btnJogarNovamenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJogarNovamenteActionPerformed
        btnUm.setText("");
        btnUm.setEnabled(true);
        btnDois.setText("");
        btnDois.setEnabled(true);
        btnTres.setText("");
        btnTres.setEnabled(true);
        btnQuatro.setText("");
        btnQuatro.setEnabled(true);
        btnCinco.setText("");
        btnCinco.setEnabled(true);
        btnSeis.setText("");
        btnSeis.setEnabled(true);
        btnSete.setText("");
        btnSete.setEnabled(true);
        btnOito.setText("");
        btnOito.setEnabled(true);
        btnNove.setText("");
        btnNove.setEnabled(true);
        limpaCampos();
        txtPlacar.setText("");
        jogo1 = true;
        jogo2 = true;
    }//GEN-LAST:event_btnJogarNovamenteActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão DOIS, fixará e apresentará o mesmo
    private void btnDoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoisActionPerformed
        // botãodois
        verificaJogada();
        if (aux == 1) {
            btnDois.setText("X");
            campos[0][1] = "X";
        } else {
            btnDois.setText("O");
            campos[0][1] = "O";
        }

        btnDois.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnDoisActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão TRÊS, fixará e apresentará o mesmo
    private void btnTresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTresActionPerformed
        // botãotres
        verificaJogada();
        if (aux == 1) {
            btnTres.setText("X");
            campos[0][2] = "X";
        } else {
            btnTres.setText("O");
            campos[0][2] = "O";
        }

        btnTres.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnTresActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão QUATRO, fixará e apresentará o mesmo
    private void btnQuatroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuatroActionPerformed
        // botãoquatro
        verificaJogada();
        if (aux == 1) {
            btnQuatro.setText("X");
            campos[1][0] = "X";
        } else {
            btnQuatro.setText("O");
            campos[1][0] = "O";
        }

        btnQuatro.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnQuatroActionPerformed
    
    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão CINCO, fixará e apresentará o mesmo
    private void btnCincoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCincoActionPerformed
        // botãocinco
        verificaJogada();
        if (aux == 1) {
            btnCinco.setText("X");
            campos[1][1] = "X";
        } else {
            btnCinco.setText("O");
            campos[1][1] = "O";
        }

        btnCinco.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnCincoActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão SEIS, fixará e apresentará o mesmo
    private void btnSeisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeisActionPerformed
        // botãoseis
        verificaJogada();
        if (aux == 1) {
            btnSeis.setText("X");
            campos[1][2] = "X";
        } else {
            btnSeis.setText("O");
            campos[1][2] = "O";
        }

        btnSeis.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnSeisActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão SETE, fixará e apresentará o mesmo
    private void btnSeteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeteActionPerformed
        // botãosete
        verificaJogada();
        if (aux == 1) {
            btnSete.setText("X");
            campos[2][0] = "X";
        } else {
            btnSete.setText("O");
            campos[2][0] = "O";
        }

        btnSete.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnSeteActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão OITO, fixará e apresentará o mesmo
    private void btnOitoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOitoActionPerformed
        //botãooito
        verificaJogada();
        if (aux == 1) {
            btnOito.setText("X");
            campos[2][1] = "X";
        } else {
            btnOito.setText("O");
            campos[2][1] = "O";
        }

        btnOito.setEnabled(false);
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnOitoActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão NOVE, fixará e apresentará o mesmo
    private void btnNoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNoveActionPerformed
        //botãonove
        verificaJogada();
        if (aux == 1) {
            btnNove.setText("X");
            campos[2][2] = "X";
        } else {
            btnNove.setText("O");
            campos[2][2] = "O";
        }

        btnNove.setEnabled(false);//Desabilitado, pois algum símbolo está aplicado
        deuVelha();
        encontraGanhador();
    }//GEN-LAST:event_btnNoveActionPerformed

    private void txtPlacarJog1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPlacarJog1ActionPerformed
    }//GEN-LAST:event_txtPlacarJog1ActionPerformed
    //Método para limpar os campos
    public void limpaCampos() {
        for (i = 0; i < 3; i++) {
            for (k = 0; k < 3; k++) {
                campos[i][k] = "";
            }
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Jogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Jogo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCinco;
    private javax.swing.JButton btnDois;
    private javax.swing.JButton btnJogarNovamente;
    private javax.swing.JButton btnNove;
    private javax.swing.JButton btnOito;
    private javax.swing.JButton btnQuatro;
    private javax.swing.JButton btnSeis;
    private javax.swing.JButton btnSete;
    private javax.swing.JButton btnTres;
    private javax.swing.JButton btnUm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField txtPlacar;
    private javax.swing.JTextField txtPlacarJog1;
    private javax.swing.JTextField txtPlacarJog2;
    // End of variables declaration//GEN-END:variables
}
