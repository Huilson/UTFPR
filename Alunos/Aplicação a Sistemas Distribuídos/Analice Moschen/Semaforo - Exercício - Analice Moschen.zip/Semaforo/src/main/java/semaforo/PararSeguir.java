/*package semaforo;

======= Essa classe PararSeguir contêm o esperaVerde e o desligar
estava testando com os mesmos aqui, porém não me retornaram o esperado

/**
 *
 * @author Analice
 
public class PararSeguir {

    boolean verificar;
    boolean desligar;

    
    public synchronized void esperaVerde() throws InterruptedException {
        while (!verificar) {
            wait();
            //esperando a thread terminar para a outra ser utilizada
        }
        System.out.println("(Parar)");

        /*try {
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //O verificar recebe o false porque já terminou
        verificar = false;
    }

    //Aqui o método defini quando desligar o semáforo
    public synchronized void desligarSemaforo() {
        this.desligar = true;

    }

}*/
