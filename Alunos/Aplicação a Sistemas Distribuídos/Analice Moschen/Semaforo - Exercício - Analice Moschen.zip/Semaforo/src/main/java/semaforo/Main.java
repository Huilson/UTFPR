package semaforo;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Analice
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        Semaforo semafo = new Semaforo();

        Carro carro1 = new Carro(7, 1993, "Uno");
        Carro carro2 = new Carro(12, 1999, "Passat");
        Carro carro3 = new Carro(3, 2008, "Fusca");
        Carro carro4 = new Carro(1, 2004, "Corsa");
        Carro carro5 = new Carro(5, 1985, "Celta");
        Carro carro6 = new Carro(4, 2022, "Citroën");
        Carro carro7 = new Carro(18, 2014, "Mini Countryman");
        Carro carro8 = new Carro(23, 2021, "Audi");
        Carro carro9 = new Carro(4, 2005, "Nissan Kicks");
        Carro carro10 = new Carro(9, 2018, "Jaguar");
        Carro carro11 = new Carro(31, 2022, "Porsche Cayenne");
        Queue<Carro> carros = new LinkedList<>();
        //fazer fila

        carros.add(carro1);
        carros.add(carro2);
        carros.add(carro3);
        carros.add(carro4);
        carros.add(carro5);
        carros.add(carro6);
        carros.add(carro7);
        carros.add(carro8);
        carros.add(carro9);
        carros.add(carro10);
        carros.add(carro11);

        Semaforo semaforo = new Semaforo("Iniciar", carros);

        //for (Carro carro : carros) {
        while (!carros.isEmpty()) {//Se tiver carros na fila
            // if (carros.peek() != null) {//se tiver carros na fila
            semaforo.esperaVerde();//É necessário esperar o "Seguir" = Verde para começar
            if (semaforo.getPararSeguir() == CorSinal.Seguir) {
                //Apresentar que o sinal agora está verde
                System.out.println("Agora você pode " + semaforo.getPararSeguir() + "\nSeguindo...");

                //Preferi passar novamente o semaforo.getPararSeguir() == CorSinal.Seguir
                // e depois o !carros.isEmpty, porque apresenta se o sinal está verde para seguir
                //ou parar que é o vermelho...
                while (semaforo.getPararSeguir() == CorSinal.Seguir && !carros.isEmpty()){//ou somente while (!carros.isEmpty()) {
                    //É necessário que seja buscado da fila o carro, então
                    //utilizei o peek para buscar o primeiro elemento da fila
                    semaforo.verificarTempo(carros.peek());
                    //Obs: teste dessa forma: semaforo.verificarTempo(carros.element()) e funcionou também, mas preferi utilizar o peek()
                    //System.out.println(carros.peek());
                    //E o poll é utilizado para tirar da fila
                    System.out.println(carros.poll());
                }
            } else {
                //Se o sinal vermelho for vermelho irá mostrar o "Parando..."
                System.out.println("Agora você deve " + semaforo.getPararSeguir() + "\nParando...");
                // System.out.println(carros.remove());
            }
            semaforo.desligarSemaforo();
        }
    }
    
}
