package semaforo;

/**
 *
 * @author Analice
 */
public class Carro {

    int num;
    int ano;
    String nome;
    Thread t;
    final int NUM = 10;

    public Carro() {
    }

    //construtor
    public Carro(int num, int ano, String nome) {
        this.num = num;
        this.ano = ano;
        this.nome = nome;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return " " + nome + " ano " + ano;
    }

}
