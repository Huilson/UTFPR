package semaforo;

/**
 *
 * @author Analice
 */

public enum CorSinal {
    Parar,//vermelho
    Seguir;//verde

}
