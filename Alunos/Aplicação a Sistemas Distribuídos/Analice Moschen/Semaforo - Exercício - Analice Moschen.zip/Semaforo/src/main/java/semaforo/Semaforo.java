package semaforo;

import java.util.Queue;

/**
 *
 * @author Analice
 */

public class Semaforo implements Runnable {

   // PararSeguir ps = new PararSeguir();
    private Queue<Carro> carros;
    private Thread t;
    private String nome;
    private CorSinal sinal;
    private int num;
    private boolean verificar;
    private boolean desligar;

    public Semaforo() {
    }

    //Construtor que apresenta nome e a fila de carros
    public Semaforo(String nome, Queue<Carro> carros) {
        this.nome = nome;
        this.carros = carros;
        //this.ps = ps;
        this.sinal = CorSinal.Parar;
        t = new Thread(this, nome);
        t.start();
    }

    /*public enum Sinal {
        VERMELHO,
        VERDE;
    }*/
    //Opções de sinal: vermelho e verde
    //Verificação do tempo, utilizei o carro por paramêtro, assim verificando o ano do carro
    public void verificarTempo(Carro carro) throws InterruptedException {
        if (carro.getAno() < 2008) {
            Thread.sleep(4000);//Aqui o tempo será de 4000 milissegundos
        } else if (carro.getAno() == 2005) {
            Thread.sleep(3500);////Aqui o tempo será de 3500 milissegundos
        } else if (carro.getAno() > 2008) {
            Thread.sleep(2600);//Aqui o tempo será de 2600 milissegundos
        } else {
            Thread.sleep(2000);//Aqui o tempo será de 2000 milissegundos
        }
    }

    public synchronized void esperaVerde() throws InterruptedException {
        while (!verificar) {
            wait();//esperando a thread terminar para a outra ser utilizada
        }
        //O verificar recebe o false porque já terminou.
        verificar = false;
    }

    //Aqui o método define quando desligar o semáforo
    public synchronized void desligarSemaforo() {
        this.desligar = true;
    }

    public CorSinal getPararSeguir() {
        return sinal;
    }

    @Override
    public void run() {
        while (!desligar) {//ou verificar
            try {
                switch (this.sinal) {
                    //  case Parar://Vermelho
                    case Parar:
                        //System.out.println("Parar");
                        Thread.sleep(2000);
                        break;
                    case Seguir://Verde
                        // System.out.println("Seguir");
                        Thread.sleep(4000);
                        break;
                    default:
                        break;
                }
                //metodo para mudar a cor do sinal
                this.mudarSinal();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //System.out.println("Fim....");
    }

    public synchronized void mudarSinal() {
        switch (this.sinal) {
            case Parar://VERMELHO 
                //Caso o sinal seja vermelho, após irá receber o verde contando com o tempo de espera.
                this.sinal = CorSinal.Seguir;// this.pararSeguir = "Siga";
                break;
            case Seguir://VERDE
                //Caso o sinal seja verde, após irá receber o vermelho  
                this.sinal = CorSinal.Parar;//this.pararSeguir = "Pare";
                break;
            default:
                break;
        }
        verificar = true;
        notify();
    }

}
