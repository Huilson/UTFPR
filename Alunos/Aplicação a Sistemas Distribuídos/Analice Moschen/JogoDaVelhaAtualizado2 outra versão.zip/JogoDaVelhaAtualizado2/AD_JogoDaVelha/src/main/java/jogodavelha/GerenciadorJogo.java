/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jogodavelha;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class GerenciadorJogo implements Runnable {

    public static ArrayList<GerenciadorJogo> jogadores = new ArrayList<>();
    private Socket socket;
    private String nomeJogador;
    private BufferedWriter bw;
    private BufferedReader br;
    //private Jogo jg = new Jogo();

    private Jogo jogos;
    int aux, cnt;
    public boolean jogo1 = true;
    public boolean jogo2 = true;
    public boolean verifica;
    public boolean ganhador;
    String campos[][] = new String[3][3];
    int auxX = 1, auxO = 1, placarX = 0, placarO = 0;
    public String l1, l2, l3, c1, c2, c3, d1, d2;
    private String simbolo;
    private String simboloX = "X";
    private String simboloO = "O";
    private String msg;

    public GerenciadorJogo() {
    }

    public GerenciadorJogo(Socket socket) throws IOException {
        try {
            this.socket = socket;
            //estancio um novo buffer sempre que enviar uma nova mensagem atraves do socket
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            //estancio um novo buffer sempre que alguem enviar uma mensagem
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //envia o nome do cliente atraves da conexao com o servidor
            this.nomeJogador = br.readLine();
            jogadores.add(this);
            jogos = new Jogo(socket, nomeJogador);
            broadcast("Servidor: " + nomeJogador + " Entrou no chat!");
        } catch (IOException e) {
            encerraTudo(socket, bw, br);//se der errado fecha tudo
            e.printStackTrace();
        }
    }

    public int getAux() {
        return aux;
    }

    public void setAux(int aux) {
        this.aux = aux;
    }

    /*    @Override
    public void run() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (!ganhador) {
                    try {
                        verificaJogada();
                        msg = br.readLine();
                        broadcast(msg);
                    } catch (IOException e) {
                        encerraTudo(socket, bw, br);
                    }
                }
            }
        }).start();
    }*/
    @Override
    public void run() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (!ganhador) {
                    try {
                        if (verificaJogada().equals("Vez do jogador O ")) {
                            jogos.verificaJogadaO();
                        } else if (verificaJogada().equals("Vez do jogador X ")) {
                            jogos.verificaJogadaX();
                        }
                        msg = br.readLine();
                        broadcast(msg);
                    } catch (IOException e) {
                        encerraTudo(socket, bw, br);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(GerenciadorJogo.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }).start();
    }

//    @Override
//    public void run() {
//        while(socket.isConnected()){
//            verificaJogada();
////          deuVelha();
//            try{
//                simbolo = br.readLine();
////                verificaJogada();
////                deuVelha();
//                broadcast(simbolo);                
//            } catch(IOException e){
//                encerraTudo(socket, bw, br);
//                break;
//            }
//            
//        }
//    } 
    public void broadcast(String msg) {
        for (GerenciadorJogo gj : jogadores) {
            try {
                if (!gj.nomeJogador.equals(nomeJogador)) {
                    //todos os jogadores não escreveram a mensagem terão bloco abaixo executado
                    gj.bw.write(msg);//recebe a mensagem escrita pelo cliente não
                    gj.bw.newLine();//pula de linha depois de receber a mesnasgaem
                    gj.bw.flush();//limpa buffer
                }
            } catch (IOException e) {
                encerraTudo(socket, bw, br);
            }
        }
    }

    public void remove() {
        jogadores.remove(this);
        broadcast("Servidor: " + nomeJogador + " saiu do chat!");
    }

    public void encerraTudo(Socket socket, BufferedWriter bw, BufferedReader br) {
        remove();

        try {
            if (br != null) {
                br.close();//enquanto tiver leitura não encerra
            }
            if (bw != null) {
                bw.close();//enquanto tiver escrita não encerra
            }
            if (socket != null) {
                socket.close();//enquanto tiver enviando ou recebendo não encerra
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*Esse método é utilizado para encontrar o ganhador, verificando em quais botões foram
      atribuídos o símbolo "X" e "O" e mostrar o resultado*/
    public String encontraGanhador() {
        String str = "";
        /*Abaixo está sendo apresentado em qual posição os botões são considerados 
        diagonais, linhas e colunas, no caso 3 posições para cada*/
        d1 = campos[0][0] + campos[1][1] + campos[2][2];
        d2 = campos[0][2] + campos[1][1] + campos[2][0];

        l1 = campos[0][0] + campos[0][1] + campos[0][2];
        l2 = campos[1][0] + campos[1][1] + campos[1][2];
        l3 = campos[2][0] + campos[2][1] + campos[2][2];

        c1 = campos[0][0] + campos[1][0] + campos[2][0];
        c2 = campos[0][1] + campos[1][1] + campos[2][1];
        c3 = campos[0][2] + campos[1][2] + campos[2][2];

        //se tiver três X nas linhas, ou nas colunas ou nas diagonais quem ganhou essa rodada foi Jogador 1
        //com isso, chama o método bloqueiaJogadas e apresenta o ganhador
        if (l1.equals("XXX") || l2.equals("XXX") || l3.equals("XXX") || c1.equals("XXX") || c2.equals("XXX") || c3.equals("XXX") || d1.equals("XXX") || d2.equals("XXX")) {
            JOptionPane.showMessageDialog(null, "Quem ganhou está rodada foi " + nomeJogador);
            jogos.bloqueiaJogadas();//chama o método bloqueiaJogadas
            //Então se o jogador 1 ganhou essa rodada, será somado com o placar, apresentando o placar atual 
            placarX = placarX + auxX;
            str = nomeJogador + ": " + placarX + "\n\t\tX\nPlacar O" + placarO;
            this.ganhador = true;
            //se tiver três O nas linhas, ou nas colunas ou nas diagonais quem ganhou essa rodada foi Jogador 2
            //com isso, chama o método bloqueiaJogadas e apresenta o ganhador
        } else if (l1.equals("OOO") || l2.equals("OOO") || l3.equals("OOO") || c1.equals("OOO") || c2.equals("OOO") || c3.equals("OOO") || d1.equals("OOO") || d2.equals("OOO")) {
            JOptionPane.showMessageDialog(null, "Quem ganhou está rodada foi " + nomeJogador);
            jogos.bloqueiaJogadas();
            //Então se o jogador 2 ganhou essa rodada, será somado com o placar, apresentando o placar atual 
            placarO = placarO + auxO;
            str = nomeJogador + ": " + placarO + "\n\t\tX\nPlacar X" + placarX;
            this.ganhador = true;
            /*Se nenhum dos símbolos fecha 3, não sendo igual ao que atribuimos nas linhas,
            colunas e diagonais, dará velha*/
        } else if (cnt == 9) {
            JOptionPane.showMessageDialog(null, "Deu velha! Ninguém ganhou a rodada!");
            this.ganhador = true;
        }

        return str;
    }

    public synchronized String verificaJogada() {
        String str;
        //Verificando a vez e apresentando o símbolo (X ou O) do jogador
        if (jogo1 == true && jogo2 == true) {
            this.aux = 1;
            jogo1 = false;//desativado
            jogo2 = true;
            //Vez do jogador com o símbolo O, podendo escolher o botão

            str = "Vez do jogador O "; //+ nomeJogador;
           // jogos.setSimboloO(simboloO);
            notify();
        } else if (jogo1 == true && jogo2 == false) {
            this.aux = 1;
            jogo1 = false;//desativado
            jogo2 = true;

            str = "Vez do jogador O ";// + nomeJogador;
           // jogos.setSimboloO(simboloO);
            notify();
        } else {
            this.aux = 2;
            jogo1 = true;
            jogo2 = false;//desativado
            //Vez do jogador com o símbolo X, podendo escolher o botão

            str = "Vez do jogador X ";// + nomeJogador;
           // jogos.setSimboloX(simboloX);
            notify();
        }
        verifica = true;
        return str;
    }

    public synchronized void aguardaMudanca() throws InterruptedException {
        while (!verifica) {//enquanto verifica for verdadeiro
            wait();
            //a thread deve esperar a outra terminar seu
            //processo e assim por diante
        }
        //quando as threads terminarem seus processos e
        //sair do while o verifica ira receber o valor
        //falso pois os processos já terminaram
        verifica = false;
    }

    //Se "X" e "O" não estão ocupando 3 linhas, ou 3 colunas ou 3 diagonais, 
    //será verificado assim dará velha
    /* public void deuVelha() {
        cnt = 0;

        for (int i = 0; i < 3; i++) {
            for (int k = 0; k < 3; k++) {
                if (campos[i][k] == "X" || campos[i][k] == "O") {
                    cnt++;
                }
            }
        }
    }*/
}
