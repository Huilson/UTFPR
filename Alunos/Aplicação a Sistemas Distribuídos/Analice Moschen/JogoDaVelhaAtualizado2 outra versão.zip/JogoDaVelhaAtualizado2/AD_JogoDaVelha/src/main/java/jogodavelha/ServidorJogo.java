/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jogodavelha;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author danie
 */
public class ServidorJogo {

    ServerSocket serversocket;
    
    //Construtor
    public ServidorJogo(ServerSocket serversocket){
        this.serversocket = serversocket;
    }
    
    public void start() throws IOException{
        try{
            while(!serversocket.isClosed()){
                //aceita a requisição de conexão de um cliente
                Socket socket = serversocket.accept();
                System.out.println("Jogador foi conectado");
                
                GerenciadorJogo gj = new GerenciadorJogo(socket);
                
                //uma thread da o direito a um cliente de ser ouvido e ouvir
                Thread thread = new Thread(gj);
                thread.start();
            }
        } catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    public void closeServer(){
        try{
            if(serversocket != null){
                serversocket.close();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) throws IOException {
        ServerSocket serversocket = new ServerSocket(1286);//porta que o servidor fica ouvindo
        ServidorJogo server = new ServidorJogo(serversocket);//construtor de acesso ao servidor
        server.start();//tenho Jogador? Sim! inicio o servidor!
    }
    
}
