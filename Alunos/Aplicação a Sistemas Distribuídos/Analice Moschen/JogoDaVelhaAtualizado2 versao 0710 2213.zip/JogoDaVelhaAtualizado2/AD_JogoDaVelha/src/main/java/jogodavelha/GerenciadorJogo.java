/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jogodavelha;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author danie
 */
public class GerenciadorJogo implements Runnable {

    public static ArrayList<GerenciadorJogo> jogadores = new ArrayList<>();
    private Socket socket;
    private String nomeJogador;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    //private Jogo jg = new Jogo();

    private Jogo jogos;
    int aux, cnt;
    public boolean jogo1 = true;
    public boolean jogo2 = true;
    public boolean verifica;
    public boolean ganhador;
    String campos[][] = new String[3][3];
    int auxX = 1, auxO = 1, placarX = 0, placarO = 0;
    public String l1, l2, l3, c1, c2, c3, d1, d2;
    private String simbolo;
    private String simboloX = "X";
    private String simboloO = "O";
    private String msg;

    public GerenciadorJogo() {
    }

    public GerenciadorJogo(Socket socket) throws IOException {
        try {
            this.socket = socket;
            //estancio um novo buffer sempre que enviar uma nova mensagem atraves do socket
            this.oos = new ObjectOutputStream(socket.getOutputStream());
            //estancio um novo buffer sempre que alguem enviar uma mensagem
            this.ois = new ObjectInputStream(socket.getInputStream());
            //envia o nome do cliente atraves da conexao com o servidor
            this.nomeJogador = ois.readUTF();
            jogadores.add(this);
            jogos = new Jogo(socket, nomeJogador);
            broadcast("Servidor: " + nomeJogador + " Entrou no chat!");
        } catch (IOException e) {
            encerraTudo(socket, oos, ois);//se der errado fecha tudo
            e.printStackTrace();
        }
    }

    public int getAux() {
        return aux;
    }

    public void setAux(int aux) {
        this.aux = aux;
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public String getSimboloX() {
        return simboloX;
    }

    public String getSimboloO() {
        return simboloO;
    }
    
    @Override
    public void run() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (!ganhador) {
                    try {
                        if (jogos.verificaJogadaO()) {
                            simbolo = ois.readUTF();
                            broadcast(simbolo);
                            jogos.verificaJogadaX();
                        } else if (jogos.verificaJogadaX()) {
                            simbolo = ois.readUTF();
                            broadcast(simbolo);
                            jogos.verificaJogadaO();
                        }
                        /*if (jogos.verificaJogadaO() == true) {
                            jogos.verificaJogadaX();
                        } else if (jogos.verificaJogadaX() == true) {
                            jogos.verificaJogadaO();
                        }*/
                        
                    } catch (IOException e) {
                        encerraTudo(socket, oos, ois);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(GerenciadorJogo.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }).start();
    }
    
    public void broadcast(String msg) {
        for (GerenciadorJogo gj : jogadores) {
            try {
                if (!gj.nomeJogador.equals(nomeJogador)) {
                    //todos os jogadores não escreveram a mensagem terão bloco abaixo executado
                    gj.oos.writeUTF(msg);//recebe a mensagem escrita pelo cliente não
                    //gj.bw.newLine();//pula de linha depois de receber a mesnasgaem
                    gj.oos.flush();//limpa buffer
                }
            } catch (IOException e) {
                encerraTudo(socket, oos, ois);
            }
        }
    }

    public void remove() {
        jogadores.remove(this);
        broadcast("Servidor: " + nomeJogador + " saiu do chat!");
    }

    public void encerraTudo(Socket socket, ObjectOutputStream oos, ObjectInputStream ois) {
        remove();

        try {
            if (ois != null) {
                ois.close();//enquanto tiver leitura não encerra
            }
            if (oos != null) {
                oos.close();//enquanto tiver escrita não encerra
            }
            if (socket != null) {
                socket.close();//enquanto tiver enviando ou recebendo não encerra
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
