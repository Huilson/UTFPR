package utfpr.aula.jokenpo.theojokenpo;

/**
 *
 * @author Theo
 */

public class Jogador {

    private String nickname;
    private String jogada;
    private int pontos;

    public Jogador(String nickname) {
        this.nickname = "Anônimo";
        this.nickname = nickname;
        this.pontos = 0;
    }
    


    public String getNickname() {
        return nickname;
    }

    public String getJogada() {
        return jogada;
    }

    public void setJogada(String jogada) {
        this.jogada = jogada;
    }

    public int getPontos() {
        return pontos;
    }

    public void atualizaScore(int points) {
        pontos += points;
    }

}
