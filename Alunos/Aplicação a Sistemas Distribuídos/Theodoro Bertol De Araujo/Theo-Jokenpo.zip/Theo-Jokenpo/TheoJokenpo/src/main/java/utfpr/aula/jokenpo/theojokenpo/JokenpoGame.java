package utfpr.aula.jokenpo.theojokenpo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Theo
 */
public class JokenpoGame {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Jogador> jogadores = new ArrayList<>();

        System.out.print("Digite o número de jogadores: ");
        int numeroJogadores = scanner.nextInt();

        for (int i = 0; i < numeroJogadores; i++) {
            System.out.print("Digite o nickname do jogador " + (i + 1) + ": ");
            String nickname = scanner.next();
            jogadores.add(new Jogador(nickname));
        }

        while (true) {
            for (Jogador jogador : jogadores) {
                System.out.print(jogador.getNickname() + ", escolha o seu movimento (r/p/s): ");
                String jogada = scanner.next();
                jogador.setJogada(jogada);
            }

            boolean todasJogadasFeitas = false;
            while (!todasJogadasFeitas) {
                todasJogadasFeitas = true;
                for (Jogador jogador : jogadores) {
                    if (jogador.getJogada() == null) {
                        todasJogadasFeitas = false;
                        break;
                    }
                }
            }

            for (int i = 0; i < jogadores.size() - 1; i++) {
                Jogador jogadorI = jogadores.get(i);
                String jogada1 = jogadorI.getJogada();
                for (int j = i + 1; j < jogadores.size(); j++) {
                    Jogador jogadorJ = jogadores.get(j);
                    String jogada2 = jogadorJ.getJogada();
                    int resultado = verificaJogada(jogada1, jogada2);
                    jogadorI.atualizaScore(resultado);
                    jogadorJ.atualizaScore(resultado);
                }
            }

            System.out.println("Pontuações:");
            for (Jogador jogador : jogadores) {
                System.out.println(jogador.getNickname() + ": " + jogador.getPontos());
            }

            System.out.print("Deseja continuar jogando? (s/n): ");
            String escolha = scanner.next();
            if (escolha.equalsIgnoreCase("n")) {
                break;
            }

            for (Jogador jogador : jogadores) {
                jogador.setJogada(null);
            }
        }

        scanner.close();
    }

    private static int verificaJogada(String jogada1, String jogada2) {
        if (jogada1.equals(jogada2)) {
            return 1; // empate
        } else if ((jogada1.equals("r") && jogada2.equals("s"))
                || (jogada1.equals("p") && jogada2.equals("r"))
                || (jogada1.equals("s") && jogada2.equals("p"))) {
            return 2; // jogador 1 vence
        } else {
            return 3; // jogador 2 vence
        }
    }
}
