package com.mycompany.tcp;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

//Theodoro Bertol

public class ClienteTCP1 {

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 8081);

        ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());

        Pessoa pessoa = new Pessoa("Theo", 80, 180, 19, 0);
        System.out.println(pessoa.toString());
        saida.writeObject(pessoa);

        saida.close();
        socket.close();
    }
}
