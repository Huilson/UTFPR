package com.mycompany.tcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

//Theodoro Bertol

public class ServidorTCP {

    private static final int PORTA = 8081;

    public static void main(String[] args) {
        try {
            ServerSocket servidor = new ServerSocket(PORTA);
            System.out.println("Servidor rodando na porta " + PORTA);

            Socket socket = servidor.accept();
            System.out.printf("O cliente IP %s se conectou!\n", socket.getInetAddress().getHostAddress());

            EntityManagerFactory factory = Persistence.createEntityManagerFactory("servidorTcp");
            EntityManager em = factory.createEntityManager();

            ObjectInputStream entradaObj = new ObjectInputStream(socket.getInputStream());
            Pessoa pessoa = (Pessoa) entradaObj.readObject();

            Double imc = pessoa.getPeso() / Math.pow(pessoa.getAltura(), 2);
            pessoa.setImc(imc);

            em.getTransaction().begin();
            em.persist(pessoa);
            em.getTransaction().commit();

            Socket socketConsulta = servidor.accept();
            DataInputStream entradaStrm = new DataInputStream(socketConsulta.getInputStream());
            String nome = entradaStrm.readUTF();

            String jpql = "SELECT p FROM Pessoa p WHERE p.nome = :nome";
            List<Pessoa> pessoasFiltradas = em.createQuery(jpql, Pessoa.class)
                    .setParameter("nome", nome).getResultList();
            String mensagem = pessoasFiltradas.isEmpty() ?
                    "Nenhuma pessoa cadastrada com esse nome" :
                    "Nome: " + pessoasFiltradas.get(0).getNome() +
                            " IMC: " + pessoasFiltradas.get(0).getImc();

            DataOutputStream saidaStrm = new DataOutputStream(socketConsulta.getOutputStream());
            saidaStrm.writeUTF(mensagem);

            entradaObj.close();
            saidaStrm.close();
            em.close();
            socket.close();
            socketConsulta.close();
            servidor.close();
        } catch(IOException | ClassNotFoundException ex) {
            System.err.printf("Erro ao executar servidor: %s\n", ex.getMessage());
        }
    }
}
