package com.example.pagamentoms.model;

public enum StatusParcela {
    PAGO,
    EM_ABERTO
}
