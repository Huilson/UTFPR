package com.example.pagamentoms.model;

public enum StatusPagamento {
    PAGO,
    AGUARDANDO,
    CANCELADO

}
