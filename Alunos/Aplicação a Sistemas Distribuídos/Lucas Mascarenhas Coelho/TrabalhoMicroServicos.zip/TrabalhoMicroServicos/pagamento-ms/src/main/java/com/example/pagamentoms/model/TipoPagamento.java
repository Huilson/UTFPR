package com.example.pagamentoms.model;

public enum TipoPagamento {

    UNICA,
    PRAZO
}
