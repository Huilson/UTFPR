package com.example.pagamentoms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagamentoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
