package br.edu.utfpr.Estoque.controller;

import br.edu.utfpr.Estoque.dto.ProdutoDTO;
import br.edu.utfpr.Estoque.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequestMapping("/produto")
public class ProdutoController {

    @Autowired
    private ProdutoService service;

    //lista todos os produtos
    @GetMapping
    public List<ProdutoDTO> listar(){
        return service.buscaTodos();
    }

    //retorna um produto na busca
    @GetMapping("/{id}")
    public ResponseEntity<ProdutoDTO> buscar(@PathVariable @NotNull Long id) {
        ProdutoDTO dto = service.obterId(id);

        return ResponseEntity.ok(dto);
    }

    @PostMapping("/{id}") //este é o id do pedido
    public ResponseEntity<String> atualizarEstoque(@PathVariable @NotNull Long id) {
        String resultado;
        try {
            resultado = service.atualizarEstoque(id); //dependendo do status um método interno diferente é usado
            return ResponseEntity.ok(resultado);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}