package br.edu.utfpr.Estoque.repository;

import br.edu.utfpr.Estoque.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {

}
