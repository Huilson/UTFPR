package br.edu.utfpr.Estoque.model;

public enum Status {
    AGUARDANDO,
    CANCELADO,
    PAGO
}
