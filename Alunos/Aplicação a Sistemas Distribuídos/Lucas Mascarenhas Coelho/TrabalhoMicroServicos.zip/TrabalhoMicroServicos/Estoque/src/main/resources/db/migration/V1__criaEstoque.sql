CREATE TABLE produto(
    id SERIAL CONSTRAINT PK_PRODUTO PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    quantidade INTEGER NOT NULL,
    valor DECIMAL(10,2) NOT NULL
);

INSERT INTO produto VALUES(DEFAULT, 'tomate', 30, 5.00);
INSERT INTO produto VALUES(DEFAULT, 'coca cola', 55, 6.00);
INSERT INTO produto VALUES(DEFAULT, 'fanta laranja', 12, 4.00);
INSERT INTO produto VALUES(DEFAULT, 'café', 60, 8.00);
INSERT INTO produto VALUES(DEFAULT, 'sabonete', 150, 2.00);
INSERT INTO produto VALUES(DEFAULT, 'alface', 80, 2.00);
INSERT INTO produto VALUES(DEFAULT, 'desodorante', 200, 10.00);