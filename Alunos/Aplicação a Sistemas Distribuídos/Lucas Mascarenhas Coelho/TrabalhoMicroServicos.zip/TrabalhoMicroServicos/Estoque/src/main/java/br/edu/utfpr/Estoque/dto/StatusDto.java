package br.edu.utfpr.Estoque.dto;
import br.edu.utfpr.Estoque.model.Status;

import lombok.Data;

@Data
public class StatusDto {
    private Status status;
}
