package br.edu.utfpr.Estoque.dto;


import lombok.Data;

import java.time.LocalDateTime;
import br.edu.utfpr.Estoque.model.Status;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Data
public class PedidoDto {
    private Long id;
    private LocalDateTime datahora;
    private Status status;
    private String nome;
    private String sobrenome;
    private String cpf;
    private String email;
    private String telefone;
    private List<ItemPedidoDto> itens = new ArrayList<>();
}