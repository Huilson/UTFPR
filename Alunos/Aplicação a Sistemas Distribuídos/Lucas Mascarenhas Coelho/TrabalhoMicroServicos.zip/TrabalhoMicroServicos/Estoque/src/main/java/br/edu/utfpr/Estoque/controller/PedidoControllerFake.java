package br.edu.utfpr.Estoque.controller;

import br.edu.utfpr.Estoque.dto.PedidoDto;
import br.edu.utfpr.Estoque.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pedido")
public class PedidoControllerFake {

    @Autowired
    private ProdutoService service;

    //teste de endpoint para gerar um pedido fake com alguns itens
    @GetMapping("/3")
    public ResponseEntity<PedidoDto> buscarPedidoFake() {
        PedidoDto dto = service.montarPedidoFake(3L);
        return ResponseEntity.ok(dto);
    }

    //a service monta o pedido como o endpoint acima e valida com o banco do estoque
    //se é possível realizar a transação
    @GetMapping("/validar/3")
    public ResponseEntity<String> validarPedido() {
        String validacao = service.atualizarEstoqueFake(3L);

        return ResponseEntity.ok(validacao);
    }
}
