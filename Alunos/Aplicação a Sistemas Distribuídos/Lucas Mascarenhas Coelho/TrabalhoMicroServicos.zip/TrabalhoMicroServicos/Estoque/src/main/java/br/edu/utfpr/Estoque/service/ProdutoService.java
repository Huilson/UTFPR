package br.edu.utfpr.Estoque.service;

import br.edu.utfpr.Estoque.dto.ItemPedidoDto;
import br.edu.utfpr.Estoque.dto.PedidoDto;
import br.edu.utfpr.Estoque.dto.ProdutoDTO;
import br.edu.utfpr.Estoque.http.EstoqueHttp;
import br.edu.utfpr.Estoque.model.Produto;
import br.edu.utfpr.Estoque.model.Status;
import br.edu.utfpr.Estoque.repository.ProdutoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProdutoService {

    @Autowired
    EstoqueHttp pedido;

    @Autowired
    private ProdutoRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    public List<ProdutoDTO> buscaTodos() {
        return repository.findAll().stream().map(
                p -> modelMapper.map(p, ProdutoDTO.class)
        ).collect(Collectors.toList());
    }

    public ProdutoDTO obterId(Long id) {
        Produto produto = repository.findById(id)
                .orElseThrow(EntityNotFoundException::new);

        return modelMapper.map(produto, ProdutoDTO.class);
    }

    //atualizando quando o pedido estiver com status diferente de cancelado apenas
    //dar baixa no estoque somente
    public String atualizarEstoque(Long id) {

        PedidoDto pd = pedido.buscarPedido(id); //aqui vem os dados do pedido
        Produto produto;

        if (!pd.getStatus().equals(Status.CANCELADO)) {

            for (ItemPedidoDto item : pd.getItens()) {
                Long idProduto = item.getId_produto();
                Integer quantidadeProduto = item.getQuantidade(); //quantidade do produto presente no pedido

                Optional<Produto> produtoAux = repository.findById(idProduto);

                if (!produtoAux.isPresent()) { //se não houver produto com esse id retorna erro
                    throw new EntityNotFoundException("Produto: " + item.getDescricao() + " não encontrado");
                }

                produto = produtoAux.get();

                if (produto.getQuantidade() >= quantidadeProduto) {
                    produto.setQuantidade(produto.getQuantidade() - quantidadeProduto);
                    repository.save(produto);
                } else { //se a quantidade no pedido for maior que no banco
                    throw new IllegalArgumentException("Produto: " + produto.getNome() + " insuficiente");
                }
            }
            return "ok"; //retorna caso o estoque tenha sido atualizado com sucesso
        } else {
            return atualizarEstoqueEstorno(pd); //aqui entra caso o status do pedido seja CANCELADO
        }
    }

    //atualiza apenas quando o status é CANCELADO
    public String atualizarEstoqueEstorno(PedidoDto pd) {
        Produto produto;

        for (ItemPedidoDto item : pd.getItens()) {
            Long idProduto = item.getId_produto();
            Integer quantidadeProduto = item.getQuantidade(); //quantidade do produto presente no pedido

            Optional<Produto> produtoAux = repository.findById(idProduto);

            if (!produtoAux.isPresent()) { //se não houver produto com esse id retorna erro
                throw new EntityNotFoundException("Produto: " + item.getDescricao() + " não encontrado");
            }

            produto = produtoAux.get();
            produto.setQuantidade(produto.getQuantidade() + quantidadeProduto);
            repository.save(produto);
        }

        return "estornado"; //retorno caso o cancelamento ocorra com sucesso
    }



//======================================================================================================
//MÉTODOS PARA PEDIDO FAKE

    //montando um pedido com status realizado(aguardando pagamento ou ser cancelado)
    public PedidoDto montarPedidoFake(Long id) {
        PedidoDto pedido = new PedidoDto();
        List<ItemPedidoDto> listaItens = new ArrayList<>();


        for (int i = 1; i <= 4; i++) {
            ItemPedidoDto itemPedido = new ItemPedidoDto();
            itemPedido.setId((long) i);
            itemPedido.setDescricao("Testando");
            itemPedido.setQuantidade((int) Math.floor(Math.random() * 6 + 1));
            listaItens.add(itemPedido);
        }

        pedido.setId(id);
        pedido.setStatus(Status.AGUARDANDO);
        pedido.setDatahora(LocalDateTime.now());
        pedido.setItens(listaItens);

        return pedido;
    }

    public String atualizarEstoqueFake(Long id) {
        PedidoDto pd = montarPedidoFake(id); //aqui vem os dados do pedidoFake
        Produto produto;

        if (!pd.getStatus().equals(Status.CANCELADO)) {

            for (ItemPedidoDto item : pd.getItens()) {
                Long idProduto = item.getId();
                Integer quantidadeProduto = item.getQuantidade(); //quantidade do produto presente no pedido

                Optional<Produto> produtoAux = repository.findById(idProduto);

                if (!produtoAux.isPresent()) { //se não houver produto com esse id retorna erro
                    throw new EntityNotFoundException("Produto: " + item.getDescricao() + " não encontrado");
                }

                produto = produtoAux.get();

                if (produto.getQuantidade() >= quantidadeProduto) {
                    produto.setQuantidade(produto.getQuantidade() - quantidadeProduto);
                    repository.save(produto);
                } else { //se a quantidade no pedido for maior que no banco
                    throw new IllegalArgumentException("Produto: " + produto.getNome() + " insuficiente");
                }
            }
            return "ok"; //retorna caso o estoque tenha sido atualizado com sucesso
        } else {
            return atualizarEstoqueEstornoFake(pd); //aqui entra caso o status do pedido seja CANCELADO
        }
    }

    private String atualizarEstoqueEstornoFake(PedidoDto pd) {
        Produto produto;

        for (ItemPedidoDto item : pd.getItens()) {
            Long idProduto = item.getId();
            Integer quantidadeProduto = item.getQuantidade(); //quantidade do produto presente no pedido

            Optional<Produto> produtoAux = repository.findById(idProduto);

            if (!produtoAux.isPresent()) { //se não houver produto com esse id retorna erro
                throw new EntityNotFoundException("Produto: " + item.getDescricao() + " não encontrado");
            }

            produto = produtoAux.get();
            produto.setQuantidade(produto.getQuantidade() + quantidadeProduto);
            repository.save(produto);
        }

        return "estornado"; //retorno caso o cancelamento ocorra com sucesso
    }
//======================================================================================================
}
