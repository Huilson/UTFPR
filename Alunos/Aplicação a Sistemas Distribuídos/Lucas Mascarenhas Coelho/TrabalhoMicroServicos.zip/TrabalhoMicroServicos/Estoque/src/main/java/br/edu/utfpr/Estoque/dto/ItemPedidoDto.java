package br.edu.utfpr.Estoque.dto;

import lombok.Data;

@Data
public class ItemPedidoDto {
    private Long id;
    private String descricao;
    private Integer quantidade;
    private Double valor;
    private Long id_produto;
}
