package br.edu.utfpr.pedido.http;

import br.edu.utfpr.pedido.dto.PagamentoDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient("pagamento-v1")
public interface PagamentoHttp {
    @PostMapping("/pagamento")
    void gerarPagamento(@RequestBody PagamentoDto pagamento);
}
