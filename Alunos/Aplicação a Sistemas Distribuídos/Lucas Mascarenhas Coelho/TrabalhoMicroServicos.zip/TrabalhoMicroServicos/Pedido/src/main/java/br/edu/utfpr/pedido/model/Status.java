package br.edu.utfpr.pedido.model;

public enum Status {
    AGUARDANDO,
    CANCELADO,
    PAGO
}
