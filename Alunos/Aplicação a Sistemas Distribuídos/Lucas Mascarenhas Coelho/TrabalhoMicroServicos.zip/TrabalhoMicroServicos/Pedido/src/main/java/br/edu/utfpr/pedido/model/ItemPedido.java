package br.edu.utfpr.pedido.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ItemPedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String descricao;

    @NotNull
    @Positive
    private Integer quantidade;

    @ManyToOne(optional = false)
    private Pedido pedido;

    @NotNull
    @Positive
    private Double valor;

    @NotNull
    @Positive
    private Long id_produto;
}
