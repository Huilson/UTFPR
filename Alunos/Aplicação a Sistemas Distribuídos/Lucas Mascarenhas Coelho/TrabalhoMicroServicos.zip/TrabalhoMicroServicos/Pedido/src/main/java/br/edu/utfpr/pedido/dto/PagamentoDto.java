package br.edu.utfpr.pedido.dto;

import lombok.Data;

@Data
public class PagamentoDto {

    private String formaPagamento;
    private Double valor;
    private String numero;
    private String expiracao;
    private String codigo;
    private Long idPedido;
    private String nome;
    private Integer qtdParcelas;

}