package aulatcp;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class TCPClient {
	

	public static void main(String[] args ) throws IOException, ClassNotFoundException{
		
		Pessoa p1 = new Pessoa();
		p1.setId(0);
		p1.setNome("Antonio");
		p1.setAltura(1.70);
		p1.setIdade(25);
		p1.setPeso(82);

		Pessoa p2 = new Pessoa();
		p2.setId(0);
		p2.setNome("Carlos");
		p2.setAltura(1.10);
		p2.setIdade(29);
		p2.setPeso(92);
		
		System.out.println("\nCadastrando: " + p1.getNome());
		sendObject(p1);
		System.out.println("\nCadastrando: " + p1.getNome());
		sendObject(p1);
		
		System.out.println("\nCadastrando: " + p2.getNome());
		sendObject(p2);
		
		Pessoa p3 = new Pessoa();
		p3.setId(-1);
		p3.setNome("Antonio");
		
		System.out.println("\nBuscando pessoa com nome: "+ p3.getNome());
		buscaPessoa(p3);
		
		Pessoa p4 = new Pessoa();
		p4.setId(-1);
		p4.setNome("Antonio2");
		
		System.out.println("\nBuscando pessoa com nome: "+ p4.getNome());
		buscaPessoa(p4);
		
	}
	
	static void sendObject(Pessoa item) throws IOException, ClassNotFoundException {
		Socket socketClient = new Socket("127.0.0.1", 9000);
		
		ObjectOutputStream outputStream = new ObjectOutputStream(socketClient.getOutputStream());
		ObjectInputStream inputStream = new ObjectInputStream(socketClient.getInputStream());
		
		outputStream.writeObject(item);
		
		String novaMensagem = (String) inputStream.readObject();
		System.out.println(novaMensagem);
		
		outputStream.close();
		inputStream.close();
		socketClient.close();
		
	}
	
	static void buscaPessoa(Pessoa item) throws IOException, ClassNotFoundException {
		
		Socket socketClient = new Socket("127.0.0.1", 9000);
		
		ObjectOutputStream outputStream = new ObjectOutputStream(socketClient.getOutputStream());
		ObjectInputStream inputStream = new ObjectInputStream(socketClient.getInputStream());
		
		outputStream.writeObject(item);
		
		Pessoa resposta = (Pessoa) inputStream.readObject();
		if(resposta != null && resposta.getNome() != null) {
			System.out.println("Nome da pessoa: " + resposta.getNome() + "\nIMC: " + resposta.getImc());
		}else {
			System.out.println("Pessoa não encontrada");
		}
		
		outputStream.close();
		inputStream.close();
		socketClient.close();
		
		
	}

}
