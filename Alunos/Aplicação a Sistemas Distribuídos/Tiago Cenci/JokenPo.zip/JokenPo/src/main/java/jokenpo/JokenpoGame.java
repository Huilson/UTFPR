package jokenpo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//teste

/**
 *
 * @author 55469
 */
public class JokenpoGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Jogador> jogadores = new ArrayList<>();

        // solicitar o número de jogadores
        System.out.print("Digite o número de jogadores: ");
        int numeroJogadores = scanner.nextInt();

        // solicitar o nickname de cada jogador
        for (int i = 0; i < numeroJogadores; i++) {
            System.out.print("Digite o nickname do jogador " + (i + 1) + ": ");
            String nickname = scanner.next();
            jogadores.add(new Jogador(nickname));
        }

        // iniciar o jogo
        while (true) {
            // solicitar o movimento de cada jogador
            for (Jogador jogador : jogadores) {
                System.out.print(jogador.getNickname() + ", escolha o seu movimento (r/p/s): ");
                String jogada = scanner.next();
                jogador.setJogada(jogada);
            }

            // aguardar todos os jogadores escolherem um movimento
            boolean todasJogadasFeitas = false;
            while (!todasJogadasFeitas) {
                todasJogadasFeitas = true;
                for (Jogador jogador : jogadores) {
                    if (jogador.getJogada() == null) {
                        todasJogadasFeitas = false;
                    }
                }
            }

            for (int i = 0; i < jogadores.size(); i++) {
                Jogador jogadorI = jogadores.get(i);
                String jogada1 = jogadorI.getJogada();
                for (int j = i + 1; j < jogadores.size(); j++) {
                    Jogador jogadorJ = jogadores.get(j);
                    String jogada2 = jogadorJ.getJogada();
                    if (jogada1.equals(jogada2)) {
                        // empate
                        jogadorI.atualizaScore(1);
                        jogadorJ.atualizaScore(1);
                    } else if ((jogada1.equals("r") && jogada2.equals("s"))
                            || (jogada1.equals("p") && jogada2.equals("r"))
                            || (jogada1.equals("s") && jogada2.equals("p"))) {
                        // jogador 1 vence
                        jogadorI.atualizaScore(2);
                    } else {
                        // jogador 2 vence
                        jogadorJ.atualizaScore(2);
                    }
                }
            }
            // exibir as pontuações atualizadas
            System.out.println("Pontuações:");
            for (Jogador jogador : jogadores) {
                System.out.println(jogador.getNickname() + ": " + jogador.getPontos());
            }

            // perguntar se os jogadores querem continuar jogando
            System.out.print("Deseja continuar jogando? (s/n): ");
            String escolha = scanner.next();
            if (escolha.equals("n")) {
                break;
            }

            // resetar os movimentos dos jogadores
            for (Jogador jogador : jogadores) {
                jogador.setJogada(null);
            }
        }

        scanner.close();
    }
}
