package com.mycompany.tcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClienteTCP2 {

    public static void main(String[] args) throws IOException {
        Socket socket2 = new Socket("127.0.0.1", 8081);

        DataOutputStream saida = new DataOutputStream(socket2.getOutputStream());
        String nome = "Tiago";
        saida.writeUTF(nome);

        DataInputStream entrada2 = new DataInputStream(socket2.getInputStream());
        String nomeImc = entrada2.readUTF();

        System.out.println(nomeImc);

        entrada2.close();
        saida.close();

        socket2.close();

    }

}
