package com.mycompany.tcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ServidorTCP {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ServerSocket servidor = new ServerSocket(8081);//Cria servidor com a porta 8081
        System.out.println("Servidor rodando na porta 8081");

        Socket socket = servidor.accept();//cliente socket conecta no servidor
        System.out.println("O cliente IP " + socket.getInetAddress().getHostAddress() + " se conectou!");

        ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());

        Pessoa pessoa = (Pessoa) entrada.readObject();

        pessoa.setImc(pessoa.getPeso() / pessoa.getAltura() * pessoa.getAltura());

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("servidorTcp");
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        em.persist(pessoa);
        em.getTransaction().commit();

        Socket socket2 = servidor.accept();
        DataInputStream entrada2 = new DataInputStream(socket2.getInputStream());
        String nome = entrada2.readUTF();

        String jpql = "SELECT p FROM Pessoa p WHERE p.nome = :nome";
        List<Pessoa> pessoasFiltradas = em.createQuery(jpql, Pessoa.class).setParameter("nome", nome).getResultList();

        String nomeImc = "Nome: " + pessoasFiltradas.get(0).getNome() + " IMC: " + pessoasFiltradas.get(0).getImc();

        DataOutputStream saida = new DataOutputStream(socket2.getOutputStream());
        saida.writeUTF(nomeImc);
        entrada.close();
        saida.close();
        em.close();
        socket.close();
        socket2.close();
        servidor.close();

    }
}
