import lombok.Data;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public @Data class ServerSideConnection implements Runnable {

    private static final int ROCK = 1;
    private static final int PAPER = 2;
    private static final int SCISSORS = 3;
    private static final String SERVER = "SERVER";

    public static Vector<ServerSideConnection> players = new Vector<>();

    private Socket socket;
    private ObjectInputStream dataIn;
    private ObjectOutputStream dataOut;
    private String playerID;
    private Integer score;
    private List<Integer> choices;
    private Boolean alreadyPlayed;
    private Boolean isInGame;

    /*
     Classe que representa a conexão do socket pelo lado do servidor.
     É utilizada uma instância para cada jogador conectado.
     */
    public ServerSideConnection(Socket s, String id) {
        try {
            this.socket = s;
            this.playerID = id;
            this.dataOut = new ObjectOutputStream(socket.getOutputStream());
            this.dataIn = new ObjectInputStream(socket.getInputStream());

            choices = new ArrayList<>();

            score = 0;
            alreadyPlayed = false;
            isInGame = true;

            players.add(this);
        } catch (IOException e) {
            System.out.println("IOException from SSC constructor");
        }
    }

    @Override
    public void run() {
        try {
            //Envia ID novo player
            dataOut.writeObject(playerID);
            dataOut.flush();

            while (true) {
                if (enoughPlayers()) {
                    DataObject dataObject = new DataObject(SERVER, playerID);
                    dataObject.setTipo(3);
                    dataObject.setStr("Iniciando jogo!");
                    dataOut.writeObject(dataObject);
                    dataOut.flush();

                    if (!alreadyPlayed) {
                        DataObject choice = (DataObject) dataIn.readObject();
                        choices.add(choice.getValue());
                        alreadyPlayed = true;

                    } else{
                        if (verifyRoundEnded()) {
                            System.out.println("Start new round");
                            //startNewRound();
                        } else {
                            Thread.sleep(200);
                        }
                    }
                } else {
                    System.out.println("Quantidade de player insuficiente para comecar partida");
                    DataObject statusPlayer = new DataObject(SERVER, playerID);
                    statusPlayer.setTipo(2);
                    dataOut.writeObject(statusPlayer);
                    dataOut.flush();
                    choices = new ArrayList<>();
                    Thread.sleep(100);
                }
            }

        } catch (IOException e) {
            System.out.println("Jogador #" + playerID + " saiu");
            isInGame = false;
            System.out.println("IOException from run() SSC");
            closeConnection();
        } catch (ClassNotFoundException e) {
            isInGame = false;
            System.out.println("ClassNotFoundException from run() SSC");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    Verifica se todos os jogadores finalizaram a jogada na rodada atual
     */
    synchronized public boolean verifyRoundEnded() {
        if(alreadyPlayed) {
            for (ServerSideConnection player : players) {
                if (!player.alreadyPlayed && player.isInGame) {
                    return false;
                }
            }

            for (ServerSideConnection player : players) {
                if (player.isInGame) {
                    player.alreadyPlayed = false;
                }
            }

            startNewRound();
            getRoundBalance();
            refreshScores();
            return true;
        }

        return false;
    }

    /*
    Verifica se existem jogadores suficientes para início de uma partida
     */
    synchronized public boolean enoughPlayers() {
        int playersOnline = 0;
        for (ServerSideConnection player : players) {
            System.out.println(player.playerID);
            if (player.isInGame) {
                playersOnline++;
            }

            if (playersOnline > 1) {
                return true;
            }
        }

        return false;
    }

    /*
    Calcula o score de cada jogador separadamente, atualizando por rodada
     */
    public void getRoundBalance() {
        for (ServerSideConnection player : players) {
            if (player.getIsInGame()) {

                for (ServerSideConnection playerComp : players) {
                    if (playerComp.getIsInGame()) {
                        if (player.getLastChoice() == ROCK) {
                            if (playerComp.getLastChoice() == SCISSORS) {
                                player.addScore(1);
                            }
                            /* Decrementa 1 caso o jogador perca a jogada
                            else{
                                player.decScore(1);
                            }

                             */
                        } else if (player.getLastChoice() == PAPER) {
                            if (playerComp.getLastChoice() == ROCK) {
                                player.addScore(1);
                            }
                        } else if (player.getLastChoice() == SCISSORS) {
                            if (playerComp.getLastChoice() == PAPER) {
                                player.addScore(1);
                            }
                        }
                    }
                }
            }

        }
    }

    /*
    Seleciona valor da última jogada de um jogador
     */
    public int getLastChoice() {
        return choices.get(choices.size() - 1);
    }

    /*
    Adiciona o valor passado por parametro a váriavel score
     */
    public void addScore(int score) {
        this.score += score;
    }

    /*
    Decrementa o valor passado por parametro a váriavel score
     */
    public void decScore(int score) {
        this.score -= score;
    }

    /*
    Envia os dados passados por parametro ao socket conectado.
     */
    synchronized public void sendData(DataObject dataObject) {
        try {
            dataOut.writeObject(dataObject);
            dataOut.flush();
        } catch (IOException err) {
            System.out.println("IOException from sendData() ssc");
        }
    }

    /*
    Envia o score atualizado a cada um dos jogadores da partida
     */
    synchronized public void refreshScores() {
        for (ServerSideConnection player : players) {
            if (player.getIsInGame()) {
                String results = getScores(player.getPlayerID());
                System.out.println(results);
                DataObject sendScores = new DataObject(SERVER, player.getPlayerID());
                sendScores.setTipo(0);
                sendScores.setStr(results);
                player.sendData(sendScores);
            }
        }

    }

    /*
    Inicia uma nova rodada na partida
     */
    synchronized public void startNewRound() {
        for (ServerSideConnection player : players) {
            if (player.getIsInGame()) {
                DataObject startNewRoundObject = new DataObject(SERVER, player.getPlayerID());
                startNewRoundObject.setTipo(1);
                player.alreadyPlayed = false;
                player.sendData(startNewRoundObject);
            }
        }
    }

    /*
    Formata o placar de forma personalizada para cada jogador utilizando o parametro passado na função
     */
    public String getScores(String pID) {
        String res = "";
        int playerScore = 0;
        for (ServerSideConnection player : players) {
            if (player.getIsInGame()) {
                if (player.getPlayerID().equals(pID)) {
                    playerScore = player.getScore();
                }
                res += player.getPlayerID() + ": " + player.getScore() + "\n";
            }
        }
        res += "\n Meu score: " + playerScore;

        return res;
    }

    /*
    Fecha a conexão com um jogador
     */
    public void closeConnection() {
        try {
            isInGame = false;
            if (socket != null) {
                socket.close();
            }
            if (dataIn != null) {
                dataIn.close();
            }
            if (dataOut != null) {
                dataOut.close();
            }

            System.out.println("PlayerID: " + playerID + " | Connection closed");
        } catch (IOException err) {
            System.out.println("IOException on closeConnection() SSC");
        }
    }

}