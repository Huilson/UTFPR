import lombok.Data;

import java.io.Serializable;
import java.util.UUID;

public @Data class DataObject implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    private String sender;

    private String receiver;

    private int tipo;

    private int value;

    private String str;

    public DataObject(String _sender, String _receiver) {
        id = UUID.randomUUID().toString();
        this.sender = _sender;
        this.receiver = _receiver;

        this.value = -1;
        this.str = "";
    }
}
