import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Objects;

public class Player extends JFrame {

    private static final long serialVersionUID = 1L;
    private int height;
    private int width;
    private Container contentPane;
    private JTextArea message;
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private String playerID;
    private boolean buttonsEnabled;

    private static ClientSideConnection csc;

    public Player(int w, int h) {
        height = h;
        width = w;
        contentPane = this.getContentPane();
        message = new JTextArea();
        b1 = new JButton();
        b1.setName("1");
        ImageIcon iconB1 = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("rock.png")));
        iconB1 = ResizeIcon(iconB1, 50, 50);
        b1.setIcon(iconB1);
        b1.setBackground(Color.WHITE);

        b2 = new JButton();
        b2.setName("2");
        ImageIcon iconB2 = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("paper.png")));
        iconB2 = ResizeIcon(iconB2, 50, 50);
        b2.setIcon(iconB2);
        b2.setBackground(Color.WHITE);


        b3 = new JButton();
        b3.setName("3");
        ImageIcon iconB3 = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("scissor.png")));
        iconB3 = ResizeIcon(iconB3, 50, 50);
        b3.setIcon(iconB3);
        b3.setBackground(Color.WHITE);

    }

    /*
    Inicia interface gráfica do modo jogador
     */
    public void setupGUI() {
        this.setSize(width, height);
        this.setTitle("Player #" + playerID);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane.setLayout(new GridLayout(1, 5));
        contentPane.add(message);
        message.setWrapStyleWord(true);
        message.setLineWrap(true);
        message.setEditable(false);
        contentPane.add(b1);
        contentPane.add(b2);
        contentPane.add(b3);

        message.setText("Iniciando o jogo!");
        buttonsEnabled = true;

        this.setVisible(true);

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (csc != null) {
                    csc.closeConnection();
                }
            }
        });
    }

    /*
    Redimenciona imagem para tamanho passado por parametro
     */
    private ImageIcon ResizeIcon(ImageIcon icon, int height, int width) {
        Image image = icon.getImage(); // transform it
        Image newimg = image.getScaledInstance(height, width, java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(newimg);
    }

    /*
    Realiza a conexão inicial do jogador
     */
    public void connectToServer() {
        csc = new ClientSideConnection();
    }

    /*
    Inicia funções dos botões da interface gráfica
     */
    public void setupButtons() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                int bNum = Integer.parseInt(b.getName());

                buttonsEnabled = false;
                toggleButtons();

                csc.sendButtonNum(bNum);
            }
        };

        b1.addActionListener(al);
        b2.addActionListener(al);
        b3.addActionListener(al);
    }

    /*
    Alterna o status dos botões da interface entre habilitado e desabilitado
     */
    public void toggleButtons() {
        b1.setEnabled(buttonsEnabled);
        b2.setEnabled(buttonsEnabled);
        b3.setEnabled(buttonsEnabled);
    }

    /*
    Classe responsável pela conexão pelo lado do cliente.
     */
    private class ClientSideConnection implements Runnable {

        private Socket socket;
        private ObjectInputStream dataIn;
        private ObjectOutputStream dataOut;

        public ClientSideConnection() {
            System.out.println("---New Client---");
            try {
                socket = new Socket("localhost", 51734);
                dataIn = new ObjectInputStream(socket.getInputStream());
                dataOut = new ObjectOutputStream(socket.getOutputStream());

                playerID = (String) dataIn.readObject();
                System.out.println("Connected to server as Player #" + playerID + ".");

            } catch (IOException e) {
                System.out.println("IOException from CSC constructor");
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

            new Thread(this).start();
        }


        @Override
        public void run() {
            DataObject dataObject;
            try {
                if (!socket.isClosed()) {

                    while (!socket.isClosed()) {
                        dataObject = (DataObject) dataIn.readObject();
                        System.out.println(dataObject);
                        System.out.println(dataObject.getTipo() == 1);
                        if (dataObject != null) {
                            //TYPE=0 -> Atualizar Players Scoreboard
                            if (dataObject.getTipo() == 0) {
                                if (!dataObject.getStr().equals("")) {
                                    message.setText("\t     PLACAR\n" + "\n" + dataObject.getStr());

                                }

                                //TYPE=1 -> Habilitar nova jogada
                            } else if (dataObject.getTipo() == 1) {
                                buttonsEnabled = true;
                                toggleButtons();

                            } else if (dataObject.getTipo() == 2) {
                                buttonsEnabled = false;
                                toggleButtons();
                                message.setText("Aguardando players para inicio da partida");

                                while (dataObject.getTipo() != 3) {
                                    Thread.sleep(100);
                                    dataObject = (DataObject) dataIn.readObject();
                                }
                                if (dataObject.getTipo() == 3) {
                                    message.setText(dataObject.getStr());
                                    buttonsEnabled = true;
                                    toggleButtons();
                                }
                            }
                        }

                    }

                }
            } catch (IOException err) {
                System.out.println("Thread Client - Socket error message: " + err.getMessage());
            } catch (ClassNotFoundException e) {
                System.out.println("Thread Client - Error parsing dataObject");
                System.out.println(e.getMessage());
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        }

        /*
        Envia os dados das jogadas para o servidor
         */
        public void sendButtonNum(int n) {
            try {
                DataObject dataObject = new DataObject(playerID, "SERVER");
                dataObject.setTipo(1);
                dataObject.setValue(n);
                dataOut.writeObject(dataObject);
                dataOut.flush();
            } catch (IOException er) {
                System.out.println("IOException form CSC sendButtonNum");
            }
        }

        /*
        Finaliza conexão entre o jogador e o servidor
         */
        public void closeConnection() {
            try {
                if (socket != null) {
                    socket.close();
                }
                System.out.println("---CONNECTION CLOSED ----");

            } catch (IOException err) {
                System.out.println("IOException on closeConnection() CSC");
            }
        }


    }

    public static void main(String[] args) {
        Player p = new Player(1200, 200);
        p.connectToServer();
        p.setupGUI();
        p.setupButtons();
    }


}
