import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GameServer {

    private ServerSocket ss;

    private static List<ServerSideConnection> players = new ArrayList<>();

    public GameServer() {
        try {
            ss = new ServerSocket(51734);
        } catch (IOException err) {
            System.out.println("IOException from GameServer Constructor");
        }
    }

    /*
    SocketServer entra em loop esperando novas conexões
     */
    public void acceptConnections() {
        try {
            System.out.println("Waiting for connections...");
            while (!ss.isClosed()) {
                Socket s = ss.accept();

                String userID = UUID.randomUUID().toString();

                ServerSideConnection player = new ServerSideConnection(s, userID);

                System.out.println("Player connected: " + userID);

                new Thread(player).start();

                players.add(player);
            }

        } catch (IOException err) {
            System.out.println("IOException from acceptConnections()");
        }
    }

    public static void main(String[] args) {
        GameServer gs = new GameServer();
        gs.acceptConnections();
    }

}
