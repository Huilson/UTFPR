package br.com.utfpr.sistemasdistribuidos.JokenpoProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import br.com.utfpr.sistemasdistribuidos.JokenpoProject.model.Player;

public class App {

	private static final int ROCK = 1;
	private static final int PAPER = 2;
	private static final int SCISSORS = 3;
	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Welcome to Jokempo!");

		// Get number of players
		System.out.print("Enter number of players: ");
		int numPlayers = scanner.nextInt();

		// Create list of players
		List<Player> players = new ArrayList<>();
		for (int i = 1; i <= numPlayers; i++) {
			addPlayer(players);
		}

		int roundNumber = 1;
		while (true) {
			System.out.println("\nRound " + roundNumber + " begins!");
			for (Player player: players) {
				if (!enoughPlayersInGame(players)) {
					System.out.println("Game over - all other players have left.");
					return;
				}
				if (player.isInGame()) {
					int choice = 0;
					do{
						System.out.print(player.getName() + ", choose (1=Rock, 2=Paper, 3=Scissors, 9=Leave the game): ");
						choice = scanner.nextInt();
						if(choice == 9){
							player.setInGame(false);
							System.out.println(player.getName() + " has left the game.");
						} else if( choice == 1 || choice == 2 || choice == 3) {
							player.addChoice(choice);
						}else {
							System.out.println("Choose a valid option!");
						}
					} while(choice != 1 && choice != 2 && choice != 3 && choice != 9);

				}
			}

			if (!enoughPlayersInGame(players)) {
				System.out.println("Game over - all other players have left.");
				return;
			}

			getRoundBalance(players);
			System.out.println();
			// Show players scores at the end of each round
			for (Player player : players) {
				if (player.isInGame()) {
					System.out.println(player.getName() + " score: " + player.getScore());
				}
			}

			System.out.println("\nAdd new player to the game?\nY - Add \nC - Continue");
			String res = scanner.next();
			if(res.equalsIgnoreCase("y")){
				addPlayer(players);
			}

			roundNumber++;
		}
	}

	public static void getRoundBalance(List<Player> players) {
		for (Player playerAtual : players) {
			if(playerAtual.isInGame()){

				for(Player playerComp : players){
					if(playerComp.isInGame()){
						if(playerAtual.getLastChoice() == ROCK){
							if(playerComp.getLastChoice() == SCISSORS) {
								playerAtual.addScore(1);
							}
						} else if(playerAtual.getLastChoice() == PAPER){
							if(playerComp.getLastChoice() == ROCK) {
								playerAtual.addScore(1);
							}
						} else if(playerAtual.getLastChoice() == SCISSORS){
							if(playerComp.getLastChoice() == PAPER) {
								playerAtual.addScore(1);
							}
						}
					}
				}
			}

		}
	}

	public static boolean enoughPlayersInGame(List<Player> players){
		int playersInGame = 0;
		for (Player player : players){
			if(player.isInGame()){
				playersInGame += 1;
			}
		}
		return playersInGame >= 2;
	}

	static void addPlayer(List<Player> listPlayer){
		System.out.print("Enter name for player " + (listPlayer.size()+1) + ": ");
		String name = scanner.next();
		while(checkIfPlayerExists( listPlayer, name)){
			System.out.println("Player already used! Choose another one: ");
			name = scanner.next();
		}
		Player p = new Player(name);
		listPlayer.add(p);
		System.out.println("Player: " + p.getName() + " joined!");
	}

	static boolean checkIfPlayerExists(List<Player> lstPlayer, String name){
		Player player = lstPlayer.stream().filter(x -> name.equals(x.getName())).findAny().orElse(null);
		return player != null;
	}

}
