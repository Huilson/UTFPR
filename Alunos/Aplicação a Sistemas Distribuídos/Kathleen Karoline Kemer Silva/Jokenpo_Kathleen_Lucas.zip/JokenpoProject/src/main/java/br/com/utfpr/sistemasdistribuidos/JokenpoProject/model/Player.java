package br.com.utfpr.sistemasdistribuidos.JokenpoProject.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public @Data class Player {
	private String id;
	private String name;
	private Integer score;
	private List<Integer> choices;
	private boolean inGame;

	public Player(String _name) {
		this.id = UUID.randomUUID().toString();
		this.name = _name;
		this.score = 0;
		this.choices = new ArrayList<>();
		this.inGame = true;
	}

	public void addScore(int score) {
		this.score += score;
	}

	public void decScore(int score) { this.score -= score; }

	public void addChoice(int choice) {
		choices.add(choice);
	}

	public int getLastChoice() {
		return choices.get(choices.size() - 1);
	}

	public boolean isInGame() {
		return inGame;
	}
}
