package atividade_imc;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class clienteTCPBusca {

	
	public static void main(String[] args ) throws IOException, ClassNotFoundException{
		
		Socket socketClient = new Socket("127.0.0.1", 9000);

		Pessoa p1 = new Pessoa();
		p1.setId(-1);
		p1.setNome("Júlia");
//		p1.setAltura(1.80);
//		p1.setIdade(30);
//		p1.setPeso(90);
		
		ObjectOutputStream output = new ObjectOutputStream(socketClient.getOutputStream());
		output.writeObject(p1);
		
		ObjectInputStream input = new ObjectInputStream(socketClient.getInputStream());
		Pessoa resposta = (Pessoa) input.readObject();
		if(resposta != null && resposta.getNome() != null) {
			System.out.println("Pessoa: " + resposta.getNome() + "\nE seu IMC é: " + resposta.getImc());
		}else {
			System.out.println("Pessoa ");
		}
		
		
		output.close();
		input.close();
		socketClient.close();
	}
}
