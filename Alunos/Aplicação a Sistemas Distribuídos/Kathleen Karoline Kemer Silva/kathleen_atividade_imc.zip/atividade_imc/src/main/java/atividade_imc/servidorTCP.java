package atividade_imc;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class servidorTCP  {
	
	public static void main(String[] args ) throws IOException, ClassNotFoundException{
		
		List<Pessoa> lstPessoa = new ArrayList<Pessoa>();
		
		ServerSocket servidor = new ServerSocket(9000);
		
		System.out.println("Server rodando na porta 9000");
		
		while(true) {
			Socket socket = servidor.accept();
			
			System.out.println("O cliente com IP: "+socket.getInetAddress()+ " se conectou " + socket.getPort());
			
			ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
			
			
			Pessoa pessoa = (Pessoa) input.readObject();
			
			if(pessoa.getId() == 0) {
				
				if( !checkPessoaExists(lstPessoa, pessoa.getNome())   ) {
					
					Double imc = pessoa.getPeso() / (pessoa.getAltura()*pessoa.getAltura());
					pessoa.setImc( imc );
					
					lstPessoa.add(pessoa);
					
					System.out.println(lstPessoa.size());
					for(Pessoa pp : lstPessoa) {
						System.out.println(pp.getNome());
					}
					output.writeObject("Pessoa adicionada com sucesso!");
				} else {
					output.writeObject("Pessoa já cadastrada!");
				}
				
			} else if(pessoa.getId() == -1) {
				Pessoa p = null;
				for(Pessoa item: lstPessoa) {
					if(item.getNome().equals(pessoa.getNome())) {
						p = item;
					}
				}
				output.writeObject(p);
			} else if (pessoa.getId() == -1234567) {
				servidor.close();
			}
			
			
			input.close();
			output.close();
			socket.close();
		}
		
		
	}
	
	public static boolean checkPessoaExists(final List<Pessoa> list, final String name){
		boolean pessoaExists = false;
		for(Pessoa item: list) {
			if( item.getNome().equals(name) ) {
				pessoaExists = true;
			}
		}
		return pessoaExists;
	}

}
