package atividade_imc;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class clienteTCP {
	

	public static void main(String[] args ) throws IOException, ClassNotFoundException{
		
		Socket socketClient = new Socket("127.0.0.1", 9000);
		
		ObjectOutputStream outputStream = new ObjectOutputStream(socketClient.getOutputStream());
		ObjectInputStream inputStream = new ObjectInputStream(socketClient.getInputStream());
		
		Pessoa p1 = new Pessoa();
		p1.setId(0);
		p1.setNome("Júlia");
		p1.setAltura(1.80);
		p1.setIdade(30);
		p1.setPeso(90);
		
		outputStream.writeObject(p1);
		
		String novaMensagem = (String) inputStream.readObject();
		System.out.println(novaMensagem);
		
		
		outputStream.close();
		inputStream.close();
		socketClient.close();	
	}


}
