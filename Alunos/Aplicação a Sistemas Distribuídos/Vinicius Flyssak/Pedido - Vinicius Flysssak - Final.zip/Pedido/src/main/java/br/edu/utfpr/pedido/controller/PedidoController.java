package br.edu.utfpr.pedido.controller;

import br.edu.utfpr.pedido.dto.ItemPedidoDto;
import br.edu.utfpr.pedido.dto.PedidoDto;
import br.edu.utfpr.pedido.dto.StatusDto;
import br.edu.utfpr.pedido.service.PedidoService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.validation.constraints.*;
import javax.validation.Valid;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/pedido")
public class PedidoController {

    @Autowired
    private PedidoService service;

    @GetMapping
    public List<PedidoDto> listar(){
        return service.buscaTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PedidoDto> buscar(@PathVariable @NotNull Long id){
        PedidoDto dto = service.obterId(id);
        return ResponseEntity.ok(dto);
    }

    @PostMapping()
    public ResponseEntity<PedidoDto> realizaPedido(@RequestBody @Valid PedidoDto dto, UriComponentsBuilder uri){
        try {
            dto.getItens().forEach(item -> item.setDescricao(service.buscaProdutoEstoque(item))); //busca nome e valida quantidade
            PedidoDto pedidoDto = service.criarPedido(dto);
            URI endereco = uri.path("/pedido/{id}").buildAndExpand(pedidoDto.getId()).toUri();
            ResponseEntity<PedidoDto> result = ResponseEntity.created(endereco).body(pedidoDto);
            service.gerarPagamento(Objects.requireNonNull(result.getBody()));
            return ResponseEntity.ok(pedidoDto);
        }catch (Exception e){
            throw new RuntimeException(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<PedidoDto> atualizarStatus(@PathVariable Long id, StatusDto status){
        PedidoDto dto = service.atualizarStatus(id, status);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}/pago")
    public ResponseEntity<Void> aprovaPagamento(@PathVariable @NotNull Long id){
        service.aprovarPagamentoPedido(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/cancelado")
    public ResponseEntity<Void> cancelaPagamento(@PathVariable @NotNull Long id){
        service.cancelarPagamentoPedido(id);
        return ResponseEntity.ok().build();
    }
}
