package br.edu.utfpr.pedido.http;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient("estoque-ms")
public interface EstoqueHttp {
    @GetMapping("/produto/{id}")
    JsonNode buscarProduto(@PathVariable("id") Long id);

    @PostMapping("/produto/{id}")
    void atualizarEstoque(@PathVariable("id") Long id);
}
