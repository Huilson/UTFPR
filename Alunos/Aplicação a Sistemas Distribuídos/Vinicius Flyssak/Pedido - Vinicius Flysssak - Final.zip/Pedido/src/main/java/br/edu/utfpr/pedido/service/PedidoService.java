package br.edu.utfpr.pedido.service;

import br.edu.utfpr.pedido.dto.ItemPedidoDto;
import br.edu.utfpr.pedido.dto.PagamentoDto;
import br.edu.utfpr.pedido.dto.PedidoDto;
import br.edu.utfpr.pedido.dto.StatusDto;
import br.edu.utfpr.pedido.http.EstoqueHttp;
import br.edu.utfpr.pedido.http.PagamentoHttp;
import br.edu.utfpr.pedido.model.Pedido;
import br.edu.utfpr.pedido.model.Status;
import br.edu.utfpr.pedido.repository.PedidoRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.*;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository repository;

    @Autowired
    private PagamentoHttp pagamentoHttp;

    @Autowired
    private EstoqueHttp estoqueHttp;

    @Autowired
    private ModelMapper modelMapper;

    public List<PedidoDto> buscaTodos(){
        return repository.findAll().stream().map(
                p-> modelMapper.map(p, PedidoDto.class))
                .collect(Collectors.toList());
    }

    public PedidoDto obterId(Long id){
        Pedido pedido = repository.findById(id).
                orElseThrow(()-> new EntityNotFoundException());

        return modelMapper.map(pedido, PedidoDto.class);
    }

    public PedidoDto criarPedido(PedidoDto dto){
        Pedido pedido = modelMapper.map(dto, Pedido.class);
        pedido.setStatus(Status.AGUARDANDO);
        pedido.setDatahora(LocalDateTime.now());
        pedido.getItens().forEach(item -> item.setPedido(pedido));

        pedido.setCpf(dto.getCpf());
        pedido.setNome(dto.getNome());
        pedido.setSobrenome(dto.getSobrenome());
        pedido.setEmail(dto.getEmail());
        pedido.setTelefone(dto.getTelefone());

        repository.save(pedido);
        return modelMapper.map(pedido, PedidoDto.class);
    }

    public PedidoDto atualizarStatus (Long id, StatusDto dto){
        Pedido pedido = repository.buscaIdcomItem(id);
        if(pedido == null)
            throw new EntityNotFoundException();
        pedido.setStatus(dto.getStatus());
        repository.atualizaStatus(dto.getStatus(), pedido);
        return  modelMapper.map(pedido, PedidoDto.class);
    }

    public void aprovarPagamentoPedido(Long id){
        Pedido pedido = repository.buscaIdcomItem(id);

        if(pedido == null)
            throw new EntityNotFoundException();

        pedido.setStatus(Status.PAGO);
        repository.save(pedido);
        atualizarEstoque(pedido.getId());
    }

    public void cancelarPagamentoPedido(Long id){
        Pedido pedido = repository.buscaIdcomItem(id);

        if(pedido == null)
            throw new EntityNotFoundException();

        pedido.setStatus(Status.CANCELADO);
        repository.save(pedido);
        atualizarEstoque(pedido.getId());
    }

    public void gerarPagamento(PedidoDto pedido) {
        //fake
        //return //-> somente irá sair do método pois o mesmo não influencia no pedido nessa parte

        try {
            Double valorTotal = 0.00;
            for (ItemPedidoDto item : pedido.getItens()) {
                valorTotal += item.getValor();
            }

            PagamentoDto pagamento = new PagamentoDto();
            pagamento.setFormaPagamento("Cartao");
            pagamento.setValor(valorTotal);
            pagamento.setNumero("1234123412341234");
            pagamento.setExpiracao("10/10/29");
            pagamento.setCodigo("123");
            pagamento.setIdPedido(pedido.getId());
            pagamento.setNome(pedido.getNome());
            pagamento.setQtdParcelas(3);

            pagamentoHttp.gerarPagamento(pagamento);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void atualizarEstoque(Long id) {
        //fake
        //return // -> nesse caso, como a validação de quantidade é feita anteriormente, não precisa entrar nesse método
        try{
            estoqueHttp.atualizarEstoque(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String buscaProdutoEstoque(ItemPedidoDto item) {
        try {
            JsonNode jsonNode = estoqueHttp.buscarProduto(item.getId_produto());

            String nome = jsonNode.get("nome").asText();
            Double quantidade = jsonNode.get("quantidade").asDouble();

            //fake
            //String nome = "Tomate";
            //Double quantidade = 22;

            item.setDescricao(nome);

            if (item.getQuantidade() > quantidade) {
                throw new RuntimeException("Estoque não possui a quantidade necessária de " + nome + "!");
            }

        } catch (FeignException e) {
            if (e.status() == 404) {
                throw new RuntimeException("Produto não encontrado!");
            } else {
                throw new RuntimeException("Erro ao buscar o produto: " + e.getMessage());
            }
        }

        return item.getDescricao();
    }
}
