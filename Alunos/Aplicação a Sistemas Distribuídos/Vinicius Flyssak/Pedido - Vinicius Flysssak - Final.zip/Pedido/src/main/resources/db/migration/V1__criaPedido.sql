CREATE TABLE pedido(
    id serial PRIMARY KEY,
    datahora timestamp NOT NULL,
    status varchar(255) NOT NULL,
    nome varchar(255) NOT NULL,
    sobrenome varchar(255) NOT NULL,
    telefone varchar(20),
    cpf varchar(16),
    email varchar(100)
);