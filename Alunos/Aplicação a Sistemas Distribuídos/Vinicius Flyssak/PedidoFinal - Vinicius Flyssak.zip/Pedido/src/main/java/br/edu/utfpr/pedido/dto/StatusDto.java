package br.edu.utfpr.pedido.dto;

import br.edu.utfpr.pedido.model.Status;
import lombok.Data;

@Data
public class StatusDto {
    private Status status;
}
