CREATE TABLE pedidos (
  id serial PRIMARY KEY,
  data_hora date NOT NULL,
  status varchar(255) NOT NULL
)