package com.utfpr.jokenpo.classes;

public class Jogador {
    private int pontuacao;
    private String nome;
    private char jogada;

    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public char getJogada() {
        return jogada;
    }

    public void setJogada(char jogada) {
        this.jogada = jogada;
    }

    public Jogador() {
        this.nome = "";
        this.pontuacao = 0;
        this.jogada = ' ';
    }
}
