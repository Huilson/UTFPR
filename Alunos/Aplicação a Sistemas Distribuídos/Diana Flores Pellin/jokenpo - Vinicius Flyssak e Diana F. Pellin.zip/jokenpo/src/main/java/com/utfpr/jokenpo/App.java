//Alunos: Vinicius Flyssak e Diana F. Pellin

package com.utfpr.jokenpo;

import com.utfpr.jokenpo.classes.Jogador;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class App { 
    public static ArrayList<Jogador> jogadores = new ArrayList<Jogador>(); //Array que contém todos os jogadores
    public static Scanner scan = new Scanner(System.in); 
    
    public static void adicionarJogador(){
        Jogador jogador = new Jogador();
        System.out.println("Digite o nickname do jogador: ");
        scan.nextLine();
        jogador.setNome(scan.next());     
        jogadores.add(jogador); //Cadastra jogador
    }
    
    public static void iniciar() throws IOException, InterruptedException {
        if (jogadores.size() < 2){ //Valida quantidade de jogadores
            System.out.println("Quantidade insuficiente de jogadores!");
            return;
        }
        for (int i = 0; i < jogadores.size(); i++) {      
            System.out.println("==========================================");            
            System.out.println("Jogador: " + jogadores.get(i).getNome());
            System.out.println("Digite a jogada: ");
            System.out.println("P para Papel, R para Rocha, T para Tesoura ou S para Sair");
            scan.nextLine();           
            jogadores.get(i).setJogada(scan.next().charAt(0)); // Registra a jogada
            //Valida a jogada realizada
            while (jogadores.get(i).getJogada() != 'S' && jogadores.get(i).getJogada() != 'R' &&
                   jogadores.get(i).getJogada() != 'T' && jogadores.get(i).getJogada() != 'P'){
                System.err.println("Jogada inválida! tente novamente!");
                scan.nextLine();           
                jogadores.get(i).setJogada(scan.next().charAt(0)); 
            }
            if (jogadores.get(i).getJogada() == 'S'){ //Se o jogador pressionar 'S', ele irá sair do jogo
                jogadores.remove(jogadores.get(i));
            }
            if (jogadores.size() < 2){
                System.out.println("Quantidade insuficiente de jogadores para continuar, o jogo está encerrado!");
                jogadores.clear();
                return;    
            }
        }
        calcularPontos();
        jogadores.clear();
    }
    
    public static void calcularPontos(){        
        for (int i = 0; i < jogadores.size(); i++) {  // Primeiro for, o que irá definir o jogador a ser comparado
            for (int j = 0; j < jogadores.size(); j++) { //j é  o contador do segundo for
                if (jogadores.get(i).getJogada() != jogadores.get(j).getJogada()){ //se for empate, ninguém pontua
                    if (((jogadores.get(i).getJogada() == 'P') && (jogadores.get(j).getJogada() == 'R')) || //valida se jogador ganhou de outro participante
                        ((jogadores.get(i).getJogada() == 'R') && (jogadores.get(j).getJogada() == 'T')) ||
                        ((jogadores.get(i).getJogada() == 'T') && (jogadores.get(j).getJogada() == 'P'))){
                        jogadores.get(i).setPontuacao(jogadores.get(i).getPontuacao() + 1);
                    }     
                }
            }
            System.out.println("Pontuação do jogador " + jogadores.get(i).getNome() + " é de " +jogadores.get(i).getPontuacao()+ " pontos");
        }
    }
    
    public static void main(String[] args) throws IOException, InterruptedException {             
        int opcao = -1; //Para evitar que o jogo feche ao abrir
        while (opcao != 0) {
            //Cria o menu principal
            System.out.println("Bem vindo ao jokenpô 3000!"); 
            System.out.println("0 - Sair");
            System.out.println("1 - Adicionar Jogador");
            System.out.println("2 - Iniciar");
            opcao = scan.nextInt();
            switch (opcao){
                case 1 -> adicionarJogador();
                case 2 -> iniciar();
            }
        }
        
    }
}
