package br.edu.utfpr.pagamento.model;

public enum Status {
    CRIADO,
    CONFIRMADO,
    CANCELADO

}
