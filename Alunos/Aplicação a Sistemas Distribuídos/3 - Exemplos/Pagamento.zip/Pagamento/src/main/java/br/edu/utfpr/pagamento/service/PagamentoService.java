package br.edu.utfpr.pagamento.service;

import br.edu.utfpr.pagamento.dto.PagamentoDto;
import br.edu.utfpr.pagamento.model.Pagamento;
import br.edu.utfpr.pagamento.model.Status;
import br.edu.utfpr.pagamento.repository.PagamentoRepository;

import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class PagamentoService {

    @Autowired
    private PagamentoRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    //Retorna todos os pagamentos páginados por em X elementos
    public Page<PagamentoDto> buscaTodos(Pageable pag){
        return repository
                .findAll(pag)//esse método retorna todas as páginas
                //mas precisa passar pra ele qual classe sera paginada
                .map(p-> modelMapper.map(p, PagamentoDto.class));
        //esse método diz pro FINDALL qual será classe usada para a paginação
    }

    //Esse método retorna um pagamento que corresponde ao ID
    //passado por REQUEST
    public PagamentoDto obterId(Long id){
        Pagamento pagamento = repository.findById(id).
                orElseThrow(()-> new EntityNotFoundException());

        return modelMapper.map(pagamento, PagamentoDto.class);
    }

    //Quando o método Cadastrar for chamado na CONTROLLER
    //Esse método transforma um dto em PAGAMENTO para poder
    //ser salvo pelo REPOSITORY, que só entende pagamento e
    //não DTO, por fim converte novamente e manda para a CONTROLLER
    public PagamentoDto criarPagamento(PagamentoDto dto){
        Pagamento pagamento = modelMapper.map(dto, Pagamento.class);
        pagamento.setStatus(Status.CRIADO);
        repository.save(pagamento);
        return modelMapper.map(pagamento, PagamentoDto.class);
    }

    //Passa-se um ID via REQUEST e depois altera o objeto no BODY
    //e envia a alteração para a CONTROLLER gerenciar
    public PagamentoDto atualizarPagamento (Long id, PagamentoDto dto){
        Pagamento pagamento = modelMapper.map(dto, Pagamento.class);
        pagamento.setId(id);
        pagamento = repository.save(pagamento);
        return modelMapper.map(pagamento, PagamentoDto.class);
    }

    //Passa-se um ID via REQUEST e depois deleta ele do banco
    public void deletarPagamento(Long id){
        repository.deleteById(id);
    }
}