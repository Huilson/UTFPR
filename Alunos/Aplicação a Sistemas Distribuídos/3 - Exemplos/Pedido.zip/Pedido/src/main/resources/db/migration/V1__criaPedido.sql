CREATE TABLE pedido(
    id serial PRIMARY KEY,
    datahora timestamp NOT NULL,
    status varchar(255) NOT NULL
);