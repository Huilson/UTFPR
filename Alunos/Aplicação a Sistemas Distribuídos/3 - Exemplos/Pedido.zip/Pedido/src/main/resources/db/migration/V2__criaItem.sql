CREATE TABLE item_pedido(
    id serial PRIMARY KEY,
    quantidade int NOT NULL,
    descricao varchar(255) NOT NULL,
    pedido_id bigint NOT NULL,
    CONSTRAINT fk_pedido
                   FOREIGN KEY (pedido_id)
                   REFERENCES pedido(id)
);