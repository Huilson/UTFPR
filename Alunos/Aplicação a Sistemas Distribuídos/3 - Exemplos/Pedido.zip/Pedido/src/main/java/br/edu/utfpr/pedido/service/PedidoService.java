package br.edu.utfpr.pedido.service;

import br.edu.utfpr.pedido.dto.PedidoDto;
import br.edu.utfpr.pedido.dto.StatusDto;
import br.edu.utfpr.pedido.model.Pedido;
import br.edu.utfpr.pedido.model.Status;
import br.edu.utfpr.pedido.repository.PedidoRepository;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository repository;

    @Autowired
    private ModelMapper modelMapper;

    public List<PedidoDto> buscaTodos(){
        return repository.findAll().stream().map(
                p-> modelMapper.map(p, PedidoDto.class))
                .collect(Collectors.toList());
    }

    public PedidoDto obterId(Long id){
        Pedido pedido = repository.findById(id).
                orElseThrow(()-> new EntityNotFoundException());

        return modelMapper.map(pedido, PedidoDto.class);
    }

    public PedidoDto criarPedido(PedidoDto dto){
        Pedido pedido = modelMapper.map(dto, Pedido.class);
        pedido.setStatus(Status.REALIZADO);
        pedido.setDatahora(LocalDateTime.now());
        //Itera sobre a lista de itens para salvar os itens passados na requesição
        pedido.getItens().forEach(item -> item.setPedido(pedido));
        repository.save(pedido);
        return modelMapper.map(pedido, PedidoDto.class);
    }

    public PedidoDto atualizarStatus (Long id, StatusDto dto){
        Pedido pedido = repository.buscaIdcomItem(id);
        if(pedido == null)
            throw new EntityNotFoundException();
        pedido.setStatus(dto.getStatus());
        repository.atualizaStatus(dto.getStatus(), pedido);
        return  modelMapper.map(pedido, PedidoDto.class);
    }

    //Passa-se um ID via REQUEST e depois deleta ele do banco
    public void aprovarPagamentoPedido(Long id){
        Pedido pedido = repository.buscaIdcomItem(id);

        if(pedido == null)
            throw new EntityNotFoundException();

        pedido.setStatus(Status.PAGO);
        repository.save(pedido);
    }
}
