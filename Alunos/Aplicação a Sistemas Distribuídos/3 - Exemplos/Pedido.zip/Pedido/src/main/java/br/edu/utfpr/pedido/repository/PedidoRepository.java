package br.edu.utfpr.pedido.repository;

import br.edu.utfpr.pedido.model.Pedido;
import br.edu.utfpr.pedido.model.Status;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PedidoRepository extends JpaRepository <Pedido, Long> {

    @Transactional
    @Query("update Pedido p set p.status = :status where p = :pedido")
    void atualizaStatus (Status status, Pedido pedido);

    @Query(value = "select p from Pedido p left join fetch p.itens where p.id = :id")
    Pedido buscaIdcomItem(Long id);
}
