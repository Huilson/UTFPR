package br.edu.utfpr.pedido.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class ItemPedidoDto {
    private Long id;
    private String descricao;
    private Integer quantidade;
}
