package br.edu.utfpr.pedido.controller;

import br.edu.utfpr.pedido.dto.PedidoDto;
import br.edu.utfpr.pedido.dto.StatusDto;
import br.edu.utfpr.pedido.model.Pedido;
import br.edu.utfpr.pedido.service.PedidoService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/pedido")
public class PedidoController {

    @Autowired
    private PedidoService service;

    @GetMapping
    public List<PedidoDto> listar(){
        return service.buscaTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PedidoDto> buscar(@PathVariable @NotNull Long id){
        PedidoDto dto = service.obterId(id);
        return ResponseEntity.ok(dto);
    }

    @PostMapping()
    public ResponseEntity<PedidoDto> realizaPedido(@RequestBody @Valid PedidoDto dto, UriComponentsBuilder uri){
        PedidoDto pedidoDto = service.criarPedido(dto);
        URI endereco = uri.path("/pedido/{id}").buildAndExpand(pedidoDto.getId()).toUri();
        return ResponseEntity.created(endereco).body(pedidoDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PedidoDto> atualizarStatus(@PathVariable Long id, StatusDto status){
        PedidoDto dto = service.atualizarStatus(id, status);
        return ResponseEntity.ok(dto);
    }

    //Método que só serve para ser usado no monolito
    @PutMapping
    public ResponseEntity<Void> aprovaPagamento(@RequestBody @NotNull Long id){
        service.aprovarPagamentoPedido(id);
        return ResponseEntity.ok().build();
    }
}
