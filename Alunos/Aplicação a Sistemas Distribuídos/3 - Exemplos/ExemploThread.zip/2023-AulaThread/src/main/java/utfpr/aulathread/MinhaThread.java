package utfpr.aulathread;

public class MinhaThread implements Runnable {

    private String nome;
    private int tempo;
    //Thread t;

    public MinhaThread(String nome, int tempo) {
        this.nome = nome;
        this.tempo = tempo;
        /*t = new Thread(this);
        t.start();*/
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                System.out.println(nome + " esta contando: " + i);
                Thread.sleep(tempo);
            }
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        /*if (t.isAlive()) {
            System.out.println(nome + " acabou!");
        }*/
    }
}
