package com.mycompany.poo2.aula1;
import java.util.Scanner;

public class POO2Aula1 {

    public static void main(String[] args) {
        
        //Teste t = new Teste();
        
        //Leitura l = new Leitura();
        //System.out.println("O numero lido foi " + l.lerInt());
        
        //Shadowing s = new Shadowing();
        //System.out.println(s.shadowing());
        
        Fibonacci f = new Fibonacci();
        System.out.println(f.fibonacci(5));
    }
}

