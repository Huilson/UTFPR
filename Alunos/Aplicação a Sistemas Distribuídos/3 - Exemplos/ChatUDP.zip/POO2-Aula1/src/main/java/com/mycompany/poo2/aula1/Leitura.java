package com.mycompany.poo2.aula1;

import java.util.Scanner;

public class Leitura {
    Scanner scan = new Scanner(System.in);
    int lerInt(){
        int i = scan.nextInt();
        return i;
    }
    
    double lerDouble(){
        double d = scan.nextDouble();
        return d;
    }
    
    String lerString(){
        scan.nextLine(); //pula linha
        String s = scan.nextLine();
        return s;
    }
    
    void fechaScan(){
        scan.close();
    }
}
