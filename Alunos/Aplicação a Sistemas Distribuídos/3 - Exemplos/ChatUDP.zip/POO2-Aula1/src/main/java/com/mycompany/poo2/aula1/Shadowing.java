package com.mycompany.poo2.aula1;

public class Shadowing {
    int a = 10;
    
    public int shadowing() {
        int a = 20; // shadowing
        return a;//imprime 20
    }    
}
