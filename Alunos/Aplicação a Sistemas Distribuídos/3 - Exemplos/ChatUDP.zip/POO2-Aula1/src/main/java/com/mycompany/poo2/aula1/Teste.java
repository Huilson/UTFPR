package com.mycompany.poo2.aula1;

class Teste {
    int Teste = 305;

    void Teste() {
        System.out.println(Teste);
    }

}