package com.mycompany.poo2.aula1;

public class Fibonacci {
    public int fibonacci(int x) {
        if (x == 0 || x == 1 ){
            return x;
        }
        int num1 = x-1;
        int num2 = x-2;
        System.out.println("Os numeros somados sao: " + num1 +" e "+num2);
        return fibonacci(x - 1) + fibonacci(x - 2);
    }
}
