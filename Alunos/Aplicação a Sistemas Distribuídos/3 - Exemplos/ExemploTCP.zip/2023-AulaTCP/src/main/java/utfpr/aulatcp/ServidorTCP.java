package utfpr.aulatcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ServidorTCP {

    public static void main(String[] args) throws IOException{
        //Iniciar um servidor, esse servidor precisa ter um porta 
        //para ficar ouvindo solicitações do cliente
        ServerSocket servidor = new ServerSocket(8081);        
        System.out.println("Servidor rodando na porta 8081");
        
        //Ficar no aguardo de alguma solicitação do lado dos clientes
        Socket socket = servidor.accept();
        
        Pessoa p = new Pessoa();
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("servidortcp");
        EntityManager em = factory.createEntityManager();
        
        em.getTransaction().begin();
        
        //salva no banco
        em.persist(p);
        em.getTransaction().commit();
        
        //consulta ao banco precisa estar dentro de uma classe (pode ser a propria classe pessoa)
        String jpql = "SELECT aluno FROM Aluno aluno WHERE aluno.nome =:nome";
        em.createQuery(jpql, Pessoa.class).setParameter("nome",p.getNome()).getResultList();
        
        em.close();
        
        //Imprime o IP e o Porta do cliente
        System.out.println("O cliente ip: "+socket.getInetAddress().getHostAddress()+" se conectou!");
        
        //Definir um stream de entrada de dados no servidor
        ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
        
        //Por padrão o próprio Stream(socket) Java serealiza as informações
        String mensagem = entrada.readUTF();
        
        //O servidor tem a função de converter string (char) para maiúsculo
        String novaMensagem = mensagem.toUpperCase();
        
        //Definir um stream de saída para os dados enviados para o cliente
        DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        
        saida.writeUTF(novaMensagem);
        
        //Fecho minhas streams de entrada e saída com os clientes
        entrada.close();
        saida.close();
        
        //Fecho a conexão
        socket.close();
        servidor.close();
    }
}