package utfpr.semaforothread;

public class Carros {
    private int placa;//identificar o carro
    private int ano;//determinar potência do motor
    private String modelo;//determina também a potência do motor

    //CONSTRUCTOR
    public Carros() {
    }

    public Carros(int placa, int ano, String modelo) {
        this.placa = placa;
        this.ano = ano;
        this.modelo = modelo;
    }
    
    //GETTERS & SETTERS

    public int getPlaca() {
        return placa;
    }

    public void setPlaca(int placa) {
        this.placa = placa;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return "Carros{" + "placa=" + placa + ", ano=" + ano + ", modelo=" + modelo + '}';
    }
    
}