package utfpr.semaforothread;

import java.util.LinkedList;
import java.util.Queue;

public class App {

    public static void main(String[] args) {
        Semaforo semaforo = new Semaforo();

        Carros carro0 = new Carros(3, 2020, "bmw");
        Carros carro1 = new Carros(1, 1982, "fusca");
        Carros carro2 = new Carros(2, 1990, "gol");
        Carros carro3 = new Carros(4, 2003, "fox");
        Carros carro4 = new Carros(5, 2011, "civic");
        Carros carro5 = new Carros(6, 2015, "corolla");
        Carros carro6 = new Carros(7, 2021, "jeep");
        Carros carro7 = new Carros(8, 2023, "jetta");
        Carros carro8 = new Carros(9, 2014, "palio");
        Carros carro9 = new Carros(10, 2009, "pagero");
        Carros carro10 = new Carros(11, 1999, "brasilia");
        Carros carro11 = new Carros(12, 2022, "mustang");
        Carros carro12 = new Carros(13, 2013, "c4");
        Carros carro13 = new Carros(0, 2017, "highlander");
        Carros carro14 = new Carros(14, 2015, "onix");
        Carros carro15 = new Carros(15, 2013, "prisma");
        Carros carro16 = new Carros(16, 2014, "triton");
        Carros carro17 = new Carros(17, 2010, "megane");
        Carros carro18 = new Carros(18, 1992, "chevet");

        Queue<Carros> carros = new LinkedList<>();
        carros.add(carro0);
        carros.add(carro1);
        carros.add(carro2);
        carros.add(carro3);
        carros.add(carro4);
        carros.add(carro5);
        carros.add(carro6);
        carros.add(carro7);
        carros.add(carro8);
        carros.add(carro9);
        carros.add(carro10);
        carros.add(carro11);
        carros.add(carro12);
        carros.add(carro13);
        carros.add(carro14);
        carros.add(carro15);
        carros.add(carro16);
        carros.add(carro17);
        carros.add(carro18);

        for (int i = 0; i < 10; i++) {
            System.out.println("Sinal esta: " + semaforo.getSinal());
            while (semaforo.getSinal().equals("verde")) {
                if (!carros.isEmpty()) {
                    System.out.println("Carros em movimento...");
                    semaforo.verificaPotencia(carros.element().getAno());
                    System.out.println("O " + carros.poll() + " saiu");
                } else {
                    break;
                }
            }//fim while
            semaforo.tempoSinal();
        }//fim for
        semaforo.desligar();
    }
}
