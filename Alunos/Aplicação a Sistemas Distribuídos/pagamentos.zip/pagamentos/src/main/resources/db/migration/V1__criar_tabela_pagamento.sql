CREATE TABLE pagamentos (
 id serial PRIMARY KEY,
 valor double precision NOT NULL,
 nome varchar(100) DEFAULT NULL,
 numero varchar(19) DEFAULT NULL,
 expiracao varchar(7) DEFAULT NULL,
 codigo varchar(3) DEFAULT NULL,
 status varchar(255) NOT NULL,
 forma_de_pagamento_id bigint NOT NULL,
 pedido_id bigint NOT NULL
);