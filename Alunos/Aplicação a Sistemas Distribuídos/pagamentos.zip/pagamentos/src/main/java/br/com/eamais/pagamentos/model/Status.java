package br.com.eamais.pagamentos.model;

public enum Status {
    CRIADO,
    CONFIRMADO,
    CANCELADO
}