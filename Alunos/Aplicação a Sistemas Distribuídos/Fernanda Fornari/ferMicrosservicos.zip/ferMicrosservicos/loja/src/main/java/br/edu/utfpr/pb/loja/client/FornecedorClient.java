package br.edu.utfpr.pb.loja.client;

import br.edu.utfpr.pb.loja.dto.InfoFornecedorDto;
import br.edu.utfpr.pb.loja.dto.InfoPedidoDto;
import br.edu.utfpr.pb.loja.dto.ItemDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@FeignClient("fornecedor")
public interface FornecedorClient {

    @RequestMapping("/info/{estado}")
    InfoFornecedorDto getFornecedorPorEstado (@PathVariable String estado);

    @RequestMapping(method= RequestMethod.POST, value="/pedido")
    InfoPedidoDto realizaPedido(List<ItemDto> itens);

}
