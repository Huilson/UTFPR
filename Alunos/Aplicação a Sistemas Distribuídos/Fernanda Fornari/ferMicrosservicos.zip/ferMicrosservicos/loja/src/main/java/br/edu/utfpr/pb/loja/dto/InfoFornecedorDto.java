package br.edu.utfpr.pb.loja.dto;

import lombok.Data;

@Data
public class InfoFornecedorDto {
    private String endereco;
}
