package br.edu.utfpr.pb.loja.dto;

import lombok.Data;

@Data
public class InfoPedidoDto {

    private Long id;
    public Integer tempoPreparo;
}
