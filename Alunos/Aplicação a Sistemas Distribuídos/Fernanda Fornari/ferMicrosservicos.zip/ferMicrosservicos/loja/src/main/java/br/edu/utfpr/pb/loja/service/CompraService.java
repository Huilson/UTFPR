package br.edu.utfpr.pb.loja.service;

import br.edu.utfpr.pb.loja.client.FornecedorClient;
import br.edu.utfpr.pb.loja.dto.CompraDto;
import br.edu.utfpr.pb.loja.dto.InfoFornecedorDto;
import br.edu.utfpr.pb.loja.dto.InfoPedidoDto;
import br.edu.utfpr.pb.loja.model.Compra;
import com.netflix.discovery.DiscoveryClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CompraService {

    private static final Logger LOG = LoggerFactory.getLogger(CompraService.class);

    @Autowired
    private FornecedorClient fornecedorClient;


    //Faz requisição para FORNECEDOR, para receber
    //fornecedores disponíveis por estado
    public Compra realizaCompra (CompraDto compra){

        final String estado = compra.getEndereco().getEstado();

        LOG.info("buscando informações do fornecedor de {}", estado);
        InfoFornecedorDto info = fornecedorClient.getFornecedorPorEstado(estado);

        LOG.info("realizando um pedido");
        InfoPedidoDto infoPedido = fornecedorClient.realizaPedido(compra.getItens());

        Compra compraSalva = new Compra();
        compraSalva.setPedidoId(infoPedido.getId());
        compraSalva.setTempoPreparo(infoPedido.getTempoPreparo());
        compraSalva.setEnderecoDestino(info.getEndereco());

        System.out.println(info.getEndereco());

        return compraSalva;
    }
}
