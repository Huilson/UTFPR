package br.edu.utfpr.pb.loja.dto;

import lombok.Data;

@Data
public class EnderecoDto {

    private String rua;
    private int numero;
    private String estado;

}
