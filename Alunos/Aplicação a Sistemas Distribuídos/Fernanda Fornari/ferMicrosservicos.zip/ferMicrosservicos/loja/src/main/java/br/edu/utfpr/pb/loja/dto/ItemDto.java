package br.edu.utfpr.pb.loja.dto;

import lombok.Data;

@Data
public class ItemDto {

    private Long id;
    private int quantidade;
}
