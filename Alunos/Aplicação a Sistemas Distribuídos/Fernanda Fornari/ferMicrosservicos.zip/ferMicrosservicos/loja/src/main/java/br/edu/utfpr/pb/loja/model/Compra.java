package br.edu.utfpr.pb.loja.model;

import lombok.Data;

@Data
public class Compra {

    private Long id;
    private Long pedidoId;
    private Integer tempoPreparo;
    private String enderecoDestino;

}
