package br.edu.utfpr.pb.loja.dto;

import lombok.Data;
import java.util.List;

@Data
public class CompraDto {

    private List<ItemDto> itens;
    private EnderecoDto endereco;
}
