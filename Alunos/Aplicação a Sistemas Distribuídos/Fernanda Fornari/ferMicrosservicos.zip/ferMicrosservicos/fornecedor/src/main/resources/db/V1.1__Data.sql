insert into tb_fornecedor (nome, estado, endereco) values ('Fornecedor SP 2', 'SP', 'Centro, São Paulo');
insert into tb_fornecedor (nome, estado, endereco) values ('Fornecedor PR 1', 'PR', 'Centro, Pato Branco');
insert into tb_fornecedor (nome, estado, endereco) values ('Fornecedor SP 2', 'SP', 'Vila Madalena, São Paulo');
insert into tb_fornecedor (nome, estado, endereco) values ('Fornecedor SC 1', 'SC', 'Centro, Florianópolis');
insert into tb_fornecedor (nome, estado, endereco) values ('Fornecedor SC 2', 'SC', 'Campeche, Florianópolis');

insert into tb_produto (nome, estado, descricao, preco) values ('Produto 1', 'SP', 'Produto 1', 10.0);
insert into tb_produto (nome, estado, descricao, preco) values ('Produto 2', 'SC', 'Produto 2', 15.0);
insert into tb_produto (nome, estado, descricao, preco) values ('Produto 3', 'SP', 'Produto 3', 10.0);
insert into tb_produto (nome, estado, descricao, preco) values ('Produto 4', 'SC', 'Produto 4', 20.0);
insert into tb_produto (nome, estado, descricao, preco) values ('Produto 5', 'SP', 'Produto 5', 10.0);
insert into tb_produto (nome, estado, descricao, preco) values ('Produto 6', 'PR', 'Produto 6', 5.0);