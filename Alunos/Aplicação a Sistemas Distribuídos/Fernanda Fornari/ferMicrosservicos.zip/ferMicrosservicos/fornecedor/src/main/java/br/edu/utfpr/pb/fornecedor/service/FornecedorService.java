package br.edu.utfpr.pb.fornecedor.service;

import br.edu.utfpr.pb.fornecedor.model.Fornecedor;
import br.edu.utfpr.pb.fornecedor.repository.FornecedorRepository;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FornecedorService {

    @Autowired
    private FornecedorRepository fornecedorRepository;

    public Fornecedor getFornecedorPorEstado(String estado) {
       return fornecedorRepository.findByEstado(estado);

    }
}
