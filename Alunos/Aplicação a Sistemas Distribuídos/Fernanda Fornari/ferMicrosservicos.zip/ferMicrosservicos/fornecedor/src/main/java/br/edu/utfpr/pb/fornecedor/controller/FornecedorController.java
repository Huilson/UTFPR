package br.edu.utfpr.pb.fornecedor.controller;

//Devolve informações de fornecedor por estado

import br.edu.utfpr.pb.fornecedor.model.Fornecedor;
import br.edu.utfpr.pb.fornecedor.service.FornecedorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/info")
public class FornecedorController {

    private static final Logger LOG = LoggerFactory.getLogger(FornecedorController.class);
    @Autowired
    private FornecedorService fornecedorService;

    @RequestMapping("/{estado}")
    public Fornecedor getFornecedorPorEstado (@PathVariable String estado) {
        LOG.info("recebido pedido de informações de fornecedores para {}", estado);
        return fornecedorService.getFornecedorPorEstado(estado);
    }

}
