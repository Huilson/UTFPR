package br.edu.utfpr.pb.fornecedor.dto;

import lombok.Data;

@Data
public class ItemPedidoDto {

	private long id;
	private int quantidade;
	
}
