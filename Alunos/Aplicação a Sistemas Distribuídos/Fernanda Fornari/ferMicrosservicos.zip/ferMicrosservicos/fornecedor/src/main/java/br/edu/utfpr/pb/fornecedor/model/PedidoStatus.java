package br.edu.utfpr.pb.fornecedor.model;

public enum PedidoStatus {
	RECEBIDO, PRONTO, ENVIADO;
}
