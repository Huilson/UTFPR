package br.edu.utfpr.pb.fornecedor.model;

import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;

@Entity(name = "tb_pedidoItem")
@Data
public class PedidoItem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Integer quantidade;

	@ManyToOne @JoinColumn(name = "produto_id")
	private Produto produto;
	
}
