package br.edu.utfpr.pb.fornecedor.repository;

import br.edu.utfpr.pb.fornecedor.model.Pedido;
import org.springframework.data.repository.CrudRepository;

public interface PedidoRepository extends CrudRepository<Pedido, Long>{

}
