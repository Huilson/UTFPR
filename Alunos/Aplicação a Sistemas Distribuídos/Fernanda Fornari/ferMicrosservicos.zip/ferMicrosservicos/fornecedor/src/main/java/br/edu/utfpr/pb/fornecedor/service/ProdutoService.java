package br.edu.utfpr.pb.fornecedor.service;

import br.edu.utfpr.pb.fornecedor.model.Produto;
import br.edu.utfpr.pb.fornecedor.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {

	private ProdutoRepository produtoRepository;
	
	public List<Produto> getProdutosPorEstado(String estado) {
		return produtoRepository.findByEstado(estado);
	}
	
}
