package br.edu.utfpr.pb.fornecedor.dto;

import lombok.Data;

@Data
public class ReservaDto {

	public Integer idReserva;
	public Integer tempoDePreparo;
	
}
