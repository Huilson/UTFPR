package br.edu.utfpr.pb.jogodafer;

/**
 *
 * @author fernandafornari
 */
import java.io.PrintStream;

public class ClienteServidor {
    
	String play1;
	int play1Id;
	PrintStream play1PS;
	String play2;
	int play2Id;
	PrintStream play2PS;
	int ativo;
	
	ClienteServidor(){
		
	}

	
	public String getLogin() {
		return play1;
	}

	public void setLogin(String login) {
		this.play1 = login;
	}

	public int getLoginId() {
		return play1Id;
	}

	public void setLoginId(int loginId) {
		this.play1Id = loginId;
	}

	public PrintStream getLoginPS() {
		return play1PS;
	}

	public void setLoginPS(PrintStream loginPS) {
		this.play1PS = loginPS;
	}

	public String getOponente() {
		return play2;
	}

	public void setOponente(String oponente) {
		this.play2 = oponente;
	}

	public int getOponenteId() {
		return play2Id;
	}

	public void setOponenteId(int oponenteId) {
		this.play2Id = oponenteId;
	}

	public PrintStream getOponentePS() {
		return play2PS;
	}

	public void setOponentePS(PrintStream oponentePS) {
		this.play2PS = oponentePS;
	}

	public int getAtivo() {
		return ativo;
	}

	public void setAtivo(int ativo) {
		this.ativo = ativo;
	}	
}
