package br.edu.utfpr.pb.jogodafer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author fernandafornari
 */
public class Jogo extends javax.swing.JFrame {

    // variáveis
    public int[][] matrizVelha = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
    public final String nickP1;
    public final String nickP2;
    private boolean play1 = true;
    private boolean play2 = true;
    private int score1 = 0;
    private int score2 = 0;
    private int contaPosicao = 0;
    private int op, jogada;
    private String l1, l2, l3, c1, c2, c3, d1, d2;
    public final Cliente cliente;
    private int jogador = 1;
    public String chat = "";

    /**
     * Creates new form ClienteConexao
     */
    public Jogo(String nickP1, String nickP2, final Cliente cliente) {

        initComponents(); // inicia componentes visuais
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.nickP1 = nickP1;
        this.nickP2 = nickP2;
        this.cliente = cliente;
        
        txtScoreP1.setText(nickP1 + ": 0");
        txtScoreP2.setText(nickP2 + ": 0");

        //jTextArea1.setText(this.nickP1+"\r\n");
        //jTextArea1.setText(this.nickP1 + " X " + this.nickP2+"\r\n");
        this.btn1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn1.getText() != "") {
                    return;
                }
                btn1.setText("X");
                cliqueBotaoVelha(0, 0);

                desabilitar();

            }
        });
        btn1.setBounds(125, 72, 50, 50);

        this.btn4.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn4.getText() != "") {
                    return;
                }
                btn4.setText("X");
                cliqueBotaoVelha(1, 0);

                desabilitar();

            }
        });
        btn4.setBounds(125, 133, 50, 50);

        this.btn7.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn7.getText() != "") {
                    return;
                }
                btn7.setText("X");
                cliqueBotaoVelha(2, 0);

                desabilitar();

            }
        });
        btn7.setBounds(125, 72, 50, 50);

        this.btn2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn2.getText() != "") {
                    return;
                }
                btn2.setText("X");
                cliqueBotaoVelha(0, 1);

                desabilitar();

            }
        });
        btn2.setBounds(125, 133, 50, 50);

        this.btn5.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn5.getText() != "") {
                    return;
                }
                btn5.setText("X");
                cliqueBotaoVelha(1, 1);

                desabilitar();

            }
        });
        btn5.setBounds(125, 190, 50, 50);

        this.btn8.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn8.getText() != "") {
                    return;
                }
                btn8.setText("X");
                cliqueBotaoVelha(2, 1);

                desabilitar();

            }
        });
        btn8.setBounds(125, 72, 50, 50);

        this.btn3.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn3.getText() != "") {
                    return;
                }
                btn3.setText("X");
                cliqueBotaoVelha(0, 2);

                desabilitar();

            }
        });
        btn3.setBounds(125, 133, 50, 50);

        this.btn6.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn6.getText() != "") {
                    return;
                }
                btn6.setText("X");
                cliqueBotaoVelha(1, 2);

                desabilitar();

            }
        });
        btn6.setBounds(125, 190, 50, 50);

        this.btn9.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (btn9.getText() != "") {
                    return;
                }

                btn9.setText("X");
                cliqueBotaoVelha(2, 2);

                desabilitar();

            }
        });
        btn9.setBounds(125, 190, 50, 50);

        System.out.println(cliente.getIdP1());
        System.out.println(cliente.getIdP2());

        if (Integer.parseInt(cliente.getIdP1()) > Integer.parseInt(cliente.getIdP2())) {
            habilitaBotoes();
            txtIndicador.setText("Sua vez de jogar");
        } else {
            desabilitar();
            txtIndicador.setText("aguarde sua vez");
        }

        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    chat = taChat.getText() + "\n" + cliente.getNickP1() + ": " + txtChat.getText();
                    atualizaChat();
                    cliente.enviaDados("conversar;" + cliente.getIdP1() + ";" + txtChat.getText());
                    txtChat.setText("");
                } catch (IOException ex) {
                    Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    public void habilitaBotoes() {

        if (matrizVelha[0][0] < 0) {
            btn1.setEnabled(false);
            btn1.setText("O");
        } else {
            btn1.setEnabled(true);
        }

        if (matrizVelha[0][1] < 0) {
            btn2.setEnabled(false);
            btn2.setText("O");
        } else {
            btn2.setEnabled(true);
        }

        if (matrizVelha[0][2] < 0) {
            btn3.setEnabled(false);
            btn3.setText("O");
        } else {
            btn3.setEnabled(true);
        }

        if (matrizVelha[1][0] < 0) {
            btn4.setEnabled(false);
            btn4.setText("O");
        } else {
            btn4.setEnabled(true);
        }

        if (matrizVelha[1][1] < 0) {
            btn5.setEnabled(false);
            btn5.setText("O");
        } else {
            btn5.setEnabled(true);
        }

        if (matrizVelha[1][2] < 0) {
            btn6.setEnabled(false);
            btn6.setText("O");
        } else {
            btn6.setEnabled(true);
        }

        if (matrizVelha[2][0] < 0) {
            btn7.setEnabled(false);
            btn7.setText("O");
        } else {
            btn7.setEnabled(true);
        }

        if (matrizVelha[2][1] < 0) {
            btn8.setEnabled(false);
            btn8.setText("O");
        } else {
            btn8.setEnabled(true);
        }

        if (matrizVelha[2][2] < 0) {
            btn9.setEnabled(false);
            btn9.setText("O");
        } else {
            btn9.setEnabled(true);
        }
        
        txtIndicador.setText("sua vez de jogar");

    }

    public void preencheMatriz(int linha, int coluna, int valor) {
        this.matrizVelha[linha][coluna] = valor;
    }

    public int cliqueBotaoVelha(int linha, int coluna) {

        try {
            cliente.enviaDados("jogar;" + cliente.getIdP1() + ";" + linha + ";" + coluna);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        int valor = 1;

        preencheMatriz(linha, coluna, valor);
        int retorno = verificaMatriz();
        if (retorno == 1) {
            JOptionPane.showMessageDialog(null, nickP1 + " venceu o jogo!");
            limparVelha();
            return 0;
        } else if (retorno == -1) {
            JOptionPane.showMessageDialog(null, nickP2 + " venceu o jogo!");
            limparVelha();
            return 0;
        } else if (retorno == 2) {
            return 0;
        }

        return valor;
    }

    public int verificaMatriz() {
        int retornoColunas, retornoLinhas, retornoDiagonais = 0;
        retornoColunas = checaColunas();
        retornoLinhas = checaLinhas();
        retornoDiagonais = checaDiagonais();

        if (retornoColunas == -1 || retornoLinhas == -1 || retornoDiagonais == -1) {
            score1++;
            txtScoreP1.setText(nickP1 + ": " + score1);       
            return -1;

        }

        if (retornoColunas == 1 || retornoLinhas == 1 || retornoDiagonais == 1) {
            score2++;
            txtScoreP2.setText(nickP2 + ": " + score2);            
            return 1;
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (matrizVelha[i][j] == 0) {
                    return 0;
                }
            }
        }

        limparVelha();
        JOptionPane.showMessageDialog(null, "Jogo empatou!");

        return 2;
    }

    public int checaLinhas() {
        for (int linha = 0; linha < 3; linha++) {

            if ((this.matrizVelha[linha][0] + this.matrizVelha[linha][1] + this.matrizVelha[linha][2]) == -3) {
                return -1;
            }
            if ((this.matrizVelha[linha][0] + this.matrizVelha[linha][1] + this.matrizVelha[linha][2]) == 3) {
                return 1;
            }
        }
        return 0;

    }

    public int checaColunas() {
        for (int coluna = 0; coluna < 3; coluna++) {

            if ((this.matrizVelha[0][coluna] + this.matrizVelha[1][coluna] + this.matrizVelha[2][coluna]) == -3) {
                return -1;
            }
            if ((this.matrizVelha[0][coluna] + this.matrizVelha[1][coluna] + this.matrizVelha[2][coluna]) == 3) {
                return 1;
            }
        }
        return 0;

    }

    public int checaDiagonais() {
        if ((this.matrizVelha[0][0] + this.matrizVelha[1][1] + this.matrizVelha[2][2]) == -3) {
            return -1;
        }
        if ((this.matrizVelha[0][0] + this.matrizVelha[1][1] + this.matrizVelha[2][2]) == 3) {
            return 1;
        }
        if ((this.matrizVelha[0][2] + this.matrizVelha[1][1] + this.matrizVelha[2][0]) == -3) {
            return -1;
        }
        if ((this.matrizVelha[0][2] + this.matrizVelha[1][1] + this.matrizVelha[2][0]) == 3) {
            return 1;
        }

        return 0;
    }

    public void limparVelha() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrizVelha[i][j] = 0;
            }
        }
        btn1.setText("");
        btn2.setText("");
        btn3.setText("");
        btn4.setText("");
        btn5.setText("");
        btn6.setText("");
        btn7.setText("");
        btn8.setText("");
        btn9.setText("");
    }

    public void desabilitar() {
        btn1.setEnabled(false);
        btn2.setEnabled(false);
        btn3.setEnabled(false);
        btn4.setEnabled(false);
        btn5.setEnabled(false);
        btn6.setEnabled(false);
        btn7.setEnabled(false);
        btn8.setEnabled(false);
        btn9.setEnabled(false);
        
        txtIndicador.setText("aguarde sua vez");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        btn4 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taChat = new javax.swing.JTextArea();
        btn3 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtChat = new javax.swing.JTextArea();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btnEnviar = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtScoreP1 = new javax.swing.JTextField();
        txtScoreP2 = new javax.swing.JTextField();
        txtIndicador = new javax.swing.JTextField();
        btnFinalizar1 = new javax.swing.JButton();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        taChat.setEditable(false);
        taChat.setColumns(20);
        taChat.setRows(5);
        jScrollPane1.setViewportView(taChat);

        txtChat.setColumns(20);
        txtChat.setRows(5);
        jScrollPane3.setViewportView(txtChat);

        btnEnviar.setLabel("Enviar");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });

        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Jogo da Fer");

        txtScoreP1.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        txtScoreP1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtScoreP1ActionPerformed(evt);
            }
        });

        txtScoreP2.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        txtScoreP2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtScoreP2ActionPerformed(evt);
            }
        });

        txtIndicador.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        txtIndicador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIndicadorActionPerformed(evt);
            }
        });

        btnFinalizar1.setText("Finalizar");
        btnFinalizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btn1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn7, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btn5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(14, 14, 14)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btn6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn9, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(txtIndicador)
                        .addComponent(btnFinalizar1, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtScoreP1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtScoreP2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(btnEnviar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtScoreP1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtScoreP2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtIndicador, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btn3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btn1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn4, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnEnviar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnFinalizar1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn6ActionPerformed

    private void txtScoreP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtScoreP1ActionPerformed

    }//GEN-LAST:event_txtScoreP1ActionPerformed

    private void txtScoreP2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtScoreP2ActionPerformed

    }//GEN-LAST:event_txtScoreP2ActionPerformed

    private void txtIndicadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIndicadorActionPerformed

    }//GEN-LAST:event_txtIndicadorActionPerformed

    //Botão Finalizar
    private void btnFinalizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizar1ActionPerformed
        System.exit(EXIT_ON_CLOSE);
    }//GEN-LAST:event_btnFinalizar1ActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed

    }//GEN-LAST:event_btnEnviarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn1;
    public javax.swing.JButton btn2;
    public javax.swing.JButton btn3;
    public javax.swing.JButton btn4;
    public javax.swing.JButton btn5;
    public javax.swing.JButton btn6;
    public javax.swing.JButton btn7;
    public javax.swing.JButton btn8;
    public javax.swing.JButton btn9;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnFinalizar1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    public javax.swing.JTextArea taChat;
    public javax.swing.JTextArea txtChat;
    private javax.swing.JTextField txtIndicador;
    private javax.swing.JTextField txtScoreP1;
    private javax.swing.JTextField txtScoreP2;
    // End of variables declaration//GEN-END:variables

    public JButton[][] matrizVelhaBotao
            = {{btn1, btn2, btn3}, {btn4, btn5, btn6}, {btn7, btn8, btn9}};

    void atualizaChat() {
        taChat.setText(this.chat);
    }

}
