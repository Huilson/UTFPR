package br.edu.utfpr.pb.jogodafer;

/**
 *
 * @author fernandafornari
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Cliente {

    //Variáveis
    private String host;
    private int porta = 12345;
    private Socket socketCliente;
    PrintStream saida;
    private String idP1;
    private String idP2;
    private String nickP1;
    private static Cliente cliente;

    //Construtor recebe Ip host e nick do player 1
    public Cliente(String host, String nickP1) {
        this.host = host;
        this.nickP1 = nickP1;
        cliente = this;
    }

    
    public void executa(String nickP2) throws UnknownHostException, IOException {

        this.socketCliente = new Socket(this.host, this.porta);
        System.out.println(nickP2 + " se conectou ao servidor!");

        InputStream is = this.socketCliente.getInputStream();
        Recebedor rec = new Recebedor(is);
        Thread t = new Thread(rec);
        t.start();
    }

    // lê as mensagens do teclado e manda pro servidor
    public void enviaDados(String dado) throws IOException {
        this.saida = new PrintStream(this.socketCliente.getOutputStream());
        this.saida.println(dado);
    }

    public void fechaConexao() throws IOException {
        this.saida.close();
        this.socketCliente.close();
    }

    public String getIdP1() {
        return idP1;
    }

    public void setIdP1(String idP1) {
        this.idP1 = idP1;
    }

    public String getIdP2() {
        return idP2;
    }

    public void setIdP2(String idP2) {
        this.idP2 = idP2;
    }

    public static synchronized Cliente getInstance() {
        if (cliente == null) {
            cliente = new Cliente("127.0.0.1", "NickP1");
        }
        return cliente;
    }

    public String getNickP1() {
        return nickP1;
    }

    public void setNickP1(String nickP1) {
        this.nickP1 = nickP1;
    }
}
