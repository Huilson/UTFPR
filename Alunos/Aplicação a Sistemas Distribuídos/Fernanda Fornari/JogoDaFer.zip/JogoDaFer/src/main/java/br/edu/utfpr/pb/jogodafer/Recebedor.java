package br.edu.utfpr.pb.jogodafer;

import java.io.InputStream;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author fernandafornari
 */
public class Recebedor implements Runnable {

    Jogo tabuleiro;
    private InputStream servidor;

    public Recebedor(InputStream servidor) {
        this.servidor = servidor;
    }

    public void run() {
        Scanner s = new Scanner(servidor);

        while (s.hasNextLine()) {
            String entrada = s.nextLine();
            this.trataEntrada(entrada);
        }
    }

    public void trataEntrada(String entrada) {
        String[] array = entrada.split(";");

        switch (array[0]) {
            case "logar":
                //Id, loginPlay2, idPlay2 
                this.logar(array[1], array[2], array[3]);
                break;

            case "jogar":
                this.jogar(array[1], array[2]);
                break;

            case "conversar":
                //nick do player e conversa
                this.conversar(array[1], array[2]);
                break;

            default:
                break;
        }
    }

    public void logar(String idP1, String nickP2, String idP2) {

        Cliente cliente = Cliente.getInstance();
        cliente.setIdP1(idP1);
        cliente.setIdP2(idP2);

        System.out.println("Player 2: " + cliente.getNickP1());
        System.out.println("Player 1: " + nickP2);
        this.tabuleiro = new Jogo(cliente.getNickP1(), nickP2, cliente);
        this.tabuleiro.show();
    }

    public void jogar(String linha, String coluna) {

        this.tabuleiro.matrizVelha[Integer.parseInt(linha)][Integer.parseInt(coluna)] = -1;

        int retorno = this.tabuleiro.verificaMatriz();
        if (retorno == 1) {
            JOptionPane.showMessageDialog(null, this.tabuleiro.nickP1 + " venceu o jogo!");
            this.tabuleiro.limparVelha();
        } else if (retorno == -1) {
            JOptionPane.showMessageDialog(null, this.tabuleiro.nickP2 + " venceu o jogo!");
            this.tabuleiro.limparVelha();
        }

        this.tabuleiro.habilitaBotoes();
    }

    public void conversar(String nome, String texto) {

        StringBuilder sb = new StringBuilder();

        sb.append(this.tabuleiro.chat);
        sb.append("\n");
        sb.append(nome + ": ");
        sb.append(texto);

        try {
            this.tabuleiro.chat = sb.toString();
            this.tabuleiro.atualizaChat();

        } catch (Exception e) {
            System.out.println("Falha na comunicação do chat");
            e.printStackTrace();
        }

    }

}
