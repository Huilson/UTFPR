/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jogodavelha;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author danie
 */
public class ServidorJogo {

    private ServerSocket serversocket;
//    private Socket socket;
//    private ObjectOutputStream oos;
//    private ObjectInputStream ois;
    
    //Construtor
    public ServidorJogo(ServerSocket serversocket){
//        try {
            this.serversocket = serversocket;
//            this.socket = serversocket.accept();
//            this.oos = new ObjectOutputStream(socket.getOutputStream());
//            this.ois = new ObjectInputStream(socket.getInputStream());
//        } catch (IOException e) {
//            System.out.println("Erro ao iniciar o servidor. ");
//            e.printStackTrace();
//            encerraTudo(socket, oos, ois);
//        }
    }
    
    public void start() throws IOException{
        try{
            while(!serversocket.isClosed()){
                //aceita a requisição de conexão de um cliente
                Socket  socket = serversocket.accept();
                System.out.println("Jogador foi conectado");
                
                GerenciadorJogo gj = new GerenciadorJogo(socket);
                
                //uma thread da o direito a um cliente de ser ouvido e ouvir
                Thread thread = new Thread(gj);
                //Thread threadO = new Thread(gj);
                thread.start();
                //threadO.start();
            }
        } catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    public void closeServer(){
        try{
            if(serversocket != null){
                serversocket.close();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
//    public void encerraTudo(Socket socket, ObjectOutputStream oos, ObjectInputStream ois) {
//        try {
//            if (br != null) {
//                oos.close();//enquanto tiver leitura não encerra
//            }
//            if (bw != null) {
//                ois.close();//enquanto tiver escrita não encerra
//            }
//            if (socket != null) {
//                socket.close();//enquanto tiver enviando ou recebendo não encerra
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
    
    public static void main(String[] args) throws IOException {
        ServerSocket serversocket = new ServerSocket(1286);//porta que o servidor fica ouvindo
        ServidorJogo server = new ServidorJogo(serversocket);//construtor de acesso ao servidor
        server.start();//tenho Jogador? Sim! inicio o servidor!
    }
    
}
