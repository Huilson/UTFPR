package jogodavelha;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */

/*Para iniciar o jogo, é necessário informar os nomes para saber quem usará o X e O
Iniciando com jogador que usará o X*/
public class Jogo extends javax.swing.JFrame {

    private Socket socket;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private String nomeUser;
    public boolean jogo1 = true;
    public boolean jogo2 = true;
    private boolean termina;
    public int posicao = 0, cnt = 0;
    public int k = 0, i = 0;
    int aux;
    int auxX = 1, auxO = 1, placarX = 0, placarO = 0;
    public String l1, l2, l3, c1, c2, c3, d1, d2;
    String campos[][] = new String[3][3];
    private String simboloX;
    private String simboloO;
    private String simbolo;
    boolean verifica;
    
    GerenciadorJogo gj = new GerenciadorJogo();

    /**
     * Creates new form Jogo
     */
    public Jogo() {
        initComponents();
    }

    public Jogo(Socket socket, String nomeUser) {
        try {
            this.socket = socket;
            this.oos = new ObjectOutputStream(socket.getOutputStream());
            this.ois = new ObjectInputStream(socket.getInputStream());
            this.nomeUser = gj.getNomeJogador();
        } catch (IOException e) {
            encerraTudo(socket, oos, ois);
        }
    }

    public void setSimboloX(String simboloX) {
        this.simboloX = simboloX;
    }
    
    public void setSimboloO(String simboloO) {
        this.simboloO = simboloO;
    }

    public String getSimbolo() {
        return simbolo;
    }
    
    public String[][] getCampos() {
        return campos;
    }

    public void setCampos(String[][] campos) {
        this.campos = campos;
    }

    public void run() {
        while (!termina) {
            try {
                if (verificaJogadaO()) {
                    setSimboloO(gj.getSimboloO());
                    simbolo = gj.getSimboloO();
//                    enviar();
//                    tO.start();
                    notify();
                } else if (verificaJogadaX()) {
                    setSimboloX(gj.getSimboloX());
                    simbolo = gj.getSimboloX();
//                    enviar();
//                    tX.start();
                    notify();
                }
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }

    public void enviar() throws InterruptedException{
        try {
            if (verificaJogadaO()) {
                simbolo = gj.getSimboloO();
                oos.writeUTF(simboloO);
                
                oos.flush();
            } else if (verificaJogadaX()) {
                simbolo = gj.getSimboloX();
                oos.writeUTF(simboloX);
                
                oos.flush();
            }
            
            while (socket.isConnected()) {
                String enviar = simbolo;
                oos.writeUTF(enviar);
                
                oos.flush();
            }
        } catch (IOException e) {
            encerraTudo(socket, oos, ois);
        }
    }
    
    public void ouvir(){
        new Thread(new Runnable(){
            @Override
            public void run(){
                String broadcast;
                while(socket.isConnected()){
                    try{
                        broadcast = ois.readUTF();
                        System.out.println(broadcast);
                    } catch(IOException e){
                        encerraTudo(socket, oos, ois);
                    }
                }//fim while
            }//fim run
        }).start();//fim runnable
    }//fim ouvir

    public void encerraTudo(Socket socket, ObjectOutputStream oos, ObjectInputStream ois) {
        try {
            if (ois != null) {
                ois.close();//enquanto tiver leitura não encerra
            }
            if (oos != null) {
                oos.close();//enquanto tiver escrita não encerra
            }
            if (socket != null) {
                socket.close();//enquanto tiver enviando ou recebendo não encerra
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnTres = new javax.swing.JButton();
        btnDois = new javax.swing.JButton();
        btnUm = new javax.swing.JButton();
        btnQuatro = new javax.swing.JButton();
        btnCinco = new javax.swing.JButton();
        btnSeis = new javax.swing.JButton();
        btnNove = new javax.swing.JButton();
        btnOito = new javax.swing.JButton();
        btnSete = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        txtPlacar = new javax.swing.JTextField();
        btnJogarNovamente = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        txtPlacarJog1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtPlacarJog2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        jLabel4.setBackground(new java.awt.Color(51, 204, 255));
        jLabel4.setFont(new java.awt.Font("Yu Gothic Medium", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("JOGO DA VÉIA");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        btnTres.setBackground(new java.awt.Color(255, 255, 255));
        btnTres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTresActionPerformed(evt);
            }
        });

        btnDois.setBackground(new java.awt.Color(255, 255, 255));
        btnDois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoisActionPerformed(evt);
            }
        });

        btnUm.setBackground(new java.awt.Color(255, 255, 255));
        btnUm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUmActionPerformed(evt);
            }
        });

        btnQuatro.setBackground(new java.awt.Color(255, 255, 255));
        btnQuatro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuatroActionPerformed(evt);
            }
        });

        btnCinco.setBackground(new java.awt.Color(255, 255, 255));
        btnCinco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCincoActionPerformed(evt);
            }
        });

        btnSeis.setBackground(new java.awt.Color(255, 255, 255));
        btnSeis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeisActionPerformed(evt);
            }
        });

        btnNove.setBackground(new java.awt.Color(255, 255, 255));
        btnNove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNoveActionPerformed(evt);
            }
        });

        btnOito.setBackground(new java.awt.Color(255, 255, 255));
        btnOito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOitoActionPerformed(evt);
            }
        });

        btnSete.setBackground(new java.awt.Color(255, 255, 255));
        btnSete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnSete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnQuatro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUm, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDois, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCinco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnOito, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTres, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSeis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNove, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE))
                .addGap(46, 46, 46))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDois, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTres, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCinco, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(btnSeis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnQuatro, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnNove, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)
                    .addComponent(btnOito, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));

        txtPlacar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnJogarNovamente.setBackground(new java.awt.Color(51, 204, 255));
        btnJogarNovamente.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnJogarNovamente.setForeground(new java.awt.Color(255, 255, 255));
        btnJogarNovamente.setText("JOGAR NOVAMENTE");
        btnJogarNovamente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJogarNovamenteActionPerformed(evt);
            }
        });

        txtPlacarJog1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtPlacarJog1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPlacarJog1ActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PLACAR:");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("X");

        txtPlacarJog2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtPlacarJog2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPlacarJog2ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("INFORMAÇÕES DO JOGO");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(btnJogarNovamente, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                .addGap(43, 43, 43))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtPlacar)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(txtPlacarJog1, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPlacarJog2, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(txtPlacar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnJogarNovamente, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtPlacarJog2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPlacarJog1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /*Esse método verifica de quem é a vez, se é o jogador 1 ou o jogador 2 */
    public boolean verificaJogadaX() throws InterruptedException {
        //Verificando a vez e apresentando o símbolo (X ou O) do jogador
        if (jogo1 == false && jogo2 == true) {
            this.aux = 2;
            jogo1 = true;
            jogo2 = false;//desativado
            txtPlacar.setText("Vez do jogador X ");
            //Vez do jogador com o símbolo X, podendo escolher o botão
            //txtPlacar.setText(gj.verificaJogada());
            simboloX = gj.getSimboloX();
            gj.setCampos(campos);
           //notify();
            return true;
        }
        //gj.aguardaMudanca();
        //wait();
        return false;
    }
    
    public boolean verificaJogadaO() throws InterruptedException {
        //Verificando a vez e apresentando o símbolo (X ou O) do jogador
        if (jogo1 == true && jogo2 == true) {
            this.aux = 1;
            jogo1 = false;//desativado
            jogo2 = true;
            txtPlacar.setText("Vez do jogador O ");
            //Vez do jogador com o símbolo O, podendo escolher o botão
            //txtPlacar.setText(gj.verificaJogada());
            simboloO = gj.getSimboloO();
            gj.setCampos(campos);
            //notify();
            return true;
        } else if (jogo1 == true && jogo2 == false) {
            this.aux = 1;
            jogo1 = false;//desativado
            jogo2 = true;
            txtPlacar.setText("Vez do jogador O ");
            //txtPlacar.setText(gj.verificaJogada());
            simboloO = gj.getSimboloO();
            gj.setCampos(campos);
            //notify();
            return true;
        }
        //gj.aguardaMudanca();
        //wait();
        return false;
    }

    /*Esse método é utilizado para encontrar o ganhador, verificando em quais botões foram
      atribuídos o símbolo "X" e "O" e mostrar o resultado*/
    public void encontraGanhador() {
        /*Abaixo está sendo apresentado em qual posição os botões são considerados 
        diagonais, linhas e colunas, no caso 3 posições para cada*/
        d1 = campos[0][0] + campos[1][1] + campos[2][2];
        d2 = campos[0][2] + campos[1][1] + campos[2][0];

        l1 = campos[0][0] + campos[0][1] + campos[0][2];
        l2 = campos[1][0] + campos[1][1] + campos[1][2];
        l3 = campos[2][0] + campos[2][1] + campos[2][2];

        c1 = campos[0][0] + campos[1][0] + campos[2][0];
        c2 = campos[0][1] + campos[1][1] + campos[2][1];
        c3 = campos[0][2] + campos[1][2] + campos[2][2];

        //se tiver três X nas linhas, ou nas colunas ou nas diagonais quem ganhou essa rodada foi Jogador 1
        //com isso, chama o método bloqueiaJogadas e apresenta o ganhador
        if (l1.equals("XXX") || l2.equals("XXX") || l3.equals("XXX") || c1.equals("XXX") || c2.equals("XXX") || c3.equals("XXX") || d1.equals("XXX") || d2.equals("XXX")) {
            txtPlacar.setText("Quem ganhou está rodada foi X "/* + jogador1*/);
            bloqueiaJogadas();
            placarX = placarX + auxX;
            txtPlacarJog1.setText("X: " + placarX);
            //txtPlacarJog1.setText(gj.encontraGanhador());
            //se tiver três O nas linhas, ou nas colunas ou nas diagonais quem ganhou essa rodada foi Jogador 2
            //com isso, chama o método bloqueiaJogadas e apresenta o ganhador
        } else if (l1.equals("OOO") || l2.equals("OOO") || l3.equals("OOO") || c1.equals("OOO") || c2.equals("OOO") || c3.equals("OOO") || d1.equals("OOO") || d2.equals("OOO")) {
            txtPlacar.setText("Quem ganhou está rodada foi O ");
            bloqueiaJogadas();
            placarO = placarO + auxO;
            txtPlacarJog2.setText("O: " + placarO);
            //txtPlacarJog2.setText(gj.encontraGanhador());
            /*Se nenhum dos símbolos fecha 3, não sendo igual ao que atribuimos nas linhas,
            colunas e diagonais, dará velha*/
        } else if (cnt == 9) {
            txtPlacar.setText("Deu velha! Ninguém ganhou a rodada!");
        }
    }

    //Após o jogador clicar no botão, o botão será bloqueado mostrando o símbolo de X ou O
    public void bloqueiaJogadas() {
        btnUm.setEnabled(false);
        btnDois.setEnabled(false);
        btnTres.setEnabled(false);
        btnQuatro.setEnabled(false);
        btnCinco.setEnabled(false);
        btnSeis.setEnabled(false);
        btnSete.setEnabled(false);
        btnOito.setEnabled(false);
        btnNove.setEnabled(false);
    }
    
    public void verificaCampos(){
        if(!gj.getCampos().equals(campos)){
            gj.setCampos(campos);
        }
    }

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão UM, fixará e apresentará o mesmo
    private void btnUmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUmActionPerformed
        try {
            // botãoum
            
            if (verificaJogadaX()) {
                btnUm.setText(simboloX);
                campos[0][0] = simboloX;
                gj.setCampos(campos);
                btnUm.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnUm.setText(simboloO);
                campos[0][0] = simboloO;
                gj.setCampos(campos);
                btnUm.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnUmActionPerformed

    //Aqui habilitará tudo novamente, chamando o método limpaCampos 
    private void btnJogarNovamenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJogarNovamenteActionPerformed
        btnUm.setText("");
        btnUm.setEnabled(true);
        btnDois.setText("");
        btnDois.setEnabled(true);
        btnTres.setText("");
        btnTres.setEnabled(true);
        btnQuatro.setText("");
        btnQuatro.setEnabled(true);
        btnCinco.setText("");
        btnCinco.setEnabled(true);
        btnSeis.setText("");
        btnSeis.setEnabled(true);
        btnSete.setText("");
        btnSete.setEnabled(true);
        btnOito.setText("");
        btnOito.setEnabled(true);
        btnNove.setText("");
        btnNove.setEnabled(true);
        limpaCampos();
        txtPlacar.setText("");
        jogo1 = true;
        jogo2 = true;
    }//GEN-LAST:event_btnJogarNovamenteActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão DOIS, fixará e apresentará o mesmo
    private void btnDoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoisActionPerformed
        try {
            // botãodois
            if (verificaJogadaX()) {
                btnDois.setText(simboloX);
                campos[0][1] = simboloX;
                gj.setCampos(campos);
                btnDois.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnDois.setText(simboloO);
                campos[0][1] = simboloO;
                gj.setCampos(campos);
                btnDois.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnDoisActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão TRÊS, fixará e apresentará o mesmo
    private void btnTresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTresActionPerformed
        try {
            // botãotres
            if (verificaJogadaX()) {
                btnTres.setText(simboloX);
                campos[0][2] = simboloX;
                gj.setCampos(campos);
                btnTres.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnTres.setText(simboloO);
                campos[0][2] = simboloO;
                gj.setCampos(campos);
                btnTres.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnTresActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão QUATRO, fixará e apresentará o mesmo
    private void btnQuatroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuatroActionPerformed
        try {
            // botãoquatro
            if (verificaJogadaX()) {
                btnQuatro.setText(simboloX);
                campos[1][0] = simboloX;
                gj.setCampos(campos);
                btnQuatro.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnQuatro.setText(simboloO);
                campos[1][0] = simboloO;
                gj.setCampos(campos);
                btnQuatro.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnQuatroActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão CINCO, fixará e apresentará o mesmo
    private void btnCincoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCincoActionPerformed
        try {
            // botãocinco
            if (verificaJogadaX()) {
                btnCinco.setText(simboloX);
                campos[1][1] = simboloX;
                gj.setCampos(campos);
                btnCinco.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnCinco.setText(simboloO);
                campos[1][1] = simboloO;
                gj.setCampos(campos);
                btnCinco.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCincoActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão SEIS, fixará e apresentará o mesmo
    private void btnSeisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeisActionPerformed
        try {
            // botãoseis
            if (verificaJogadaX()) {
                btnSeis.setText(simboloX);
                campos[1][2] = simboloX;
                gj.setCampos(campos);
                btnSeis.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnSeis.setText(simboloO);
                campos[1][2] = simboloO;
                gj.setCampos(campos);
                btnSeis.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnSeisActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão SETE, fixará e apresentará o mesmo
    private void btnSeteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeteActionPerformed
        try {
            // botãosete
            if (verificaJogadaX()) {
                btnSete.setText(simboloX);
                campos[2][0] = simboloX;
                gj.setCampos(campos);
                btnSete.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnSete.setText(simboloO);
                campos[2][0] = simboloO;
                gj.setCampos(campos);
                btnSete.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnSeteActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão OITO, fixará e apresentará o mesmo
    private void btnOitoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOitoActionPerformed
        try {
            //botãooito
            if (verificaJogadaX()) {
                btnOito.setText(simboloX);
                campos[2][1] = simboloX;
                gj.setCampos(campos);
                btnOito.setEnabled(false);
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnOito.setText(simboloO);
                campos[2][1] = simboloO;
                gj.setCampos(campos);
                btnOito.setEnabled(false);
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnOitoActionPerformed

    //Após clicar no botão é verificado se é X ou O e quem é o jogador.
    //Sabendo que o símbolo será posicionado neste botão NOVE, fixará e apresentará o mesmo
    private void btnNoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNoveActionPerformed
        try {
//botãonove
            if (verificaJogadaX()) {
                btnNove.setText(simboloX);
                campos[2][2] = simboloX;
                gj.setCampos(campos);
                btnNove.setEnabled(false);//Desabilitado, pois algum símbolo está aplicado
                deuVelha();
                encontraGanhador();
            } else if (verificaJogadaO()){
                btnNove.setText(simboloO);
                campos[2][2] = simboloO;
                gj.setCampos(campos);
                btnNove.setEnabled(false);//Desabilitado, pois algum símbolo está aplicado
                deuVelha();
                encontraGanhador();
            }

            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnNoveActionPerformed

    private void txtPlacarJog1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPlacarJog1ActionPerformed

    }//GEN-LAST:event_txtPlacarJog1ActionPerformed

    private void txtPlacarJog2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPlacarJog2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPlacarJog2ActionPerformed
    //Método para limpar os campos
    public void limpaCampos() {
        for (i = 0; i < 3; i++) {
            for (k = 0; k < 3; k++) {
                campos[i][k] = "";
                gj.setCampos(campos);
            }
        }
    }
    
    public synchronized void aguardaMudanca() throws InterruptedException{
        while(!verifica){//enquanto verifica for verdadeiro
            wait();
            //a thread deve esperar a outra terminar seu
            //processo e assim por diante
        }
        //quando as threads terminarem seus processos e
        //sair do while o verifica ira receber o valor 
        //falso pois os processos já terminaram
        verifica = false;
    }
    
    public synchronized void fim(){
        gj.setGanhador(true);
        this.termina = true;
    }

    public static void main(String args[]) throws IOException, InterruptedException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Jogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Jogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Jogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Jogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        String nomeUser = JOptionPane.showInputDialog(null, "Digite o nome do jogador: ");
        Socket socket = new Socket("localhost", 1286);

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Jogo().setVisible(true);
            }
        });

        Jogo jg = new Jogo(socket, nomeUser);
        while(jg.getCampos().length<9){
            jg.aguardaMudanca();
            
            if(jg.getSimbolo().equals("O")){
                jg.verificaJogadaO();
                jg.enviar();
                jg.ouvir();
//                jg.verificaCampos();
            }else{
                 jg.verificaJogadaX();
                 jg.enviar();
                 jg.ouvir();
//                 jg.verificaCampos();
            }
        }
        jg.fim();
        //jg.enviar();
    }

    /* Se "X" e "O" não estão ocupando 3 linhas, ou 3 colunas ou 3 diagonais, 
    será verificado assim dará velha*/
    public void deuVelha() {
        cnt = 0;
        for (i = 0; i < 3; i++) {
            for (k = 0; k < 3; k++) {
                if (campos[i][k] == "X" || campos[i][k] == "O") {
                    cnt++;
                }
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCinco;
    private javax.swing.JButton btnDois;
    private javax.swing.JButton btnJogarNovamente;
    private javax.swing.JButton btnNove;
    private javax.swing.JButton btnOito;
    private javax.swing.JButton btnQuatro;
    private javax.swing.JButton btnSeis;
    private javax.swing.JButton btnSete;
    private javax.swing.JButton btnTres;
    private javax.swing.JButton btnUm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField txtPlacar;
    private javax.swing.JTextField txtPlacarJog1;
    private javax.swing.JTextField txtPlacarJog2;
    // End of variables declaration//GEN-END:variables
}
