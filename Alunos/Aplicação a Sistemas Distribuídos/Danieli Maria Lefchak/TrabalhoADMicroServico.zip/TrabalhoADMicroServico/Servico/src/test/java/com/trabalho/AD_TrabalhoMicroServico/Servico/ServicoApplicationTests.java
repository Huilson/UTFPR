package com.trabalho.AD_TrabalhoMicroServico.Servico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
