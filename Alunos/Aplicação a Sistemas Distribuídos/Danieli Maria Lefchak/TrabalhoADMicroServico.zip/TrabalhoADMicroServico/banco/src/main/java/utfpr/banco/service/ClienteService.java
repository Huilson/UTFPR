package utfpr.banco.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import utfpr.banco.model.Cliente;
import utfpr.banco.model.Conta;
import utfpr.banco.repository.ClienteRepository;
import utfpr.banco.repository.ContaRepository;

/**
 *
 * @author Analice
 */
@Service
public class ClienteService {

    @Autowired
    ClienteRepository clienteRepository;

    public Cliente getClienteById(String id) {
        Optional<Cliente> cl = clienteRepository.findById(id);
        Cliente cliente = null;
        if (cl.isPresent()) {
            cliente = cl.get();
        } else {
            throw new RuntimeException("Cliente não encontrado, o id: " + id + " não foi encontrado.");
        }
        return cliente;
    }

    public void deleteClienteById(String id) {
        clienteRepository.deleteById(id);
    }

}
