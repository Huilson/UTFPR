//package utfpr.banco.repository;
//
//import org.springframework.data.mongodb.repository.MongoRepository;
//import utfpr.banco.model.Funcionario;
//
///**
// *
// * @author Analice
// */
//public interface FuncionarioRepository extends MongoRepository<Funcionario, Object>{
//    
//}
