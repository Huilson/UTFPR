package utfpr.banco.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import utfpr.banco.model.Conta;
import utfpr.banco.repository.ContaRepository;

/**
 *
 * @author Analice
 */
@Service
public class ReportService {

    @Autowired(required = true)
    private ContaRepository contaRepository;

    public String exportReport(String reportFormat) throws FileNotFoundException, JRException {
        String path = "C:\\Users\\User\\Desktop\\Report";

        List<Conta> contas = contaRepository.findAll();

        //Aqui irá carregar os arquivos e compilar os mesmos
        File arquivo = ResourceUtils.getFile("classpath:Conta.jrxml");

        JasperReport jasperReport = JasperCompileManager.compileReport(arquivo.getAbsolutePath());

        //compila e serializa os dados do banco mongo
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(contas);

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("Criado por Analice", "Moschen");

        //cria o relatorio com os seguintes atributos: objeto compilado, parametros ded criação, base de dados no nosso banco
        JasperPrint relatorio = JasperFillManager
                .fillReport(jasperReport, parameters, dataSource);

//        //se buscarmos na URL por html, esse relatorio sera gerado
//        if (reportFormat.equalsIgnoreCase("html")) {
//            JasperExportManager.exportReportToHtmlFile(relatorio, path + "\\conta.html");
//        }
        //se buscarmos na URL por pdf, esse relatorio sera gerado
        if (reportFormat.equalsIgnoreCase("pdf")) {
            JasperExportManager.exportReportToPdfFile(relatorio, path + "\\conta.pdf");
        }

        return "report genetared in path " + path;
    }
}
