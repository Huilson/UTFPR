package utfpr.banco.dto;

import javax.validation.constraints.NotBlank;
import utfpr.banco.model.Cliente;
/**
 *
 * @author Analice
 */
public class NovoCliente {

    @NotBlank
    private String nome;
    private String endereco;
    private String profissao;
//    private Pessoa pessoa;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public Cliente toCliente() {
        Cliente cliente = new Cliente();
        cliente.setNome(nome);
        cliente.setEndereco(endereco);
        cliente.setProfissao(profissao);
//        cliente.(pessoa);
//        conta.getCliente()
        return cliente;
    }
}
