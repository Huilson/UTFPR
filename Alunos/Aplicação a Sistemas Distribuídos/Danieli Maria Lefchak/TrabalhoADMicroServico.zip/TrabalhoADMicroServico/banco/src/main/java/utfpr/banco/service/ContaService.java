package utfpr.banco.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import utfpr.banco.http.PetShopClient;
import utfpr.banco.model.Conta;
import utfpr.banco.model.Status;
import utfpr.banco.repository.ContaRepository;

import javax.persistence.EntityNotFoundException;
import org.springframework.web.bind.annotation.PatchMapping;

/**
 *
 * @author Analice
 */
@Service
public class ContaService {

    @Autowired
    ContaRepository contaRepository;

    @Autowired
    private PetShopClient servico;

    public Conta getContaSaque(Conta conta, double valor) {
        double saldo = conta.getSaldo();

        if (valor <= saldo) {
            double aux = saldo-valor;

            conta.setSaldo(aux);

            contaRepository.save(conta);

            return conta;
        } else{
            throw new RuntimeException("Conta não possui o saldo suficiente");
        }
    }
    
    @PatchMapping
    public void confirmaSaque(Long conta, double valor){
        Conta cont = contaRepository.findBynumero(conta);
        System.out.println("confirmaSaque: " + cont);
        
        if(cont == null){
            throw new EntityNotFoundException();
        }
        if(valor<=cont.getSaldo()){
            servico.atualizaPagamento(cont.getNumero(), valor);
            cont= getContaSaque(cont, valor);
            cont.setStatus(Status.REALIZADO);
            contaRepository.save(cont);
            System.out.println("confirmaSaque 1: " + cont);
            
        } else if(valor>=cont.getSaldo()){
            servico.atualizaPagamento(cont.getNumero(), valor);
            cont.setStatus(Status.NAO_AUTORIZADO);
            contaRepository.save(cont);
            System.out.println("confirmaSaque 2: " + cont);
            
        } else if(valor==0){
            servico.atualizaPagamento(cont.getNumero(), valor);
            cont.setStatus(Status.NAO_PAGO);
            contaRepository.save(cont);
            System.out.println("confirmaSaque 3: " + cont);
            
        }
    }

    public Conta getContaDeposido(Conta conta, double valor) {
        double saldo = conta.getSaldo();

        double aux = saldo+valor;

        conta.setSaldo(aux);

        contaRepository.save(conta);

        return conta;
    }

    public void deleteContaById(String id) {
        contaRepository.deleteById(id);
    }
}
