package utfpr.banco.model;

public enum Status {
    REALIZADO,
    NAO_AUTORIZADO,
    NAO_PAGO;
}
