package utfpr.banco.model;

import javax.persistence.JoinColumn;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author Analice
 */
@Document
public class Cliente {
    
    @Id
    private String id;

    private String nome;
    private String endereco;
    private String profissao;

    
//    Get e Set
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    
     public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }
    
    @Override
    public String toString() {
        return "Cliente: " + nome +
                " | Endereço: " + endereco + 
                " | Profissão: " + profissao;
    }

    
    
    
}
