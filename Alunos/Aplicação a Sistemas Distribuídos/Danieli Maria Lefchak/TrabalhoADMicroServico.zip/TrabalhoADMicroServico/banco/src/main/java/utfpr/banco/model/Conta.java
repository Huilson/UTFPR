package utfpr.banco.model;

import java.text.DecimalFormat;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author Analice
 */
//@Entity
@Document
@Data
//@Table(name = "conta")
public class Conta {

    @Id
    private String idConta;
    private long numero;
    private double saldo;
    private double valor;
    private String tipo;

    private Status status;

    private Cliente cliente;
//    public Conta() {
//    }
//
//    public Conta(long numero, double saldo, String tipo, Cliente cliente) {
//        this.numero = numero;
//        this.saldo = saldo;
//        this.tipo = tipo;
//        this.cliente = cliente;
//    }

//    public String getIdConta() {
//        return idConta;
//    }
//
//    public void setIdConta(String idConta) {
//        this.idConta = idConta;
//    }
//
//    public long getNumero() {
//        return numero;
//    }
//
//    public void setNumero(long numero) {
//        this.numero = numero;
//    }
//
//    public String getTipo() {
//        return tipo;
//    }
//
//    public void setTipo(String tipo) {
//        this.tipo = tipo;
//    }
//
//    public double getSaldo() {
//        return saldo;
//    }
//
//    public void setSaldo(double saldo) {
//        this.saldo = saldo;
//    }
//
//    public double getValor() {
//        return valor;
//    }
//
//    public void setValor(double valor) {
//        this.valor = valor;
//    }
////    public boolean setSaldo(double s) {
////        /*if (s >= 0) {
////            saldo = s;
////            return true;
////
////        } else {
////            saldo = 0;
////        }*/
////        if (s <= 0) {
////            //saldo = 0;
////            return false;
////
////        } else if (saldo > 0) {
////            saldo = s;
////        }
////        return true;
////    }
//
//    /*Se o valor informado pelo cliente para o dep�sito
//    for maior que 0, o valor ser� somado com o saldo, retornando o saldo atual*/
////    public void depositar() {
////        if (valor > 0) {
////            saldo += valor;
////        }
////    }
//
//    /*Se o valor informado pelo cliente para sacar
//     for maior que saldo, n�o ser� poss�vel fazer o saque, s
//    sendo necess�rio informar outro  valor.
//    Mas se o valor existir na conta ser� diminu�do com o saldo
//    retonando o saldo atual*/
////    double valor
//    public boolean sacar() {
//        if (valor > saldo) {
//            return false;
//        } else if (valor > 0) {
//            saldo -= valor;
//        }
//        return true;
//    }
//
//    public Cliente getCliente() {
//        return cliente;
//    }
//
//
//    public void setCliente(Cliente cliente) {
//        this.cliente = cliente;
//    }
//
    
    @Override
    public String toString() {
        DecimalFormat formatador = new DecimalFormat("R$ #, ##0.00");
        String saldoFormatado = formatador.format(saldo);
        /*return ("Saldo da conta" + numero ": " + saldoFormatado);*/
        return "\n Conta de " + cliente
                + "\nN�mero da conta: " + numero
                + "\nTipo: " + tipo
                + "\nSaldo da conta: " + saldoFormatado;
    }
}
