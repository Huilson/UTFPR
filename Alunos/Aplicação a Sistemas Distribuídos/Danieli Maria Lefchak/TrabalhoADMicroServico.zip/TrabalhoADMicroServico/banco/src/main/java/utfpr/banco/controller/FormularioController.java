package utfpr.banco.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import utfpr.banco.dto.NovaConta;
import utfpr.banco.dto.NovoCliente;
import utfpr.banco.model.Cliente;
import utfpr.banco.model.Conta;
import utfpr.banco.repository.ClienteRepository;
import utfpr.banco.repository.ContaRepository;

/**
 *
 * @author Analice
 */
@Controller
@RequestMapping("criacao")
public class FormularioController {

    @Autowired//faz a injenção do que é necessário para funcionar os métodos de outras classes
    private ContaRepository contaRepository;
    @Autowired
    private ClienteRepository clienteRepository;
//    @Autowired
//    private PessoaRepository pessoaRepository;

    //pessoa/cliente/conta 
//    @GetMapping("formularioPessoa")
//    public String formularioPessoa(NovaPessoa novaPessoa) {
//        return "criacao/formularioPessoa";
//    }
//
//    @PostMapping("novapessoa")
//    public String novaPessoa(@Valid NovaPessoa novaPessoa, BindingResult result) {
//
//        if (result.hasErrors()) {
//            return "criacao/formularioPessoa";
//        }
//        Pessoa pessoa = novaPessoa.toPessoa();
//        pessoaRepository.save(pessoa);
//
//        return "redirect:/criacao/formularioCliente";
//    }
    @GetMapping("formularioCliente")
    public String formularioCliente(NovoCliente novoCliente) {
        return "criacao/formularioCliente";
    }

    @PostMapping("novocliente")
    public String novoCliente(@Valid NovoCliente novoCliente, BindingResult result, RedirectAttributes ra) {

        if (result.hasErrors()) {
            return "criacao/formularioCliente";
        }
        Cliente cliente = novoCliente.toCliente();
        clienteRepository.save(cliente);

        ra.addFlashAttribute("success", "Cadastro do cliente, efetuado com sucesso!");
        return "redirect:/criacao/formularioCliente";
    }

    @GetMapping("formularioConta")
    public String formulario(NovaConta requisicao) {
        return "criacao/formularioConta";
    }

    @PostMapping("novaconta")
    public String novaConta(@Valid NovaConta requisicao, BindingResult result, RedirectAttributes raa) {

        if (result.hasErrors()) {
            return "criacao/formularioConta";
        }

        Conta conta = requisicao.toConta();
        contaRepository.save(conta);
//        Pessoa pessoa = comparar(comparar, model);
        raa.addFlashAttribute("success", "Sua conta foi cadastrada com sucesso!");
        return "redirect:/criacao/formularioConta";
    }

    @GetMapping("/buscar/{id}")
    public String buscar(@PathVariable("id") String id, Model model) {
        Cliente cliente = clienteRepository.findById(id).orElseThrow();
        model.addAttribute("cliente", cliente);
        return "index";
    }

}
