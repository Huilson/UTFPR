package utfpr.banco.http;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import utfpr.banco.model.Conta;

@FeignClient("petshop-ms")
public interface PetShopClient {
    @RequestMapping(method = RequestMethod.POST, value="pagamento/enviar/{conta}/{val}")
    void atualizaPagamento(@RequestParam(value = "conta") Long numConta, @RequestParam(value = "val") double valor);
}
