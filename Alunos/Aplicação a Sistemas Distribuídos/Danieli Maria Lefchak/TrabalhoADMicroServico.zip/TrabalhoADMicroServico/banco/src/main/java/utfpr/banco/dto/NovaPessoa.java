//package utfpr.banco.dto;
//
//import javax.validation.constraints.NotBlank;
//import utfpr.banco.model.Pessoa;
//
///**
// *
// * @author Analice
// */
//public class NovaPessoa {
//    
//    @NotBlank
//    private String nome;
//
//    public String getNome() {
//        return nome;
//    }
//
//    public void setNome(String nome) {
//        this.nome = nome;
//    }
//    
//     public Pessoa toPessoa() {
//        Pessoa pessoa = new Pessoa();
//        pessoa.setNome(nome);
//     
//        return pessoa;
//    }
//    
//}
