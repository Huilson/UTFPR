package utfpr.banco.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import utfpr.banco.model.Cliente;
import utfpr.banco.model.Conta;

/**
 *
 * @author Analice
 */
public class NovaConta {

    @NotNull
    private Long numero;
    private double saldo;
    private String tipo;
    private double valor;
    private Cliente cliente;

    
    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Conta toConta(){
        Conta conta = new Conta();
        conta.setNumero(numero);
        conta.setSaldo(saldo);
        conta.setTipo(tipo);
        conta.setValor(valor);
        conta.setCliente(cliente);
//        conta.getCliente()
        return conta;
    }
}
