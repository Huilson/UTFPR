package com.trabalho.OO_Trabalho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OoTrabalhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
