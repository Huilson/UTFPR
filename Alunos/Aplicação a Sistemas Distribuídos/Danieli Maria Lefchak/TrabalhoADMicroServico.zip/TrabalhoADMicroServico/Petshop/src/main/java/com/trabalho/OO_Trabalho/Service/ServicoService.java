package com.trabalho.OO_Trabalho.Service;

import com.trabalho.OO_Trabalho.Dto.StatusDto;
import com.trabalho.OO_Trabalho.Model.Servicos;
import com.trabalho.OO_Trabalho.Model.Status;
import com.trabalho.OO_Trabalho.Repository.ServicoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ServicoService {
    @Autowired
    private ServicoRepository repository;

    public Servicos atualizaStatus(Long conta, StatusDto dto) {
        Optional<Servicos> servico = Optional.of(repository.findByAccountNumber(conta));
        System.out.println("atualizaStatus: " + servico);
        
        if (servico == null) {
            throw new EntityNotFoundException();
        }

        servico.get().setStatus(dto.getStatus());
        repository.atualizaStatus(dto.getStatus(), servico.get().getConta());
        
        System.out.println("atualizaStatus atualizado : " + servico);
        return servico.get();
    }

    public void aprovaPagamento(Long conta) {
        Servicos servico = repository.findByAccountNumber(conta);
        System.out.println("aprovaPagamento conta: " + servico);
        
        if (servico == null) {
            throw new EntityNotFoundException();
        } else{
            servico.setStatus(Status.REALIZADO);
            repository.atualizaStatus(Status.REALIZADO, servico.getIdServ());
        } 
    }
}
