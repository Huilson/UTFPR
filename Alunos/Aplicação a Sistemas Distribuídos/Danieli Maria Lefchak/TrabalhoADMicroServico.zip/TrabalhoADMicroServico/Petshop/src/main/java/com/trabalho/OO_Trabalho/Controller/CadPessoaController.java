/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Dto.PessoaDto;
import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Repository.PessoaRepository;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author danie
 */
@Controller
@RequestMapping("/CadastrarPessoas")
public class CadPessoaController {
    @Autowired
    private PessoaRepository repository;
    
    //metodo que mostra o fomulario de pessoas
    @GetMapping("/Pessoas")
    public String formulario(PessoaDto pessoa) {
        return "Formularios/FormularioDeCadastroPessoas";
    }
    
    //metodo responsavel pelo cadastro de uma nova pessoa
    @PostMapping("novaPessoa")
    public String cadastrar(@Valid PessoaDto pessoa, BindingResult result){
        if(result.hasErrors()){
            return "Formularios/FormularioDeCadastroPessoas";
        }
        
        Pessoa p = pessoa.toPessoa();
        System.out.println(p.toString());
        repository.save(p);
        return "redirect:/CadastrarAnimal/animal";
    }
}
