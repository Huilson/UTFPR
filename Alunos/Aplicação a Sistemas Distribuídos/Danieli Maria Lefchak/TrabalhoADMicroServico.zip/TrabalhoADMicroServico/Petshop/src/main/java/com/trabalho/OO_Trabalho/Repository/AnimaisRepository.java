/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.trabalho.OO_Trabalho.Repository;

import com.trabalho.OO_Trabalho.Model.Animal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


/**
 *
 * @author danie
 */
public interface AnimaisRepository extends JpaRepository<Animal, Long>{
    Animal findBynome(String nome);//chama o metodo que ira fazer uma busca por nomes no banco
    
    //cria a query responsavel pela busca dos atendimentos ainda não realizados que será usada
    //no metodo que está "findatendimento"
    @Query(value = "select a from Animal a join a.atendimento d where d.idAten = a.atendimento.idAten and d.dt>=CURRENT_DATE")
    List<Animal> findatendimentoByDate();
    
    @Query(value = "SELECT s from Animal s where s.servico.conta = :conta")
    Animal findByAccountNumber(Long conta);
}
