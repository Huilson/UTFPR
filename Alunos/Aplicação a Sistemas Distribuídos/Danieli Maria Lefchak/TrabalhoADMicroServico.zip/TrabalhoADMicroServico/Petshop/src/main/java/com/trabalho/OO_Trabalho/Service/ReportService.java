/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Service;

import com.trabalho.OO_Trabalho.Model.Animal;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

/**
 *
 * @author danie
 */
@Service
public class ReportService {
    @Autowired
    private AnimalService service;
    
    public String exportReport() throws FileNotFoundException, JRException{
        //variavel que contem o destino dos relatorios        
        String path = "C:\\Users\\danie\\Desktop\\Report";
        
        List<Animal> animal = service.getData();
        
        //carregar os arquivos e compila eles tanto em pdf como em html
        File arquivo = ResourceUtils.getFile("classpath:agendamento.jrxml");
        JasperReport jasperReport = JasperCompileManager.compileReport(arquivo.getAbsolutePath());
        
        //compila "serializa" os dados do banco
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(animal);
        
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("Criado por: ", "Danieli");
        
        //cria o relatorio com os seguintes atributos: objeto compilado, parametros de criacao, base de dados no nosso banco
        JasperPrint relatorio = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
        
        //se buscarmos na url por pdf, esse relatorio sera gerado
        JasperExportManager.exportReportToPdfFile(relatorio, path + "\\agendamento.pdf");
        
        
        return "Arquivo gerado em: " + path;
    }
    
    
}
