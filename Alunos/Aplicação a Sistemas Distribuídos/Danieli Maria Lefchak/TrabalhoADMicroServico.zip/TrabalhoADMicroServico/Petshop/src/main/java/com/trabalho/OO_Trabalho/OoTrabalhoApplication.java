package com.trabalho.OO_Trabalho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableEurekaClient
//@EnableFeignClients(value = "petshop-ms")
@SpringBootApplication
@EnableWebMvc
public class OoTrabalhoApplication {

    public static void main(String[] args) {
        SpringApplication.run(OoTrabalhoApplication.class, args);
    }
}
