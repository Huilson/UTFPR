package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Repository.AnimaisRepository;
import com.trabalho.OO_Trabalho.Service.AnimalService;

import java.net.URI;
import java.util.List;

import com.trabalho.OO_Trabalho.Service.ServicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

@Controller
@RequestMapping("/home")
public class HomeController {
    @Autowired
    private AnimaisRepository repository;

    @Autowired
    private AnimalService service;

    @Autowired
    private ServicoService servService;

    //metodo responsavel por mostrar todos os animais cadastrados na home
    @GetMapping
    public String home(Model model) {
        List<Animal> animais = repository.findAll();
        model.addAttribute("animais", animais);
        return "/home";
    }
    
    //metodo responsavel pro slavar um animal
    @PostMapping("salvar")
    public String salvar(@ModelAttribute("animal") Animal animal) {
        repository.save(animal);
        return "redirect:/home";
    }
    
    //metodo responsavel por atualizar o registro de um animal
    @GetMapping("/formularioAtualizado/{idAni}")
    public String formularioAtualizado(@PathVariable(value = "idAni") Long id, Model model) {
        Animal animal = service.getAnimalById(id);
        model.addAttribute("animal", animal);
        return "formulario_atualiza";
    }
    
    //metodo responsavel por excluir um animal
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable (value="id") Long id){
        service.deletePedidoById(id);
        return "redirect:/home";
    }
    
    //metodo que ira pegar o nome digitado no campo da pesquisa
    @GetMapping("/pesquisaNome")
    public String pesquisaNome(){
        return "pesquisaNome";
    }
    
    //metodo que irá retornar um nome pesquisado na url
    @GetMapping("/findName/{name}")
    public ResponseEntity<Animal> findByName(@PathVariable String name){
	return ResponseEntity.ok(service.findByname(name));
    }
    
    //metodo que ira buscar o nome digitado no metodo "pesquisaNome"
    @PostMapping("pesquisaCompleta")
    public String pesquisar(@RequestParam(value= "campoPesquisa")String campoPesquisa, Model model){
        System.out.println(campoPesquisa); 
        model.addAttribute("animais", repository.findBynome(campoPesquisa));
        
        return "/home";
    }
    
    //metodo que irá retornar um id pesquisado na url
    @GetMapping("{id}")
    public String buscar(@PathVariable("id") Long id, Model model){
        Animal animal = repository.findById(id).orElseThrow();
        model.addAttribute("animal", animal);
        return "home";
    }
    
    //metodo reponsave por mostrar a lista de servicos nao realizados
    @GetMapping("servicosAindaNaoRealizados")
    public String listaAtendimentos(Model model) {
        List<Animal> animais = repository.findAll();
        model.addAttribute("animais", animais);
        return "/servicosAindaNaoRealizados";
    }
}