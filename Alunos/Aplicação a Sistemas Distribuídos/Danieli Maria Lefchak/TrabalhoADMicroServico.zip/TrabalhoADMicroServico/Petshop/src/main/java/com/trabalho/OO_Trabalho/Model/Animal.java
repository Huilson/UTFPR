/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Model;

import java.io.Serializable;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author danie
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Animal implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAni;
    
    private String nome;
    private String especie;
    
    @ManyToOne
    @JoinColumn(name="idPes")
    private Pessoa tutor;
    
    @ManyToOne
    @JoinColumn(name="idServ")
    private Servicos servico;
    
    @ManyToOne
    @JoinColumn(name="idAten")
    private Atendimento atendimento;
    
    @Override
    public String toString() {
        return " Nome do animal: " + nome + ", especie: " + especie + tutor + servico + atendimento;
    }
}
