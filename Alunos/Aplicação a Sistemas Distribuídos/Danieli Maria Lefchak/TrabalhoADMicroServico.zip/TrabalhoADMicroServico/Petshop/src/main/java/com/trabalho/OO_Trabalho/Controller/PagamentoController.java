/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Repository.AnimaisRepository;
import com.trabalho.OO_Trabalho.Service.AnimalService;
import com.trabalho.OO_Trabalho.Service.ServicoService;
import java.net.URI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriComponentsBuilder;

/**
 *
 * @author danie
 */
@Controller
@RequestMapping("pagamento")
public class PagamentoController {
    @Autowired
    private AnimaisRepository repository;
    
    @Autowired
    private AnimalService service;
    
    @Autowired
    private ServicoService servService;
    
    @GetMapping("RealizaPag/{idAni}")
    public String aprovaPagamento(@PathVariable(value = "idAni") Long id, Model model) {
        Animal animal = service.getAnimalById(id);
        model.addAttribute("animal", animal);

        Long numConta = animal.getServico().getConta();
        
        System.out.println("numConta " + numConta);
        
        servService.aprovaPagamento(numConta);

        return "pagamento";
    }
    
    @PatchMapping
    @PostMapping("/enviar/{conta}")
    public String realizaPagamento(@PathVariable(value = "conta") Long numConta, UriComponentsBuilder uriBuilder) {
        System.out.println("realizaPagamento numconta " + numConta);
        Animal pagamento = repository.findByAccountNumber(numConta);
        
        System.out.println("realizaPagamento valor " + pagamento.getServico().getVal());
        
        URI endereco = uriBuilder.path("pagamento/enviar/{conta}/{val}").buildAndExpand(numConta, pagamento.getServico().getVal()).toUri();
        
        return "redirect:/petshop-ms/home";
    }
}
