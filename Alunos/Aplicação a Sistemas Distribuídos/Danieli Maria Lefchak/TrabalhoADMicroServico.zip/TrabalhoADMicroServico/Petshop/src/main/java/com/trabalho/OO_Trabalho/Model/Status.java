package com.trabalho.OO_Trabalho.Model;

public enum Status {
    REALIZADO,
    NAO_AUTORIZADO,
    NAO_PAGO;
}
