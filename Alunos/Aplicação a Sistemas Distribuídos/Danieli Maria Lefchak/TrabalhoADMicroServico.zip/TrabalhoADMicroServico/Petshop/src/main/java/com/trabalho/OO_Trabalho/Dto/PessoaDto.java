/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Dto;

import com.trabalho.OO_Trabalho.Model.Pessoa;
import lombok.Data;

/**
 *
 * @author danie
 */
@Data
public class PessoaDto {
    private String nomeTutor;
    private String tel;
    
    //metodo que converte um dto em Pessoa
    public Pessoa toPessoa(){
        Pessoa pessoa = new Pessoa();
        pessoa.setNomeTutor(nomeTutor);
        pessoa.setTel(tel);
        
        return pessoa;
    }
}
