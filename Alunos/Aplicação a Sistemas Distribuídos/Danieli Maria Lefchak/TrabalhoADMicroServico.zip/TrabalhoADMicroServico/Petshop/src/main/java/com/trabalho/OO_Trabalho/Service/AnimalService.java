/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Service;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Repository.AnimaisRepository;
import com.trabalho.OO_Trabalho.Repository.AtendimentoRepository;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author danie
 */
@Service
public class AnimalService {
    @Autowired
    AnimaisRepository repository;
    
    @Autowired
    AtendimentoRepository atendRepository;
    
    //implementação do metodo responsavel pela busca por id
    public Animal getAnimalById(Long id) {
        Optional<Animal> op = repository.findById(id);
        Animal animal = null;
        
        if (op.isPresent()) {
            animal = op.get();
        } else {
            throw new RuntimeException("Animal não encontrado, o id: " + id + " não foi encontrado.");
        }
        return animal;
    }
    
    //implementação do metodo responsavel por filtrar 
    //os servicos ainda não realizados
    public List<Animal> getData(){
        List<Animal> animal = repository.findatendimentoByDate();
        
        return animal;
    }
    
    //implementação do metodo responsavel por encontrar 
    //um animal pelo nome dele
    public Animal findByname(String name){
        return repository.findBynome(name);
    }
    
    //implementação do metodo que irá deletar um
    //animal pro id
    public void deletePedidoById(Long id){
        repository.deleteById(id);
    }
}
