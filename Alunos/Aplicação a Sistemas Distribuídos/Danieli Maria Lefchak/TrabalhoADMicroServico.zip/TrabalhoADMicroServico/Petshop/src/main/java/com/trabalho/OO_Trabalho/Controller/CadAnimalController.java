/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Dto.AnimalDto;
import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Model.Atendimento;
import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Model.Servicos;
import com.trabalho.OO_Trabalho.Repository.AnimaisRepository;
import com.trabalho.OO_Trabalho.Repository.AtendimentoRepository;
import com.trabalho.OO_Trabalho.Repository.PessoaRepository;
import com.trabalho.OO_Trabalho.Repository.ServicoRepository;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author danie
 */
@Controller
@RequestMapping("/CadastrarAnimal")
public class CadAnimalController {
    @Autowired
    private AnimaisRepository repository;
    
    @Autowired
    private ServicoRepository servRep;
    
    @Autowired
    private PessoaRepository pesRep;
    
    @Autowired
    private AtendimentoRepository atenRep;
    
    //metodo que mostra o fomulario de animais e os ids dos servicos, pessoas e atendimentos
    @GetMapping("/animal")
    public String formulario(AnimalDto animal, Model model) {
        List<Servicos> servicos = servRep.findAll();
        model.addAttribute("servicos", servicos);
        List<Pessoa> pessoas = pesRep.findAll();
        model.addAttribute("pessoas", pessoas);
        List<Atendimento> atendimentos = atenRep.findAll();
        model.addAttribute("atendimentos", atendimentos);
        
        return "Formularios/FormularioDeCadastroAnimal";
    }
    
    //metoso responsavel pelo cadastro de um novo animal
    @PostMapping("novo")
    public String cadastrar(@Valid AnimalDto animal, BindingResult result){
        
        Animal ani = animal.toAnimal();
        repository.save(ani);
        return "redirect:/home";
    }
}
