/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.trabalho.OO_Trabalho.Repository;

import com.trabalho.OO_Trabalho.Model.Servicos;
import com.trabalho.OO_Trabalho.Model.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;


/**
 *
 * @author danie
 */
public interface ServicoRepository extends JpaRepository<Servicos, Long>{
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update Servicos s set s.status = :status where s.idServ = :id")
    void atualizaStatus(Status status, Long id);

    @Query(value = "SELECT s from Servicos s where s.conta = :conta")
    Servicos findByAccountNumber(Long conta);
}
