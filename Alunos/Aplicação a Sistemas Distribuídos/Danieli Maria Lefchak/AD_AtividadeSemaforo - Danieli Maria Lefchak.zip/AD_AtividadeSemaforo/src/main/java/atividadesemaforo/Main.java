/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividadesemaforo;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author danie
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        //cria os carros
        Carro car1 = new Carro("PND7P36", "Mobi", 2020, 1.0);
        Carro car2 = new Carro("LKG8L89", "Gol", 2000, 1.2);
        Carro car3 = new Carro("LUI5F49", "Uno", 2003, 1.4);
        Carro car4 = new Carro("PMT5k82", "Fusca", 1976, 2.0);
        Carro car5 = new Carro("OTY8L28", "Corcel", 1983, 1.6);
        Carro car6 = new Carro("YUH9L10", "Celta", 2015, 1.8);
        Carro car7 = new Carro("WDT5N36", "Passat", 1988, 1.5);
        Carro car8 = new Carro("KLM6U25", "Logan", 1976, 1.6);
        Carro car9 = new Carro("ASD4W12", "Fox", 2018, 1.0);
        Carro car10 = new Carro("PLK2H45", "Saveiro", 1999, 1.2);
        Carro car11 = new Carro("MDS9O03", "Onix", 2020, 1.3);
        Carro car12 = new Carro("PQN7R26", "Toro", 2021, 1.5);
        Carro car13 = new Carro("JSC3Q65", "Pajero", 2021, 1.4);
        Carro car14 = new Carro("MDB1S83", "Captiva", 2014, 2.4);
        Carro car15 = new Carro("KLP0Y42", "Verona", 1990, 1.8);
        Carro car16 = new Carro("TDB3Z19", "Ford Escort", 1994, 1.6);
        Carro car17 = new Carro("YUG9L28","Ford ka", 2003, 1.6);
        Carro car18 = new Carro("XDS1O95", "Azera", 2015, 3.0);
        Carro car19 = new Carro("WIM4T16","Hilux", 2021, 2.8);
        Carro car20 = new Carro("ZET3Y79", "Fusion", 2008, 2.3);
        Queue<Carro> carros = new LinkedList<>();//cria uma fila
        
        //adiciona os carros a fila
        carros.add(car1);
        carros.add(car2);
        carros.add(car3);
        carros.add(car4);
        carros.add(car5);
        carros.add(car6);
        carros.add(car7);
        carros.add(car8);
        carros.add(car9);
        carros.add(car10);
        carros.add(car11);
        carros.add(car12);
        carros.add(car13);
        carros.add(car14);
        carros.add(car15);
        carros.add(car16);
        carros.add(car17);
        carros.add(car18);
        carros.add(car19);
        carros.add(car20);
        
        Semaforo sem = new Semaforo("Semaforo1", carros);//cria um novo semáforo
        while(carros.peek()!=null){//enquanto ainda existirem carros na fila
            sem.aguardaMudancaVerde();
            //irá chamar o método que faz uma thread aguardar a outra
            if(sem.getSinal() == SinalEnum.verde){//se o sinal for verde
                System.out.println("O sinal está " + sem.getSinal());//irá avisar que o sinal esta verde
                
                //enquanto o sinal etiver verde e exitirem carros na fila
                while(sem.getSinal() == SinalEnum.verde && carros.peek()!=null){
                    //irá chamar o metodo que controla o tempo 
                    //de movimento dos carros
                    sem.verificaTempoDeMovimento(carros.peek());
                    //irá mostrar os carros e tiralos em ordem de chegada
                    System.out.println(carros.poll());
                }
            } else{//caso o sinal esteja vermelho
                //vai mostrar uma mensagem falando que o sinal
                //é vermelho e os carros estão parados
                System.out.println("O sinal está " + sem.getSinal() + ", carros estão aguardado");
            }
        }
        //quando acabar a lista de carros será chamado o método
        //que desliga o sinal
        sem.desligarSinal();
    }
    
}
