/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadesemaforo;

import java.util.Queue;

/**
 *
 * @author danie
 */
public class Semaforo implements Runnable{//classe que controla a thread
    private boolean verifica;
    private boolean desliga;
    private Queue<Carro> carros;
    private SinalEnum sinal;
    private String nome;
    private Thread t;
    
    //construtor que recebe como parametro o nome da thread e a fila de carros
    public Semaforo(String nome, Queue<Carro> carros) {
        this.nome = nome;
        this.carros = carros;
        this.sinal = SinalEnum.vermelho;//inicializa com vermelho
        t = new Thread(this, nome);
        t.start();//inicia a thread
    }
    
    //metodo get para que seja possivel ver qual o sinal atual 
    public SinalEnum getSinal() {
        return sinal;
    }
    
    //metodo que ira verificar qual o tempo que levara para o carro se mover
    //ele recebera um carro por parametro e irá verificar o ano e o motor do 
    //carro para fazer o tempo de movimento
    public void verificaTempoDeMovimento(Carro car) throws InterruptedException{
        if ((car.getAno() < 2001) && (car.getMotor() <= 1.3)) {
        //se o carro for mais velho que 21 anos e tiver um motor menor ou igual a 1.3
            Thread.sleep(3500);
            //o tempo que ele levara para se movimentar será de 3500 milesegundos
        } else if ((car.getAno() > 2001) && (car.getMotor() <= 1.3)) {
            //se o carro for mais novo que 21 anos e tiver um motor menor ou igual a 1.3
            Thread.sleep(2000);
            //o tempo que ele levara para se movimentar será de 2000 milesegundos
        } else {//caso contrario
            Thread.sleep(500);
            //o tempo que ele levara para se movimentar será de 500 milesegundos
        }
    }
    
    @Override
    public void run() {
        while(!desliga){//enquanto o sinal não estirver desligado
            try {
                switch(this.sinal){
                //ira pegar as opções de sinal que estão no enum
                    case vermelho:
                        //o tempo que o sinal levara vermelho
                        Thread.sleep(2500);
                        break;
                    case verde:
                        //o tempo que o sinal levara verde
                        Thread.sleep(4000);
                        break;
                }
                trocaSinal();//metodo que ira realizar a troca do sinal
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //quando o sinal for desligado ira mostrar esta mensagem
        System.out.println("Sinal desligado ");
    }
    
    //metodo que irá realizar as trocas do sinal enquanto o sinal 
    //estiver ligado
    public synchronized void trocaSinal() throws InterruptedException{
        switch (this.sinal) {//ira receber as opções de sinal do enum
            case vermelho:
                //se o sinal estiver vermelho ainda 
                //o sinal ira receber verde apos o tempo 
                //de espera estabelecido no metodo run
                sinal = SinalEnum.verde;
                break;
            case verde:
                //se o sinal estiver verde ainda 
                //o sinal ira receber vermelho apos o tempo 
                //de espera estabelecido no metodo run
                sinal = SinalEnum.vermelho;
                break;
        }
        verifica = true;
        notify();//notifica a thread que
    }
    
    //metodo que ira fazer com que a thread aguarde o antes de realizar a troca
    public synchronized void aguardaMudancaVerde() throws InterruptedException{
        while(!verifica){//enquanto verifica for verdadeiro
            wait();
            //a thread deve esperar a outra terminar seu
            //processo e assim por diante
        }
        //quando as threads terminarem seus processos e
        //sair do while o verifica ira receber o valor 
        //falso pois os processos já terminaram
        verifica = false;
    }
    
    //metodo que ira definir quando o sinal será deligado
    public synchronized void desligarSinal(){
        this.desliga = true;
    }
}
