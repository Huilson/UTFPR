/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadesemaforo;

/**
 *
 * @author danie
 */
public class Carro {//classe de carros que irá ter as informações dos carros
    private String placa;
    private String modelo;
    private int ano;
    private double motor;
    
    //construtor vazio
    public Carro() {
    }
    
    //cosntrutor que irá receber todos os dados do carro
    public Carro(String placa, String modelo, int ano, double motor) {
        this.placa = placa;
        this.modelo = modelo;
        this.ano = ano;
        this.motor = motor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public double getMotor() {
        return motor;
    }

    public void setMotor(double motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return modelo;
    }
}
