/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadechatproxy;

/**
 *
 * @author danie
 */
//classe que irá implementar a interface IFiltroMensagem
public class Mensagens implements IFiltroMensagem{
    @Override
    public boolean filtrarMensagens(String mensagem) throws Exception {
        //implementação do método filtrarMensagens que recebe uma mensagem 
        //por parametro e retorna um boolean
        System.out.println("Menasagem filtrada e enviada: " + mensagem);
        
        return false;
    }
}
