/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package atividadechatproxy;

/**
 *
 * @author danie
 */
//calsse que será como uma ponte entre o proxy e o original
public interface IFiltroMensagem {
    //método que será implementado nas classes que implementarem esta
    //interface. Este metodo irá receber uma mensagem por parametro
    //e retornar um boolean.
    public boolean filtrarMensagens(String mensagem) throws Exception;
}
