/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadechatproxy;

/**
 *
 * @author danie
 */
//a classe FiltroMensagensProxy irá implemntar a interface
//IFiltroMensagem
public class FiltroMensagensProxy implements IFiltroMensagem{
    //Cria um objeto do tipo IFiltroMensagem
    private IFiltroMensagem filtro;
    //Cria um objeto do tipo boolean
    private boolean encontra;
    
    //construtor
    public FiltroMensagensProxy() {
        //o filtro do tipo IFiltroMensagem irá
        //ser instanciado como um objeto mensagem
        this.filtro = new Mensagens();
    }
    
    //vai implementar o metodo que vem da classe IFiltroMensagem
    @Override
    public boolean filtrarMensagens(String mensagem) throws Exception {
        //Cria uma lista de possiveis palavras de baixo calão que o usuário 
        //possa vir a utilizar em suas mensagens.(Listas pegas na internet)
        String palavras[]={"Anus","Arregão","Arregao","Ass","Babaca","Bacura","Bagos","Baitola","Bebum",
                           "Besta","Bicha","Biscate","Bitch","Bixa","Boazuda","Boceta","Boco","Boiola",
                           "Bolagato","Boquete","Bolcat","Bosseta","Bosta","Bostana","Brecha","Brexa",
                           "Brioco","Broxa","Bronha","Buceta","Bunda","Bunduda","Burra","Burro","Busseta",
                           "Cadela","Caga","Cagado","Cagao","Cagona","Canalha","Caralho","Casseta",
                           "Cassete","Checheca","Chereca","Chifruda","Chifrudo","Chota","Chochota",
                           "Chupada","Chupado","Coco","Cock","Corna","Corno","Cornuda","Cornudo",
                           "Cretina","Cretino","Crickhold","Cu","Culhao","Curalho","Cuzao","Cuzuda",
                           "Cuzudo","Debiloide","Demonio","Dick","Doido","Doida","Escrota","Escroto",
                           "Esporrada","Esporrado","Esporro","Estupida","Estupidez","Estupido","Fedida",
                           "Fedido","Feia","Feio","Feiosa","Feioso","Feioza","Feiozo","Felacao","Foda",
                           "Fodao","Fode","Fodida","Fodido","Fornica","Fudendo","Fuder","Fude","Fuck",
                           "Fucker","Fucked","Fucking","Fudecao","Fudida","Fudido","Furnica","Furnicar",
                           "Gay","Geba","Gonorrea","Gonorreia","Grelinho","Grelo","Homo-sexual",
                           "Homossexual","Homossexual","Idiota","Idiotice","Imbecil","Iscrota","Iscroto",
                           "Jeba","Jerk","Ladra","Ladrao","Ladrona","Leprosa","Leproso","Lésbica",
                           "Macaca","Macaco","Machona","Machorra","Masturba","Merda","Mija","Mijada",
                           "Mijado","Mijo","Mocrea","Mocreia","Moleca","Moleque","Mondronga","Mondrongo",
                           "Nadega","Nojenta","Nojento","Otaria","Otario","Paspalha","Paspalhao","Paspalho",
                           "Peido","Pemba","Pênis","Pentelha","Pentelho","Pilantra","Piroca","Piroco","Piru",
                           "Porra","Prega","Punheta","Punhetao","Pustula","Puta","Puto","Rabuda","Rabudao",
                           "Rabudo","Rabudona","Retardada","Retardado","Ridícula","Rola","Rolinha","Sacana",
                           "Safada","Safado","Sapatao","Shit","Siririca","Sucker","Tarada","Tarado",
                           "Testuda","Tezao","Tezuda","Tezudo","Tramp","Troxa","Vagabunda","Vadia",
                           "Vadio","Vagabundo","Vagina","Viada","Víado","Viadao","Xavasca","Xerereca",
                           "Xexeca","Xibiu","Xibumba","Xota","Xochota","Xoxota","Xana","Xaninha"};
        
        //percorre a lista de possiveis palavras
        for(int i = 0; i<palavras.length; i++){
            //aqui antes de fazer a validação ele ira transformar ambas as
            //mensagens e as palavras da lista em minusculo para não acontecer
            //de alguma palavra passar batido por não estar com letra minuscula
            //então ele vai verificar se na minha string(mensagem) que foi passada
            //por parametro vai conter alguma das palavras da lista usando a função
            //contains que irá servir para verificar se na minha lista de mensagem 
            //possui algum elemento que está na minha lista de palavras
            if (mensagem.toLowerCase().contains(palavras[i].toLowerCase())) {
                //caso ele encontre alguma das palavras da lista na mensagem
                //ele a variavel encontra irá receber true
                encontra = true;
                //vai sair apos encontrar uma palavra
                break;
            } else{//caso contrario
                //encontra vai receber falso
                encontra = false;
            }
        }
        
        //vai retornar o valor de encontra
        return encontra;
    }
}
