/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadechatproxy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author danie
 */
public class GerenciadorClientes implements Runnable{
    //cria um array de clientes
    public static ArrayList<GerenciadorClientes> clientes = new ArrayList<>();
    private Socket socket;//cria um objeto socket
    private String nomeCliente;
    private BufferedWriter bw;//cria um novo objeto BufferedWriter
    private BufferedReader br;//cria um novo objeto BufferedReader
    
    public GerenciadorClientes(Socket socket) throws IOException {
        try{
            this.socket = socket;
            //estancio um novo buffer sempre que enviar uma nova mensagem atraves do socket
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            //estancio um novo buffer sempre que alguem enviar uma mensagem
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //envia o nome do cliente atraves da conexao com o servidor
            this.nomeCliente = br.readLine();
            clientes.add(this);//adiciona o cliente ao array
            broadcast("Servidor: " + nomeCliente + " Entrou no chat!");
            //passa a mensagem por parametro para o método broadcast
        } catch(IOException e){
            encerraTudo(socket, bw, br);//se der errado fecha tudo
            e.printStackTrace();
        }
    }//fim construtor

    @Override
    public void run() {
        String msgCliente;
        //enquanto o socket estiver conectado
        while(socket.isConnected()){
            try{
                //irá ler as mensagens que o cliente informa
                msgCliente = br.readLine();
                //passa essa mensagem por parametro para o broad cast
                broadcast(msgCliente);
                
            } catch(IOException e){
                //se cair na exceçao
                //irá chamar o método que encerra tudo
                encerraTudo(socket, bw, br);
                break;
            }//fim catch
            
        }//fim while
    }//fim runnable 
    
    public void broadcast(String msg){
        for(GerenciadorClientes gc : clientes){
            //gc irá receber os clientes que estão na lista
            try{
                if(!gc.nomeCliente.equals(nomeCliente)){
                    //todos os clientes não escreveram a mensagem terão bloco abaixo executado
                    gc.bw.write(msg);//recebe a mensagem escrita pelo cliente não 
                    gc.bw.newLine();//pula de linha depois de receber a mesnasgaem
                    gc.bw.flush();//limpa buffer
                }
            } catch(IOException e){
                //se cair na exceçao
                //irá chamar o método que encerra tudo
                encerraTudo(socket, bw, br);
            }
        }
    }
    
    public void remove(){
        //método que irá remover os cliente quando eles sairem
        clientes.remove(this);
        broadcast("Servidor: " + nomeCliente + " saiu do chat!");
    }
    
    public void encerraTudo(Socket socket, BufferedWriter bw, BufferedReader br){
        remove();
        //chama o método que remove o cliente que sair
        try{
            if(br != null){
                br.close();//enquanto tiver leitura não encerra
            }
            if(bw != null){
                bw.close();//enquanto tiver escrita não encerra
            }
            if(socket != null){
                socket.close();//enquanto tiver enviando ou recebendo não encerra
            }
        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
