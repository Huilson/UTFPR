/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadechatproxy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Cliente {
    private Socket socket;//cria um novo objeto socket
    private BufferedWriter bw;//cria um novo objeto BufferedWriter
    private BufferedReader br;//cria um novo objeto BufferedReader
    private String nomeUser;//cria um novo objeto string
    private FiltroMensagensProxy filtro = new FiltroMensagensProxy();
    //cria um novo objeto FiltroMensagensProxy
    private boolean valida;//cria um novo objeto boolean

    public Cliente(Socket socket,String nomeUser) {
        try {
            this.socket = socket;
            //estancio um novo buffer sempre que enviar uma nova mensagem atraves do socket
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            //estancio um novo buffer sempre que alguem enviar uma mensagem
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.nomeUser = nomeUser;
        } catch(IOException e){
            //se cair na exceçao
            //irá chamar o método que encerra tudo
            encerraTudo(socket, bw, br);
        }
    }
    
    public void ouvir(){
        //cria uma nova thread
        new Thread(new Runnable(){
            @Override
            public void run(){
                String broadcast;
                //enquanto o socket estiver conectado
                while(socket.isConnected()){
                    try{
                        //broadCasy irá receber oque estiver no 
                        //BufferedReader
                        broadcast = br.readLine();
                        System.out.println(broadcast);
                    } catch(IOException e){
                        //se cair na exceçao
                        //irá chamar o método que encerra tudo
                        encerraTudo(socket, bw, br);
                    }
                }//fim while
            }//fim run
        }).start();//fim runnable
    }//fim ouvir
    
    public void enviar() throws Exception{
        try{
            bw.write(nomeUser);//escreve o nome do usuario
            bw.newLine();//pula uma linha
            bw.flush();
            
            //cria um objeto scanner
            Scanner scan = new Scanner(System.in);
            
            //enquanto o socket estiver conectado
            while (socket.isConnected()) {
                String enviar = scan.nextLine();
                //enviar vai receber oque for escrito
                
                valida = filtro.filtrarMensagens(enviar);
                //valida irá receber o retorno do método que verifica
                //se as mensagens tem ou não palavrões que está na 
                //classe FiltroMensagensProxy, se a mensagem 
                //tem palavão ele vai retornar true caso contrario 
                //false. 
                
                //Faz a validação da mensagem que o usuário digitou.
                //Para filtrar a mensagem antes que ela seja enviada
                //o método filtrarMensagens foi chamado, valida irá
                //receber seu retorno, se valida for true ele irá 
                //retornar um aviso para o usuário que tentou
                //envia-la dizendo que a mensagem é inapropriada
                if (valida == true) {
                    System.out.println("Está mensagem contem conteudo inapropriado!");
                } else {//caso contrario irá mostrar a mensagem que foi digitada
                    bw.write(nomeUser + ": " + enviar);
                    bw.newLine();
                    bw.flush();
                }

            }//fim do while
        } catch(IOException e){
            //se cair na exceçao
            //irá chamar o método que encerra tudo
            encerraTudo(socket, bw, br);
        }
    }//fim enviar
    
    public void encerraTudo(Socket socket, BufferedWriter bw, BufferedReader br){
        try{
            if(br != null){
                br.close();//enquanto tiver leitura não encerra
            }
            if(bw != null){
                bw.close();//enquanto tiver escrita não encerra
            }
            if(socket != null){
                socket.close();//enquanto tiver enviando ou recebendo não encerra
            }
        } catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) throws IOException, Exception {
        Scanner scan = new Scanner(System.in);
        //cria um novo objeto scanner
        System.out.println("Digite seu nome de usuario: ");
        String nomeUser = scan.nextLine();
        //recebe o nome que foi escrito
        Socket socket = new Socket("localhost", 1286);
        //cria um novo socket
        Cliente cliente = new Cliente(socket, nomeUser);
        //cria um novo cliente passando para ele o
        //socket e o nome do usuario
        cliente.ouvir();//chama o método ouvir
        cliente.enviar();//chama o método enviar
    }
}
