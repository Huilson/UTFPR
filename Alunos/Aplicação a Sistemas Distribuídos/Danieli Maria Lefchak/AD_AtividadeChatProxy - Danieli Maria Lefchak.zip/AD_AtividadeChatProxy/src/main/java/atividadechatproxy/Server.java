/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadechatproxy;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 *
 * @author danie
 */
public class Server {
    //variavel de conexao
    ServerSocket serversocket;
    
    //Construtor
    public Server(ServerSocket serversocket){
        this.serversocket = serversocket;
    }
    
    public void start() throws IOException{
        try{
            while(!serversocket.isClosed()){
                //aceita a requisição de conexão de um cliente
                Socket socket = serversocket.accept();
                System.out.println("Cliente foi conectado");
                //chama a classe que gerencia os clientes passando o 
                //socket por parametro
                GerenciadorClientes gc = new GerenciadorClientes(socket);
                
                //Cria uma thread que dará o direito a um cliente de 
                //ser ouvido e ouvir
                Thread thread = new Thread(gc);
                thread.start();
            }//fim while
        } catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    public void closeServer(){
        try{
            //se o servidor não for nulo
            if(serversocket != null){
                //irá fechar
                serversocket.close();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }//fim do metodo close server
    
    public static void main(String[] args) throws IOException {
        ServerSocket serversocket = new ServerSocket(1286);//porta que o servidor fica ouvindo
        Server server = new Server(serversocket);//construtor de acesso ao servidor
        server.start();//tenho cliente? Sim! inicio o servidor!
    }
}
