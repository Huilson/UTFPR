package org.example.Controller;

import org.bson.types.ObjectId;
import org.example.Repository.AnimalRepository;
import org.example.Repository.TutorRepository;
import org.example.model.Animal;
import org.example.model.Tutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class AnimalController {

    //Injeção de dependência
    @Autowired
    private AnimalRepository animalRepository;
    @Autowired
    private TutorRepository tutorRepository;

    // Método para de requisição para cadastrar um animal
    @GetMapping("/animal/cadastrar")
    public String cadastrar(Model model){
        //Adiciona um novo animal na model
        model.addAttribute("animal", new Animal());
        //Recupera a lista de tutores do Repository e adiciona
        List<Tutor> tutores = tutorRepository.findAll();
        model.addAttribute("tutores", tutores);
        //Retorno para a página
        return "animal/cadastrar";
    }

    //Faz uma requisição POST para salvar animal
    @PostMapping("/animal/salvar")
    public String salvar(@ModelAttribute Animal animal){
        //Insere um animal no Repository
        animalRepository.insert(animal);
        return "redirect:/";
    }

    //Requisição de GET para listar todos os animais
    @GetMapping("/animal/listar")
    public String listar(Model model){
        //Recupera a lista de todos os animais
        List<Animal> animais = animalRepository.findAll();
        model.addAttribute("animais", animais);
        return "animal/listar";
    }

    //Requisição GET para visualizar um animal via ID
    @GetMapping("/animal/visualizar/{id}")
    public String visualizar(@PathVariable ObjectId id, Model model){
        // Recupera o animal pelo ID no repository
        Animal animal = animalRepository.findById(id).orElse(null);
        model.addAttribute("animal", animal);
        return "animal/visualizar";
    }

    //GET excluir um animal por ID
    @GetMapping("/animal/excluir/{id}")
    public String excluir(@PathVariable ObjectId id){
        //Faz a exclusão do animal pelo ID
        animalRepository.deleteById(id);
        return "redirect:/animal/listar";
    }

    //Requisição GET para atualizar um animal pelo ID
    @GetMapping("/animal/atualizar/{id}")
    public String atualizar(@PathVariable ObjectId id, Model model){
        //Recupera pelo ID e tutores do repository
        Animal animal = animalRepository.findById(id).orElse(null);
        List<Tutor> tutores = tutorRepository.findAll();
        model.addAttribute("tutores", tutores);
        model.addAttribute("animal", animal);
        return "animal/atualizar";
    }

    //Requisição POST para editar/salvar um animal
    @PostMapping("/animal/editar/{id}")
    public String editar(@ModelAttribute Animal animal){
        //Salva as alterações do repository
        animalRepository.save(animal);
        return "redirect:/animal/listar";
    }

}


