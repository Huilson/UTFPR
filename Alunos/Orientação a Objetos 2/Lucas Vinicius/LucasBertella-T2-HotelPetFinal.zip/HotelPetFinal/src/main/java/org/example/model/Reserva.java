package org.example.model;


import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document
public class Reserva {

    @Id
    private ObjectId id;
    private int andar;
    private String datainicial;
    private String datafinal;
    private String gasto;
    @DBRef
    private Animal animal;

    public Reserva(ObjectId id, int andar, String datainicial, String datafinal, String gasto, Animal animal) {
        this.id = id;
        this.andar = andar;
        this.datainicial = datainicial;
        this.datafinal = datafinal;
        this.animal = animal;
        this.gasto = gasto;
    }

    public Reserva() {
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public String getDatainicial() {
        return datainicial;
    }

    public void setDatainicial(String datainicial) {
        this.datainicial = datainicial;
    }

    public String getDatafinal() {
        return datafinal;
    }

    public void setDatafinal(String datafinal) {
        this.datafinal = datafinal;
    }

    public String getGasto() {
        return gasto;
    }

    public void setGasto(String gasto) {
        this.gasto = gasto;
    }
}

