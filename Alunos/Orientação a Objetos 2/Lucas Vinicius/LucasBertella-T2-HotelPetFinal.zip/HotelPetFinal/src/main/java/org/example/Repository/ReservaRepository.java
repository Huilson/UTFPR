package org.example.Repository;

import org.bson.types.ObjectId;
import org.example.model.Reserva;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
//Fornece operações de CRUD para a entidade Reserva
public interface ReservaRepository extends MongoRepository<Reserva, ObjectId> {
}
