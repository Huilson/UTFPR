package org.example.Controller;

import org.bson.types.ObjectId;
import org.example.Repository.AnimalRepository;
import org.example.Repository.TutorRepository;
import org.example.model.Animal;
import org.example.model.Tutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class TutorController {
    @Autowired
    private TutorRepository repository;

    @Autowired
    private AnimalRepository animalRepository;

    //Requisição GET para cadastrar um tutor
    @GetMapping("/tutor/cadastrar")
    public String cadastrar(Model model){
        //Adiciona um novo tutor na model
        model.addAttribute("tutor", new Tutor());
        return "tutor/cadastrar";
    }

    //Requisição POST para salvar um tutor
    @PostMapping("/tutor/salvar")
    public String salvar(@ModelAttribute Tutor tutor){
        //Insere um tutor no repository
        repository.insert(tutor);
        return "redirect:/";
    }

    //Requisição GET para listar os tutores
    @GetMapping("/tutor/listar")
    public String listar(Model model){
        //Recupera na listade tutores do repository e adiciona
        List<Tutor> tutores = repository.findAll();
        model.addAttribute("tutores", tutores);
        return "tutor/listar";
    }

    //Requisição GET para visualizar tutores por ID
    @GetMapping("/tutor/visualizar/{id}")
    public String visualizar(@PathVariable ObjectId id, Model model){
        //Recupera tutor pelo ID do repository
        Tutor tutor = repository.findById(id).orElse(null);
        model.addAttribute("tutor", tutor);
        return "tutor/visualizar";
    }

    //Requisição GET para excluir tutor por ID
    @GetMapping("/tutor/excluir/{id}")
    public String excluir(@PathVariable ObjectId id){
        //Recupera por ID
        Tutor tutor = repository.findById(id).orElse(null);
        //Faz a exclusão do tutor
        repository.deleteById(id);
        return "redirect:/tutor/listar";
    }

    //Requisição GET para atualizar por ID
    @GetMapping("/tutor/atualizar/{id}")
    public String atualizar(@PathVariable ObjectId id, Model model){
        Tutor tutor = repository.findById(id).orElse(null);
        model.addAttribute("tutor", tutor);
        return "tutor/atualizar";
    }

    //Requisição POST para editar por ID
    @PostMapping("/tutor/editar/{id}")
    public String editar(@ModelAttribute Tutor tutor){
        //Salva as alterações feitas no tutor no repository
        repository.save(tutor);
        return"redirect:/tutor/listar";
    }
}
