package org.example.Controller;

import org.bson.types.ObjectId;
import org.example.Repository.AnimalRepository;
import org.example.Repository.ReservaRepository;
import org.example.Repository.TutorRepository;
import org.example.model.Animal;
import org.example.model.Reserva;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ReservaController {
    @Autowired
    private AnimalRepository animalRepository;

    @Autowired
    private TutorRepository tutorRepository;

    @Autowired
    private ReservaRepository reservaRepository;

    //Requisição GET para realizar reserva
    @GetMapping("/reserva/realizarReserva")
    public String realizarReserva(Model model){
        //Cria uma nova reserva e recupera a lista de animais no repository
        Reserva reserva = new Reserva();
        List<Animal> animais = animalRepository.findAll();
        //Adiciona a lista de animais e na lista de reserva na model
        model.addAttribute("animais", animais);
        model.addAttribute("reserva", reserva);
        return "reserva/realizarReserva";
    }

    //Requisição POST para salvar uma reserva
    @PostMapping("/reserva/salvar")
    public String salvar(@ModelAttribute Reserva reserva){
        //Recupera o ID do animal na reserva e compara até achar o animal correspondente
        ObjectId idAnimal = reserva.getAnimal().getId();
        Animal animalSelecionado = animalRepository.findById(idAnimal).orElse(null);
        //Seta o andar da reserva
        if(animalSelecionado.getEspecie().equalsIgnoreCase("Cachorro")){
            reserva.setAndar(1);
        } else if (animalSelecionado.getEspecie().equalsIgnoreCase("Gato")) {
            reserva.setAndar(2);
        }else {
            reserva.setAndar(3);
        }
        //Atualiza e insere no repository da reserva
        reserva.setAnimal(animalSelecionado);
        reservaRepository.insert(reserva);
        return "redirect:/";
    }

    //Requisição GET para listar as reservas
    @GetMapping("/reserva/listar")
    public String listar(Model model){
        //Recupera a lista do repository e adiciona
        List<Reserva> reservas = reservaRepository.findAll();
        model.addAttribute("reservas", reservas);
        return "reserva/listar";
    }

    //Requisição GET para excluir uma reserva
    @GetMapping("/reserva/excluir")
    public String excluir(@PathVariable ObjectId id){
        //Faz a exclusão via id
        reservaRepository.deleteById(id);
        return "redirect:/reserva/listar";
    }


    @GetMapping("/reserva/excluir/{id}")
    public String excluirPorId(@PathVariable ObjectId id){
        //Exclui reserva por ID
        reservaRepository.deleteById(id);
        return"redirect:/reserva/listar";
    }
}
