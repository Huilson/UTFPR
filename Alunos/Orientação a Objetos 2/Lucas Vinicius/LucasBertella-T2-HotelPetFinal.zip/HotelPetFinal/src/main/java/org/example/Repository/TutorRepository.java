package org.example.Repository;


import org.bson.types.ObjectId;
import org.example.model.Tutor;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
//Interface extende MongoRepository, fornece operações de CRUD para a entidade Tutor
public interface TutorRepository extends MongoRepository<Tutor, ObjectId> {

}
