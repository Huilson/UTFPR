package org.example.Animal;

import org.example.Animal.Animal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Cachorro extends Animal {

    private static List<Cachorro> listaCachorros = new ArrayList<>();
    public Cachorro(String nome, String especie, String raca, int idade, int andar){
        super(nome, "cachoro", raca, idade, 1);

        listaCachorros.add(this);
    }

    public static List<Cachorro> getListaCachorros(){
        return listaCachorros;
    }

    public static void setListaCachorros(List<Cachorro> listaCachorros) {
        Cachorro.listaCachorros = listaCachorros;
    }

    public static void listarCachorros() {
        List<Cachorro> cachorros = getListaCachorros();
        if (cachorros.isEmpty()) {
            System.out.println("Nenhum cachorro cadastrado.");
        } else {
            System.out.println("Lista de Cachorros\n");
            for (int i = 0; i < cachorros.size(); i++) {
                Cachorro cachorro = cachorros.get(i);
                System.out.println("Número: " + (i + 1));
                System.out.println("Nome: " + cachorro.getNome());
                System.out.println("Espécie: " + cachorro.getEspecie());
                System.out.println("Raça: " + cachorro.getRaca());
                System.out.println("Idade: " + cachorro.getIdade());
                System.out.println("Andar: \n" + cachorro.getAndar());

            }
        }
    }

    public static void editaCachorro() {
        List<Cachorro> cachorros = getListaCachorros();

        if (cachorros.isEmpty()) {
            System.out.println("Nenhum cachorro cadastrado.");
        }
        else{
            System.out.println("Lista de Cachorros:");
            for (int i = 0; i < cachorros.size(); i++) {
                Cachorro cachorro = cachorros.get(i);
                System.out.println((i + 1) + "Nome: " + cachorro.getNome());
            }

            Scanner scan = new Scanner(System.in);
            System.out.println("Selecione o número do cachorro que deseja editar: ");
            int escolha = scan.nextInt();

            if (escolha >= 1 && escolha <= cachorros.size()) {
                Cachorro cachorroSelecionado = cachorros.get(escolha - 1);

                System.out.println("Editar Cachorro");
                System.out.println("Informe o novo nome do cachorro:");
                String novoNome = scan.nextLine();
                System.out.println("Informe a nova espécie do cachorro:");
                String novaEspecie = scan.nextLine();
                System.out.println("Informe a nova raça do cachorro:");
                String novaRaca = scan.nextLine();
                System.out.println("Informe a nova idade do cachorro:");
                int novaIdade = scan.nextInt();

                cachorroSelecionado.setNome(novoNome);
                cachorroSelecionado.setEspecie(novaEspecie);
                cachorroSelecionado.setRaca(novaRaca);
                cachorroSelecionado.setIdade(novaIdade);

                System.out.println("Cachorro editado com sucesso!");
            } else {
                System.out.println("Número de cachorro inválido.");
            }
        }
    }

    public static void removeCachorro(String nome) {
        List<Cachorro> cachorros = getListaCachorros();

        for (Cachorro cachorro : cachorros) {
            if (cachorro.getNome().equals(nome)) {
                cachorros.remove(cachorro);
                System.out.println("Cachorro removido com sucesso!");
            }
        }
        System.out.println("Cachorro não encontrado na lista.");
    }
}
