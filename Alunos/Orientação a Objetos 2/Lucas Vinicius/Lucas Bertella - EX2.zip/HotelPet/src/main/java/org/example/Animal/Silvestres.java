package org.example.Animal;

import org.example.Animal.Animal;

import java.util.ArrayList;
import java.util.List;

public class Silvestres extends Animal {

    public static List<Silvestres> listaSilvestres = new ArrayList<>();
    public Silvestres(String nome, String especie, String raca, int idade, int andar) {
        super(nome, "silvestre", raca, idade, 3);

        listaSilvestres.add(this);
    }

    public static List<Silvestres> getListaSilvestres() {
        return listaSilvestres;
    }

    public static void setListaSilvestres(List<Silvestres> listaSilvestres) {
        Silvestres.listaSilvestres = listaSilvestres;
    }
}
