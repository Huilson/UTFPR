package org.example.Animal;

import org.example.Animal.Animal;

import java.util.ArrayList;
import java.util.List;

public class Gato extends Animal {

    private static List<Gato> listaGatos = new ArrayList<>();
    public Gato(String nome, String especie, String raca, int idade, int andar){
        super(nome, "gato", raca, idade, andar);

        listaGatos.add(this);
    }

    public static List<Gato> getListaGatos() {
        return listaGatos;
    }

    public static void setListaGatos(List<Gato> listaGatos) {
        Gato.listaGatos = listaGatos;
    }
}
