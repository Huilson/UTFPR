package org.example.Pessoa;

import org.example.Animal.Animal;
import org.example.Pessoa.Pessoa;

public class Tutor extends Pessoa {

    public Tutor(String nome, int documento, Animal animalEst) {
        super(nome, documento, animalEst);
    }
}
