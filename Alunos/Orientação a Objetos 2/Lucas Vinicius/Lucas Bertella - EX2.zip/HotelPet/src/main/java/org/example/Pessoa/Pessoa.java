package org.example.Pessoa;

import org.example.Animal.Animal;

public class Pessoa {
    String nome;
    int documento;

    protected Animal animalEst;

    public Pessoa(String nome, int documento, Animal animalEst) {
        this.nome = nome;
        this.documento = documento;
        this.animalEst = animalEst;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getDocumento() {
        return documento;
    }

    public void setDocumento(int documento) {
        this.documento = documento;
    }

    public Animal getAnimalEst() {
        return animalEst;
    }

    public void setAnimalEst(Animal animalEst) {
        this.animalEst = animalEst;
    }
}
