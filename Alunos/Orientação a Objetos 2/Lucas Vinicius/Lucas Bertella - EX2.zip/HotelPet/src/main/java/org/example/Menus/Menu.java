package org.example.Menus;

import org.example.Animal.Cachorro;
import org.example.Animal.Gato;
import org.example.Animal.Silvestres;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {

    Scanner scan = new Scanner(System.in);

    public void menuPrincipal() {
        while (true) {
            System.out.println("\n----------Menu----------");
            System.out.println("Escolha uma opção: ");
            System.out.println("1 - Animal");
            System.out.println("2 - Tutor");
            System.out.println("3 - Agenda");
            System.out.println("4 - Sair");

            int escolha = scan.nextInt();

            switch (escolha) {
                case 1:
                    menuAnimal();
                    break;
                case 2:
                    menuTutor();
                    break;
                case 3:
                    menuAgenda();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opção inválida! Informe uma opção válida. ");
            }
        }
    }

    public void menuAnimal(){
        System.out.println("\n----------Animal----------");
        System.out.println("Escolha uma opção: ");
        System.out.println("1 - Cadastrar animal");
        System.out.println("2 - Editar cadastro animal");
        System.out.println("3 - Excluir cadastro animal");
        System.out.println("4 - Voltar");
        int opcao = scan.nextInt();

        switch (opcao) {
            case 1:
                System.out.println("Informe o nome do animal: ");
                String nomeAnimal = scan.next();
                System.out.println("Infome a espécie do animal: ");
                String especieAnimal = scan.next();
                System.out.println("Informe a raça do animal: ");
                String racaAnimal = scan.next();
                System.out.println("Informe a idade do animal: ");
                int idadeAnimal = scan.nextInt();

                System.out.println("Selecione o andar pertence ao tipo do animal: ");
                int andar = scan.nextInt();

                if (andar == 1) {
                    Cachorro ca = new Cachorro(nomeAnimal, especieAnimal, racaAnimal, idadeAnimal, andar);
                    Cachorro.getListaCachorros().add(ca);
                } else if (andar == 2) {
                    Gato ga = new Gato(nomeAnimal, especieAnimal, racaAnimal, idadeAnimal, andar);
                    Gato.getListaGatos().add(ga);
                } else if (andar == 3) {
                    Silvestres sil = new Silvestres(nomeAnimal, especieAnimal, racaAnimal, idadeAnimal, andar);
                    Silvestres.getListaSilvestres().add(sil);
                } else {
                    System.out.println("Opção inválida. Informe uma opção válida!");
                }
            case 2:
            Cachorro.editaCachorro();

            case 3:
            // exclui animal

            case 4:// Retorna ao menu principal
        }
    }

    public void menuTutor() {
        System.out.println("\n----------Tutor----------");
        System.out.println("Escolha uma opção: ");
        System.out.println("1 - Cadastrar Tutor");
        System.out.println("2 - Editar cadastro Tutor");
        System.out.println("3 - Excluir cadastro Tutor");
        System.out.println("4 - voltar");
        int opcao = scan.nextInt();
    }

    public void menuAgenda() {
        System.out.println("\n----------Agenda----------");
        System.out.println("Escolha uma opção: ");
        System.out.println("1 - Agendar");
        System.out.println("2 - Editar Agendamento");
        System.out.println("3 - Excluir Agendamento");
        System.out.println("4 - voltar");
        int opcao = scan.nextInt();
    }
}