package org.example.Pessoa;

import org.example.Animal.Animal;

public class Funcionario extends Pessoa{

    public Funcionario(String nome, int documento, Animal animalEst) {
        super(nome, documento, animalEst);
    }
}
