package org.example.DAO;

import org.example.Pessoa;
import org.example.Profissao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class PessoaDAO{
        private EntityManager entidade;

        //Contrutor que recebe uma entidade para gerenciar as operações
        public PessoaDAO(EntityManager entidade){
            this.entidade = entidade;
        }

        public void conectar() {
            this.entidade.getTransaction().begin();
        }

        //Método para encerrar o EntityManager
        public void encerrar() {
            this.entidade.close();
        }

        //Salva a pessoa no banco
        public void salvaPessoa(Pessoa pessoa) {
            entidade.merge(pessoa);
            entidade.getTransaction().commit();
        }

        //Método para remover um pessoa do banco
        public void removerPessoa(Pessoa p) {
            entidade.getTransaction().begin();
            Pessoa pessoa = entidade.find(Pessoa.class, p);
            if (pessoa != null) {
                entidade.remove(pessoa);
            }
            entidade.getTransaction().commit();
        }

        //Lista todas as pessoas
        public List<Pessoa> listarPessoas() {
            TypedQuery<Pessoa> query = entidade.createQuery("SELECT p FROM Pessoa p", Pessoa.class);
            return query.getResultList();
        }

        public Pessoa buscarPessoa(Profissao p) {
            return entidade.find(Pessoa.class, p);
        }

        //Atualiza os dados de uma pessoa no banco
        public void atualizaPessoa(Pessoa pessoa) {
            entidade.merge(pessoa);
            entidade.getTransaction().commit();
        }
    }

