package org.example.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Factory {
    // Cria uma Factory para gerenciar as Entity
    private static final EntityManagerFactory cria = Persistence.createEntityManagerFactory("postgres");

    //Obtem o gerenciador
    public static EntityManager getEntityManager(){
        //retorna um novo gerenciador criado pelo Factory
        return cria.createEntityManager();
    }
}
