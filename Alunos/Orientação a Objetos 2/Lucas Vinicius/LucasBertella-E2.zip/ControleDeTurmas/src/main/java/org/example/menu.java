package org.example;

import org.example.DAO.Factory;
import org.example.DAO.PessoaDAO;
import org.example.DAO.ProfissaoDAO;

import javax.persistence.EntityManager;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class menu {

    private Scanner scan = new Scanner(System.in);
    EntityManager entidade = Factory.getEntityManager();
    EntityManager pessoafac = Factory.getEntityManager();
    ProfissaoDAO profissaoD = new ProfissaoDAO(entidade);
    PessoaDAO pessoaD = new PessoaDAO(pessoafac);

    //Menu principal
    public void menuPrincipal() {
        while (true) {
            System.out.println("\nMENU PRINCIPAL\n");
            System.out.println("1 - Gerenciar pessoa");
            System.out.println("2 - Gerenciar profissão");
            System.out.println("3- Sair");
            System.out.println("\nEscolha uma opcao: ");

            int escolha = scan.nextInt();

            switch (escolha) {
                case 1:
                    menuPessoa();
                    break;

                case 2:
                    menuProfissao();
                    break;

                case 3:
                    System.exit(0);//Encerra o programa
                    break;

                default:
                    System.out.println("Escolha inválida. Escolha uma opção válida!\n");
            }
        }
    }

    public void menuPessoa() {
        while (true) {
            System.out.println("\nMENU PESSOA\n");
            System.out.println("1 - Adicionar Pessoa");
            System.out.println("2 - Editar Pessoas");
            System.out.println("3 - Remover pessoa");
            System.out.println("4 - Listar Pessoa");
            System.out.println("5 -  Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");

            int escolha = scan.nextInt();

            switch (escolha) {
                case 1:
                    //Adiciona uma nova pessoa
                    System.out.println("\nADICIONA PESSOA\n");
                    System.out.print("Nome: ");
                    String nome = scan.next();
                    System.out.print("Documento: ");
                    String cpf = scan.next();
                    System.out.print("Contato: ");
                    int idade = scan.nextInt();
                    String contato = scan.next();
                    System.out.print("Idade: ");
                    String cidade = scan.next();
                    System.out.print("Rua: ");
                    String rua = scan.next();
                    System.out.print("Numero: ");
                    int numero = scan.nextInt();

                    System.out.println("Deseja visualizar as profissões disponíveis? (1 - Sim, 2 - Não)");

                    int opc = scan.nextInt();

                    Profissao profis = null;
                    if (opc == 1) {
                        System.out.println("LISTA DE PROFISSÕES:");
                        profissaoD.conectar();
                        List<Profissao> profissoes = profissaoD.listarProfissao();
                        profissaoD.encerrar();
                        for (Profissao prof : profissoes) {
                            System.out.println(prof.getId() + " - " + prof.getProfissao());
                        }
                        System.out.print("escolha uma profissão: ");
                        int idProfissao = scan.nextInt();

                        profis = null;
                        for (Profissao prof : profissoes) {//Percorre a lista
                            if (prof.getId() == idProfissao) {//Compara os id's passados
                                profis = prof;
                                break;
                            }
                        }
                    } else {
                        menuPrincipal();
                    }

                    //Cria objeto pessoa com os atributos
                    Pessoa pessoa = new Pessoa(nome, cpf, idade, contato, cidade, rua, numero, profis);
                    pessoaD.conectar();//Inicia uma transação
                    pessoaD.salvaPessoa(pessoa);//Salva a instância
                    pessoaD.encerrar();//Encerra a conexão

                    System.out.println("Pessoa cadastrada com sucesso");
                    menuPessoa();

                    break;

                case 2:
                    System.out.println("\nEdita Pessoa\n");
                    pessoaD.conectar();//Inicia Transação
                    List<Pessoa> editaPess = pessoaD.listarPessoas();//Cria lista das pessoa que estão no banco
                    boolean pessoaEdit = false;

                    for (Pessoa p : editaPess) {//Percorre a lista
                        p.listaPessoa();
                    }
                    System.out.println("Selecione o id da pessoa que deseja editar: ");
                    int editarid = scan.nextInt();

                    Iterator<Pessoa> percorrePessoa = editaPess.iterator();//Percorre a lista e busca id correspondente
                    while (percorrePessoa.hasNext()) {
                        Pessoa p = percorrePessoa.next();

                        if (p.getId() == editarid) {//Compara os ids, se forem iguais atualiza os dados
                            System.out.print("Nome: ");
                            String nomeEditado = scan.next();
                            p.setNome(nomeEditado);

                            System.out.print("CPF: ");
                            String cpfEditado = scan.next();
                            p.setCpf(cpfEditado);

                            System.out.print("Idade: ");
                            int idadeEditado = scan.nextInt();
                            p.setIdade(idadeEditado);

                            System.out.print("Contato: ");
                            String contatoEditado = scan.next();
                            p.setContato(contatoEditado);

                            System.out.print("Cidade: ");
                            String cidadeEditado = scan.next();
                            p.setCidade(cidadeEditado);

                            System.out.print("Rua: ");
                            String ruaEditado = scan.next();
                            p.setRua(ruaEditado);

                            System.out.print("Numero: ");
                            int numeroEditado = scan.nextInt();
                            p.setNumero(numeroEditado);

                            System.out.println("Lista de profissões");
                            profissaoD.conectar();
                            List<Profissao> profissaoEditada = profissaoD.listarProfissao();
                            profissaoD.encerrar();

                            for (Profissao prof : profissaoEditada) {
                                System.out.println(prof.getId() + " - " + prof.getProfissao());
                            }

                            System.out.print("Selecione uma profissao: ");
                            int profEditada = scan.nextInt();

                            for (Profissao prof : profissaoEditada) {
                                if (prof.getId() == profEditada) {
                                    p.setProfissao(prof);
                                    break;
                                }
                            }
                            pessoaD.atualizaPessoa(p);// Atualiza pessoa
                            pessoaD.encerrar();// Encerra conexao
                            break;
                        }
                    }
                    break;

                case 3:
                    System.out.println("\nExcluir Pessoa\n");
                    pessoaD.conectar();//Inicia Transação
                    List<Pessoa> pessoas = pessoaD.listarPessoas();//Cria lista de todas as pessoas

                    for (Pessoa p : pessoas) {//Percorre a lista
                        System.out.println(p.getId() + "-" + p.getNome());
                    }

                    System.out.println("Selecione a pessoa que deseja excluir");
                    System.out.println("Informe o ID da pessoa selecionada: ");
                    int idselecionado = scan.nextInt();

                    Iterator<Pessoa> iterator = pessoas.iterator();

                    while (iterator.hasNext()) {
                        Pessoa pess = iterator.next();
                        if (pess.getId() == idselecionado) {
                            iterator.remove();//Remove a pessoa da lista em memória
                            pessoaD.removerPessoa(pess);//Chama método para remover a pessoa
                            break;
                        }
                    }
                    break;

                case 4:
                    System.out.println("\nLista Pessoas\n");
                    pessoaD.conectar();//Incia transação
                    List<Pessoa> listaPessoas = pessoaD.listarPessoas();//Cria lista com as pessoas
                    pessoaD.encerrar();//Encerra conexão

                    for (Pessoa pess : listaPessoas) {//Percorre a lista
                        pess.listaPessoa();//chama método para listar
                    }
                    break;

                case 5:
                    menuPrincipal();
                    break;
            }
        }
    }

    public void menuProfissao() {
        while (true) {
            System.out.println("\nMENU PROFISSAO\n");
            System.out.println("1 - Adicionar Profissao");
            System.out.println("2 - Editar Profissao");
            System.out.println("3 - Remover Profissao");
            System.out.println("4 - Listar Pessoa");
            System.out.println("5 -  Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");

            int escolha = scan.nextInt();

            switch (escolha) {
                case 1:
                    System.out.println("\nAdiciona Profissao\n");
                    System.out.println("Profissão: ");
                    String profissao = scan.next();
                    System.out.println("Descrição: ");
                    String descricao = scan.next();

                    Profissao prof = new Profissao(profissao, descricao);//Novo objeto para profissão

                    profissaoD.conectar();//Inicia Transação
                    profissaoD.salvaProfissao(prof);//Salva a nova profissao
                    profissaoD.encerrar();//Encerra a conexao

                    System.out.println("Profissao cadastrada com sucesso");
                    menuProfissao();
                    break;

                case 2:
                    System.out.println("\nEditar Profissão\n");
                    profissaoD.conectar();//Inicia transção
                    List<Profissao> ListaPEditada = profissaoD.listarProfissao();//Recupera lista do sistema
                    for (Profissao p : ListaPEditada) {//Percore a lista
                        p.listaProfissao();//Lista as profissões com suas informações
                    }

                    System.out.print("Selecione a Profissão que deseja Editar: ");
                    int idPEditada = scan.nextInt();

                    Iterator<Profissao> PercorreP = ListaPEditada.iterator();//Percorre a lista profissãp
                    while (PercorreP.hasNext()) {
                        Profissao p = PercorreP.next();
                        if (p.getId() == idPEditada) {
                            System.out.print("Informe a profissão: ");
                            String nomePEditado = scan.next();
                            System.out.println("Informe a descrição: ");
                            String descricaoPEditado = scan.next();
                            p.setProfissao(nomePEditado);//Define a nova profissao
                            p.setDescricao(descricaoPEditado);//Define a nova descrição


                            profissaoD.atualizaProfissao(p); //atualiza a profissão
                            profissaoD.encerrar();//Encerra conexão
                        }
                    }
                    break;

                case 3:
                    System.out.println("\nExcluir Profissao\n");
                    System.out.println("Lista de profissoes");
                    profissaoD.conectar();//Inicia Transação

                    List<Profissao> listarofissao = profissaoD.listarProfissao();//Lista de todas as profissões
                    for(Profissao listaprofissao : listarofissao){//Percorre a lista
                        System.out.println(listaprofissao.getId() + "-" + listaprofissao.getProfissao());//Imprime os atributos
                    }

                    System.out.println("Selecione a profissao que deseja deletar: ");
                    int idprof = scan.nextInt();

                    Iterator<Profissao> iterator = listarofissao.iterator();//Define um iterator e percorre a lista
                    while(iterator.hasNext()){
                        Profissao profV = iterator.next();
                        if(profV.getId() == idprof){//Se o id passado é igual o id do banco remove
                            iterator.remove();//Remove profissão
                            profissaoD.removerProfissao(profV);
                        }
                    }
                    System.out.println("Profissao excluida!");
                    break;

                case 4:
                    profissaoD.conectar();//Inicia Transação
                    List<Profissao> ListaProfissao = profissaoD.listarProfissao();//Define a lista de profissoes

                    for (Profissao p : ListaProfissao) {//percorre a lista
                        p.listaProfissao();//Lista as profissoes
                    }
                    profissaoD.encerrar();//Encerra a conexao
                    menuProfissao();//Chama o menu
                    break;

                case 5:
                    //Chama o menu anterior, no caso, o principal
                    menuPrincipal();
                    break;
            }
        }
    }
}
