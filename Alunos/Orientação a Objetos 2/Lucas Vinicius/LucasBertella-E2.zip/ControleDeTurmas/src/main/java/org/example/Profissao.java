package org.example;

import javax.persistence.*;

@Entity
public class Profissao {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    @Column(name = "profissao")
    String profissao;
    @Column(name = "descricao")
    String descricao;

    public Profissao(){

    }

    //Cosntrutor da classse profissao
    public Profissao(String profissao, String descricao) {
        this.profissao = profissao;
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    //Método para listar todos as profissões e seus respectivos atributos
    public void listaProfissao(){
        System.out.println("Profissao{" +
                "Id: " + id
                + "Profissao: " + profissao
                + "Descricao: " + descricao);
    }
}
