package org.example;



public class Main {
    public static void main(String[] args) {
        menu men = new menu();
        men.menuPrincipal();
    }
}