package org.example.DAO;

import org.example.Pessoa;
import org.example.Profissao;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.List;

public class ProfissaoDAO {
    //Criação de uma entidade chamada entidade
    private EntityManager entidade;

    //Construtor para gerenciar as operações
    public ProfissaoDAO(EntityManager entidade){
        this.entidade = entidade;
    }

    //Inicia uma transação
    public void conectar() {
        this.entidade.getTransaction().begin();
    }

    //Encerra uma transação
    public void encerrar() {
        this.entidade.close();
    }

    //Método para salvar uma profissao no banco
    public void salvaProfissao(Profissao profissao) {
        entidade.merge(profissao);//Mescla a profissão
        entidade.getTransaction().commit();//Confirma a transação
    }

    //Remove uma profissão do banco
    public void removerProfissao(Profissao p) {
        entidade.getTransaction().begin();
        Profissao profissao = entidade.find(Profissao.class, p);
        if (profissao != null) {
            entidade.remove(profissao);
        }
        entidade.getTransaction().commit();
    }

    //Lista todas as profissões do banco
    public List<Profissao> listarProfissao() {
        TypedQuery<Profissao> query = entidade.createQuery("SELECT p FROM Pessoa p", Profissao.class);
        return query.getResultList();
    }

    //Atualiza as informações de uma profissão
    public void atualizaProfissao(Profissao profissao) {
        entidade.merge(profissao);
        entidade.getTransaction().commit();
    }
}
