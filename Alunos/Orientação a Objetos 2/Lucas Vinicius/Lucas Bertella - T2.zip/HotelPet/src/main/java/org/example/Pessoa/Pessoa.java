package org.example.Pessoa;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.example.Animais.Animal;

public class Pessoa {
    private String nome;
    private String documento;
    String tipo;


    public Pessoa(String nome, String documento, String tipo) {
        this.nome = nome;
        this.documento = documento;
        this.tipo = tipo;
    }

    public Pessoa(){

    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}