package org.example.Menus;

import com.mongodb.ConnectionString;
import org.example.Animais.Cachorro;
import org.example.Animais.Gato;
import org.example.Animais.Silvestres;
import org.example.Conexao.MetodosAnimal;
import org.example.Conexao.MetodosPessoa;
import org.example.Pessoa.Funcionario;
import org.example.Pessoa.Tutor;

import java.util.Scanner;

public class Menu {

    Scanner scan = new Scanner(System.in);
    ConnectionString conexao;

    public Menu(){
    }

    public void menuPrincipal() {
        while (true) {
            System.out.println("\n----------Menu----------");
            System.out.println("1 - Animal");
            System.out.println("2 - Pessoa");
            System.out.println("3 - Agenda");
            System.out.println("4 - Sair");
            System.out.println("Escolha uma opção: ");

            int escolha = scan.nextInt();

            switch (escolha) {
                case 1:
                    menuAnimal();
                    break;
                case 2:
                    menuPessoa();
                    break;
                case 3:
                    menuAgenda();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opção inválida! Informe uma opção válida. ");
            }
        }
    }

    public void menuAnimal(){
        MetodosAnimal conexao = new MetodosAnimal();

        System.out.println("\n----------MENU ANIMAL----------");
        System.out.println("1 - Cadastrar animal");
        System.out.println("2 - Editar cadastro animal");
        System.out.println("3 - Excluir cadastro animal");
        System.out.println("4 - Voltar");
        System.out.println("Escolha uma opção: ");
        int opcao = scan.nextInt();

        switch (opcao) {
            case 1:
                System.out.println("Informe o nome do animal: ");
                String nomeAnimal = scan.next();
                System.out.println("Informe a raça do animal: ");
                String racaAnimal = scan.next();
                System.out.println("Informe a idade do animal: ");
                int idadeAnimal = scan.nextInt();
                System.out.println("Informe o nome do tutor do animal: ");
                String tutor = scan.next();

                System.out.println("Selecione o andar pertence ao tipo do animal: \n"
                                    +"1 - Cachorro\n"
                                    +"2 - Gato\n"
                                    +"3 - Silvestre\n");
                int andar = scan.nextInt();
                if (andar == 1) {
                    Cachorro ca = new Cachorro(nomeAnimal, racaAnimal, idadeAnimal, tutor);
                    conexao.inserirAnimal(ca);
                } else if (andar == 2) {
                    Gato ga = new Gato(nomeAnimal, racaAnimal, idadeAnimal, tutor);
                    conexao.inserirAnimal(ga);
                } else if (andar == 3) {
                    Silvestres sil = new Silvestres(nomeAnimal, racaAnimal, idadeAnimal, tutor);
                    conexao.inserirAnimal(sil);
                } else {
                    System.out.println("Opção inválida. Informe uma opção válida!");
                }
                break;
            case 2:

                System.out.println("\n==========ANIMAIS===========\n");
                conexao.listarAnimais();
                System.out.println("Informe o nome do animal que deseja editar: ");
                String nomeedit = scan.next();

                System.out.println("Informe o nome do animal: ");
                String novoNome = scan.next();
                System.out.println("Informe a raça do animal: ");
                String racaedit = scan.next();
                System.out.println("Informe a idade do animal: ");
                int idadeedit = scan.nextInt();
                System.out.println("Informe o nome do tutor do animal: ");
                String tutoredit = scan.next();

                System.out.println("Selecione o andar pertence ao tipo do animal: \n"
                        +"1 - Cachorro\n"
                        +"2 - Gato\n"
                        +"3 - Silvestre\n");
                int andaredit = scan.nextInt();
                if (andaredit == 1) {
                    conexao.editaAnimal(nomeedit, novoNome, "cachorro", racaedit, idadeedit, tutoredit, 1);
                } else if (andaredit == 2) {
                    conexao.editaAnimal(nomeedit, novoNome, "gato", racaedit, idadeedit, tutoredit, 2);
                } else if (andaredit == 3) {
                    conexao.editaAnimal(nomeedit, novoNome, "silvestre", racaedit, idadeedit, tutoredit, 3);
                } else {
                    System.out.println("Opção inválida. Informe uma opção válida!");
                }
                break;
            case 3:
                boolean resposta = true;
                do{
                    System.out.println("\n========EXCLUIR ANIMAL========\n");
                    System.out.println("Deseja listar os animais do cadastrados?( 1 - sim ou 2 - não): ");
                    int excluir = scan.nextInt();
                    if(excluir == 1)
                    {
                        conexao.listarAnimais();
                        System.out.println("\nInforme qual animal deseja excluir: ");
                        String nomeExcluir = scan.next();
                        conexao.excluirAnimal(nomeExcluir);
                    }
                    else if(excluir == 2){
                        System.out.println("\nInforme qual animal deseja excluir: ");
                        String nomeExcluir = scan.next();
                        conexao.excluirAnimal(nomeExcluir);
                    }
                    else
                    {
                        resposta = false;
                    }
                }while(!resposta);
            case 4:
                menuPrincipal();
        }
    }

    public void menuPessoa() {
        MetodosPessoa conexao = new MetodosPessoa();
        System.out.println("\n----------MENU PESSOA----------");
        System.out.println("1 - Cadastro");
        System.out.println("2 - Editar cadastro");
        System.out.println("3 - Excluir cadastro");
        System.out.println("4 - voltar");
        System.out.println("Escolha uma opção: ");
        int opcao = scan.nextInt();

        switch (opcao){
            case 1:
                System.out.println("\n----------CADASTRO----------");
                System.out.println("Informe o nome da pessoa: ");
                String nome = scan.next();
                System.out.println("Informe o documento da pessoa: ");
                String documento = scan.next();
                System.out.println("Informe o tipo da pessoa \n"
                                    + "1 - Tutor\n"
                                    + "2 - Funcionário");
                int tipo = scan.nextInt();
                if(tipo == 1){
                    Tutor tutor = new Tutor(nome, documento, "Tutor");
                    conexao.inserirPessoa(tutor);
                }
                else if(tipo == 2){
                    Funcionario func = new Funcionario(nome, documento, "Funcionário");
                    conexao.inserirPessoa(func);
                }
                else{
                    System.out.println("Informe uma opcao válida!\n");
                    menuPessoa();
                }
                break;
            case 2:
                boolean op = true;

                do{
                    System.out.println("\n----------EDITAR----------");
                    System.out.println("Deseja exibir as pessoas cadastradas(1 - sim ou 2 - não): ");
                    int escolha = scan.nextInt();
                    if(escolha == 1) {
                        conexao.listarPessoas();
                        System.out.println("Informe o nome da pessoa que deseja editar: ");
                        String nomeEditar = scan.next();


                        System.out.println("\nInforme o nome da pessoa: ");
                        String nomeEdit = scan.next();
                        System.out.println("Informe o documento da pessoa: ");
                        String documentoEdit = scan.next();
                        System.out.println("Informe o tipo da pessoa \n"
                                + "1 - Tutor\n"
                                + "2 - Funcionário");
                        int tipoEdit = scan.nextInt();
                        if (tipoEdit == 1) {
                            conexao.editaPessoa(nomeEditar, nomeEdit, documentoEdit, tipoEdit);
                        } else if (tipoEdit == 2) {
                            conexao.editaPessoa(nomeEditar, nomeEdit, documentoEdit, tipoEdit);
                        } else {
                            System.out.println("Informe uma opcao válida!\n");
                            menuPessoa();
                        }
                    }
                    else if(escolha == 2){
                            System.out.println("Informe o nome da pessoa que deseja editar: ");
                            String nomeEditar = scan.next();


                            System.out.println("\nInforme o nome da pessoa: ");
                            String nomeEdit = scan.next();
                            System.out.println("Informe o documento da pessoa: ");
                            String documentoEdit = scan.next();
                            System.out.println("Informe o tipo da pessoa \n"
                                    + "1 - Tutor\n"
                                    + "2 - Funcionário");
                            int tipoEdit = scan.nextInt();
                            if(tipoEdit == 1){
                                conexao.editaPessoa(nomeEditar, nomeEdit, documentoEdit, tipoEdit);
                            }
                            else if(tipoEdit == 2){
                                conexao.editaPessoa(nomeEditar, nomeEdit, documentoEdit, tipoEdit);
                            }
                            else{
                                System.out.println("Informe uma opcao válida!\n");
                                menuPessoa();
                            }
                        }
                    else{
                        System.out.println("Opção inválida, informe uma opção válida!\n");
                        op = false;
                    }
                        break;
                }while(!op);
                break;

            case 3:
                op = true;
                do{
                    System.out.println("\n----------EXCLUIR----------");
                    System.out.println("\nDeseja exibir as pessoas cadastradas(1 - sim ou 2 - não): ");
                    int escolha = scan.nextInt();
                    if(escolha == 1){
                        conexao.listarPessoas();
                        System.out.println("Informe o nome da pessoa que deseja excluir: ");
                        String nomeExcluir = scan.next();
                        conexao.excluirPessoa(nomeExcluir);
                        break;
                    }
                    else if(escolha == 2){
                        System.out.println("Informe o nome da pessoa que deseja excluir: ");
                        String nomeExcluir = scan.next();
                        conexao.excluirPessoa(nomeExcluir);
                        break;
                    }
                    else{
                        System.out.println("Opção inválida! Informe uma opção válida!\n");
                        op = false;
                    }
                }while(!op);
                break;

        }
    }

    public void menuAgenda() {
        MetodosAnimal conexao = new MetodosAnimal();
        System.out.println("\n----------MENU AGENDA----------");
        System.out.println("1 - Entrada do animal");
        System.out.println("2 - Saída do animal");
        System.out.println("3 - voltar");
        System.out.println("Escolha uma opção: ");
        int opcao = scan.nextInt();

        switch (opcao){
            case 1:
                boolean resposta = true;
                do{
                    System.out.println("\n========ENTRADA========\n");
                    System.out.println("Deseja listar os animais do cadastrados?( 1 - sim ou 2 - não): ");
                    int escolha = scan.nextInt();
                    if(escolha == 1){
                        conexao.listarAnimais();
                        System.out.println("\nInforme o nome do animal para a entrada: ");
                        String nomeEntrada = scan.next();
                        conexao.registrarEntrada(nomeEntrada);
                    }
                    else if(escolha == 2){
                        System.out.println("\nInforme o nome do animal para a entrada: ");
                        String nomeEntrada = scan.next();
                        conexao.registrarEntrada(nomeEntrada);
                    }
                    else
                    {
                        resposta = false;
                    }
                }while(!resposta);
                break;
            case 2:
                resposta = true;
                do{
                    System.out.println("\n========ENTRADA========\n");
                    System.out.println("Deseja listar os animais do cadastrados?( 1 - sim ou 2 - não): ");
                    int escolha = scan.nextInt();
                    if(escolha == 1){
                        conexao.listarAnimais();
                        System.out.println("\nInforme o nome do animal para a saída: ");
                        String nomeEntrada = scan.next();
                        conexao.registrarSaida(nomeEntrada);
                    }
                    else if(escolha == 2){
                        System.out.println("\nInforme o nome do animal para a saída: ");
                        String nomeEntrada = scan.next();
                        conexao.registrarSaida(nomeEntrada);
                    }
                    else
                    {
                        resposta = false;
                    }
                }while(!resposta);
                break;

            case 3:
                menuPrincipal();
        }
    }
}