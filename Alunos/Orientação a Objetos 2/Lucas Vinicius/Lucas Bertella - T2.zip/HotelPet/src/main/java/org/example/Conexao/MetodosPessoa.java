package org.example.Conexao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.example.Animais.Animal;
import org.example.Pessoa.Pessoa;

public class MetodosPessoa {
    private com.mongodb.MongoClient conecta = new MongoClient();

    //Conectar com o Database
    private MongoDatabase db = conecta.getDatabase("hotelPet");

    //Conectar na Coleção
    private MongoCollection<Document> pessoas = db.getCollection("pessoa");

    public boolean verificaPessoa(String nome) {
        Bson filtro = Filters.eq("Nome", nome);
        return pessoas.find(filtro).first() != null;
    }

    public void inserirPessoa(Pessoa pessoa){
        if(!verificaPessoa(pessoa.getNome())){
            Document novoAnimal = new Document("Nome", pessoa.getNome())
                    .append("Documento", pessoa.getDocumento())
                    .append("Tipo", pessoa.getTipo());
            pessoas.insertOne(novoAnimal);
            System.out.println("O cadastro foi realizado com sucesso!\n");
        }else{
            System.out.println("A pessoa já está cadastrada!\n");
        }
    }

    public void editaPessoa(String nome, String novoNome, String documento, int tipo) {
        if (verificaPessoa(nome)) {
            Bson filtro = Filters.eq("Nome", nome);
            Bson update = Updates.combine(
                    Updates.set("Nome", novoNome),
                    Updates.set("Documento", documento),
                    Updates.set("Tipo", tipo));

            UpdateResult resultado = pessoas.updateOne(filtro, update);

            if (resultado.getModifiedCount() > 0) {
                System.out.println("A pessoa foi editado com sucesso\n");
            } else {
                System.out.println("Não houve nenhuma alteração no registro da pessoa!\n");
            }
        } else {
            System.out.println("Erro ao editar a pessoa, a pessoa não foi encontrada!\n");
        }
    }

    public void excluirPessoa(String nome){
        if(verificaPessoa(nome)){
            pessoas.deleteOne(Filters.eq("Nome", nome));
            System.out.println("O animal foi deletado com sucesso!\n");
        }else{
            System.out.println("o animal " + nome + " nao foi encontrado!\n");
        }
    }


    public void listarPessoas() {
        MongoCursor<Document> cursor = pessoas.find().iterator();
        try {
            while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println("Nome: " + document.getString("Nome"));
                System.out.println("Documento: " + document.getString("Documento"));
                System.out.println("Tipo: " + document.getString("Tipo"));
                System.out.println();
            }
        } finally {
            cursor.close();
        }
    }
}
