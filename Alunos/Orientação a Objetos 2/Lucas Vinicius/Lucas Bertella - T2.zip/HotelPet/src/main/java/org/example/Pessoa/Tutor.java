package org.example.Pessoa;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.example.Animais.Animal;

public class Tutor extends Pessoa {


    public Tutor(String nome, String documento, String tipo) {
        super(nome, documento, "tutor");
    }

    public Tutor(){

    }
}
