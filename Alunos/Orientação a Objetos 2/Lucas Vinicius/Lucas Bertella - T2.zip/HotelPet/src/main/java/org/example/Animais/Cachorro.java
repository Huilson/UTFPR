package org.example.Animais;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class Cachorro extends Animal {

    public Cachorro(String nome, String raca, int idade, String tutor) {
        super(nome, "cachorro", raca, idade, tutor, 1);
    }

    public Cachorro(){

    }

}
