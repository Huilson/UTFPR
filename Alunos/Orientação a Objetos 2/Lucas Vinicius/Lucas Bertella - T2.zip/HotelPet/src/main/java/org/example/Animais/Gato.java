package org.example.Animais;

public class Gato extends Animal {

    public Gato(String nome, String raca, int idade, String tutor) {
        super(nome, "gato", raca, idade, tutor, 2);
    }

    public Gato(){

    }
}
