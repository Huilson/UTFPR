package org.example.Conexao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import com.mongodb.MongoClientURI;


public class Conexao {
        public static final MongoClientURI uri = new MongoClientURI("mongodb://localhost:27017");
        private static MongoClient client;
        private static MongoDatabase db;
        MongoCollection<Document> hotelpet;

        public Conexao() {
                client = new MongoClient(uri);
                db = client.getDatabase("HotelPet");
                hotelpet = db.getCollection("hotelpet");
        }


        public void close() {
                client.close();
        }
}
