package org.example.Animais;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class Silvestres extends Animal {

    public Silvestres(String nome, String raca, int idade, String tutor) {
        super(nome, "silvestre", raca, idade, tutor, 3);
    }

    public Silvestres(){

    }
}
