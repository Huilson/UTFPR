package org.example.Conexao;

import com.mongodb.MongoClient;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.example.Animais.Animal;

import java.time.LocalDate;

public class MetodosAnimal {
    private com.mongodb.MongoClient conecta = new MongoClient();

    //Conectar com o Database
    private MongoDatabase db = conecta.getDatabase("hotelPet");

    //Conectar na Coleção
    private MongoCollection<Document> animais = db.getCollection("animal");



    public boolean verificaAnimal(String nome) {
        Bson filtro = Filters.eq("Nome", nome);
        return animais.find(filtro).first() != null;
    }

    public void inserirAnimal(Animal animal){
        if(!verificaAnimal(animal.getNome())){
            Document novoAnimal = new Document("Nome", animal.getNome())
                    .append("Especie", animal.getEspecie())
                    .append("Idade", animal.getIdade())
                    .append("Tutor", animal.getTutor())
                    .append("Andar", animal.getAndar());
            animais.insertOne(novoAnimal);
            System.out.println("O cadastro foi realizado com sucesso!\n");
        }else{
            System.out.println("O animal já está cadastrado!\n");
        }
    }

    public void editaAnimal(String nome, String novoNome, String especie, String raca, int idade, String tutor, int andar) {
        if (verificaAnimal(nome)) {
            Bson filtro = Filters.eq("Nome", nome);
            Bson update = Updates.combine(
                    Updates.set("Nome", novoNome),
                    Updates.set("Especie", especie),
                    Updates.set("Raça", raca),
                    Updates.set("Idade", idade),
                    Updates.set("Tutor", tutor),
                    Updates.set("Andar", andar));

            UpdateResult resultado = animais.updateOne(filtro, update);

            if (resultado.getModifiedCount() > 0) {
                System.out.println("O animal foi editado com sucesso\n");
            } else {
                System.out.println("Nenhuma alteração foi realizada no registro do animal\n");
            }
        } else {
            System.out.println("Erro ao editar o animal. O animal não foi encontrado!\n");
        }
    }
    public void excluirAnimal(String nome){
        if(verificaAnimal(nome)){
            animais.deleteOne(Filters.eq("Nome", nome));
            System.out.println("O animal foi deletado com sucesso!\n");
        }else{
            System.out.println("o animal " + nome + " nao foi encontrado!\n");
        }
    }

    public void listarAnimais() {
        MongoCursor<Document> cursor = animais.find().iterator();
        try {
            while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println("Nome: " + document.getString("Nome"));
                System.out.println("Espécie: " + document.getString("Especie"));
                System.out.println("Idade: " + document.getInteger("Idade"));
                System.out.println("Tutor: " + document.getString("Tutor"));
                System.out.println("Andar: " + document.getInteger("Andar"));
                System.out.println();
            }
        } finally {
            cursor.close();
        }
    }

    public void registrarEntrada(String nome) {
        if (verificaAnimal(nome)) {
            Bson filtro = Filters.eq("Nome", nome);
            Bson update = Updates.set("dataEntrada", LocalDate.now().toString());
            UpdateResult resultado = animais.updateOne(filtro, update);

            if (resultado.getModifiedCount() > 0) {
                System.out.println("Entrada registrada com sucesso para o animal: " + nome);
            } else {
                System.out.println("Não foi possível registrar a entrada do animal.");
            }
        } else {
            System.out.println("Animal não encontrado, realize o cadastro do animal");
        }
    }

    public void registrarSaida(String nome) {
        if (verificaAnimal(nome)) {
            Bson filtro = Filters.eq("Nome", nome);
            Bson update = Updates.set("dataSaida", LocalDate.now().toString());
            UpdateResult resultado = animais.updateOne(filtro, update);

            if (resultado.getModifiedCount() > 0) {
                System.out.println("Saída registrada com sucesso para o animal: " + nome);
            } else {
                System.out.println("Não foi possível registrar a saída do animal.");
            }
        } else {
            System.out.println("Animal não encontrado, realize o cadastro do animal.");
        }
    }
}
