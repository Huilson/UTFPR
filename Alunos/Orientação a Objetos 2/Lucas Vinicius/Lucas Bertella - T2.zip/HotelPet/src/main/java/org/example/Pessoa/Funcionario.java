package org.example.Pessoa;

import org.example.Animais.Animal;

public class Funcionario extends Pessoa{

    public Funcionario(String nome, String documento, String tipo) {
        super(nome, documento, "funcionário");
    }

    public Funcionario(){

    }
}
