package org.example.APP;

import org.example.View.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.menuPrincipal();

    }
}
