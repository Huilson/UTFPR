package com.HotelPet.HotelPetSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelPetcomSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
