package org.example.Pessoas;

import org.example.Animais.Animal;

import java.util.ArrayList;
import java.util.Scanner;

public class Tutor extends Pessoa {

    public Tutor(String nome, int documento, int tipo) {
        super(nome, documento, tipo);

    }

    public Tutor() {
    }
}
