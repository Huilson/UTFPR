package br.com.alura.mvc.mudi.controller;

import br.com.alura.mvc.mudi.model.User;
import br.com.alura.mvc.mudi.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AuthController {
    
    @Autowired
    private CustomUserDetailsService userService;
    
    public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login");
        return modelAndView;
    }
    
    @RequestMapping(value = "/signup", method = RequestMethod.GET)
    public ModelAndView singup(){
        ModelAndView modelAndView = new ModelAndView();
        User user = new User();
        modelAndView.addObject("user", user);
        modelAndView.setViewName("signup");
        return modelAndView;
    }
    
    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public ModelAndView createNewUser (User user, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView();
        User userExists = userService.findUserByEmail(user.getEmail());
        
        if(userExists != null){
            bindingResult.rejectValue("email", "error.user", "Esse nome de usuário já esta sendo utilizado");
        }
        
        if(bindingResult.hasErrors()){
            modelAndView.setViewName("signup");
        }else{
            userService.saveUser(user);
            modelAndView.addObject("SuccessMessage", "Usuário foi cadastrado com sucesso");
            modelAndView.addObject("user", new User());
            modelAndView.setViewName("login");
        }
        
        return modelAndView;
    }
    
    @RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    public ModelAndView dashboard(){
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user  = userService.findUserByEmail(auth.getName());
        modelAndView.addObject("CurrentUser", user);
        modelAndView.addObject("Name", "Welcome "+user.getName());
        modelAndView.addObject("adminMessage", "Conteudo não permitido para esse nível de usuário");
        modelAndView.addObject("dashboard");
        return modelAndView;
    }
    
    /*@RequestMapping(value = {"/", "index"}, method = RequestMethod.GET)
    public ModelAndView index(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index");
        return modelAndView;
    }*/
}