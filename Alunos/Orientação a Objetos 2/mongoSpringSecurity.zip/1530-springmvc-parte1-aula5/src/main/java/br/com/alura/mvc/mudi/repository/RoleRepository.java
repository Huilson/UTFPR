package br.com.alura.mvc.mudi.repository;

import br.com.alura.mvc.mudi.model.Role;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RoleRepository extends MongoRepository<Role, String>{
    Role findByRole(String role);
}
