package hotelPet.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import hotelPet.codec.CodecTutor;
import hotelPet.model.Tutor;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class TutorRepository {

    public MongoDatabase conecta(){
                //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        //Passar para a classe de codificação qual será o codec usado
        CodecTutor tutorCodec = new CodecTutor(codec);
        
        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(), 
                CodecRegistries.fromCodecs(tutorCodec)
        );
        
        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();
        
        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet");
        return db;
    }
    
    public void salvar(Tutor tutor) {
        MongoDatabase db = conecta();
        MongoCollection<Tutor> tutores = db.getCollection("tutores", Tutor.class);
        //Se eu já tiver um tutor simplesmente atualizo ele
        if(tutor.getId() == null){
            tutores.insertOne(tutor);
        }else{
            tutores.updateOne(Filters.eq("_id",tutor.getId()), new Document("$set",tutor));
        }
        
        //cliente.close();
    }
    
    public List<Tutor> listar (){
        MongoDatabase db = conecta();
        MongoCollection<Tutor> tutores = db.getCollection("tutores", Tutor.class);
        MongoCursor<Tutor> resultado = tutores.find().iterator();
        
        //Lista de Iteração
        List<Tutor> tutorLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Tutor tutor = resultado.next();
            tutorLista.add(tutor);
        }
        
        return tutorLista;
    }
    
    public Tutor findById(String id){
        MongoDatabase db = conecta();
        MongoCollection<Tutor> tutores = db.getCollection("tutores", Tutor.class);
        Tutor tutor = tutores.find(Filters.eq("_id", new ObjectId(id))).first();
        return tutor;
    }

    public List<Tutor> buscarTutores() {
        MongoDatabase db = conecta();
        MongoCollection<Tutor> tutores = db.getCollection("tutores", Tutor.class);
        MongoCursor<Tutor> resultado = tutores.find().iterator();

        List<Tutor> tutorLista = new ArrayList<>();
        try {
            while (resultado.hasNext()) {
                Tutor tutor = resultado.next();
                tutorLista.add(tutor);
            }
        } finally {
            resultado.close();
        }

        return tutorLista;
    }
}


