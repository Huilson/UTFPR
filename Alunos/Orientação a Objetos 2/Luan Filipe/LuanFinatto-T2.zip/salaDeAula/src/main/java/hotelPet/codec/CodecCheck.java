package hotelPet.codec;

import hotelPet.model.Pet;
import hotelPet.model.Check;
import hotelPet.model.Tutor;
import org.bson.*;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;
import java.util.Date;

public class CodecCheck implements CollectibleCodec<Check>{
    private Codec<Document> codec;

    public CodecCheck(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Check generateIdIfAbsentFromDocument(Check check) {
        return documentHasId(check) ? check.criarId() : check;
    }

    @Override
    public boolean documentHasId(Check check) {
        return check.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Check check) {
        if(!documentHasId(check)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            return new BsonString(check.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Check check, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = check.getId();
        String descricao = check.getDescricao();
        Date dataEntrada = check.getDataEntrada();
        Date dataSaida = check.getDataSaida();
        Pet pet = check.getPet();
        Tutor tutor = check.getTutor();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("descricao", descricao);
        doc.put("dataEntrada", dataEntrada);
        doc.put("dataSaida", dataSaida);
        doc.put("andar", check.getAndar());

        doc.put("tutor", new Document("id", tutor.getId())
                .append("nome", tutor.getNome())
                .append("idade", tutor.getIdade()));
        doc.put("pet", new Document("id", pet.getId())
                .append("nome", pet.getNome())
                .append("idade", pet.getIdade()));

        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Check> getEncoderClass() {
        return Check.class;
    }

    @Override
    public Check decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Check check = new Check();
        check.setId(doc.getObjectId("_id"));
        check.setDescricao(doc.getString("descricao"));
        check.setDataEntrada(doc.getDate("dataEntrada"));
        check.setDataSaida(doc.getDate("dataSaida"));
        check.setAndar(doc.getString("andar"));

        if (doc.containsKey("tutor")) {
            Document tutorDoc = doc.get("tutor", Document.class);
            Tutor tutor = new Tutor();
            tutor.setId(tutorDoc.getObjectId("id"));
            tutor.setNome(tutorDoc.getString("nome"));
            tutor.setIdade(tutorDoc.getDate("idade"));
            check.setTutor(tutor);
        }

        if (doc.containsKey("pet")) {
            Document petDoc = doc.get("pet", Document.class);
            Pet pet = new Pet();
            pet.setId(petDoc.getObjectId("id"));
            pet.setNome(petDoc.getString("nome"));
            pet.setIdade(petDoc.getDate("idade"));
            check.setPet(pet);
        }

        return check;
    }    
}
