package hotelPet.codec;

import hotelPet.model.Pet;
import hotelPet.model.Tutor;
import hotelPet.repository.TutorRepository;
import org.bson.*;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

public class CodecPet implements CollectibleCodec<Pet>{
    //Atributo para criação de documento
    private Codec<Document> codec;

    //Construtor
    public CodecPet(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Pet generateIdIfAbsentFromDocument(Pet pet) {
        return documentHasId(pet) ? pet.criarId() : pet;
    }

    @Override
    public boolean documentHasId(Pet pet) {
        //esse método só verifica se o objeto chamado tem ID
        return pet.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Pet pet) {
        //Verifica se o ID foi criado
        if(!documentHasId(pet)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(pet.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Pet pet, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = pet.getId();
        String nome = pet.getNome();
        Date idade = pet.getIdade();
        String tipo = pet.getTipo();
        Tutor tutor = pet.getTutor();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("idade",idade);
        doc.put("tipo", tipo);

        if(tutor.getId() != null){
            doc.put("tutor", new Document("id", tutor.getId())
                    .append("nome", tutor.getNome())
                    .append("idade", tutor.getIdade()));
        }

        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Pet> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Pet.class;
    }

    @Override
    public Pet decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Pet pet = new Pet();
        pet.setId(doc.getObjectId("_id"));
        pet.setNome(doc.getString("nome"));
        pet.setIdade(doc.getDate("idade"));
        pet.setTipo(doc.getString("tipo"));

        if (doc.containsKey("tutor")) {
            Document tutorDoc = doc.get("tutor", Document.class);
            Tutor tutor = new Tutor();
            tutor.setId(tutorDoc.getObjectId("id"));
            tutor.setNome(tutorDoc.getString("nome"));
            tutor.setIdade(tutorDoc.getDate("idade"));
            pet.setTutor(tutor);
        }

        return pet;
    }    
}
