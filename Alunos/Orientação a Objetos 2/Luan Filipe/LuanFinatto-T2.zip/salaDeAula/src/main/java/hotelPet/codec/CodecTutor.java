package hotelPet.codec;

import hotelPet.model.Pet;
import hotelPet.model.Tutor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecTutor implements CollectibleCodec<Tutor>{
    //Atributo para criação de documento
    private Codec<Document> codec;
    
    //Construtor
    public CodecTutor(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Tutor generateIdIfAbsentFromDocument(Tutor tutor) {
        return documentHasId(tutor) ? tutor.criarId() : tutor;
    }

    @Override
    public boolean documentHasId(Tutor tutor) {
        //esse método só verifica se o objeto chamado tem ID
        return tutor.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Tutor tutor) {
        //Verifica se o ID foi criado
        if(!documentHasId(tutor)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(tutor.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Tutor tutor, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = tutor.getId();
        String nome = tutor.getNome();
        Date idade = tutor.getIdade();
        String telefone = tutor.getTelefone();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("idade",idade);
        doc.put("telefone", telefone);

        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Tutor> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Tutor.class;
    }

    @Override
    public Tutor decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Tutor tutor = new Tutor();
        tutor.setId(doc.getObjectId("_id"));
        tutor.setNome(doc.getString("nome"));
        tutor.setIdade(doc.getDate("idade"));
        tutor.setTelefone(doc.getString("telefone"));

        return tutor;
    }    
}
