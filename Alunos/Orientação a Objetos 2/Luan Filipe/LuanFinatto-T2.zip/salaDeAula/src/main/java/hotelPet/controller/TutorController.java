package hotelPet.controller;

import hotelPet.model.Tutor;
import hotelPet.repository.TutorRepository;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TutorController {
    
//Injeções de dependência
    @Autowired
    private TutorRepository repository;
    
    @GetMapping("/tutor/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("tutor", new Tutor());
        return "tutor/cadastrar";
    }
    
    @PostMapping("/tutor/salvar")
    public String salvar(@ModelAttribute Tutor tutor){
        System.out.println("Salvando");
        repository.salvar(tutor);
        return"redirect:/";
    }
    
    @GetMapping("/tutor/listar")
    public String listar(Model model){
        List<Tutor> tutores = repository.listar();
        model.addAttribute("tutores", tutores);
        return"tutor/listar";
    }
}
