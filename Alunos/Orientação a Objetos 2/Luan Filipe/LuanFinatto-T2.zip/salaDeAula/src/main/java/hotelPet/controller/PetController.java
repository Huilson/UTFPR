package hotelPet.controller;

import hotelPet.model.Check;
import hotelPet.model.Pet;
import hotelPet.model.Tutor;
import hotelPet.repository.PetRepository;
import hotelPet.repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class PetController {
    
    //Injeções de dependência
    @Autowired
    private PetRepository repository;

    @Autowired
    private TutorRepository tutorRepository;
    
    @GetMapping("/pet/cadastrar")
    public String cadastrar(Model model){
        List<Tutor> tutores = tutorRepository.buscarTutores();

        model.addAttribute("pet", new Pet());
        model.addAttribute("tutores", tutores);
        return "pet/cadastrar";
    }
    
    @PostMapping("/pet/salvar")
    public String salvar(@ModelAttribute Pet pet){
        System.out.println("Salvando");
        repository.salvar(pet);
        return"redirect:/";
    }
    
    @GetMapping("/pet/listar")
    public String listar(Model model){
        List<Pet> pets = repository.listar();
        model.addAttribute("pets",pets);
        return"pet/listar";
    }

    @GetMapping("/pet/atualizar/{id}")
    public String visualizar(@PathVariable String id,
                             Model model){
        Pet pet = repository.findById(id);
        List<Tutor> tutores = tutorRepository.buscarTutores();

        model.addAttribute("tutores", tutores);
        model.addAttribute("pet", pet);
        return "pet/atualizar";
    }

    @PostMapping("/pet/editar/{id}")
    public String editar(@ModelAttribute Pet pet){
        repository.salvar(pet);
        return "redirect:/pet/listar";
    }

    @GetMapping("/pet/excluir/{id}")
    public String excluir(@PathVariable String id){
        repository.excluir(id);
        return "redirect:/pet/listar";
    }
}
