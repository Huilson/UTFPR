package hotelPet.controller;

import hotelPet.model.Check;
import hotelPet.model.Pet;
import hotelPet.model.Tutor;
import hotelPet.repository.CheckRepository;
import hotelPet.repository.PetRepository;
import hotelPet.repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class CheckController {

    @Autowired
    private CheckRepository repository;
    @Autowired
    private PetRepository petRepository;
    @Autowired
    private TutorRepository tutorRepository;
    
    @GetMapping("/check-in/cadastrar")
    public String cadastrarCheckIn(Model model){
        List<Pet> pets = petRepository.buscarPets();

        model.addAttribute("check", new Check());
        model.addAttribute("pets", pets);
        return "check-in/cadastrar";
    }

    @GetMapping("/check-in/listar")
    public String listarCheckIn(Model model){
        List<Check> checks = repository.listarCheckIns(0);
        model.addAttribute("checks", checks);
        return "check-in/listar";
    }

    @GetMapping("/check-out/listar")
    public String listarCheckOut(Model model){
        List<Check> checks = repository.listarCheckOuts();
        model.addAttribute("checks", checks);
        return "check-out/listar";
    }

    @GetMapping("/check-in/andar/{andar}")
    public String primeiroAndar(@PathVariable Integer andar,
                                Model model){
        List<Check> checks = repository.listarCheckIns(andar);
        model.addAttribute("checks", checks);
        return "check-in/andar";
    }


    
    @PostMapping("/check/salvar")
    public String salvar(@ModelAttribute Check check){
        System.out.println("Salvando");
        repository.salvar(check);
        return"redirect:/";
    }

    // fazer assim ou fazer um dialog???
    @GetMapping("/check-in/atualizar/{id}")
    public String visualizar(@PathVariable String id,
                             Model model){
        Check check = repository.findById(id);
        model.addAttribute("check", check);
        return "check-in/atualizar";
    }

    @PostMapping("/check/editar/{id}")
    public String editar(@ModelAttribute Check check){
        repository.checkOut(check.getId().toString(), check.getDataSaida());
        return "redirect:/check-out/listar";
    }

    

}
