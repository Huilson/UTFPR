package hotelPet.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import hotelPet.codec.CodecPet;
import hotelPet.model.Pet;
import hotelPet.model.Pet;
import hotelPet.model.Tutor;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PetRepository {

    public MongoDatabase conecta(){
                //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        //Passar para a classe de codificação qual será o codec usado
        CodecPet petCodec = new CodecPet(codec);
        
        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(), 
                CodecRegistries.fromCodecs(petCodec)
        );
        
        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();
        
        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet");
        return db;
    }
    
    public void salvar(Pet pet) {

        TutorRepository tutorRepository = new TutorRepository();

        MongoDatabase db = conecta();

        if(pet.getTutor().getId() != null){
            pet.setTutor(tutorRepository.findById(pet.getTutor().getId().toHexString()));
        }else if(pet.getTutor().getNome() != null){
            pet.setTutor(tutorRepository.findById(pet.getTutor().getNome()));
        }

        MongoCollection<Pet> pets = db.getCollection("pets", Pet.class);
        //Se eu já tiver um pet simplesmente atualizo ele
        if(pet.getId() == null){
            pets.insertOne(pet);
        }else{
            pets.updateOne(Filters.eq("_id",pet.getId()), new Document("$set",pet));
        }
        
        //cliente.close();
    }
    
    public List<Pet> listar (){
        MongoDatabase db = conecta();
        MongoCollection<Pet> pets = db.getCollection("pets", Pet.class);
        MongoCursor<Pet> resultado = pets.find().iterator();
        
        //Lista de Iteração
        List<Pet> petLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Pet pet = resultado.next();
            petLista.add(pet);
        }
        
        return petLista;
    }
    
    public Pet findById(String id){
        MongoDatabase db = conecta();
        MongoCollection<Pet> pets = db.getCollection("pets", Pet.class);
        Pet pet = pets.find(Filters.eq("_id", new ObjectId(id))).first();
        return pet;
    }

    public List<Pet> buscarPets() {
        MongoDatabase db = conecta();
        MongoCollection<Pet> pets = db.getCollection("pets", Pet.class);
        MongoCursor<Pet> resultado = pets.find().iterator();

        List<Pet> petLista = new ArrayList<>();
        try {
            while (resultado.hasNext()) {
                Pet pet = resultado.next();
                petLista.add(pet);
            }
        } finally {
            resultado.close();
        }

        return petLista;
    }

    public void excluir(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Pet> pets = db.getCollection("pets", Pet.class);
        pets.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }
}


