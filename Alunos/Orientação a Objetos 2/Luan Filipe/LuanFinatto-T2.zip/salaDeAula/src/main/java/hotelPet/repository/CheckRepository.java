package hotelPet.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import hotelPet.codec.CodecCheck;
import hotelPet.model.Check;
import hotelPet.model.Pet;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class CheckRepository {

    public MongoDatabase conecta(){
                //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        //Passar para a classe de codificação qual será o codec usado
        CodecCheck codecCheck = new CodecCheck(codec);
        
        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(), 
                CodecRegistries.fromCodecs(codecCheck)
        );
        
        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();
        
        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet");
        return db;
    }
    
    public void salvar(Check check) {

        TutorRepository tutorRepository = new TutorRepository();
        PetRepository petRepository = new PetRepository();

        MongoDatabase db = conecta();
        MongoCollection<Check> checks = db.getCollection("checks", Check.class);

        if(check.getPet().getId() != null){
            check.setPet(petRepository.findById(check.getPet().getId().toHexString()));
            switch (check.getPet().getTipo()){
                case "GATO":
                    check.setAndar("1");
                    break;
                case "CACHORRO":
                    check.setAndar("2");
                    break;
                case "ARARA":
                    check.setAndar("3");
                    break;
            }
            check.setTutor(tutorRepository.findById(check.getPet().getTutor().getId().toHexString()));
        }

        if(check.getId() == null){
            checks.insertOne(check);
        }else{
            checks.updateOne(Filters.eq("_id",check.getId()), new Document("$set",check));
        }
        
        //cliente.close();
    }

    public void checkOut(String id, Date dataCheckout){
        Check check = findById(id);
        check.setDataSaida(dataCheckout);
        salvar(check);
    }
    
    public List<Check> listar (){
        MongoDatabase db = conecta();
        MongoCollection<Check> checks = db.getCollection("checks", Check.class);
        MongoCursor<Check> resultado = checks.find().iterator();
        
        //Lista de Iteração
        List<Check> checkLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Check check = resultado.next();
            checkLista.add(check);
        }
        
        return checkLista;
    }

    public List<Check> listarCheckIns(Integer andar){
        MongoDatabase db = conecta();
        MongoCollection<Check> checks = db.getCollection("checks", Check.class);
        MongoCursor<Check> resultado;

        if(andar != 0){
            resultado = checks.find(Filters.and(Filters.eq("dataSaida", null), Filters.eq("andar", andar.toString()))).iterator();
        }else {
            resultado = checks.find(Filters.eq("dataSaida", null)).iterator();
        }

        //Lista de Iteração
        List<Check> checkLista = new ArrayList<>();

        while(resultado.hasNext()){
            Check check = resultado.next();
            checkLista.add(check);
        }

        return checkLista;
    }

    public List<Check> listarCheckOuts (){
        MongoDatabase db = conecta();
        MongoCollection<Check> checks = db.getCollection("checks", Check.class);
        MongoCursor<Check> resultado = checks.find(Filters.ne("dataSaida", null)).iterator();

        //Lista de Iteração
        List<Check> checkLista = new ArrayList<>();

        while(resultado.hasNext()){
            Check check = resultado.next();
            checkLista.add(check);
        }

        return checkLista;
    }
    
    public Check findById(String id){
        MongoDatabase db = conecta();
        MongoCollection<Check> checks = db.getCollection("checks", Check.class);
        Check check = checks.find(Filters.eq("_id", new ObjectId(id))).first();
        return check;
    }

    public List<Check> buscarCheckes() {
        MongoDatabase db = conecta();
        MongoCollection<Check> checks = db.getCollection("checks", Check.class);
        MongoCursor<Check> resultado = checks.find().iterator();

        List<Check> checkLista = new ArrayList<>();
        try {
            while (resultado.hasNext()) {
                Check check = resultado.next();
                checkLista.add(check);
            }
        } finally {
            resultado.close();
        }

        return checkLista;
    }
}


