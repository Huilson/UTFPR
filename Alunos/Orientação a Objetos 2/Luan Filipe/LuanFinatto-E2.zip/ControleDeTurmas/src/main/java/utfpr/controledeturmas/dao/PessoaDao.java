package utfpr.controledeturmas.dao;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.controledeturmas.model.Pessoa;

public class PessoaDao {
        private EntityManager em;
        
        //Cria uma injenção de dependência
        public PessoaDao(EntityManager em){
            this.em = em;
        }
        
        public void conecta(){
            this.em.getTransaction().begin();
        }
        
        public void encerrar(){
            this.em.close();
        }
        
        public void salvar(Pessoa pessoa){
            this.em.persist(pessoa);
            this.em.getTransaction().commit();
        }
        
        public void excluir(Pessoa pessoa){
            pessoa = em.merge(pessoa);//Atualiza os dados antes da alteração final
            em.remove(pessoa);
            em.getTransaction().commit();
        }
        
        public List<Pessoa> consultar(){
            String jpql = "SELECT p FROM Pessoa p";
            return this.em.createQuery(jpql, Pessoa.class).getResultList();
        }
        
        public List<Pessoa> consultarNome(String nome){
            String jpql = "SELECT p FROM Pessoa p WHERE p.nome = :nome";
            return this.em.createQuery(jpql, Pessoa.class)
                    .setParameter("nome", nome)
                    .getResultList();
        }
        
        public Pessoa consultarId(int id){
            return this.em.find(Pessoa.class, id);
        }
        
        public void atualizar(Pessoa pessoa){
            this.em.merge(pessoa);
        }
        
        public void apagaTransacao(){
            this.em.getTransaction().rollback();
        }
}
