package utfpr.controledeturmas;

import utfpr.controledeturmas.model.Pessoa;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.model.Profissao;
import utfpr.controledeturmas.util.Factory;

public class ControleDeTurmas {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.startMenu();
    }
}