package utfpr.controledeturmas;

import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.model.Pessoa;
import utfpr.controledeturmas.model.Profissao;
import utfpr.controledeturmas.util.Factory;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Scanner;

public class Menu {
    public void startMenu(){

        // Instancia a classe DAO e inicia a conexão
        EntityManager em = Factory.getEntityManager();
        PessoaDao dao = new PessoaDao(em);
        dao.conecta();
        Scanner sc = new Scanner( System.in );

        // Entra no loop do menu
        Boolean loop = true;
        while ( loop ) {
            System.out.println("\nEscolha uma opção:\n" +
                "1 - Cadastrar Pessoa\n" +
                "2 - Excluir Pessoa\n" +
                "3 - Listar Pessoa\n" +
                "4 - Selecionar Pessoas\n" +
                "5 - Atualizar Pessoas\n" +
                "0 - Sair");

            switch ( sc.nextInt() ) {
                case 1:
                    // Instancia uma nova pessoa e pega todos os dados
                    Pessoa pessoa = new Pessoa();
                    System.out.println("Dados para cadastro: ");
                    System.out.print("Nome: ");
                    pessoa.setNome( sc.next() );
                    System.out.print("CPF: ");
                    pessoa.setCpf( sc.next() );
                    System.out.print("Idade: ");
                    pessoa.setIdade( sc.nextInt() );
                    System.out.print("Contato: ");
                    pessoa.setContato( sc.next() );
                    System.out.print("Cidade: ");
                    pessoa.setCidade( sc.next() );
                    System.out.print("Rua: ");
                    pessoa.setRua( sc.next() );
                    System.out.print("Numero: ");
                    pessoa.setNumero( sc.nextInt() );

                    // Imprime todas as profissões disponiveis
                    System.out.println("Qual a profissão da pessoa: ");
                    int cont = 1;
                    for( Profissao p : Profissao.values()){
                        System.out.println(cont + " - " +p);
                        cont++;
                    }
                    // Pega a pessoa pelo index
                    pessoa.setProfissao( Profissao.values()[ sc.nextInt( )-1] );
                    dao.salvar(pessoa);
                    break;
                case 2:
                    // Imprime todas as pessoas para o usuario
                    // saber o id daquela que ele deseja excluir;
                    List<Pessoa> list = dao.consultar();
                    for(Pessoa p : list){
                        System.out.println("Id: "+p.getId()+" - Nome: "+p.getNome() );
                    }
                    System.out.print("Digite o id da pessoa que deseja deletar: ");
                    Pessoa delete = dao.consultarId( sc.nextInt() );
                    dao.excluir( delete );
                    break;

                case 3:
                    // Imprime todas as pessoas
                    List<Pessoa> lista = dao.consultar();
                    for(Pessoa p : lista){
                        System.out.println("Id: "+p.getId() +
                            "\nNome: "+p.getNome() +
                            "\nCPF: "+p.getCpf()+"\n----------------\n");
                    }
                    break;
                case 4:
                    // Auto Explicativo
                    System.out.println("Buscar pessoa por: \n1 - Id\n2 - Nome" );
                    switch ( sc.nextInt() ){
                        case 1:
                            System.out.print("Digite o id: ");
                            Pessoa p = dao.consultarId( sc.nextInt() );
                            System.out.println("Id: "+p.getId() +
                                "\nNome: "+p.getNome() +
                                "\nCPF: "+p.getCpf());
                            continue;
                        case 2:
                            System.out.print("Digite o nome: ");
                            List<Pessoa> pessoas = dao.consultarNome( sc.next() );
                            for(Pessoa pe : pessoas){
                                System.out.println("Id: "+pe.getId() +
                                    "\nNome: "+pe.getNome() +
                                    "\nCPF: "+pe.getCpf());
                            }
                            continue;
                        default:
                            System.out.println("Opção inválida!" );
                            continue;
                    }
                case 5:
                    // No caso de atualizar, a pessoa escolhe o registro desejado
                    // e sobscreve os registros que deseja. Os campos que deseja
                    // manter igual, precisa apenas deixar o campo em branco,
                    // ai o sistema verifica se está vazio e não sobscreve oq ja está.
                    List<Pessoa> listAtt = dao.consultar();
                    for(Pessoa p : listAtt){
                        System.out.println("Id: "+p.getId()+" - Nome: "+p.getNome() );
                    }
                    System.out.print("Digite o id da pessoa que deseja atualizar: ");
                    Pessoa atualizar = dao.consultarId( sc.nextInt() );

                    System.out.println("Atualizando cadastro - DEIXE EM BRANCO PARA PULAR UM CAMPO" );
                    sc.nextLine(); //pra ignorar
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    if(!nome.isEmpty()) atualizar.setNome( nome );
                    System.out.print("CPF: ");
                    String cpf = sc.nextLine();
                    if(!cpf.isEmpty()) atualizar.setCpf( cpf );
                    System.out.print("Idade: ");
                    String idade = sc.nextLine();
                    if(!idade.isEmpty()) atualizar.setIdade( Integer.parseInt( idade ) );
                    System.out.print("Contato: ");
                    String contato = sc.nextLine();
                    if(!idade.isEmpty()) atualizar.setContato( contato );
                    System.out.print("Cidade: ");
                    String cidade = sc.nextLine();
                    if(!cidade.isEmpty()) atualizar.setCidade( cidade );
                    System.out.print("Rua: ");
                    String rua = sc.nextLine();
                    if(!rua.isEmpty()) atualizar.setRua( rua );
                    System.out.print("Numero: ");
                    String numero = sc.nextLine();
                    if(!numero.isEmpty()) atualizar.setNumero( Integer.parseInt( numero ) );

                    System.out.println("Qual a profissão da pessoa: ");
                    int conte = 1;
                    for( Profissao p : Profissao.values()){
                        System.out.println(conte + " - " +p);
                        conte++;
                    }

                    String nro = sc.nextLine();
                    if(!nro.isEmpty()) atualizar.setProfissao( Profissao.values()[ Integer.parseInt( nro )-1] );

                    dao.atualizar(atualizar);
                    dao.salvar( atualizar );
                    continue;

                case 0:
                    System.out.println("Saindo!" );
                    loop = false;
                    break;
                default:
                    System.out.println("Opção inválida");
                    break;
            }
        }
        dao.encerrar();
    }
}

