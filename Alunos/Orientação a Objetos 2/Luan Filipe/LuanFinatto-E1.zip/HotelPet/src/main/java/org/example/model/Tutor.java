package org.example.model;

public class Tutor extends Pessoa {

  private String pet;

  public String getPet( ) {
    return pet;
  }

  public void setPet( String pet ) {
    this.pet = pet;
  }

  @Override
  public String toString() {
    return "Tutor: Id = " + getId() + ", Nome = " + getNome() + ", Documento = " + getDocumento();
  }
}
