package org.example.Controller;

import org.example.model.CheckInCheckOut;
import org.example.model.Gato;

import java.util.ArrayList;
import java.util.List;

public class CheckInCheckOutController {

    List<CheckInCheckOut> primeiroAndar = new ArrayList<>( );
    List<CheckInCheckOut> segundoAndar = new ArrayList<>( );
    List<CheckInCheckOut> terceiroAndar = new ArrayList<>( );

    public void checkIn( Long animal, String tipo ) {
        CheckInCheckOut check = new CheckInCheckOut( );
        switch ( tipo ) {
            case "ARARA":
                check.setAnimalId( animal );
                primeiroAndar.add( check );
                break;
            case "GATO":
                check.setAnimalId( animal );
                segundoAndar.add( check );
                break;
            case "CACHORRO":
                check.setAnimalId( animal );
                terceiroAndar.add( check );
                break;
        }
    }

    public void checkOut( Long animal, String tipo ) {
        switch ( tipo ) {
            case "ARARA":
                for ( CheckInCheckOut a : primeiroAndar ) {
                    if ( a.getAnimalId( ).equals( animal ) ) {
                        primeiroAndar.remove( a );
                        break;
                    }
                }
                System.out.println( "Animal não encontrado" );
                break;
            case "GATO":
                for ( CheckInCheckOut a : segundoAndar ) {
                    if ( a.getAnimalId( ).equals( animal ) ) {
                        segundoAndar.remove( a );
                        break;
                    }
                }
                System.out.println( "Animal não encontrado" );
                break;
            case "CACHORRO":
                for ( CheckInCheckOut a : terceiroAndar ) {
                    if ( a.getAnimalId( ).equals( animal ) ) {
                        terceiroAndar.remove( a );
                        break;
                    }
                }
                System.out.println( "Animal não encontrado" );
                break;
        }
    }

    public void mostrarAndar( Integer andar ) {
        switch ( andar ) {
            case 1:
                System.out.println( "Primeiro andar: Cachorros" );
                if(primeiroAndar.isEmpty()){
                    System.out.println("Nenhum cachorro hospedado" );
                    break;
                }
                for ( CheckInCheckOut c : primeiroAndar ) {
                    System.out.println( c.toString( ) );
                }
                break;
            case 2:
                System.out.println( "Segundo andar: Gatos" );
                if(segundoAndar.isEmpty()){
                    System.out.println("Nenhum gato hospedado" );
                    break;
                }
                for ( CheckInCheckOut c : segundoAndar ) {
                    System.out.println( c.toString( ) );
                }
                break;
            case 3:
                System.out.println( "Terceiro andar: Araras" );
                if(terceiroAndar.isEmpty()){
                    System.out.println("Nenhuma arara hospedada" );
                }
                for ( CheckInCheckOut c : terceiroAndar ) {
                    System.out.println( c.toString( ) );
                }
                break;
        }
    }
}
