package org.example.Controller;

import org.example.Enum.ESexo;
import org.example.model.AraraAzul;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AraraAzulController {

    private Long araraIdCounter = 1L;

    public List<AraraAzul> telaAraraAzul( List<AraraAzul> listAraras ) {
        Scanner input = new Scanner( System.in );

        System.out.println( "1 - Adicionar arara" );
        System.out.println( "2 - Listar Araras" );
        System.out.println( "3 - Atualizar arara" );
        System.out.println( "4 - Remover arara" );
        System.out.println( "0 - Voltar" );


        switch ( input.nextInt( ) ) {
            case 1:
                // Adicionar arara
                AraraAzul arara = new AraraAzul( );
                System.out.print( "Nome: " );
                arara.setNome( input.next( ) );
                System.out.print( "Documento: " );
                arara.setDocumento( input.next( ) );
                System.out.print( "Espécie: " );
                arara.setEspecie( input.next( ) );
                System.out.print( "Idade: " );
                arara.setIdade( input.nextDouble( ) );
                System.out.print( "Peso: " );
                arara.setPeso( input.nextDouble( ) );
                System.out.print( "Sexo (M/F): " );
                arara.setSexo( ESexo.valueOf( input.next( ).toUpperCase( ) ) );
                arara.setId( araraIdCounter++ );
                listAraras.add( arara );
                System.out.println( "AraraAzul adicionado com sucesso!" );
                break;
            case 2:
                // Listar araras
                for ( AraraAzul a : listAraras ) {
                    System.out.println( a );
                }
                break;
            case 3:
                // Atualizar arara
                System.out.print( "Informe o ID do arara a ser atualizado: " );
                Long updateId = input.nextLong( );
                AraraAzul araraExistente = null;
                for ( AraraAzul a : listAraras ) {
                    if ( a.getId( ).equals( updateId ) ) {
                        araraExistente = a;
                        break;
                    }
                }
                if ( araraExistente != null ) {
                    System.out.print( "Novo nome: " );
                    araraExistente.setNome( input.next( ) );
                    System.out.print( "Novo Documento: " );
                    araraExistente.setDocumento( input.next( ) );
                    System.out.print( "Nova idade: " );
                    araraExistente.setIdade( input.nextDouble( ) );
                    System.out.print( "Novo peso: " );
                    araraExistente.setPeso( input.nextDouble( ) );
                    System.out.println( "AraraAzul atualizado com sucesso!" );
                } else {
                    System.out.println( "AraraAzul não encontrado." );
                }
                break;
            case 4:
                // Remover arara
                System.out.print( "Informe o ID do arara a ser removido: " );
                Long removeId = input.nextLong( );
                AraraAzul araraRemover = null;
                for ( AraraAzul a : listAraras ) {
                    if ( a.getId( ).equals( removeId ) ) {
                        araraRemover = a;
                        break;
                    }
                }
                if ( araraRemover != null ) {
                    listAraras.remove( araraRemover );
                    System.out.println( "AraraAzul removido com sucesso!" );
                } else {
                    System.out.println( "AraraAzul não encontrado." );
                }
                break;
            case 0:
                // Voltar

                return listAraras;
            default:
                System.out.println( "Opção inválida." );
                break;
        }
        telaAraraAzul( listAraras );
        return listAraras;
    }
}
