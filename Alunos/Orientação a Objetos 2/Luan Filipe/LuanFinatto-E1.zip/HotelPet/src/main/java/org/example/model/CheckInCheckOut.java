package org.example.model;

import java.util.Date;

public class CheckInCheckOut {
//    private Long id;
    private Long animalId;
    private Date checkIn = new Date();

//    public Long getId( ) {
//        return id;
//    }
//
//    public void setId( Long id ) {
//        this.id = id;
//    }

    public Long getAnimalId( ) {
        return animalId;
    }

    public void setAnimalId( Long animalId ) {
        this.animalId = animalId;
    }

    public Date getCheckIn( ) {
        return checkIn;
    }

    public void setCheckIn( Date checkIn ) {
        this.checkIn = checkIn;
    }

    @Override
    public String toString() {
        return "CheckInCheckOut: AnimalId = " + getAnimalId() + ", CheckIn = " + getCheckIn();
    }
}
