package org.example.Controller;

import org.example.Enum.ESexo;
import org.example.model.Cachorro;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CachorroController {

    private Long  cachorroIdCounter = 1L;

    public List<Cachorro> telaCachorro( List<Cachorro> listCachorros ) {
        Scanner input = new Scanner( System.in );

        System.out.println( "1 - Adicionar cachorro" );
        System.out.println( "2 - Listar cachorros" );
        System.out.println( "3 - Atualizar cachorro" );
        System.out.println( "4 - Remover cachorro" );
        System.out.println( "0 - Voltar" );


        switch ( input.nextInt( ) ) {
            case 1:
                // Adicionar cachorro
                Cachorro cachorro = new Cachorro( );
                System.out.print( "Nome: " );
                cachorro.setNome( input.next( ) );
                System.out.print( "Espécie: " );
                cachorro.setEspecie( input.next( ) );
                System.out.print( "Idade: " );
                cachorro.setIdade( input.nextDouble( ) );
                System.out.print( "Peso: " );
                cachorro.setPeso( input.nextDouble( ) );
                System.out.print( "Sexo (M/F): " );
                cachorro.setSexo( ESexo.valueOf( input.next( ).toUpperCase( ) ) );
                cachorro.setId(  cachorroIdCounter++ );
                listCachorros.add( cachorro );
                System.out.println( "Cachorro adicionado com sucesso!" );
                break;
            case 2:
                // Listar listCachorros
                for ( Cachorro a : listCachorros ) {
                    System.out.println( a );
                }
                break;
            case 3:
                // Atualizar cachorro
                System.out.print( "Informe o ID do cachorro a ser atualizado: " );
                Long updateId = input.nextLong( );
                Cachorro cachorroExistente = null;
                for ( Cachorro a : listCachorros ) {
                    if ( a.getId( ).equals( updateId ) ) {
                        cachorroExistente = a;
                        break;
                    }
                }
                if ( cachorroExistente != null ) {
                    System.out.print( "Novo nome: " );
                    cachorroExistente.setNome( input.next( ) );
                    System.out.print( "Nova idade: " );
                    cachorroExistente.setIdade( input.nextDouble( ) );
                    System.out.print( "Novo peso: " );
                    cachorroExistente.setPeso( input.nextDouble( ) );
                    System.out.println( "Cachorro atualizado com sucesso!" );
                } else {
                    System.out.println( "Cachorro não encontrado." );
                }
                break;
            case 4:
                // Remover cachorro
                System.out.print( "Informe o ID do cachorro a ser removido: " );
                Long removeId = input.nextLong( );
                Cachorro cachorroRemover = null;
                for ( Cachorro a : listCachorros ) {
                    if ( a.getId( ).equals( removeId ) ) {
                        cachorroRemover = a;
                        break;
                    }
                }
                if ( cachorroRemover != null ) {
                    listCachorros.remove( cachorroRemover );
                    System.out.println( "Cachorro removido com sucesso!" );
                } else {
                    System.out.println( "Cachorro não encontrado." );
                }
                break;
            case 0:
                // Voltar
                return listCachorros;
            default:
                System.out.println( "Opção inválida." );
                break;
        }

        telaCachorro( listCachorros );
        return listCachorros;
    }
}
