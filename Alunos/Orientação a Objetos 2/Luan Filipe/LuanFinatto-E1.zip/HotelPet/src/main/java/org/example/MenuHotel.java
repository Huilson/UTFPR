package org.example;

import org.example.Controller.*;
import org.example.Enum.ESexo;
import org.example.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuHotel {
    private Scanner scan = new Scanner( System.in );
    private List<Tutor> listTutores = new ArrayList<>( );
    private List<AraraAzul> listAraras = new ArrayList<>( );
    private List<Gato> listGatos = new ArrayList<>( );
    private List<Cachorro> listCachorros = new ArrayList<>( );
    private List<Funcionario> listFuncionarios = new ArrayList<>( );
    private List<Despesa> listDespesas = new ArrayList<>();


    private AraraAzulController araraAzulController = new AraraAzulController( );
    private GatoController gatoController = new GatoController( );
    private CachorroController cachorroController = new CachorroController( );
    private TutorController tutorController = new TutorController();
    private FuncionarioController funcionarioController = new FuncionarioController();
    private CheckInCheckOutController checkInCheckOutController = new CheckInCheckOutController();
    private DespesaController despesaController = new DespesaController();


    public void abreMenu( ) {
        boolean loop = true;

        while ( loop ) {
            System.out.println( "----------------------\n" +
                "1 - Pessoa\n" +
                "2 - Animal\n" +
                "3 - Controle entrada\n" +
                "4 - Controle despesas\n" +
                "0 - Sair" );

            switch ( scan.nextInt( ) ) {
                case 1:
                    System.out.println( "----------------------\nAbrindo tela de pessoa" );
                    System.out.println( "1 - Tutor\n" +
                        "2 - Funcionario\n" +
                        "0 - Sair" );

                    switch ( scan.nextInt( ) ) {
                        case 1:
                            listTutores = tutorController.telaTutor( listTutores );
                            break;
                        case 2:
                            listFuncionarios = funcionarioController.telaFuncionario( listFuncionarios );
                            break;
                        case 0:
                            continue;
                        default:
                            System.out.println( "Digite um valor válido" );
                    }
                    break;
                case 2:
                    System.out.println( "Abrindo tela de animais" );
                    System.out.println( "----------------------\n" +
                        "1 - AraraAzul\n" +
                        "2 - Gato\n" +
                        "3 - Cachorro\n" +
                        "0 - Sair" );

                    switch ( scan.nextInt( ) ) {
                        case 1:
                            listAraras = araraAzulController.telaAraraAzul( listAraras );
                            break;
                        case 2:
                            listGatos = gatoController.telaGato( listGatos );
                            break;
                        case 3:
                            listCachorros = cachorroController.telaCachorro( listCachorros );
                            break;
                        case 0:
                            continue;
                        default:
                            System.out.println( "Digite um valor válido" );
                    }
                    break;
                case 3:
                    System.out.println( "Abrindo controle de entrada" );
                    controleEntradaSaida( );
                    break;
                case 4:
                    System.out.println( "Abrindo controle de despesas" );
                    controleDespesas( );
                    break;
                case 0:
                    System.out.println( "Encerrando o sistema!" );
                    loop = false;
                    break;
                default:
                    System.out.println( "Digite um valor válido" );
                    break;
            }
        }
    }

    public void controleEntradaSaida( ) {
        System.out.println( "Abrindo tela de checkIn e checkOut" );
        System.out.println( "----------------------\n" +
            "1 - CheckIn\n" +
            "2 - CheckOut\n" +
            "3 - Listar animais hospedados por andar\n");

        switch ( scan.nextInt( ) ) {
            case 1:
                System.out.println( "----------- QUAL TIPO DE ANIMAL DESEJA HOSPEDAR -----------\n" +
                    "1 - Gato\n" +
                    "2 - Cachorro\n" +
                    "3 - Arara");

                switch ( scan.nextInt( ) ) {
                    case 1:
                        System.out.print("Id do seu gato: " );
                        checkInCheckOutController.checkIn( scan.nextLong( ), "GATO");
                        break;
                    case 2:
                        System.out.print("Id do seu cachorro: " );
                        checkInCheckOutController.checkIn( scan.nextLong( ), "CACHORRO");
                        break;
                    case 3:
                        System.out.print("Id da sua arara: " );
                        checkInCheckOutController.checkIn( scan.nextLong( ), "ARARA");
                        break;
                    default:
                        System.out.println( "Digite um valor válido" );
                }
                break;
            case 2:
                System.out.println( "----------- QUAL TIPO DE ANIMAL DESEJA RESGATAR -----------\n" +
                    "1 - Gato\n" +
                    "2 - Cachorro\n" +
                    "3 - Arara");

                switch ( scan.nextInt( ) ) {
                    case 1:
                        System.out.print("Id do seu cachorro: " );
                        checkInCheckOutController.checkOut( scan.nextLong( ), "GATO");
                        break;
                    case 2:
                        System.out.print("Id do seu gato: " );
                        checkInCheckOutController.checkOut( scan.nextLong( ), "CACHORRO");
                        break;
                    case 3:
                        System.out.print("Id da sua arara: " );
                        checkInCheckOutController.checkOut( scan.nextLong( ), "ARARA");
                        break;
                    default:
                        System.out.println( "Digite um valor válido" );
                }
                break;
            case 3:
                System.out.println( "----------------------\n" +
                    "1º Andar\n" +
                    "2º Andar\n" +
                    "3º Andar\n");

                switch ( scan.nextInt( ) ) {
                    case 1:
                        checkInCheckOutController.mostrarAndar( 1 );
                        break;
                    case 2:
                        checkInCheckOutController.mostrarAndar( 2 );
                        break;
                    case 3:
                        checkInCheckOutController.mostrarAndar( 3 );
                        break;
                    default:
                        System.out.println( "Digite um valor válido" );
                }
                break;

            default:
                System.out.println( "Digite um valor válido" );
        }
    }

    public void controleDespesas( ) {
        listDespesas = despesaController.telaDespesa( listDespesas );
    }
}
