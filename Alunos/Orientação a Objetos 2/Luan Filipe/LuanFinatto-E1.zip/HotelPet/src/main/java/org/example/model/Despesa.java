package org.example.model;

public class Despesa extends AbstractModel {

    private String descricao;
    private Double valor;

    public String getDescricao( ) {
        return descricao;
    }

    public void setDescricao( String descricao ) {
        this.descricao = descricao;
    }

    public Double getValor( ) {
        return valor;
    }

    public void setValor( Double valor ) {
        this.valor = valor;
    }

    @Override
    public String toString( ) {
        return "Despesa: Id = " + getId( ) +
            ", Descricao = " + getDescricao() +
            ", Valor = " + getValor();
    }

}
