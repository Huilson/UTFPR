package org.example.Controller;

import org.example.model.Funcionario;

import java.util.List;
import java.util.Scanner;

public class FuncionarioController {

    private Long tutorIdCounter = 1L;

    public List<Funcionario> telaFuncionario( List<Funcionario> listFuncionarios ) {
        Scanner input = new Scanner( System.in );

        System.out.println( "1 - Adicionar funcionario" );
        System.out.println( "2 - Listar funcionarios" );
        System.out.println( "3 - Atualizar funcionario" );
        System.out.println( "4 - Remover funcionario" );
        System.out.println( "0 - Voltar" );

        switch ( input.nextInt( ) ) {
            case 1:
                // Adicionar funcionario
                Funcionario pessoa = new Funcionario( );
                System.out.print( "Nome: " );
                pessoa.setNome( input.next( ) );
                System.out.print( "Documento: " );
                pessoa.setDocumento( input.next( ) );
                pessoa.setId( tutorIdCounter++ );
                listFuncionarios.add( pessoa );
                System.out.println( "Funcionario adicionado com sucesso!" );
                break;
            case 2:
                // Listar funcionarios
                for ( Funcionario p : listFuncionarios ) {
                    System.out.println( p.toString( ) );
                }
                break;
            case 3:
                // Atualizar funcionario
                System.out.print( "Informe o ID do funcionario a ser atualizado: " );
                Long updateId = input.nextLong( );
                Funcionario funcionarioExistente = null;
                for ( Funcionario p : listFuncionarios ) {
                    if ( p.getId( ).equals( updateId ) ) {
                        funcionarioExistente = p;
                        break;
                    }
                }
                if ( funcionarioExistente != null ) {
                    System.out.print( "Novo nome: " );
                    funcionarioExistente.setNome( input.next( ) );
                    System.out.print( "Novo documento: " );
                    funcionarioExistente.setDocumento( input.next( ) );
                    System.out.println( "Funcionario atualizado com sucesso!" );
                } else {
                    System.out.println( "Funcionario não encontrado." );
                }
                break;
            case 4:
                // Remover funcionario
                System.out.print( "Informe o ID do funcionario a ser removido: " );
                Long removeId = input.nextLong( );
                Funcionario funcionarioRemover = null;
                for ( Funcionario p : listFuncionarios ) {
                    if ( p.getId( ).equals( removeId ) ) {
                        funcionarioRemover = p;
                        break;
                    }
                }
                if ( funcionarioRemover != null ) {
                    listFuncionarios.remove( funcionarioRemover );
                    System.out.println( "Funcionario removido com sucesso!" );
                } else {
                    System.out.println( "Funcionario não encontrado." );
                }
                break;
            case 0:
                // Voltar
                return listFuncionarios;
            default:
                System.out.println( "Opção inválida." );
                break;
        }

        telaFuncionario( listFuncionarios );
        return listFuncionarios;
    }

}
