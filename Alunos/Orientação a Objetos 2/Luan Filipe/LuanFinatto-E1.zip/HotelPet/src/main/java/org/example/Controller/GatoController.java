package org.example.Controller;

import org.example.Enum.ESexo;
import org.example.model.Gato;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GatoController {

    private Long araraIdCounter = 1L;

    public List<Gato> telaGato( List<Gato> listGatos ) {
        Scanner input = new Scanner( System.in );

        System.out.println( "1 - Adicionar gato" );
        System.out.println( "2 - Listar gatos" );
        System.out.println( "3 - Atualizar gato" );
        System.out.println( "4 - Remover gato" );
        System.out.println( "0 - Voltar" );


        switch ( input.nextInt( ) ) {
            case 1:
                // Adicionar gato
                Gato gato = new Gato( );
                System.out.print( "Nome: " );
                gato.setNome( input.next( ) );
                System.out.print( "Espécie: " );
                gato.setEspecie( input.next( ) );
                System.out.print( "Idade: " );
                gato.setIdade( input.nextDouble( ) );
                System.out.print( "Peso: " );
                gato.setPeso( input.nextDouble( ) );
                System.out.print( "Sexo (M/F): " );
                gato.setSexo( ESexo.valueOf( input.next( ).toUpperCase( ) ) );
                gato.setId( araraIdCounter++ );
                listGatos.add( gato );
                System.out.println( "Gato adicionado com sucesso!" );
                break;
            case 2:
                // Listar listGatos
                for ( Gato a : listGatos ) {
                    System.out.println( a );
                }
                break;
            case 3:
                // Atualizar gato
                System.out.print( "Informe o ID do gato a ser atualizado: " );
                Long updateId = input.nextLong( );
                Gato gatoExistente = null;
                for ( Gato a : listGatos ) {
                    if ( a.getId( ).equals( updateId ) ) {
                        gatoExistente = a;
                        break;
                    }
                }
                if ( gatoExistente != null ) {
                    System.out.print( "Novo nome: " );
                    gatoExistente.setNome( input.next( ) );
                    System.out.print( "Nova idade: " );
                    gatoExistente.setIdade( input.nextDouble( ) );
                    System.out.print( "Novo peso: " );
                    gatoExistente.setPeso( input.nextDouble( ) );
                    System.out.println( "Gato atualizado com sucesso!" );
                } else {
                    System.out.println( "Gato não encontrado." );
                }
                break;
            case 4:
                // Remover gato
                System.out.print( "Informe o ID do gato a ser removido: " );
                Long removeId = input.nextLong( );
                Gato gatoRemover = null;
                for ( Gato a : listGatos ) {
                    if ( a.getId( ).equals( removeId ) ) {
                        gatoRemover = a;
                        break;
                    }
                }
                if ( gatoRemover != null ) {
                    listGatos.remove( gatoRemover );
                    System.out.println( "Gato removido com sucesso!" );
                } else {
                    System.out.println( "Gato não encontrado." );
                }
                break;
            case 0:
                // Voltar
                return listGatos;
            default:
                System.out.println( "Opção inválida." );
                break;
        }


        telaGato( listGatos );
        return listGatos;
    }
}
