package org.example.Controller;

import org.example.model.Tutor;

import java.util.List;
import java.util.Scanner;

public class TutorController {

    private Long tutorIdCounter = 1L;

    public List<Tutor> telaTutor( List<Tutor> listTutores ) {
        Scanner input = new Scanner( System.in );

        System.out.println( "1 - Adicionar  2 - Listar   3 - Atualizar   4 - Remover   0 - Voltar" );

        switch ( input.nextInt( ) ) {
            case 1:
                // Adicionar cliente
                Tutor pessoa = new Tutor( );
                System.out.print( "Nome: " );
                pessoa.setNome( input.next( ) );
                System.out.print( "Documento: " );
                pessoa.setDocumento( input.next( ) );
                pessoa.setId( tutorIdCounter++ );
                listTutores.add( pessoa );
                System.out.println( "Tutor adicionado com sucesso!" );
                break;
            case 2:
                // Listar clientes
                for ( Tutor p : listTutores ) {
                    System.out.println( p.toString( ) );
                }
                break;
            case 3:
                // Atualizar cliente
                System.out.print( "Informe o ID do cliente a ser atualizado: " );
                Long updateId = input.nextLong( );
                Tutor clienteExistente = null;
                for ( Tutor p : listTutores ) {
                    if ( p.getId( ).equals( updateId ) ) {
                        clienteExistente = p;
                        break;
                    }
                }
                if ( clienteExistente != null ) {
                    System.out.print( "Novo nome: " );
                    clienteExistente.setNome( input.next( ) );
                    System.out.print( "Novo documento: " );
                    clienteExistente.setDocumento( input.next( ) );
                    System.out.println( "Tutor atualizado com sucesso!" );
                } else {
                    System.out.println( "Tutor não encontrado." );
                }
                break;
            case 4:
                // Remover cliente
                System.out.print( "Informe o ID do cliente a ser removido: " );
                Long removeId = input.nextLong( );
                Tutor clienteRemover = null;
                for ( Tutor p : listTutores ) {
                    if ( p.getId( ).equals( removeId ) ) {
                        clienteRemover = p;
                        break;
                    }
                }
                if ( clienteRemover != null ) {
                    listTutores.remove( clienteRemover );
                    System.out.println( "Tutor removido com sucesso!" );
                } else {
                    System.out.println( "Tutor não encontrado." );
                }
                break;
            case 0:
                // Voltar
                return listTutores;
            default:
                System.out.println( "Opção inválida." );
                break;
        }

        telaTutor( listTutores );
        return listTutores;
    }

}
