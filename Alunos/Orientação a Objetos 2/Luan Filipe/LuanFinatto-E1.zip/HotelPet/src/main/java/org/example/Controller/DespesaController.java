package org.example.Controller;

import org.example.Enum.ESexo;
import org.example.model.Despesa;

import java.util.List;
import java.util.Scanner;

public class DespesaController {

    private Long  despesaIdCounter = 1L;

    public List<Despesa> telaDespesa( List<Despesa> listDespesas ) {
        Scanner input = new Scanner( System.in );

        System.out.println( "1 - Adicionar despesa" );
        System.out.println( "2 - Listar despesas" );
        System.out.println( "3 - Apagar despesa" );
        System.out.println( "0 - Voltar" );


        switch ( input.nextInt( ) ) {
            case 1:
                // Adicionar despesa
                Despesa despesa = new Despesa( );
                System.out.print( "Descrição: " );
                despesa.setDescricao( input.next( ) );
                System.out.print( "Valor: " );
                despesa.setValor( input.nextDouble( ) );
                despesa.setId(  despesaIdCounter++ );
                listDespesas.add( despesa );
                System.out.println( "Despesa adicionado com sucesso!" );
                break;
            case 2:
                // Listar listDespesas
                for ( Despesa a : listDespesas ) {
                    System.out.println( a );
                }
                break;
            case 3:
                // Remover despesa
                System.out.print( "Informe o ID do despesa a ser removido: " );
                Long removeId = input.nextLong( );
                Despesa despesaRemover = null;
                for ( Despesa a : listDespesas ) {
                    if ( a.getId( ).equals( removeId ) ) {
                        despesaRemover = a;
                        break;
                    }
                }
                if ( despesaRemover != null ) {
                    listDespesas.remove( despesaRemover );
                    System.out.println( "Despesa removido com sucesso!" );
                } else {
                    System.out.println( "Despesa não encontrado." );
                }
                break;
            case 0:
                // Voltar
                return listDespesas;
            default:
                System.out.println( "Opção inválida." );
                break;
        }

        telaDespesa( listDespesas );
        return listDespesas;
    }
}
