package org.example.model;

public class AraraAzul extends Animal {

    private String documento;

    public String getDocumento( ) {
        return documento;
    }

    public void setDocumento( String documento ) {
        this.documento = documento;
    }

    @Override
    public String toString( ) {
        return "AraraAzul: Id = " + getId( ) +
            ", Nome = " + getNome( ) +
            ", Documento = " + getDocumento( ) +
            ", Especie = " + getEspecie( ) +
            ", Idade = " + getIdade( ) +
            ", Peso = " + getPeso( ) +
            ", Sexo = " + getSexo( );
    }
}
