package org.example.model.Animal;

import org.example.model.Animal.Animal;

public class Gato extends Animal {
    private String cor;
    private Boolean docil;
    private Boolean castrado;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public Boolean getDocil() {
        return docil;
    }

    public void setDocil(Boolean docil) {
        this.docil = docil;
    }

    public Boolean getCastrado() {
        return castrado;
    }

    public void setCastrado(Boolean castrado) {
        this.castrado = castrado;
    }

    @Override
    public String toString() {
        return "Gato: Id = " + getId() +
                ", Codigo = " + getCodigo() +
                ", Nome = " + getNome() +
                ", Especie = " + getEspecie() +
                ", Idade = " + getIdade() +
                ", Peso = " + getPeso() +
                ", Sexo = " + getSexo();
    }
}
