package org.example.Enum;

public enum ESexo {

    M,
    F;


}
