package org.example.Controller;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.example.DAO.CounterDAO;
import org.example.model.Despesa;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DespesaController {
    private final MongoCollection<Document> despesaCollection;
    private Long despesaIdCounter = 1L;

    public DespesaController() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        despesaCollection = db.getCollection("despesas");
    }

    public void telaDespesa() {
        Scanner input = new Scanner(System.in);

        System.out.println("1 - Adicionar despesa");
        System.out.println("2 - Listar despesas");
        System.out.println("3 - Apagar despesa");
        System.out.println("0 - Voltar");

        switch (input.nextInt()) {
            case 1:
                // Adicionar despesa
                Despesa despesa = new Despesa();
                System.out.print("Descrição: ");
                despesa.setDescricao(input.next());
                System.out.print("Valor: ");
                despesa.setValor(input.nextDouble());

                CounterDAO counterDAO = new CounterDAO();
                Long codigo = counterDAO.getNextSequence("despesas");

                // Converte o objeto Despesa em um Document
                Document document = new Document("id", despesa.getId())
                        .append("codigo", codigo)
                        .append("descricao", despesa.getDescricao())
                        .append("valor", despesa.getValor());

                // Insere o Document no MongoDB
                despesaCollection.insertOne(document);

                System.out.println("Despesa adicionada com sucesso!");
                break;
            case 2:
                // Listar despesas
                List<Despesa> despesas = listAll();
                for (Despesa d : despesas) {
                    System.out.println(d);
                }
                break;
            case 3:
                // Remover despesa
                System.out.print("Informe o codigo da despesa a ser removida: ");
                Long removeCodigo = input.nextLong();

                // Remove a despesa com base no ID
                boolean removed = excluir(removeCodigo);

                if (removed) {
                    System.out.println("Despesa removida com sucesso!");
                } else {
                    System.out.println("Despesa não encontrada.");
                }
                break;
            case 0:
                // Voltar
                return;
            default:
                System.out.println("Opção inválida.");
                break;
        }

        telaDespesa();
    }

    public List<Despesa> listAll() {
        List<Despesa> despesas = new ArrayList<>();
        FindIterable<Document> documents = despesaCollection.find();

        for (Document document : documents) {
            Despesa despesa = new Despesa();
            despesa.setId(document.get("_id", ObjectId.class).toString());
            despesa.setCodigo(document.getLong("codigo"));
            despesa.setDescricao(document.getString("descricao"));
            despesa.setValor(document.getDouble("valor"));
            despesas.add(despesa);
        }

        return despesas;
    }

    public boolean excluir(Long codigo) {
        Document query = new Document("codigo", codigo);
        return despesaCollection.deleteOne(query).getDeletedCount() > 0;
    }
}
