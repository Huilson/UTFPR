/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example.DAO;


import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.example.Enum.ESexo;
import org.example.model.Pessoa.Funcionario;

public class FuncionarioDAO {

    private MongoCollection<Document> funcionarioCollection;

    public FuncionarioDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        funcionarioCollection = db.getCollection("funcionario");
    }

    public void insert(Funcionario func) {

        CounterDAO counterDAO = new CounterDAO();
        Long codigo = counterDAO.getNextSequence("funcionario");

        Document document = new Document("nome", func.getNome())
                .append("codigo", codigo)
                .append("documento", func.getDocumento())
                .append("registro", func.getRegistro())
                .append("setor", func.getSetor());

        funcionarioCollection.insertOne(document);
    }

    public void listAll() {
        FindIterable<Document> funcs = funcionarioCollection.find();
        for (Document document : funcs) {
            // Converte o documento do MongoDB de volta para a classe Funcionario
            Funcionario func = documentToFuncionario(document);
            System.out.println(func);
        }
    }

    public Funcionario findByCodigo(Long codigo) {
        Document query = new Document("codigo", codigo);
        Document document = funcionarioCollection.find(query).first();

        if (document != null) {
            return documentToFuncionario(document);
        } else {
            return null;
        }
    }

    public void update(Funcionario func) {

        funcionarioCollection.updateOne(Filters.eq("codigo", func.getCodigo()),
                new Document("$set", new Document("nome", func.getNome())
                        .append("documento", func.getDocumento())
                        .append("registro", func.getRegistro())
                        .append("setor", func.getSetor())));
    }

    public void delete(Long cod) {
        Document query = new Document("codigo", cod);
        funcionarioCollection.deleteOne(query);
    }

    // Método auxiliar para converter um documento do MongoDB em um objeto Funcionario
    private Funcionario documentToFuncionario(Document document) {
        Funcionario funcionario = new Funcionario();
//        funcionario.setId(document.get("_id", ObjectId.class).toString());
        funcionario.setNome(document.getString("nome"));
        funcionario.setDocumento(document.getString("documento"));
        funcionario.setRegistro(document.getString("registro"));
        funcionario.setSetor(document.getString("setor"));

        return funcionario;
    }
}
