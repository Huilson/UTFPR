package org.example;

import org.example.Controller.*;
import org.example.model.*;
import org.example.model.Animal.AraraAzul;
import org.example.model.Animal.Cachorro;
import org.example.model.Animal.Gato;
import org.example.model.Pessoa.Funcionario;
import org.example.model.Pessoa.Tutor;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuHotel {
    private Scanner scan = new Scanner(System.in);
    private AraraAzulController araraAzulController = new AraraAzulController();
    private GatoController gatoController = new GatoController();
    private CachorroController cachorroController = new CachorroController();
    private TutorController tutorController = new TutorController();
    private FuncionarioController funcionarioController = new FuncionarioController();
    private CheckInCheckOutController checkInCheckOutController = new CheckInCheckOutController();
    private DespesaController despesaController = new DespesaController();


    public void abreMenu() {
        boolean loop = true;

        while (loop) {
            System.out.println("----------------------\n" +
                    "1 - Pessoa\n" +
                    "2 - Animal\n" +
                    "3 - Controle entrada\n" +
                    "4 - Controle despesas\n" +
                    "0 - Sair");

            switch (scan.nextInt()) {
                case 1:
                    System.out.println("----------------------\nAbrindo tela de pessoa");
                    System.out.println("1 - Tutor\n" +
                            "2 - Funcionario\n" +
                            "0 - Sair");

                    switch (scan.nextInt()) {
                        case 1:
                            tutorController.telaTutor();
                            break;
                        case 2:
                            funcionarioController.telaFuncionario();
                            break;
                        case 0:
                            continue;
                        default:
                            System.out.println("Digite um valor válido");
                    }
                    break;
                case 2:
                    System.out.println("Abrindo tela de animais");
                    System.out.println("----------------------\n" +
                            "1 - AraraAzul\n" +
                            "2 - Gato\n" +
                            "3 - Cachorro\n" +
                            "0 - Sair");

                    switch (scan.nextInt()) {
                        case 1:
                            araraAzulController.telaArara();
                            break;
                        case 2:
                            gatoController.telaGato();
                            break;
                        case 3:
                            cachorroController.telaCachorro();
                            break;
                        case 0:
                            continue;
                        default:
                            System.out.println("Digite um valor válido");
                    }
                    break;
                case 3:
                    System.out.println("Abrindo controle de entrada");
                    controleEntradaSaida();
                    break;
                case 4:
                    System.out.println("Abrindo controle de despesas");
                    controleDespesas();
                    break;
                case 0:
                    System.out.println("Encerrando o sistema!");
                    loop = false;
                    break;
                default:
                    System.out.println("Digite um valor válido");
                    break;
            }
        }
    }

    public void controleEntradaSaida() {
        System.out.println("Abrindo tela de checkIn e checkOut");
        System.out.println("----------------------\n" +
                "1 - CheckIn\n" +
                "2 - CheckOut\n" +
                "3 - Listar animais hospedados por andar\n");

        switch (scan.nextInt()) {
            case 1:
                System.out.println("----------- QUAL TIPO DE ANIMAL DESEJA HOSPEDAR -----------\n" +
                        "1 - Gato\n" +
                        "2 - Cachorro\n" +
                        "3 - Arara");

                switch (scan.nextInt()) {
                    case 1:
                        System.out.print("Código do seu gato: ");
                        checkInCheckOutController.checkIn(scan.nextLong(), 1);
                        break;
                    case 2:
                        System.out.print("Código do seu cachorro: ");
                        checkInCheckOutController.checkIn(scan.nextLong(), 2);
                        break;
                    case 3:
                        System.out.print("Código da sua arara: ");
                        checkInCheckOutController.checkIn(scan.nextLong(), 3);
                        break;
                    default:
                        System.out.println("Digite um valor válido");
                }
                break;
            case 2:
                System.out.println("----------- QUAL TIPO DE ANIMAL DESEJA RESGATAR -----------\n" +
                        "1 - Gato\n" +
                        "2 - Cachorro\n" +
                        "3 - Arara");

                switch (scan.nextInt()) {
                    case 1:
                        System.out.print("Código do seu cachorro: ");
                        checkInCheckOutController.checkOut(scan.nextLong());
                        break;
                    case 2:
                        System.out.print("Código do seu gato: ");
                        checkInCheckOutController.checkOut(scan.nextLong());
                        break;
                    case 3:
                        System.out.print("Código da sua arara: ");
                        checkInCheckOutController.checkOut(scan.nextLong());
                        break;
                    default:
                        System.out.println("Digite um valor válido");
                }
                break;
            case 3:
                System.out.println("----------------------\n" +
                        "1º Andar\n" +
                        "2º Andar\n" +
                        "3º Andar\n");

                switch (scan.nextInt()) {
                    case 1:
                        checkInCheckOutController.mostrarAndar(1);
                        break;
                    case 2:
                        checkInCheckOutController.mostrarAndar(2);
                        break;
                    case 3:
                        checkInCheckOutController.mostrarAndar(3);
                        break;
                    default:
                        System.out.println("Digite um valor válido");
                }
                break;

            default:
                System.out.println("Digite um valor válido");
        }
    }

    public void controleDespesas() {
        despesaController.telaDespesa( );
    }
}
