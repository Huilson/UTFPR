package org.example.model.Pessoa;

import org.example.model.Pessoa.Pessoa;

public class Tutor extends Pessoa {

  private String pet;

  public String getPet( ) {
    return pet;
  }

  public void setPet( String pet ) {
    this.pet = pet;
  }

  @Override
  public String toString() {
    return "Tutor: Id = " + getId() +
            ", Codigo = " + getCodigo() +
            ", Nome = " + getNome() +
            ", Documento = " + getDocumento();
  }
}
