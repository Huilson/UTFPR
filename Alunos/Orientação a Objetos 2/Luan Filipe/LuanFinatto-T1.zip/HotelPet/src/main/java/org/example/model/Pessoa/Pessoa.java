package org.example.model.Pessoa;

public abstract class Pessoa {

  private String id;
  private String nome;
  private String documento;

  private Long codigo;

  public Long getCodigo() {
    return codigo;
  }

  public void setCodigo(Long codigo) {
    this.codigo = codigo;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getNome( ) {
    return nome;
  }

  public void setNome( String nome ) {
    this.nome = nome;
  }

  public String getDocumento( ) {
    return documento;
  }

  public void setDocumento( String documento ) {
    this.documento = documento;
  }
}
