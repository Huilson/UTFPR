package org.example.Controller;

import org.example.DAO.GatoDAO;
import org.example.Enum.ESexo;
import org.example.model.Animal.Gato;
import java.util.List;
import java.util.Scanner;

public class GatoController {

    private GatoDAO gatoDAO = new GatoDAO();

    public void telaGato() {
        Scanner input = new Scanner(System.in);

        System.out.println("1 - Adicionar gato");
        System.out.println("2 - Listar gatos");
        System.out.println("3 - Atualizar gato");
        System.out.println("4 - Remover gato");
        System.out.println("0 - Voltar");

        switch (input.nextInt()) {
            case 1:
                // Adicionar gato
                Gato gato = new Gato();
                System.out.print("Nome: ");
                gato.setNome(input.next());
                System.out.print("Espécie: ");
                gato.setEspecie(input.next());
                System.out.print("Idade: ");
                gato.setIdade(input.nextDouble());
                System.out.print("Peso: ");
                gato.setPeso(input.nextDouble());
                System.out.print("Sexo (M/F): ");
                gato.setSexo(ESexo.valueOf(input.next().toUpperCase()));

                // Use o GatoDAO para inserir no banco de dados
                gatoDAO.insert(gato);

                System.out.println("Gato adicionado com sucesso!");
                break;
            case 2:
                // Listar gatos
                gatoDAO.listAll();
                break;
            case 3:
                // Atualizar gato
                System.out.print("Informe o codigo do gato a ser atualizado: ");
                Long updateCodigo = input.nextLong();
                Gato gatoExistente = gatoDAO.findByCodigo(updateCodigo);

                if (gatoExistente != null) {
                    System.out.print("Novo nome: ");
                    gatoExistente.setNome(input.next());
                    System.out.print("Nova idade: ");
                    gatoExistente.setIdade(input.nextDouble());
                    System.out.print("Novo peso: ");
                    gatoExistente.setPeso(input.nextDouble());

                    // Use o GatoDAO para atualizar no banco de dados
                    gatoDAO.update(gatoExistente);

                    System.out.println("Gato atualizado com sucesso!");
                } else {
                    System.out.println("Gato não encontrado.");
                }
                break;
            case 4:
                // Remover gato
                System.out.print("Informe o nome do gato a ser removido: ");
                Long removeCodigo = input.nextLong();
                Gato gatoRemover = gatoDAO.findByCodigo(removeCodigo);

                if (gatoRemover != null) {
                    gatoDAO.delete(removeCodigo);
                    System.out.println("Gato removido com sucesso!");
                } else {
                    System.out.println("Gato não encontrado.");
                }
                break;
            case 0:
                // Voltar
                return;
            default:
                System.out.println("Opção inválida.");
                break;
        }
        return;
    }
}
