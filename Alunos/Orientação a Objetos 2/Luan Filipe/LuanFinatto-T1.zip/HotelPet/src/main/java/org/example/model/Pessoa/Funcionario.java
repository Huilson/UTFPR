package org.example.model.Pessoa;

public class Funcionario extends Pessoa {

    private String setor;
    private String registro;

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getRegistro() {
        return registro;
    }

    public void setRegistro(String registro) {
        this.registro = registro;
    }

    @Override
    public String toString() {
        return "Funcionario: Id = " + getId() +
                ", Codigo = " + getCodigo() +
                ", Nome = " + getNome() +
                ", Documento = " + getDocumento();
    }
}
