/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example.DAO;


import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.example.Enum.ESexo;
import org.example.model.Animal.AraraAzul;

public class AraraAzulDAO {

    private MongoCollection<Document> araraCollection;

    public AraraAzulDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        araraCollection = db.getCollection("arara");
    }

    public void insert(AraraAzul animal) {
        CounterDAO counterDAO = new CounterDAO();
        Long codigo = counterDAO.getNextSequence("arara");

        Document document = new Document("nome", animal.getNome())
                .append("codigo", codigo)
                .append("especie", animal.getEspecie())
                .append("idade", animal.getIdade())
                .append("peso", animal.getPeso())
                .append("sexo", animal.getSexo().toString())
                .append("documento", animal.getDocumento());

        araraCollection.insertOne(document);
    }

    public void listAll() {
        FindIterable<Document> animals = araraCollection.find();
        for (Document document : animals) {
            // Converte o documento do MongoDB de volta para a classe Arara
            AraraAzul animal = documentToArara(document);
            System.out.println(animal);
        }
    }

    public AraraAzul findByCodigo(Long cod) {
        Document query = new Document("codigo", cod);
        Document document = araraCollection.find(query).first();

        if (document != null) {
            return documentToArara(document);
        } else {
            return null;
        }
    }

    public void update(AraraAzul animal) {
        araraCollection.updateOne(Filters.eq("codigo", animal.getCodigo()),
                new Document("$set", new Document("nome", animal.getNome())
                        .append("idade", animal.getIdade())
                        .append("peso", animal.getPeso())
                        .append("sexo", animal.getSexo().toString())
                        .append("documento", animal.getDocumento())));
    }

    public void delete(Long cod) {
        Document query = new Document("codigo", cod);
        araraCollection.deleteOne(query);
    }

    // Método auxiliar para converter um documento do MongoDB em um objeto Arara
    private AraraAzul documentToArara(Document document) {
        AraraAzul arara = new AraraAzul();
        arara.setId(document.get("_id", ObjectId.class).toString());
        arara.setCodigo(document.getLong("codigo"));
        arara.setNome(document.getString("nome"));
        arara.setEspecie(document.getString("especie"));
        arara.setIdade(document.getDouble("idade"));
        arara.setPeso(document.getDouble("peso"));
        arara.setDocumento(document.getString("documento"));

        return arara;
    }
}
