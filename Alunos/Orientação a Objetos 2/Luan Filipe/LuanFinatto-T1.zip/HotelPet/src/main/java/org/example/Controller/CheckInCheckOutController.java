package org.example.Controller;

import org.example.DAO.CheckInCheckOutDAO;


public class CheckInCheckOutController {

    private CheckInCheckOutDAO controller = new CheckInCheckOutDAO();

    public void checkIn( Long animal, Integer andar ) {
        controller.checkIn(animal, andar);
    }

    public void checkOut( Long animal ) {
        controller.checkOut(animal);
    }

    public void mostrarAndar( Integer andar ) {
        switch ( andar ) {
            case 1:
                System.out.println( "Primeiro andar: Cachorros" );
                break;
            case 2:
                System.out.println( "Segundo andar: Gatos" );
                break;
            case 3:
                System.out.println( "Terceiro andar: Araras" );
                break;
        }
        controller.mostrarAndar(andar);
    }
}
