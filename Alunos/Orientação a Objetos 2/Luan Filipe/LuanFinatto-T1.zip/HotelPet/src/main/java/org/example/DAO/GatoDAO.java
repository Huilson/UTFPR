/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example.DAO;


import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.example.Enum.ESexo;
import org.example.model.Animal.Gato;

public class GatoDAO {

    private MongoCollection<Document> gatoCollection;

    public GatoDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        gatoCollection = db.getCollection("gato");
    }

    public void insert(Gato animal) {

        CounterDAO counterDAO = new CounterDAO();
        Long codigo = counterDAO.getNextSequence("gato");

        Document document = new Document("nome", animal.getNome())
                .append("codigo", codigo)
                .append("especie", animal.getEspecie())
                .append("idade", animal.getIdade())
                .append("peso", animal.getPeso())
                .append("sexo", animal.getSexo().toString())
                .append("cor", animal.getCor())
                .append("docil", animal.getDocil())
                .append("castrado", animal.getCastrado());

        gatoCollection.insertOne(document);
    }

    public void listAll() {
        FindIterable<Document> animals = gatoCollection.find();
        for (Document document : animals) {
            // Converte o documento do MongoDB de volta para a classe Gato
            Gato animal = documentToGato(document);
            System.out.println(animal);
        }
    }

    public Gato findByCodigo(Long codigo) {
        Document query = new Document("codigo", codigo);
        Document document = gatoCollection.find(query).first();

        if (document != null) {
            return documentToGato(document);
        } else {
            return null;
        }
    }

    public void update(Gato animal) {
        gatoCollection.updateOne(Filters.eq("codigo", animal.getCodigo()),
                new Document("$set", new Document("nome", animal.getNome())
                        .append("idade", animal.getIdade())
                        .append("peso", animal.getPeso())
                        .append("docil", animal.getDocil())
                        .append("castrado", animal.getCastrado())));
    }

    public void delete(Long codigo) {
        Document query = new Document("codigo", codigo);
        gatoCollection.deleteOne(query);
    }

    // Método auxiliar para converter um documento do MongoDB em um objeto Gato
    private Gato documentToGato(Document document) {
        Gato gato = new Gato();
        gato.setId(document.get("_id", ObjectId.class).toString());
        gato.setNome(document.getString("nome"));
        gato.setCodigo(document.getLong("codigo"));
        gato.setEspecie(document.getString("especie"));
        gato.setIdade(document.getDouble("idade"));
        gato.setPeso(document.getDouble("peso"));
        gato.setSexo(ESexo.valueOf(document.getString("sexo")));
        gato.setCor(document.getString("cor"));
        gato.setDocil(document.getBoolean("docil"));
        gato.setCastrado(document.getBoolean("castrado"));

        return gato;
    }
}
