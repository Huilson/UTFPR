package org.example.Controller;

import org.example.DAO.CachorroDAO;
import org.example.Enum.ESexo;
import org.example.model.Animal.Cachorro;
import java.util.List;
import java.util.Scanner;

public class CachorroController {

    private CachorroDAO cachorroDAO = new CachorroDAO();

    public void telaCachorro() {
        Scanner input = new Scanner(System.in);

        System.out.println("1 - Adicionar cachorro");
        System.out.println("2 - Listar cachorros");
        System.out.println("3 - Atualizar cachorro");
        System.out.println("4 - Remover cachorro");
        System.out.println("0 - Voltar");

        switch (input.nextInt()) {
            case 1:
                // Adicionar cachorro
                Cachorro cachorro = new Cachorro();
                System.out.print("Nome: ");
                cachorro.setNome(input.next());
                System.out.print("Espécie: ");
                cachorro.setEspecie(input.next());
                System.out.print("Idade: ");
                cachorro.setIdade(input.nextDouble());
                System.out.print("Peso: ");
                cachorro.setPeso(input.nextDouble());
                System.out.print("Sexo (M/F): ");
                cachorro.setSexo(ESexo.valueOf(input.next().toUpperCase()));

                // Use o CachorroDAO para inserir no banco de dados
                cachorroDAO.insert(cachorro);

                System.out.println("Cachorro adicionado com sucesso!");
                break;
            case 2:
                // Listar cachorros
                cachorroDAO.listAll();
                break;
            case 3:
                // Atualizar cachorro
                System.out.print("Informe o nome do cachorro a ser atualizado: ");
                Long updateCodigo = input.nextLong();
                Cachorro cachorroExistente = cachorroDAO.findByCodigo(updateCodigo);

                if (cachorroExistente != null) {
                    System.out.print("Novo nome: ");
                    cachorroExistente.setNome(input.next());
                    System.out.print("Nova idade: ");
                    cachorroExistente.setIdade(input.nextDouble());
                    System.out.print("Novo peso: ");
                    cachorroExistente.setPeso(input.nextDouble());

                    // Use o CachorroDAO para atualizar no banco de dados
                    cachorroDAO.update(cachorroExistente);

                    System.out.println("Cachorro atualizado com sucesso!");
                } else {
                    System.out.println("Cachorro não encontrado.");
                }
                break;
            case 4:
                // Remover cachorro
                System.out.print("Informe o nome do cachorro a ser removido: ");
                Long removeCodigo = input.nextLong();
                Cachorro cachorroRemover = cachorroDAO.findByCodigo(removeCodigo);

                if (cachorroRemover != null) {
                    cachorroDAO.delete(removeCodigo);
                    System.out.println("Cachorro removido com sucesso!");
                } else {
                    System.out.println("Cachorro não encontrado.");
                }
                break;
            case 0:
                // Voltar
                return;
            default:
                System.out.println("Opção inválida.");
                break;
        }
        return;
    }
}
