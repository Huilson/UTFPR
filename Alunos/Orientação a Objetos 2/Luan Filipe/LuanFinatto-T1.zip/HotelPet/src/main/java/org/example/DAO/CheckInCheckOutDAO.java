package org.example.DAO;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Date;

public class CheckInCheckOutDAO {
    private MongoCollection<Document> checkInCheckOutCollection;

    public CheckInCheckOutDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        checkInCheckOutCollection = db.getCollection("check");;
    }


    // na hora de fazer o checkIn, ele cria um registro na tabela check
    // onde ele salva a data de entrada, o codigo do animal e o andar
    public void checkIn(Long animalId, Integer andar) {
        Date dataEntrada = new Date();
        Document document = new Document("animalId", animalId)
                .append("andar", andar)
                .append("dataEntrada", dataEntrada);

        checkInCheckOutCollection.insertOne(document);
    }

    // na hora de fazer o checkout ele atualiza o registro criado no
    // checkin e salva a data de saida
    public void checkOut(Long animalId) {
        Date dataSaida = new Date();
        Document query = new Document("animalId", animalId)
                .append("dataSaida", null);

        Document update = new Document("$set", new Document("dataSaida", dataSaida));

        checkInCheckOutCollection.updateOne(query, update);
    }

    // para listar ele busca todos os animais do respectivo andar,
    // buscando apenas aqueles que não tem a data de saida
    public void mostrarAndar(Integer andar) {
        Document query = new Document("andar", andar)
                .append("dataSaida", null);

        FindIterable<Document> activeCheckIns = checkInCheckOutCollection.find(query);

        System.out.println("Check-ins ativos no andar " + andar + ":");
        for (Document document : activeCheckIns) {
            Long animalId = document.getLong("animalId");
            Date dataEntrada = document.getDate("dataEntrada");

            System.out.println("Animal ID: " + animalId);
            System.out.println("Data de Entrada: " + dataEntrada);
            System.out.println("------------------------------");
        }
    }
}
