package org.example.DAO;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class CounterDAO {
    private MongoCollection<Document> countersCollection;

    public CounterDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        countersCollection = db.getCollection("counters");
    }

    // a ideia do counter é salvar o ultimo codigo utilizado para cada tabela,
    // a fim de acessar de forma facil e manter o codigo para controle de cada classe.
    public long getNextSequence(String collectionName) {
        Document filter = new Document("collectionName", collectionName);
        Document update = new Document("$inc", new Document("seq", 1));

        // busca o codigo e atualiza
        Document result = countersCollection.findOneAndUpdate(filter, update);

        if (result == null) {
            // inicializa o contador se ele não existe
            Document newCounter = new Document("collectionName", collectionName)
                    .append("seq", 1);
            countersCollection.insertOne(newCounter);
            return 1L;
        }

        // retorna o codigo
        return (long) result.getInteger( "seq" );
    }
}
