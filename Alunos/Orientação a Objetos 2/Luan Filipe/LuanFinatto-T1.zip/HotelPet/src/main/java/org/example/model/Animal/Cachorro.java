package org.example.model.Animal;

import org.example.model.Animal.Animal;

public class Cachorro extends Animal {
    private String raca;
    private Boolean docil;
    private Boolean castrado;

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public Boolean getDocil() {
        return docil;
    }

    public void setDocil(Boolean docil) {
        this.docil = docil;
    }

    public Boolean getCastrado() {
        return castrado;
    }

    public void setCastrado(Boolean castrado) {
        this.castrado = castrado;
    }

    @Override
    public String toString() {
        return "Cachorro: id: " + getId() +
                ", Codigo = " + getCodigo() +
                ", Nome = " + getNome() +
                ", Especie = " + getEspecie() +
                ", Idade = " + getIdade() +
                ", Peso = " + getPeso() +
                ", Sexo = " + getSexo();
    }
}
