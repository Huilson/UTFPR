package org.example.Controller;

import org.example.DAO.AraraAzulDAO;
import org.example.Enum.ESexo;
import org.example.model.Animal.AraraAzul;

import java.util.Scanner;

public class AraraAzulController {

    private AraraAzulDAO araraDAO = new AraraAzulDAO();

    public void telaArara() {
        Scanner input = new Scanner(System.in);

        System.out.println("1 - Adicionar arara");
        System.out.println("2 - Listar araras");
        System.out.println("3 - Atualizar arara");
        System.out.println("4 - Remover arara");
        System.out.println("0 - Voltar");

        switch (input.nextInt()) {
            case 1:
                // Adicionar arara
                AraraAzul arara = new AraraAzul();
                System.out.print("Nome: ");
                arara.setNome(input.next());
                System.out.print("Espécie: ");
                arara.setEspecie(input.next());
                System.out.print("Idade: ");
                arara.setIdade(input.nextDouble());
                System.out.print("Peso: ");
                arara.setPeso(input.nextDouble());
                System.out.print("Sexo (M/F): ");
                arara.setSexo(ESexo.valueOf(input.next().toUpperCase()));

                // Use o AraraAzulDAO para inserir no banco de dados
                araraDAO.insert(arara);

                System.out.println("AraraAzul adicionado com sucesso!");
                break;
            case 2:
                // Listar araras
                araraDAO.listAll();
                break;
            case 3:
                // Atualizar arara
                System.out.print("Informe o codigo do arara a ser atualizado: ");
                Long updateCod = input.nextLong();
                AraraAzul araraExistente = araraDAO.findByCodigo(updateCod);

                if (araraExistente != null) {
                    System.out.print("Novo nome: ");
                    araraExistente.setNome(input.next());
                    System.out.print("Nova idade: ");
                    araraExistente.setIdade(input.nextDouble());
                    System.out.print("Novo peso: ");
                    araraExistente.setPeso(input.nextDouble());

                    // Use o AraraAzulDAO para atualizar no banco de dados
                    araraDAO.update(araraExistente);

                    System.out.println("AraraAzul atualizado com sucesso!");
                } else {
                    System.out.println("AraraAzul não encontrado.");
                }
                break;
            case 4:
                // Remover arara
                System.out.print("Informe o codigo da arara a ser removido: ");
                Long removeNome = input.nextLong();
                AraraAzul araraRemover = araraDAO.findByCodigo(removeNome);

                if (araraRemover != null) {
                    araraDAO.delete(removeNome);
                    System.out.println("Arara removido com sucesso!");
                } else {
                    System.out.println("Arara não encontrado.");
                }
                break;
            case 0:
                // Voltar
                return;
            default:
                System.out.println("Opção inválida.");
                break;
        }
        return;
    }
}
