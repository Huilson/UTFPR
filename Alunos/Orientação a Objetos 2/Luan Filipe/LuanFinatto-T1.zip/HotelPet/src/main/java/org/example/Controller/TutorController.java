package org.example.Controller;

import org.example.DAO.TutorDAO;
import org.example.Enum.ESexo;
import org.example.model.Pessoa.Tutor;

import java.util.List;
import java.util.Scanner;

public class TutorController {

    private TutorDAO tutorDAO = new TutorDAO();

    public void telaTutor() {
        Scanner input = new Scanner(System.in);

        System.out.println("1 - Adicionar tutor");
        System.out.println("2 - Listar tutors");
        System.out.println("3 - Atualizar tutor");
        System.out.println("4 - Remover tutor");
        System.out.println("0 - Voltar");

        switch (input.nextInt()) {
            case 1:
                // adiciona um novo tutor
                Tutor tutor = new Tutor();
                System.out.print("Nome: ");
                tutor.setNome(input.next());
                System.out.print("Documento: ");
                tutor.setDocumento(input.next());

                // usa o TutorDAO para inserir no banco de dados
                tutorDAO.insert(tutor);

                System.out.println("Tutor adicionado com sucesso!");
                break;
            case 2:
                // lista os tutores
                tutorDAO.listAll();
                break;
            case 3:
                // atualiza um tutor tutor
                System.out.print("Informe o nome do tutor a ser atualizado: ");
                Long updateCodigo = input.nextLong();
                Tutor tutorExistente = tutorDAO.findByCodigo(updateCodigo);

                if (tutorExistente != null) {
                    System.out.print("Novo nome: ");
                    tutorExistente.setNome(input.next());
                    System.out.print("Novo documento: ");
                    tutorExistente.setDocumento(input.next());

                    // usa o TutorDAO para atualizar no banco de dados
                    tutorDAO.update(tutorExistente);

                    System.out.println("Tutor atualizado com sucesso!");
                } else {
                    System.out.println("Tutor não encontrado.");
                }
                break;
            case 4:
                // apaga um tutor
                System.out.print("Informe o nome do tutor a ser removido: ");
                Long removeCodigo = input.nextLong();
                Tutor tutorRemover = tutorDAO.findByCodigo(removeCodigo);

                if (tutorRemover != null) {
                    tutorDAO.delete(removeCodigo);
                    System.out.println("Tutor removido com sucesso!");
                } else {
                    System.out.println("Tutor não encontrado.");
                }
                break;
            case 0:
                // Voltar
                return;
            default:
                System.out.println("Opção inválida.");
                break;
        }
        return;
    }
}
