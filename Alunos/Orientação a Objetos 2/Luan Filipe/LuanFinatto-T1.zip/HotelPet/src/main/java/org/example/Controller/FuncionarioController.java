package org.example.Controller;

import org.example.DAO.FuncionarioDAO;
import org.example.Enum.ESexo;
import org.example.model.Pessoa.Funcionario;

import java.util.List;
import java.util.Scanner;

public class FuncionarioController {

    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

    public void telaFuncionario() {
        Scanner input = new Scanner(System.in);

        System.out.println("1 - Adicionar funcionario");
        System.out.println("2 - Listar funcionarios");
        System.out.println("3 - Atualizar funcionario");
        System.out.println("4 - Remover funcionario");
        System.out.println("0 - Voltar");

        switch (input.nextInt()) {
            case 1:
                // Adicionar funcionario
                Funcionario funcionario = new Funcionario();
                System.out.print("Nome: ");
                funcionario.setNome(input.next());
                System.out.print("Documento: ");
                funcionario.setDocumento(input.next());

                // Use o FuncionarioDAO para inserir no banco de dados
                funcionarioDAO.insert(funcionario);

                System.out.println("Funcionario adicionado com sucesso!");
                break;
            case 2:
                // Listar funcionarios
                funcionarioDAO.listAll();
                break;
            case 3:
                // Atualizar funcionario
                System.out.print("Informe o nome do funcionario a ser atualizado: ");
                Long codigo = input.nextLong();
                Funcionario funcionarioExistente = funcionarioDAO.findByCodigo(codigo);

                if (funcionarioExistente != null) {
                    System.out.print("Novo nome: ");
                    funcionarioExistente.setNome(input.next());
                    System.out.print("Novo documento: ");
                    funcionarioExistente.setDocumento(input.next());

                    // Use o FuncionarioDAO para atualizar no banco de dados
                    funcionarioDAO.update(funcionarioExistente);

                    System.out.println("Funcionario atualizado com sucesso!");
                } else {
                    System.out.println("Funcionario não encontrado.");
                }
                break;
            case 4:
                // Remover funcionario
                System.out.print("Informe o nome do funcionario a ser removido: ");
                Long cod = input.nextLong();
                Funcionario funcionarioRemover = funcionarioDAO.findByCodigo(cod);

                if (funcionarioRemover != null) {
                    funcionarioDAO.delete(cod);
                    System.out.println("Funcionario removido com sucesso!");
                } else {
                    System.out.println("Funcionario não encontrado.");
                }
                break;
            case 0:
                // Voltar
                return;
            default:
                System.out.println("Opção inválida.");
                break;
        }
        return;
    }
}
