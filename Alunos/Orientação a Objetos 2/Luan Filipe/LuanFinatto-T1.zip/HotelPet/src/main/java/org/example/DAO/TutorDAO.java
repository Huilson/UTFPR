/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example.DAO;


import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.example.model.Pessoa.Tutor;

public class TutorDAO {

    private MongoCollection<Document> tutorCollection;

    public TutorDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        tutorCollection = db.getCollection("tutor");
    }

    public void insert(Tutor func) {

        CounterDAO counterDAO = new CounterDAO();
        Long codigo = counterDAO.getNextSequence("tutor");

        Document document = new Document("nome", func.getNome())
                .append("codigo", codigo)
                .append("documento", func.getDocumento());

        tutorCollection.insertOne(document);
    }

    public void listAll() {
        FindIterable<Document> funcs = tutorCollection.find();
        for (Document document : funcs) {
            // Converte o documento do MongoDB de volta para a classe Tutor
            Tutor func = documentToTutor(document);
            System.out.println(func);
        }
    }

    public Tutor findByCodigo(Long codigo) {
        Document query = new Document("codigo", codigo);
        Document document = tutorCollection.find(query).first();

        if (document != null) {
            return documentToTutor(document);
        } else {
            return null;
        }
    }

    public void update(Tutor func) {
        tutorCollection.updateOne(Filters.eq("codigo", func.getCodigo()),
                new Document("$set", new Document("nome", func.getNome())
                        .append("codigo", func.getCodigo())
                        .append("documento", func.getDocumento())));
    }

    public void delete(Long codigo) {
        Document query = new Document("codigo", codigo);
        tutorCollection.deleteOne(query);
    }

    // Método auxiliar para converter um documento do MongoDB em um objeto Tutor
    private Tutor documentToTutor(Document document) {
        Tutor tutor = new Tutor();
        tutor.setId(document.get("_id", ObjectId.class).toString());
        tutor.setCodigo(document.getLong("codigo"));
        tutor.setNome(document.getString("nome"));
        tutor.setDocumento(document.getString("documento"));

        return tutor;
    }
}
