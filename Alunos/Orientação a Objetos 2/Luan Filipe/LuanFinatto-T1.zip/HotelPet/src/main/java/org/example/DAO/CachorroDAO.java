/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example.DAO;


import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.example.Enum.ESexo;
import org.example.model.Animal.Cachorro;


import com.mongodb.client.*;
import org.bson.Document;
import org.bson.types.ObjectId;

public class CachorroDAO {

    private MongoCollection<Document> cachorroCollection;

    public CachorroDAO() {
        MongoClient client = new MongoClient();
        MongoDatabase db = client.getDatabase("HotelPet");
        cachorroCollection = db.getCollection("cachorro");
    }

    public void insert(Cachorro animal) {
        CounterDAO counterDAO = new CounterDAO();
        Long codigo = counterDAO.getNextSequence("cachorro");

        Document document = new Document("nome", animal.getNome())
                .append("codigo", codigo)
                .append("especie", animal.getEspecie())
                .append("idade", animal.getIdade())
                .append("peso", animal.getPeso())
                .append("sexo", animal.getSexo().toString())
                .append("raca", animal.getRaca())
                .append("docil", animal.getDocil())
                .append("castrado", animal.getCastrado());

        cachorroCollection.insertOne(document);
    }

    public void listAll() {
        FindIterable<Document> animals = cachorroCollection.find();
        for (Document document : animals) {
            // Converte o documento do MongoDB de volta para a classe Cachorro
            Cachorro animal = documentToCachorro(document);
            System.out.println(animal);
        }
    }

    public Cachorro findByCodigo(Long codigo) {
        Document query = new Document("codigo", codigo);
        Document document = cachorroCollection.find(query).first();

        if (document != null) {
            return documentToCachorro(document);
        } else {
            return null;
        }
    }

    public void update(Cachorro animal) {

        cachorroCollection.updateOne(Filters.eq("codigo", animal.getCodigo()),
                new Document("$set", new Document("nome", animal.getNome())
                        .append("codigo", animal.getCodigo())
                        .append("idade", animal.getIdade())
                        .append("peso", animal.getPeso())
                        .append("docil", animal.getDocil())
                        .append("castrado", animal.getCastrado())));
    }

    public void delete(Long codigo) {
        Document query = new Document("codigo", codigo);
        cachorroCollection.deleteOne(query);
    }

    // Método auxiliar para converter um documento do MongoDB em um objeto Cachorro
    private Cachorro documentToCachorro(Document document) {
        Cachorro cachorro = new Cachorro();
        cachorro.setId(document.get("_id", ObjectId.class).toString());
        cachorro.setNome(document.getString("nome"));
        cachorro.setCodigo(document.getLong("codigo"));
        cachorro.setIdade(document.getDouble("idade"));
        cachorro.setPeso(document.getDouble("peso"));
        cachorro.setSexo(ESexo.valueOf(document.getString("sexo")));
        cachorro.setRaca(document.getString("raca"));
        cachorro.setDocil(document.getBoolean("docil"));
        cachorro.setCastrado(document.getBoolean("castrado"));

        return cachorro;
    }
}
