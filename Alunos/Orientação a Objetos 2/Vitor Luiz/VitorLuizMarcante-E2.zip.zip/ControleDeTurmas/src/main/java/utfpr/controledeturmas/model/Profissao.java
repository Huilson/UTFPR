package utfpr.controledeturmas.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//De classe para classe
//import javax.persistence.ManyToOne;

@Entity
public class Profissao {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)        
    private int id;
    private String descricao;


    //CONSTRUCTOR
    public Profissao(String descricao) {
        this.descricao = descricao;
    }

    public Profissao() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
