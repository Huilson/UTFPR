/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package utfpr.controledeturmas;
/**
 *
 * @author Vitor
 */

import utfpr.controledeturmas.dao.ProfissaoDao;
import java.util.InputMismatchException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.model.Pessoa;
import utfpr.controledeturmas.model.Profissao;
import utfpr.controledeturmas.util.Factory;
import utfpr.controledeturmas.util.SalvarPessoa;
import utfpr.controledeturmas.util.SalvarProfissao;

public class Menu {

    public Menu() {

        //EntityManagerFactory emf = Persistence.createEntityManagerFactory("controleturmas");
        EntityManager em = Factory.getEntityManager();
        PessoaDao pessoaDao = new PessoaDao(em);
        ProfissaoDao profissaoDao = new ProfissaoDao(em);

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            //declara as possibilidades
            System.out.println("Menu:");
            System.out.println("1. Cadastrar Pessoa");
            System.out.println("2. Cadastrar Profissao");
            System.out.println("3. Listar Pessoas");
            System.out.println("4. Listar Profissoes");
            System.out.println("5. Atualizar Pessoa");
            System.out.println("6. Atualizar Profissao");
            System.out.println("7. Deletar Pessoa");
            System.out.println("8. Deletar Profissao");
            System.out.println("0. Sair");
            System.out.println("Escolha uma opção: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

//incia o switch case para o usuario escolher a opcao
            switch (choice) {
                case 1:
                    SalvarPessoa salvarPessoa = new SalvarPessoa();

                    break;
                case 2:
                    SalvarProfissao salvarProfissao = new SalvarProfissao();
                    break;
                case 3:
                    // Opção para listar Pessoas
                    System.out.println("Listagem de Pessoas:");

                    // Consulta todas as Pessoas no banco de dados
                    List<Pessoa> pessoas = pessoaDao.consultar(new Pessoa());

                    if (pessoas.isEmpty()) {
                        // Se não houver pessoas cadastradas, exibe uma mensagem
                        System.out.println("Nenhuma pessoa cadastrada.");
                    } else {
                        // Caso haja pessoas na lista, exibe os detalhes de cada uma
                        System.out.println("Lista de Pessoas:");
                        for (Pessoa pessoa : pessoas) {
                            // Exibe informações da Pessoa
                            System.out.println("ID: " + pessoa.getId());
                            System.out.println("Nome: " + pessoa.getNome());
                            System.out.println("Idade: " + pessoa.getIdade());
                            System.out.println("Contato: " + pessoa.getContato());
                            System.out.println("Cidade: " + pessoa.getCidade());
                            System.out.println("Rua: " + pessoa.getRua());
                            System.out.println("Número: " + pessoa.getNumero());
                            // Você pode adicionar saídas para outros atributos da Pessoa, se necessário
                            System.out.println("-----------------------");
                        }
                    }
                    break;

                case 4:
                    // Opção para listar Profissões
                    System.out.println("Listagem de Profissões:");

                    // Conecta ao banco de dados antes de consultar as Profissões
                    profissaoDao.conecta();
                    List<Profissao> profissoes = profissaoDao.consultar(new Profissao());

                    // Encerra a conexão com o banco de dados após a consulta
                    profissaoDao.encerrar();

                    if (profissoes.isEmpty()) {
                        // Se não houver profissões cadastradas, exibe uma mensagem
                        System.out.println("Nenhuma profissão cadastrada.");
                    } else {
                        // Caso haja profissões na lista, exibe os detalhes de cada uma
                        System.out.println("Lista de Profissões:");
                        for (Profissao profissao : profissoes) {
                            // Exibe informações da Profissão
                            System.out.println("ID: " + profissao.getId());
                            System.out.println("Descrição: " + profissao.getDescricao());
                            // Você pode adicionar saídas para outros atributos da Profissão, se necessário
                            System.out.println("-----------------------");
                        }
                    }
                    break;
                case 5:
                    // Opção para atualizar uma Pessoa
                    System.out.println("Atualização de Pessoa:");
                    System.out.println("Digite o ID da pessoa que deseja atualizar: ");
                    int pessoaIdToUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume a quebra de linha

                    // Conecta ao banco de dados antes de consultar a Pessoa pelo ID
                    pessoaDao.conecta();
                    Pessoa pessoaToUpdate = pessoaDao.consultarPeloId(pessoaIdToUpdate);
                    if (pessoaToUpdate == null) {
                        System.out.println("Pessoa com o ID " + pessoaIdToUpdate + " não encontrada.");
                    } else {
                        // Solicita e atualiza informações da Pessoa
                        System.out.println("Novo nome: ");
                        String novoNome = scanner.nextLine();
                        pessoaToUpdate.setNome(novoNome);


                        System.out.println("Nova idade: ");
                        int novaIdade = scanner.nextInt();
                        scanner.nextLine(); // Consume a quebra de linha
                        pessoaToUpdate.setIdade(novaIdade);

                        // Você pode adicionar mais atualizações para outros campos, se necessário
                        pessoaDao.atualizar(pessoaToUpdate);
                        System.out.println("Pessoa com o ID " + pessoaIdToUpdate + " atualizada com sucesso.");
                    }
                    // Encerra a conexão com o banco de dados
                    pessoaDao.encerrar();
                    break;

                case 6:
                    // Opção para atualizar uma Profissão
                    System.out.println("Atualização de Profissão:");
                    System.out.println("Digite o ID da profissão que deseja atualizar: ");
                    int profissaoIdToUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume a quebra de linha

                    // Conecta ao banco de dados antes de consultar a Profissão pelo ID
                    profissaoDao.conecta();
                    Profissao profissaoToUpdate = profissaoDao.consultarPeloId(profissaoIdToUpdate);
                    if (profissaoToUpdate == null) {
                        System.out.println("Profissão com o ID " + profissaoIdToUpdate + " não encontrada.");
                    } else {
                        // Solicita e atualiza informações da Profissão
                        System.out.println("Nova descrição: ");
                        String novaDescricao = scanner.nextLine();
                        profissaoToUpdate.setDescricao(novaDescricao);

                        // Você pode adicionar mais atualizações para outros campos, se necessário
                        profissaoDao.atualizar(profissaoToUpdate);
                        System.out.println("Profissão com o ID " + profissaoIdToUpdate + " atualizada com sucesso.");
                    }
                    // Encerra a conexão com o banco de dados
                    profissaoDao.encerrar();
                    break;
                case 7:
                    // Opção para excluir uma Pessoa
                    System.out.println("Exclusão de Pessoa:");
                    System.out.println("Digite o ID da pessoa que deseja excluir: ");
                    int pessoaIdToDelete = scanner.nextInt();
                    scanner.nextLine(); // Consume a quebra de linha

                    // Consulta a Pessoa pelo ID
                    Pessoa pessoaToDelete = pessoaDao.consultarPeloId(pessoaIdToDelete);
                    if (pessoaToDelete == null) {
                        System.out.println("Pessoa com o ID " + pessoaIdToDelete + " não encontrada.");
                    } else {
                        // Conecta ao banco de dados e executa a exclusão da Pessoa
                        pessoaDao.conecta();
                        pessoaDao.excluir(pessoaToDelete);
                        System.out.println("Pessoa com o ID " + pessoaIdToDelete + " excluída com sucesso.");
                    }
                    // Encerra a conexão com o banco de dados
                    pessoaDao.encerrar();
                    break;

                case 8:
                    // Opção para excluir uma Profissão
                    System.out.println("Exclusão de Profissão:");
                    System.out.println("Digite o ID da profissão que deseja excluir: ");
                    int profissaoIdToDelete = scanner.nextInt();
                    scanner.nextLine(); // Consume a quebra de linha

                    // Conecta ao banco de dados antes de consultar a Profissão pelo ID
                    profissaoDao.conecta();
                    Profissao profissaoToDelete = profissaoDao.consultarPeloId(profissaoIdToDelete);

                    if (profissaoToDelete == null) {
                        System.out.println("Profissão com o ID " + profissaoIdToDelete + " não encontrada.");
                    } else {
                        // Realiza a exclusão da Profissão se não houver Pessoas associadas
                        profissaoDao.excluir(profissaoToDelete);
                        System.out.println("Profissão com o ID " + profissaoIdToDelete + " excluída com sucesso.");
                    }

                    // Encerra a conexão com o banco de dados
                    profissaoDao.encerrar();
                    break;
                case 0:
                    //sai do programa se o usuario digitar 0
                    System.out.println("Saindo do programa.");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (choice != 0);

        em.close();

    }
}
