/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.controledeturmas.util;

import java.util.InputMismatchException;
import java.util.Scanner;
import javax.persistence.EntityManager;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.dao.ProfissaoDao;
import utfpr.controledeturmas.model.Pessoa;
import utfpr.controledeturmas.model.Profissao;

/**
 *
 * @author Vitor
 */
public class SalvarProfissao {
     public SalvarProfissao() {
        // Inicialização do EntityManager e outros objetos necessários
        EntityManager em = Factory.getEntityManager();
        Scanner scanner = new Scanner(System.in);
        Profissao novaProfissao = new Profissao();
        ProfissaoDao profissaoDao = new ProfissaoDao(em);

        // Solicitação de informações da nova Profissão
        //juntamente faz as validacoes de entrada
        System.out.println("Cadastro de Profissão:");

        System.out.println("Descrição: ");
        String descricao = scanner.nextLine();
        if (descricao.isEmpty()) {
            System.out.println("Descrição não pode estar vazia.");
            return;
        }
        novaProfissao.setDescricao(descricao);

        profissaoDao.conecta();
        profissaoDao.salvar(novaProfissao);
        profissaoDao.encerrar();

        System.out.println("Profissão cadastrada com sucesso!");
        return;
    }
}
