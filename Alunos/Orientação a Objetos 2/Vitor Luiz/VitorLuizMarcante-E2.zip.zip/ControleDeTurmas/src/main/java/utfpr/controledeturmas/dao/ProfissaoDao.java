/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.controledeturmas.dao;
import java.util.List;
import javax.persistence.EntityManager;
import utfpr.controledeturmas.model.Profissao;

/**
 *
 * @author Vitor
 */
public class ProfissaoDao {

    private EntityManager em;

    public ProfissaoDao(EntityManager em) {
        this.em = em;
    }

    public void conecta() {
        // Inicia uma transação se ainda não estiver ativa
        if (!em.getTransaction().isActive()) {
            this.em.getTransaction().begin();
        }
    }

    public void encerrar() {
        // Limpa o contexto do EntityManager
        if (em.isOpen()) {
            this.em.clear();
        }
    }

    public void salvar(Profissao profissao) {
        // Persiste a Profissao no banco de dados e finaliza a transação
        this.em.persist(profissao);
        this.em.getTransaction().commit();
    }

    public void excluir(Profissao profissao) {
        // Remove a Profissao do banco de dados e finaliza a transação
        profissao = em.merge(profissao);
        em.remove(profissao);
        this.em.getTransaction().commit();
    }

    public List<Profissao> consultar(Profissao profissao) {
        // Consulta todas as Profissoes no banco de dados
        String jpql = "select p from Profissao p";
        return this.em.createQuery(jpql, Profissao.class).getResultList();
    }

    public List<Profissao> consultarPelaDescricao(String descricao) {
        // Consulta Profissoes com uma determinada descrição
        String jpql = "select p from Profissao p where p.descricao = :descricao";
        return this.em.createQuery(jpql, Profissao.class).setParameter("descricao", descricao)
                .getResultList();
    }

    public Profissao consultarPeloId(Integer id) {
        // Consulta uma Profissao pelo ID
        return this.em.find(Profissao.class, id);
    }

    public void atualizar(Profissao profissao) {
        // Atualiza uma Profissao no banco de dados
        this.em.merge(profissao);
        salvar(profissao); // Salva as mudanças e finaliza a transação
    }
}
