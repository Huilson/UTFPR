package utfpr.controledeturmas;

import utfpr.controledeturmas.model.Pessoa;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.model.Profissao;
import utfpr.controledeturmas.util.Factory;

public class ControleDeTurmas {

    public static void main(String[] args) {
        EntityManager em = Factory.getEntityManager();
        PessoaDao dao = new PessoaDao(em);
        
        Profissao programador = new Profissao("Programador");
        Profissao testes = new Profissao("Analista de Testes");
        Profissao requisitos = new Profissao("Analista de Requisitos");
        Pessoa pessoa = new Pessoa("fulana", "16546548", 22, "fulana@utfpr.edu.br", "Pato Branco", "Avenida Brasil", 11);        
        pessoa.setProfissao(requisitos);
        dao.conecta();
        

        dao.salvar(pessoa);
        
        dao.encerrar();
        System.out.print("Ok!");
    }
}