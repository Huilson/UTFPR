/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.controledeturmas.util;

import java.util.InputMismatchException;
import java.util.Scanner;
import javax.persistence.EntityManager;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.dao.ProfissaoDao;
import utfpr.controledeturmas.model.Pessoa;
import utfpr.controledeturmas.model.Profissao;

/**
 *
 * @author Vitor
 */
public class SalvarPessoa {
      public SalvarPessoa() {
        // Inicialização do EntityManager e outros objetos necessários
        EntityManager em = Factory.getEntityManager();
        Scanner scanner = new Scanner(System.in);
        PessoaDao pessoaDao = new PessoaDao(em);
        ProfissaoDao profissaoDao = new ProfissaoDao(em);
        Pessoa novaPessoa = new Pessoa();

        // Solicitação de informações da nova Pessoa
        //juntamente faz as validacoes de entrada
        System.out.println("Cadastro de Pessoa:");

        System.out.println("Nome: ");
        String nome = scanner.nextLine();
        if (nome.isEmpty()) {
            System.out.println("Nome não pode estar vazio.");
            return;
        }
        novaPessoa.setNome(nome);

        System.out.println("Idade: ");
        int idade;
        try {
            idade = scanner.nextInt();
            scanner.nextLine(); // Consume a quebra de linha
        } catch (InputMismatchException e) {
            System.out.println("Idade inválida. Deve ser um número inteiro.");
            return;
        }
        novaPessoa.setIdade(idade);

        System.out.println("Contato: ");
        String contato = scanner.nextLine();
        if (contato.isEmpty()) {
            System.out.println("Contato não pode estar vazio.");
            return;
        }
        novaPessoa.setContato(contato);

        System.out.println("Cidade: ");
        String cidade = scanner.nextLine();
        if (cidade.isEmpty()) {
            System.out.println("Cidade não pode estar vazia.");
            return;
        }
        novaPessoa.setCidade(cidade);

        System.out.println("Rua: ");
        String rua = scanner.nextLine();
        if (rua.isEmpty()) {
            System.out.println("Rua não pode estar vazia.");
            return;
        }
        novaPessoa.setRua(rua);

        System.out.println("Número: ");
        String numero = scanner.nextLine();
        if (numero.isEmpty()) {
            System.out.println("Número não pode estar vazio.");
            return;
        }
//        novaPessoa.setNumero(numero);

        // Solicitação do ID da Profissão associada à Pessoa
        System.out.println("Digite o ID da Profissão: ");
        int profissaoId = scanner.nextInt();
        scanner.nextLine(); // Consume a quebra de linha

        // Consulta a Profissão pelo ID -confere se a profissao realmente existe
        Profissao profissao = profissaoDao.consultarPeloId(profissaoId);
        if (profissao == null) {
            System.out.println("Profissão com o ID " + profissaoId + " não encontrada.");
            return;
        }

        // Associa a Profissão à nova Pessoa
        novaPessoa.setProfissao(profissao);

        // Conecta ao banco de dados, salva a nova Pessoa e encerra a conexão
        pessoaDao.conecta();
        pessoaDao.salvar(novaPessoa);
        pessoaDao.encerrar();

        System.out.println("Pessoa cadastrada com sucesso!");
        return;
    }
}
