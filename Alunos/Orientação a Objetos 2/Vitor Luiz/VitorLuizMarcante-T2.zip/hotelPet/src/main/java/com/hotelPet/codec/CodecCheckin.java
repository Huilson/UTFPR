/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotelPet.codec;

import com.hotelPet.model.Checkin;
import java.util.Date;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

/**
 *
 * @author Vitor
 */
public class CodecCheckin implements CollectibleCodec<Checkin>{
     //Atributo para criação de documento
    private Codec<Document> codec;
    
    //Construtor
    public CodecCheckin(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Checkin generateIdIfAbsentFromDocument(Checkin checkin) {
        return documentHasId(checkin) ? checkin.criarId() : checkin;
    }

    @Override
    public boolean documentHasId(Checkin checkin) {
        //esse método só verifica se o objeto chamado tem ID
        return checkin.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Checkin checkin) {
        //Verifica se o ID foi criado
        if(!documentHasId(checkin)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(checkin.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Checkin checkin, EncoderContext ec) {
        ObjectId id = checkin.getId();
        String nome_animal = checkin.getNome_animal();
        Date data_ck = checkin.getData_ck();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome_animal",nome_animal);
        doc.put("data_ck",data_ck);



        
        codec.encode(writer, doc, ec);
    }


    public Class<Checkin> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Checkin.class;
    }


    public Checkin decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Checkin checkin = new Checkin();
        checkin.setId(doc.getObjectId("_id"));
        checkin.setNome_animal(doc.getString("nome_animal"));
        checkin.setData_ck(doc.getDate("data_ck"));
            
               
        return checkin;
    }    
}
