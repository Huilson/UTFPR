package com.hotelPet.codec;

import com.hotelPet.model.Pessoa;
import java.util.ArrayList;
import java.util.List;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecPessoa implements CollectibleCodec<Pessoa>{
    //Atributo para criação de documento
    private Codec<Document> codec;
    
    //Construtor
    public CodecPessoa(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Pessoa generateIdIfAbsentFromDocument(Pessoa pessoa) {
        return documentHasId(pessoa) ? pessoa.criarId() : pessoa;
    }

    @Override
    public boolean documentHasId(Pessoa pessoa) {
        //esse método só verifica se o objeto chamado tem ID
        return pessoa.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Pessoa pessoa) {
        //Verifica se o ID foi criado
        if(!documentHasId(pessoa)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(pessoa.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Pessoa pessoa, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = pessoa.getId();
        String nome = pessoa.getNome();
        String documento = pessoa.getDocumento();
        Integer idade = pessoa.getIdade();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("idade",idade);
        doc.put("documento", documento);

        
//        List<Disciplina> disciplinas = aluno.getDisciplina();
//        if(disciplinas != null){
//            //Se não tiver uma disciplina cadastrada, cria-se uma lista para
//            //não tomar um NPE
//            List<Document> disDoc = new ArrayList<>();
//            
//            //Se houver uma disciplina cadastrada, cria-se um array de 
//            //disciplina no MONGODB
//            for(Disciplina disciplina : disciplinas){
//                disDoc.add(new Document("nome", disciplina.getNome())
//                        .append("professor", disciplina.getProfessor())
//                        .append("semestre", disciplina.getSemestre())
//                        .append("notas",disciplina.getNotas())
//                );                
//            }//FIM DO FOR
//            doc.put("disciplinas",disDoc);            
//        }        
//        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Pessoa> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Pessoa.class;
    }

    @Override
    public Pessoa decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Pessoa pessoa = new Pessoa();
        pessoa.setId(doc.getObjectId("_id"));
        pessoa.setNome(doc.getString("nome"));
        pessoa.setIdade(doc.getInteger("idade"));
        pessoa.setDocumento(doc.getString("documento"));
  
            
//        Document tutorDoc = doc.get("tutor", Document.class);
//        Pessoa tutor = new Pessoa();
//        tutor.setNome(tutorDoc.getString("nome"));
//        tutor.setIdade(tutorDoc.getInteger("idade"));
//        tutor.setTipo(tutorDoc.getString("tipo"));
//        tutor.setDocumento(tutorDoc.getString("documento"));
//        
//        animal.setTutor(tutor);
               
        return pessoa;
    }    
}
