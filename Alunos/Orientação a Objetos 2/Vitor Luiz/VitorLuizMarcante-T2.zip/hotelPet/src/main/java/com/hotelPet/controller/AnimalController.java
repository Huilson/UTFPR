package com.hotelPet.controller;

import com.hotelPet.model.*;
import com.hotelPet.repository.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AnimalController {
    
//Injeções de dependência
    @Autowired
    private AnimalRepository repository;
    
    @Autowired
    private PessoaRepository repositoryPessoa;
    
    @Autowired
    private CheckinRepository repositoryCheckin;
    
    @GetMapping("/animal/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("animal", new Animal());
        return"animal/cadastrar";
    }
    
@PostMapping("/animal/salvar")
public String salvar(@ModelAttribute Animal animal) {
    // Agora você pode acessar os dados de animal e checkin diretamente
    String especie = animal.getEspecie();

    
    if (especie.equals("Cachorro")) {
        animal.setAndar("Primeiro");
    } else if (especie.equals("Gato")) {
        animal.setAndar("Segundo");
    } else {
        animal.setAndar("Terceiro");
    }
    
    String nome_animal = animal.getNome();
    
    repository.salvar(animal);
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
    Date dia = new Date();
    Checkin ck = new Checkin(nome_animal, dia);
    repositoryCheckin.salvar(ck);
    return "redirect:/";
}
    
    @GetMapping("/animal/listar")
    public String listar(Model model){
        List<Animal> animais = repository.listar();
        model.addAttribute("animais", animais);
        return"animal/listar";
    }
    
    @GetMapping("/animal/visualizar/{id}")
    public String visualizar(@PathVariable String id,
            Model model){
        Animal animal = repository.obterId(id);
        model.addAttribute("animal", animal);
        return "animal/visualizar";        
    }
    
    @GetMapping("/animal/excluir/{id}")
    public String excluir(@PathVariable String id){        
        repository.excluir(id);
         return "redirect:/";     
    }
    
    @GetMapping("/animal/atualizar/{id}")
    public String atualizar(@PathVariable String id,
            Model model){
        Animal animal = repository.obterId(id);
        model.addAttribute("animal", animal);
        return "/animal/listar";        
    }
    
    @PostMapping("/animal/editar/{id}")
    public String editar(@ModelAttribute Animal animal){
        repository.salvar(animal);
        return"redirect:/animal/listar";
    }
    
}
