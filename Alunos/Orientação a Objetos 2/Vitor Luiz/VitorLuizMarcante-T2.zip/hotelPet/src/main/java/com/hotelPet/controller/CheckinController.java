/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotelPet.controller;

import com.hotelPet.model.Checkin;
import com.hotelPet.model.Pessoa;
import com.hotelPet.repository.CheckinRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author Vitor
 */
@Controller
public class CheckinController {
    //Injeções de dependência
    @Autowired
    private CheckinRepository repository;
    
    @GetMapping("/checkin/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("checkin", new Checkin());
        return"checkin/cadastrar";
    }
    
    @PostMapping("/checkin/salvar")
    public String salvar(@ModelAttribute Checkin checkin){
        System.out.println("Salvando");
        repository.salvar(checkin);
        return"redirect:/";
    }
    
    @GetMapping("/checkin/listar")
    public String listar(Model model){
        List<Checkin> checkins = repository.listar();
        model.addAttribute("checkins", checkins);
        return"checkin/listar";
    }
    
    @GetMapping("/checkin/visualizar/{id}")
    public String visualizar(@PathVariable String id,
            Model model){
        Checkin ck = repository.obterId(id);
        model.addAttribute("checkin", ck);
        return "checkin/visualizar";        
    }
    
    @GetMapping("/checkin/excluir/{id}")
    public String excluir(@PathVariable String id){        
        repository.excluir(id);
        return"redirect:/checkin/listar";
    }
}
