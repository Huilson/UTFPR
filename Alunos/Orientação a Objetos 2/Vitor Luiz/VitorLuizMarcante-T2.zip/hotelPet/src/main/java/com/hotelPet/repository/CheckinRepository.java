/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotelPet.repository;

import com.hotelPet.codec.CodecCheckin;
import com.hotelPet.model.Checkin;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Vitor
 */
@Repository
public class CheckinRepository {
     public MongoDatabase conecta() {
        //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Passar para a classe de codificação qual será o codec usado
        CodecCheckin  checkinCodec = new CodecCheckin(codec);

        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(checkinCodec)
        );

        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();

        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet_Final");
        return db;
    }
     
    public void salvar(Checkin checkin) {
        MongoDatabase db = conecta();
        MongoCollection<Checkin> checkins = db.getCollection("checkin", Checkin.class);
        //Se eu já tiver um aluno simplesmente atualizo ele
        if (checkin.getId() == null) {
            checkins.insertOne(checkin);
        } else {
            checkins.updateOne(Filters.eq("_id", checkin.getId()), new Document("$set", checkin));
        }
        //cliente.close();
    }

    public List<Checkin> listar() {
        MongoDatabase db = conecta();
        MongoCollection<Checkin> checkins = db.getCollection("checkin", Checkin.class);
        MongoCursor<Checkin> resultado = checkins.find().iterator();

        //Lista de Iteração
        List<Checkin> checkinLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Checkin checkin = resultado.next();
            checkinLista.add(checkin);
        }

        return checkinLista;
    }

    public Checkin obterId(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Checkin> checkins = db.getCollection("checkin", Checkin.class);
        Checkin checkin = checkins.find(Filters.eq("_id", new ObjectId(id))).first();
        return checkin;
    }

    public void excluir(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Checkin> checkins = db.getCollection("checkin", Checkin.class);
        checkins.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }

}
