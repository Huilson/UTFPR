/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotelPet.model;

/**
 *
 * @author Vitor
 */

import java.util.Date;
import org.bson.types.ObjectId;


public class Checkin {
    private ObjectId id;
    private String nome_animal;
    private Date data_ck;  

    public Checkin(String nome_animal,Date data_ck) {
        this.nome_animal = nome_animal;
        this.data_ck = data_ck;
    }

    public Checkin() {
    }
    
    
    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome_animal() {
        return nome_animal;
    }

    public void setNome_animal(String nome_animal) {
        this.nome_animal = nome_animal;
    } 

    public Date getData_ck() {
        return data_ck;
    }

    public void setData_ck(Date data_ck) {
        this.data_ck = data_ck;
    }
    
    
    
    public Checkin criarId(){
        setId(new ObjectId());
        return this;
    }
    
}
