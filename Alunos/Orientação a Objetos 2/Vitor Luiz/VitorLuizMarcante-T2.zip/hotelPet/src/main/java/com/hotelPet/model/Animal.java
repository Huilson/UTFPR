package com.hotelPet.model;

import org.bson.types.ObjectId;

public class Animal {
    private ObjectId id;
    private String nome;
    private Integer idade;
    private String especie;
    private String andar;
    private Pessoa tutor;
    private String tutor_nome;
   
    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getAndar() {
        return andar;
    }

    public void setAndar(String andar) {
        this.andar = andar;
    }

    public Pessoa getTutor() {
        return tutor;
    }

    public void setTutor(Pessoa tutor) {
        this.tutor = tutor;
    }

    public String getTutor_nome() {
        return tutor_nome;
    }

    public void setTutor_nome(String tutor_nome) {
        this.tutor_nome = tutor_nome;
    }
    public Animal criarId(){
        setId(new ObjectId());
        return this;
    }
    
}
