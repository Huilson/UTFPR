package com.hotelPet.model;

import org.bson.types.ObjectId;

public class Pessoa {
    private ObjectId id;
    private String nome;
    private Integer idade;
    private String documento;
    
    
    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }
    
    
    public Pessoa criarId(){
        setId(new ObjectId());
        return this;
    }
    
   
}
