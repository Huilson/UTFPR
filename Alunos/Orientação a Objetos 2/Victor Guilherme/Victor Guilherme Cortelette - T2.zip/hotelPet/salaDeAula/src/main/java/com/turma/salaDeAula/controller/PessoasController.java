package com.turma.salaDeAula.controller;

import com.turma.salaDeAula.model.Pessoa;
import com.turma.salaDeAula.repository.PessoaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PessoasController {
    
    @Autowired
    private PessoaRepository repository;
    
    @GetMapping("/aluno/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("aluno", new Pessoa());
        return"aluno/cadastrar";
    }
    
    @PostMapping("/aluno/salvar")
    public String salvar(@ModelAttribute Pessoa aluno){
        System.out.println("Salvando");
        repository.salvar(aluno);
        return"redirect:/";
    }
    
    @GetMapping("/aluno/listar")
    public String listar(Model model){
        List<Pessoa> alunos = repository.listar();
        model.addAttribute("alunos", alunos);
        return"aluno/listar";
    }
}
