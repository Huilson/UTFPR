package com.turma.salaDeAula.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.types.ObjectId;

public class Pet {
    private ObjectId id;
    private String nome;
    private String tipo;
    private String especie;
    private String hospedagemAtual;
    //Outros dados serão add posteriormente


    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }
    
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String curso) {
        this.tipo = curso;
    }
    
    public Pet criarId(){
        setId(new ObjectId());
        return this;
    }
    
    
    
//    public Pessoa addDisciplina(Pessoa aluno, Disciplina disciplina){
//        List<Disciplina> disciplinas = aluno.getDisciplina();
//        disciplinas.add(disciplina);
//        aluno.setDisciplina(disciplinas);
//        return aluno;
//    }

    public String getHospedagemAtual() {
        return hospedagemAtual;
    }

    public void setHospedagemAtual(String hospedagemAtual) {
        this.hospedagemAtual = hospedagemAtual;
    }
}
