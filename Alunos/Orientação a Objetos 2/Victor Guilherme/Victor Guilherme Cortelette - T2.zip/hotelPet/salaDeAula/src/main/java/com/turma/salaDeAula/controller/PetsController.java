package com.turma.salaDeAula.controller;

import com.turma.salaDeAula.model.Pessoa;
import com.turma.salaDeAula.model.Pet;
import com.turma.salaDeAula.repository.PessoaRepository;
import com.turma.salaDeAula.repository.PetRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PetsController {
    
    @Autowired
    private PetRepository repository;
    
    @GetMapping("/pets/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("aluno", new Pessoa());
        return"pets/cadastrar";
    }
    
    @PostMapping("/pets/salvar")
    public String salvar(@ModelAttribute Pet pet){
        System.out.println("Salvando");
        repository.salvar(pet);
        return"redirect:/";
    }
    
    @GetMapping("/pets/listar")
    public String listar(Model model){
        List<Pet> pets = repository.listar();
        model.addAttribute("pets", pets);
        return"pets/listar";
    }
}
