package com.turma.salaDeAula.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

public class Pessoa {
    private ObjectId id;
    private String nome;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date idade;
    private String tipo;
    //Outros dados serão add posteriormente


    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getIdade() {
        return idade;
    }

    public void setIdade(Date idade) {
        this.idade = idade;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String curso) {
        this.tipo = curso;
    }
    
    public Pessoa criarId(){
        setId(new ObjectId());
        return this;
    }
    
//    public Pessoa addDisciplina(Pessoa aluno, Disciplina disciplina){
//        List<Disciplina> disciplinas = aluno.getDisciplina();
//        disciplinas.add(disciplina);
//        aluno.setDisciplina(disciplinas);
//        return aluno;
//    }
}
