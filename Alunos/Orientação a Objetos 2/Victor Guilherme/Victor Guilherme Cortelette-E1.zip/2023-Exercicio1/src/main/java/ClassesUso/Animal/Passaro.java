/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassesUso.Animal;

/**
 *
 * @author Aluno
 */
public class Passaro extends Animal {

    public Passaro(String nome, String especie, int idade) {
        setNome(nome);
        setEspecie(especie);
        setIdade(idade);
    }

    public Passaro() {
    }
    
    @Override
    public String toString() {
        return "Passaro{" + "nome=" + getNome() + ", especie=" + getEspecie() + ", idade=" + getIdade() + '}';
    }
}
