/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassesUso.Pessoa;

/**
 *
 * @author Victor
 */
public class Tutor  extends Pessoa{

     @Override
    public String toString() {
        return "Tutor{" + "nome=" + getNome() + ", documento=" + getDocumento() + '}';
    }
    
}
