package App;

import ClassesUso.Animal.Animal;
import ClassesUso.Animal.Cachorro;
import ClassesUso.Animal.Gato;
import ClassesUso.Animal.Passaro;
import ClassesUso.Despesas.Despesa;
import ClassesUso.Pessoa.Funcionario;
import ClassesUso.Pessoa.Pessoa;
import ClassesUso.Pessoa.Tutor;
import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class InteracaoUsuario {

    public static int menuPrincipal() {
        int opcao;
        Scanner scan = new Scanner(System.in);

        System.out.println("O que deseja fazer?\n"
                + "1-Movimentar cadastros de Pessoas\n"
                + "2-Fazer check in de um animal\n"
                + "3-Fazer check out de um animal\n"
                + "4-Alterar Info de um animal checkado\n"
                + "5-Ver animais checkados no hotel\n"
                + "6-Movimentar cadastros de Despesa\n"
                + "7-Sair do programa");
        opcao = scan.nextInt();
        System.out.println("escolheu opcao : " + opcao);
        return opcao;
    }

    public static int menuCrud(String dados) {
        int opcao;
        //Este menu recebe os dados a serem alterados(tutores,animais,despesas,funcionarios)
        //como parametro, e recebe a resposta a ser usada
        Scanner scan = new Scanner(System.in);
        System.out.println("O que deseja fazer com os cadastros de "+ dados + "\n"
                + "1-Inserir cadastro\n"
                + "2-Excluir cadastros\n"
                + "3-Alterar cadastro\n"
                + "4-Ver cadastros\n");
        
        opcao = scan.nextInt();
        System.out.println("escolheu opcao : " + opcao);
        return opcao;
    }
    
    public static Despesa novaDespesa(){
        Scanner scan = new Scanner(System.in);
        Despesa despesa = new Despesa();

        System.out.println("Digite a descricao da despesa: ");
        despesa.setDescricao(scan.next());
        System.out.println("Digite o valor da despesa: ");
        despesa.setValor(scan.nextDouble());

        return despesa;
    }
    
     public static Despesa menuAlterarDespesa(Despesa despesa) {
        Scanner scan = new Scanner(System.in);

        System.out.println("O que deseja alterar?\n"
                + "1-Descricao\n"
                + "2-Valor\n");
        int resposta = scan.nextInt();

        System.out.print("Digite a seguir o substituto da opção que escolheu: ");
        switch (resposta) {
            case 1:
                despesa.setDescricao(scan.next());
                break;
            case 2:
                despesa.setValor(scan.nextDouble());
                break;     
        }
        return despesa;
    }

    
    public static int menuTipoPessoa() {
        int opcaoTipoPessoa;
        Scanner scan = new Scanner(System.in);

        System.out.println("Qual o tipo de Pessoa?\n"
                + "1-Funcionario\n"
                + "2-Tutor\n");
        opcaoTipoPessoa = scan.nextInt();
        return opcaoTipoPessoa;

    }
     
   
    public static Pessoa menuAlterarPessoa(Pessoa pessoa) {
        Scanner scan = new Scanner(System.in);

        System.out.println("O que deseja alterar?\n"
                + "1-Nome\n"
                + "2-Documento\n");
        int resposta = scan.nextInt();

        System.out.print("Digite a seguir o substituto da opção que escolheu: ");
        switch (resposta) {
            case 1:
                pessoa.setNome(scan.next());
                break;
            case 2:
                pessoa.setDocumento(scan.next());
                break;     
        }
        return pessoa;
    }
    public static Animal menuAlterarAnimal(Animal animal) {
        Scanner scan = new Scanner(System.in);

        System.out.println("O que deseja alterar?\n"
                + "1-Nome\n"
                + "2-Especie\n"
                + "3-idade\n");
        int resposta = scan.nextInt();

        System.out.print("Digite a seguir o substituto da opção que escolheu: ");
        switch (resposta) {
            case 1:
                animal.setNome(scan.next());
                break;
            case 2:
                animal.setEspecie(scan.next());
                break;     
            case 3:
                animal.setIdade(scan.nextInt());
                break;     
        }
        return animal;
    }
    
     public Funcionario novoFuncionario() {
        Scanner scan = new Scanner(System.in);
        Funcionario func = new Funcionario();

        System.out.println("Digite o nome do Funcionario: ");
        func.setNome(scan.next());
        System.out.println("Digite o documento do Funcionario: ");
        func.setDocumento(scan.next());

        return func;
    }
     public Tutor novoTutor() {
        Scanner scan = new Scanner(System.in);
        Tutor tutor = new Tutor();

        System.out.println("Digite o nome do Tutor");
        tutor.setNome(scan.next());
        System.out.println("Digite o documento do Tutor: ");
        tutor.setDocumento(scan.next());

        return tutor;
    }
    
    

    public static int menuIndex(String funcao) {
        //funcao alimentada com parametro para mostrar o que será feito no print
        //retorna index digitado
        int id;
        Scanner scan = new Scanner(System.in);

        System.out.println("Qual id deseja "+funcao+"?\n");
        id = scan.nextInt();
        return id;

    }
    
    public static int menuTipoAnimal() {
        int opcaoTipoAnimal;
        Scanner scan = new Scanner(System.in);

        System.out.println("Qual o tipo de animal?\n"
                + "1-Cachorro\n"
                + "2-Gato\n"
                + "3-Passaro\n"
                + "4-Cancelar");
        opcaoTipoAnimal = scan.nextInt();
        return opcaoTipoAnimal;

    }

    public Cachorro novoCachorro() {
        Scanner scan = new Scanner(System.in);
        Cachorro cachorro = new Cachorro();

        System.out.println("Digite o nome do animal: ");
        cachorro.setNome(scan.next());
        System.out.println("Digite a especie do animal: ");
        cachorro.setEspecie(scan.next());
        System.out.println("Digite a idade do animal: ");
        cachorro.setIdade(scan.nextInt());

        return cachorro;
    }

    public Gato novoGato() {
        Scanner scan = new Scanner(System.in);
        Gato gato = new Gato();

        System.out.println("Digite o nome do animal: ");
        gato.setNome(scan.next());
        System.out.println("Digite a especie do animal: ");
        gato.setEspecie(scan.next());
        System.out.println("Digite a idade do animal: ");
        gato.setIdade(scan.nextInt());

        return gato;
    }

    public Passaro novoPassaro() {
        Scanner scan = new Scanner(System.in);
        Passaro passaro = new Passaro();

        System.out.println("Digite o nome do animal: ");
        passaro.setNome(scan.next());
        System.out.println("Digite a especie do animal: ");
        passaro.setEspecie(scan.next());
        System.out.println("Digite a idade do animal: ");
        passaro.setIdade(scan.nextInt());

        return passaro;
    }
}
