package App;

import ClassesUso.Animal.Cachorro;
import ClassesUso.Animal.Gato;
import ClassesUso.Animal.Passaro;
import ClassesUso.Despesas.Despesa;
import ClassesUso.Pessoa.Funcionario;
import ClassesUso.Pessoa.Pessoa;
import ClassesUso.Pessoa.Tutor;
import java.util.ArrayList;
import java.util.List;

public class App {

    public static boolean continuarPrograma = true;

    private static List<Despesa> despesas = new ArrayList();

    private static List<Funcionario> funcionarios = new ArrayList();
    private static List<Tutor> tutores = new ArrayList(); 

    private static List<Cachorro> primeiroAndar = new ArrayList();
    private static List<Gato> segundoAndar = new ArrayList();
    private static List<Passaro> terceiroAndar = new ArrayList();

    static InteracaoUsuario menu = new InteracaoUsuario();

    public static void main(String[] args) {

        while (continuarPrograma) {
            int opcao;

            opcao = menu.menuPrincipal();

            switch (opcao) {
                case 1:
                    //Recebe o tipo de pessoa
                    int tipoPessoa = menu.menuTipoPessoa();
                    //Recebe a função do crud que será usada(1-Inserir 2-Excluir 3- Alterar 4-Select)
                    int opcaoCadastros = menu.menuCrud("Funcionarios");
                    //Tipopessoa =1 --- Funcionario
                    if (tipoPessoa == 1) {
                        if (opcaoCadastros == 1) {
                            //Nova despesa
                            funcionarios.add(menu.novoFuncionario());
                        } else if (opcaoCadastros == 2) {
                            //Excluir despesa
                            int idFuncionarioExcluir = menu.menuIndex("Excluir");
                            funcionarios.remove(idFuncionarioExcluir);
                        } else if (opcaoCadastros == 3) {
                            //Alterar despesa
                            //recebe o id da empresa, em seguida substitui pela mesma empresa após alteração
                            int idFuncionarioAlterar = menu.menuIndex("Alterar");
                            Funcionario funcionarioAlterado = (Funcionario) menu.menuAlterarPessoa(funcionarios.get(idFuncionarioAlterar));
                            funcionarios.set(idFuncionarioAlterar, funcionarioAlterado);
                        } else if (opcaoCadastros == 4) {
                            //Ver despesas
                            for (Funcionario i : funcionarios) {
                                System.out.println(i.toString());
                            }
                        }
                         //Tipopessoa =2 --- Tutor
                    }else if(tipoPessoa == 2){
                        if (opcaoCadastros == 1) {
                            //Nova despesa
                            tutores.add(menu.novoTutor());
                        } else if (opcaoCadastros == 2) {
                            //Excluir despesa
                            int idTutorExcluir = menu.menuIndex("Excluir");
                            tutores.remove(idTutorExcluir);
                        } else if (opcaoCadastros == 3) {
                            //Alterar despesa
                            //recebe o id da empresa, em seguida substitui pela mesma empresa após alteração
                            int idTutorAlterar = menu.menuIndex("Alterar");
                            Tutor tutorAlterado = (Tutor) menu.menuAlterarPessoa(tutores.get(idTutorAlterar));
                            tutores.set(idTutorAlterar, tutorAlterado);
                        } else if (opcaoCadastros == 4) {
                            //Ver despesas
                            for (Tutor i : tutores) {
                                System.out.println(i.toString());
                            }
                        }
                    }
                    break;
                case 2:
                    //Fazer check in  de um animal
                    opcao = menu.menuTipoAnimal();
                    if (opcao == 1) {
                        primeiroAndar.add(menu.novoCachorro());
                    } else if (opcao == 2) {
                        segundoAndar.add(menu.novoGato());
                    } else if (opcao == 3) {
                        terceiroAndar.add(menu.novoPassaro());
                    }
                    break;
                case 3:
                    //Fazer check out de um animal
                    int tipoAnimalCheckout = menu.menuTipoAnimal();
                    int indexAnimal = menu.menuIndex("fazer Checkout");

                    if (tipoAnimalCheckout == 1) {
                        primeiroAndar.remove(indexAnimal);
                    } else if (tipoAnimalCheckout == 2) {
                        segundoAndar.remove(indexAnimal);
                    } else if (tipoAnimalCheckout == 3) {
                        terceiroAndar.remove(indexAnimal);
                    }
                    break;
                case 4:
                    //Alterar info de um animal
                    int tipoAnimalAlterar = menu.menuTipoAnimal();
                    int indexAnimalAlterar = menu.menuIndex("fazer Checkout");
                    
                    
                    
                    if (tipoAnimalAlterar == 1) {
                        Cachorro cachorroAlterado  = (Cachorro) menu.menuAlterarAnimal(primeiroAndar.get(indexAnimalAlterar));
                        primeiroAndar.set(indexAnimalAlterar, cachorroAlterado);
                        
                    } else if (tipoAnimalAlterar == 2) {
                        Gato gatoAlterado  = (Gato) menu.menuAlterarAnimal(segundoAndar.get(indexAnimalAlterar));
                        segundoAndar.set(indexAnimalAlterar, gatoAlterado);
                    } else if (tipoAnimalAlterar == 3) {
                        Passaro passaroAlterado  = (Passaro) menu.menuAlterarAnimal(terceiroAndar.get(indexAnimalAlterar));
                        terceiroAndar.set(indexAnimalAlterar, passaroAlterado);
                    }
                    break;
                case 5:
                    for (Cachorro i : primeiroAndar) {
                        System.out.println(i.toString());
                    }
                    for (Gato i : segundoAndar) {
                        System.out.println(i.toString());
                    }
                    for (Passaro i : terceiroAndar) {
                        System.out.println(i.toString());
                    }
                    break;
                case 6:
                    //Alterar cadastros de Despesas
                    //Recebe a função do crud que será usada(1-Inserir 2-Excluir 3- Alterar 4-Select)
                    int opcaoCadastrosDespesa = menu.menuCrud("Despesa");

                    if (opcaoCadastrosDespesa == 1) {
                        //Nova despesa
                        despesas.add(menu.novaDespesa());
                    } else if (opcaoCadastrosDespesa == 2) {
                        //Excluir despesa
                        int idDespesaExcluir = menu.menuIndex("Excluir");
                        despesas.remove(idDespesaExcluir);
                    } else if (opcaoCadastrosDespesa == 3) {
                        //Alterar despesa
                        //recebe o id da empresa, em seguida substitui pela mesma empresa após alteração
                        int idDespesaAlterar = menu.menuIndex("Alterar");
                        Despesa despesaAlterada = menu.menuAlterarDespesa(despesas.get(idDespesaAlterar));
                        despesas.set(idDespesaAlterar, despesaAlterada);
                    } else if (opcaoCadastrosDespesa == 4) {
                        //Ver despesas
                        for (Despesa i : despesas) {
                            System.out.println(i.toString());
                        }
                    }

                    break;
                case 7:
                    //Sair do aplicativo
                    continuarPrograma = false;
                    break;
            }

        }
    }
}
