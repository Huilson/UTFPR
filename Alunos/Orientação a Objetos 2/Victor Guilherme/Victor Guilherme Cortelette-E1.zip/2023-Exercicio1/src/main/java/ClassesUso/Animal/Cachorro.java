/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassesUso.Animal;

/**
 *
 * @author Aluno
 */
public class Cachorro extends Animal {

    public Cachorro(String nome, String especie, int idade) {
        setNome(nome);
        setEspecie(especie);
        setIdade(idade);
    }

    public Cachorro() {
    }
    
    
    
    @Override
    public String toString() {
        return "Cachorro{" + "nome=" + getNome() + ", especie=" + getEspecie() + ", idade=" + getIdade() + '}';
    }

}
