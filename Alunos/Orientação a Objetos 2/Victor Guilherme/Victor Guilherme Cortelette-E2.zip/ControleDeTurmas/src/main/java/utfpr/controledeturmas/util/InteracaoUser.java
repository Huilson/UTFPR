/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.controledeturmas.util;

import java.util.Scanner;
import utfpr.controledeturmas.model.Pessoa;
import utfpr.controledeturmas.model.Profissao;

/**
 *
 * @author Aluno
 */
public class InteracaoUser {

    public static int menuInicial() {
        Scanner scan = new Scanner(System.in);

        System.out.println("O que deseja fazer?\n"
                + "1-Inserir um novo cadastro de pessoa\n"
                + "2-Alterar um cadastro de pessoa existente\n"
                + "3-Excluir um cadastro de pessoa\n"
                + "4-Ver os cadastros de pessoa\n"
                + "5-Sair\n");
        int resposta = scan.nextInt();

        return resposta;
    }

    public static Pessoa alterarPessoa(Pessoa pessoa) {
        Scanner scan = new Scanner(System.in);

        System.out.println("O que deseja alterar?\n"
                + "1-Nome\n"
                + "2-Cpf\n"
                + "3-Idade\n"
                + "4-Contato\n"
                + "5-Cidade\n"
                + "6-Rua\n"
                + "7-Numero\n"
                + "8-Profissao\n");
        int resposta = scan.nextInt();

        System.out.print("Digite a seguir o substituto da opção que escolheu: ");
        switch (resposta) {
            case 1:
                pessoa.setNome(scan.next());
                break;
            case 2:
                pessoa.setCpf(scan.next());
                break;
            case 3:
                pessoa.setIdade(scan.nextInt());
                break;
            case 4:
                pessoa.setContato(scan.next());
                break;
            case 5:
                pessoa.setCidade(scan.next());
                break;
            case 6:
                pessoa.setNome(scan.next());
                break;
            case 7:
                pessoa.setRua(scan.next());
                break;
            case 8:
                pessoa.setNumero(scan.nextInt());
                break;
            case 9:
                pessoa.setProfissao(Profissao.values()[scan.nextInt()]);
                break;

        }
        return pessoa;
    }

    public static Pessoa receberPessoa() {
        Scanner scan = new Scanner(System.in);
        Pessoa pessoa = new Pessoa();

        System.out.print("Digite o nome da pessoa: ");
        pessoa.setNome(scan.next());

        System.out.print("Digite o cpf da pessoa: ");
        pessoa.setCpf(scan.next());

        System.out.print("Digite a idade da pessoa: ");
        pessoa.setIdade(scan.nextInt());

        System.out.print("Digite o contato da pessoa: ");
        pessoa.setContato(scan.next());

        System.out.print("Digite a Cidade da pessoa: ");
        pessoa.setCidade(scan.next());

        System.out.print("Digite a rua da pessoa: ");
        pessoa.setRua(scan.next());

        System.out.print("Digite o numero da casa pessoa: ");
        pessoa.setNumero(scan.nextInt());

        System.out.print("Digite o numero da profissao da pessoa, estas são as opções: ");
        int cont = 0;
        System.out.print("\n");
        for (Profissao p : Profissao.values()) {
            System.out.println(cont + "-" + p);
            cont++;
        }
        pessoa.setProfissao(Profissao.values()[scan.nextInt()]);

        //Pegar enum pelo index do array
        return pessoa;
    }

    ;
    
    
    public static int receberId() {
        Scanner scan = new Scanner(System.in);

        System.out.print("Digite o id da pessoa: ");
        return scan.nextInt();

    }
;

}
