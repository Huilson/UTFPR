package utfpr.controledeturmas;

import java.util.List;
import utfpr.controledeturmas.model.Pessoa;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.model.Profissao;
import utfpr.controledeturmas.util.Factory;
import utfpr.controledeturmas.util.InteracaoUser;

public class ControleDeTurmas {

    static boolean continuarAplicacao;

    public static void main(String[] args) {
        InteracaoUser interacao = new InteracaoUser();
        EntityManager em = Factory.getEntityManager();
        PessoaDao dao = new PessoaDao(em);
        continuarAplicacao = true;

        dao.conecta();
        while (continuarAplicacao) {
            int opcaoMenu = interacao.menuInicial();

            switch (opcaoMenu) {
                case 1:
                    //Opção inserir
                    Pessoa pInserir = interacao.receberPessoa();
                    System.out.println(pInserir.toString());
                    dao.salvar(pInserir);
                    break;
                case 2:
                    //Opção alterar
                    int idAlterar = interacao.receberId();
                    Pessoa pessoaAlterar = dao.consultarId(idAlterar);
                    System.out.println("A pessoa escolhida tem as seguintes informações: ");
                    System.out.println(pessoaAlterar.toString());
                    pessoaAlterar = interacao.alterarPessoa(pessoaAlterar);
                    dao.atualizar(pessoaAlterar);
                    dao.salvar(pessoaAlterar);
                    break;
                case 3:
                    //opção excluir pessoa
                    int idExcluir = interacao.receberId();
                    Pessoa pessoaExcluir = dao.consultarId(idExcluir);
                    dao.excluir(pessoaExcluir);
                    break;
                case 4:
                    //opção listar pessoas
                    List<Pessoa> todasPessoas = dao.consultar();
                    for (Pessoa p : todasPessoas) {
                        System.out.println("----------------------");
                        System.out.println(p.toString());
                    }
                    break;
                case 5:
                    System.out.println("\nSaindo da Aplicação!");
                    continuarAplicacao = false;
                    break;
                default:
                    System.out.println("Digite uma opção válida!");
                    break;
            }

        }
        dao.encerrar();

    }
}
