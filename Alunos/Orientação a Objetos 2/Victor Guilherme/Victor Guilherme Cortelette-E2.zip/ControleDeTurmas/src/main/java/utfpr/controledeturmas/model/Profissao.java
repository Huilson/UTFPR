package utfpr.controledeturmas.model;

public enum Profissao {
    MEDICO,
    PROFESSOR,
    DESENVOLVEDOR,
    ENGENHEIRO,
    ADVOGADO,
    DESIGNER,
    POLICIAL,
    BOMBEIRO,
    ARQUITETO,
    FOTOGRAFO;
    
}
