package utfpr.controledeturmas.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//De classe para classe
//import javax.persistence.ManyToOne;

@Entity
public class Pessoa {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)        
    private int id;
    private String nome;
    @Column(name ="documento")
    private String cpf;
    private int idade;
    private String contato;
    private String cidade;
    private String rua;
    private int numero;
    @Enumerated(EnumType.STRING)
    private Profissao profissao;

    //CONSTRUCTOR
    public Pessoa(String nome, String cpf, int idade, String contato, String cidade, String rua, int numero) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.contato = contato;
        this.cidade = cidade;
        this.rua = rua;
        this.numero = numero;
    }

    public Pessoa() {
    }
    
    //GETTERS E SETTERS
    public Profissao getProfissao() {
        return profissao;
    }
    
    public void setProfissao(Profissao profissao) {    
        this.profissao = profissao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    @Override
    public String toString(){
        String str = "";
        str += "id: " + this.getId();
        str += "   Nome: " + this.getNome();
        str += "\ncpf: " + this.getCpf();
        str += "  contato: " + this.getContato();
        str += "  Idade: " + this.getIdade();
        str += "\nCidade: " + this.getCidade();
        str += "  Rua: " + this.getRua();
        str += "  Numero: " + this.getNumero();
        str += "\nProfissao: " + this.getProfissao();
        
        return str;
    }
    
}
