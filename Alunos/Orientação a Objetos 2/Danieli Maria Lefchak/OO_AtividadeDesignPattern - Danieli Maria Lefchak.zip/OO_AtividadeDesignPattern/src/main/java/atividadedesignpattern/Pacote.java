/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//Classe pacote que irá conter todas as informações
//dos pacotes que serão ou não aprovados pelo correio
public class Pacote{
    private String nomeEmissor;
    private String nomeDestinatario;
    private String endEmissor;
    private String endDestinatario;

    public Pacote() {
    }
    
    public Pacote(String nomeEmissor, String nomeDestinatario, String endEmissor, String endDestinatario) {
        this.nomeEmissor = nomeEmissor;
        this.nomeDestinatario = nomeDestinatario;
        this.endEmissor = endEmissor;
        this.endDestinatario = endDestinatario;
    }

    public String getNomeEmissor() {
        return nomeEmissor;
    }

    public void setNomeEmissor(String nomeEmissor) {
        this.nomeEmissor = nomeEmissor;
    }

    public String getNomeDestinatario() {
        return nomeDestinatario;
    }

    public void setNomeDestinatario(String nomeDestinatario) {
        this.nomeDestinatario = nomeDestinatario;
    }

    public String getEndEmissor() {
        return endEmissor;
    }

    public void setEndEmissor(String endEmissor) {
        this.endEmissor = endEmissor;
    }

    public String getEndDestinatario() {
        return endDestinatario;
    }

    public void setEndDestinatario(String endDestinatario) {
        this.endDestinatario = endDestinatario;
    }

    @Override
    public String toString() {
        return "nome Emissor: " + nomeEmissor + ", nome Destinatario: " + nomeDestinatario + ", end Emissor: " 
                + endEmissor + ", end Destinatario: " + endDestinatario;
    }
}
