/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//cria uma classe abstrata Correio para receber
//as opções das classes concretas das interfaces
//essa classe irá estender a classe pacotes
public abstract class Correio extends Pacote{
    protected IPagamento pagamento;
    //cria um objeto do tipo IPagamento
    protected ITransporte transporte;
    //cria um objeto do tipo ITransporte
    protected IValidaRemetenteExistentes endRem;
    //cria um objeto do tipo IValidaRemetenteExistentes
    protected IValidaDestinatarioExistentes endDest;
    //cria um objeto do tipo IValidaDestinatarioExistentes
    private String tipo;
    private boolean valida;
    private int tam;

    public Correio(){
    }

    public Correio(String nomeEmissor, String nomeDestinatario, String endEmissor, String endDestinatario) {
        super(nomeEmissor, nomeDestinatario, endEmissor, endDestinatario);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public int getTam() {
        return tam;
    }

    public void setTam(int tam) {
        this.tam = tam;
    }
    
    //faz um método que irá chamar o método
    //que virá da interface IPagamento
    public void validaPagemento(){
        pagamento.validaPagemento();
    }
    
    //faz um método que irá chamar o método
    //que virá da interface ITransporte
    public void validaTransporte(){
        transporte.validaTransporte();
    }
    
    //faz um método que irá chamar o método
    //que virá da interface IValidaRemetenteExistentes
    public void validaRemetExistente(){
        endRem.validaRemetExistente();
    }
    
    //faz um método que irá chamar o método
    //que virá da interface IValidaDestinatarioExistentes
    public void validaDestExistente(){
        endDest.validaDestExistente();
    }

    public boolean isValida() {
        return valida;
    }

    public void setValida(boolean valida) {
        this.valida = valida;
    }
    
    //Faz um método para finalizar thread
    public synchronized boolean finalizar(){
        this.valida = valida;
        return valida;
    }
}
