/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
public class PacoteNaoPago extends Correio {
    //classe que extende de Correio cria um construtor no 
    //contrutor chama os métodos da classe que irá ter os 
    //métodos que irão fazer a validação do pagamento 
    //correspondente para este pacote
    public PacoteNaoPago() {
        pagamento = new PagamentoNaoRealizado();
        System.out.println("Pacote reprovado, o pacote nao foi pago. Tente envia-lo novamente mais tarde!");
    }
}
