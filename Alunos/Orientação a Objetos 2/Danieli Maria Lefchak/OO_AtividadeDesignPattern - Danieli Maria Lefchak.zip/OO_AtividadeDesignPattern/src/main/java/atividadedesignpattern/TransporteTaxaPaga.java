/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
//Uma das classes concretas da estrategia ITransporte que irá
//implementar o método validaTransporte
public class TransporteTaxaPaga implements ITransporte{
    @Override
    public void validaTransporte() {//implementação do método transporte
        String tipo = JOptionPane.showInputDialog("Informe o tipo do transporte");
        System.out.println("O transporte escolhido foi: " + tipo);
    }
}
