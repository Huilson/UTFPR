/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
public class PacoteEnviar extends Correio{
    //classe que extende de Correio cria um construtor no 
    //contrutor chama os métodos da classe que irá ter os 
    //métodos que irão fazer a validação do pagamento, 
    //endRem, endDest, transporte correspondente para este 
    //pacote
    public PacoteEnviar() {
        pagamento = new PagamentoRealizado();
        endRem = new ExisteRemetente();
        endDest = new ExisteDestinatario();
        transporte = new TransporteTaxaPaga();
        System.out.print("Pacote aprovado!");
    }
}
