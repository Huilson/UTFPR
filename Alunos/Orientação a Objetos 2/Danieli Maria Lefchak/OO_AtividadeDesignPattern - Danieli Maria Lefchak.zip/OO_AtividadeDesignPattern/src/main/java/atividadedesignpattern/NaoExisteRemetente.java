/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//Outra classes concreta da estrategia IValidaRemetenteExistentes que irá
//implementar o método validaRemetExistente
public class NaoExisteRemetente implements IValidaRemetenteExistentes{
    @Override
    public void validaRemetExistente() {//implementação do método validaRemetExistente
        System.out.println("O remetente informado não existe!");
    }
}
