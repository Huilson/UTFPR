/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//cria uma interface ITransporte que terá o 
//método que todas as classes concretas 
//teram em comum
public interface ITransporte {
    public void validaTransporte();
}
