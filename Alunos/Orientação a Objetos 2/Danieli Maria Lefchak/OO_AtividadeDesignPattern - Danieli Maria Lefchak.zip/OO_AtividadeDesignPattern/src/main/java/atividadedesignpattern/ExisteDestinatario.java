/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//Uma das classes concretas da estrategia IValidaDestinatarioExistentes que irá
//implementar o método validaDestExistente
public class ExisteDestinatario implements IValidaDestinatarioExistentes{
    @Override
    public void validaDestExistente() {//implementação do método validaDestExistente
        System.out.println("O destinatario informado existe!");
    }
}
