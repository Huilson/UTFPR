/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class AprovacaoCorreio extends Correio implements Runnable{//classe que controla a thread
    private boolean segundaTentiva;
    private boolean verificaPac;
    private boolean verificaTaxa;
    private boolean verificaRem;
    private boolean verificaDest;
    private boolean verificaSeg;
    private boolean valida = false;
    private String tipoTransp;
    private String nome;
    private Thread t;
    private int cntTentativa;

    public AprovacaoCorreio(String nome, String nomeEmissor, String nomeDestinatario, String endEmissor, String endDestinatario) {
        super(nomeEmissor, nomeDestinatario, endEmissor, endDestinatario);
        this.nome = nome;
        t = new Thread(this, nome);
        t.start();//inicia a thread
    }
    
    //método que irá pedir para que o correio informe se o pacote está
    //pago e retornar esta reposta do correio
    public boolean verificaPacotes(){
        verificaPac = Boolean.parseBoolean(JOptionPane.showInputDialog("Informe se o pacote foi pago(true/false): "));
        //apos ser informado se o pacote foi ou não pago irá fazer a verificação
        if (verificaPac == true) {
            //se o pacote foi pago irá criar um objeto que mostra uma mensagem
            //indica que o pacote foi pago
            PacoteEnviar pacEnv = new PacoteEnviar();
            System.out.println(" O pacote foi pago");
        } else {//caso contrario criar um objeto que mostra 
            //uma mensagem indica que o pacote nao foi pago
            PacoteNaoPago pacNaoPag = new PacoteNaoPago();
        }

        return verificaPac;
    }
    
    //método que irá pedir para que o correio informe se o remetente é
    //valido e retornar esta reposta do correio
    public boolean verificaRemetente(){
        verificaRem = Boolean.parseBoolean(JOptionPane.showInputDialog("Informe se o remetente e valido(true/false): "));
        //se o remetente do pacote é valido irá criar um objeto que mostra 
        //uma mensagem indica que o remetente do pacote é valido
        if (verificaRem == true) {
            PacoteEnviar remValido = new PacoteEnviar();
            System.out.println(" O remetente foi verificado");
        } else {//caso contrario criar um objeto que mostra 
        //uma mensagem indica que o remetente do pacote nao é valido
            PacoteRemetInvalido remInvalido = new PacoteRemetInvalido();
        }

        return verificaRem;
    }
    
    //método que irá pedir para que o correio informe se o destinatario é
    //valido e retornar esta reposta do correio
    public boolean verificaDestinatario(){
        verificaDest = Boolean.parseBoolean(JOptionPane.showInputDialog("Informe se o destinatario e valido(true/false): "));
        //se o destinatario do pacote é valido irá criar um objeto que mostra 
        //uma mensagem indica que o destinatario do pacote é valido
        if (verificaDest == true) {
            PacoteEnviar destValido = new PacoteEnviar();
            System.out.println(" O destinatario foi verificado");
        } else {//caso contrario criar um objeto que mostra 
        //uma mensagem indica que o destinatario do pacote nao é valido
            PacoteDestinaInvalido destInvalido = new PacoteDestinaInvalido();
        }
        
        return verificaDest;
    }
    
    //método que irá pedir para que o correio informe se a taxa de transporte foi
    //paga e retornar esta reposta do correio
    public boolean verificaTaxa(){
        verificaTaxa = Boolean.parseBoolean(JOptionPane.showInputDialog("Informe se a taxa de transporte foi paga(true/false): "));
        //se a taxa de transporte do pacote foi pago e irá criar um objeto que mostra 
        //uma mensagem indica que a taxa de transporte do pacote foi paga
        if (verificaTaxa == true) {
            PacoteEnviar transpPag = new PacoteEnviar();
            System.out.println(" A taxa de transporte foi paga");
            tipoTransp = JOptionPane.showInputDialog("Informe qual é o tipo de transporte: ");
            super.setTipo(tipoTransp);
        } else {//caso contrario criar um objeto que mostra uma mensagem 
            //indica que a taxa de transporte do pacote nao foi paga
            PacoteTaxaTranspNaoPago transpNaoPag = new PacoteTaxaTranspNaoPago();
            tipoTransp = "Pacote nao passou na avaliacao! Transporte nao escolhido. ";
            super.setTipo(tipoTransp);
        }
       
        return verificaTaxa;
    }
    
    public synchronized boolean validarInfo() throws InterruptedException {
        if (verificaPacotes() == true) {
            //chama o método que faz a verificação do pacote 
            //se o retorno dele for verdadeiro
            if (verificaRemetente() == true) {
                //chama o método que faz a verificação do remetente
                //se o retorno dele for verdadeiro
                if (verificaDestinatario() == true) {
                    //chama o método que faz a verificação do destinatario
                    //se o retorno dele for verdadeiro
                    if (verificaTaxa() == true) {
                        //chama o método que faz a verificação da taxa do transporte
                        //se o retorno dele for verdadeiro
                        Thread.sleep(5000);//espera 5000
                        System.out.println("O pacote foi enviado!");//mostra mensagem
                        verificaSeg = false;//verifica segunda tentativa recebe falso
                        //imprimir as informações do pacote 
                        System.out.println("\nEmissor: " + super.getNomeEmissor()
                                + "\nEndereco: " + super.getEndEmissor()
                                + "\nDestinatario: " + super.getNomeDestinatario()
                                + "\nEndereco: " + super.getEndDestinatario()
                                + "\nTipo Transporte: " + super.getTipo());
                        //espera para começar a fazer as verificações da proxima thread
                        wait();
                    }else{//caso contrario 
                        //verifica segunda tentativa recebe verdadeiro
                        verificaSeg = true;
                    }
                    //notifica a proxima thread 
                    notify();
                } else{//caso contrario 
                    //verifica segunda tentativa recebe verdadeiro
                    verificaSeg = true;
                }
                //notifica a proxima thread 
                notify();
            } else{//caso contrario 
                //verifica segunda tentativa recebe verdadeiro
                verificaSeg = true;
            }
            //notifica a proxima thread 
            notify();
        } else{//caso contrario 
            //verifica segunda tentativa recebe verdadeiro
            verificaSeg = true;
        }
        //notifica a proxima thread 
        notify();
        //retorna o verifica segunda tentativa
        return verificaSeg;
    }

    @Override
    public void run() {
        cntTentativa = 1;//objeto que irá contar o numero de tentativas
        while(valida!=true) {//enquanto valida for diferente de verdadeiro
            try {
                //chama o método validarInfo para que as informações dos
                //pacotes sejam validadas
                segundaTentiva = validarInfo();
                //segunda tentativa irá receber o retorno da função validarInfo
                cntTentativa++;
                //se segunda tentativa for verdadeiro e o contador de tentativas
                //for igual a 2
                if(segundaTentiva==true && cntTentativa == 2){
                    //vai chamar a função validaInfo para que as informações 
                    //sejam informadas e validadas novamente
                    validarInfo();
                } else{
                    //caso contarrio mostra que o pacote não pode ser enviado
                    System.out.println("Pacote nao pode ser enviado!");
                    break;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } 
        }
        //valida irá receber o retorno da função finalizar 
        //da classe correio
        valida = super.finalizar();
    }
}
