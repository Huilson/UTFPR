/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
class PacoteDestinaInvalido extends Correio{
    //classe que extende de Correio cria um construtor no 
    //contrutor chama os métodos da classe que irá ter os 
    //métodos que irão fazer a validação do pagamento, 
    //endRem, endDest correspondente para este pacote
    public PacoteDestinaInvalido() {
        pagamento = new PagamentoRealizado();
        endRem = new ExisteRemetente();
        endDest = new NaoExisteDestinatario();
        System.out.println("Pacote reprovado, destinatario invalido. Tente envia-lo novamente mais tarde!");
    }
}
