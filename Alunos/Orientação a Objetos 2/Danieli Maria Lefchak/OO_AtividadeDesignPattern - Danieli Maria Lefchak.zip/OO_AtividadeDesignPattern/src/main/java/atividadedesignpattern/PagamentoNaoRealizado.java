/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//Outra classes concreta da estrategia IPagamento que irá
//implementar o método validaPagamento
public class PagamentoNaoRealizado implements IPagamento{
    @Override
    public void validaPagemento(){//implementação do método validaPagamento
        System.out.println("Pagamento ainda não foi realizado");
    }
}
