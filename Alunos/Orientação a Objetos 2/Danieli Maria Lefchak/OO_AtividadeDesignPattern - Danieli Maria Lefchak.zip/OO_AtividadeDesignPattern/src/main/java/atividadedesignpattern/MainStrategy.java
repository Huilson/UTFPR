/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividadedesignpattern;

import java.util.ArrayList;

/**
 *
 * @author danie
 */
public class MainStrategy {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws InterruptedException {
        //cria um novo objeto correio que recebe uma nova aprovação
        //passando por parametro as informações do pacote
        Correio correio = new AprovacaoCorreio("1","PANDA","NINO","hhhhh","mmmm");
        //cria um novo objeto correio que recebe uma nova aprovação
        //passando por parametro as informações do pacote
        correio = new AprovacaoCorreio("2","BRASI","CURTIS","pppp","lllllll");
        //cria um novo objeto correio que recebe uma nova aprovação
        //passando por parametro as informações do pacote
        correio = new AprovacaoCorreio("3","PEQUENA","DUMBO","eeeee","ppppp");
        //irá setar o valor de valida 
        correio.setValida(true);
        //chama o método finalizar
        correio.finalizar();
    }
}
