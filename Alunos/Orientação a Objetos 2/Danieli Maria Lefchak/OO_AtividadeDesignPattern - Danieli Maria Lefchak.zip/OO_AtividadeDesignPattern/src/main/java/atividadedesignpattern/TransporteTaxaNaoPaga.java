/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadedesignpattern;

/**
 *
 * @author danie
 */
//Outra classes concreta da estrategia ITransporte que irá
//implementar o método validaTransporte
public class TransporteTaxaNaoPaga implements ITransporte{
    @Override
    public void validaTransporte() {//implementação do método transporte
        System.out.println("A taixa do transporte não foi paga!");
    }
}
