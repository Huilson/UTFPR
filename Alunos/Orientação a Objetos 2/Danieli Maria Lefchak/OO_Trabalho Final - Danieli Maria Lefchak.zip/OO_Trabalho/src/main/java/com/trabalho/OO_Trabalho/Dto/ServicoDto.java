/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Dto;

import com.trabalho.OO_Trabalho.Model.Servicos;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author danie
 */

@Getter
@Setter
public class ServicoDto implements Serializable{
    private double val;
    private String servPet;
    
    //metodo que converte um dto em servicos
    public Servicos toServico(){
        Servicos servico = new Servicos();
        servico.setVal(val);
        servico.setServPet(servPet);
        
        return servico;
    }
}
