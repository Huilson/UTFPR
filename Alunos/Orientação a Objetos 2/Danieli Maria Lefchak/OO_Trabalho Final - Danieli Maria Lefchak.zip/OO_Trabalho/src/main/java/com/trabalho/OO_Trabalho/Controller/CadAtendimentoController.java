/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Dto.AtendimentoDto;
import com.trabalho.OO_Trabalho.Model.Atendimento;
import com.trabalho.OO_Trabalho.Repository.AtendimentoRepository;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author danie
 */
@Controller
@RequestMapping("/CadastrarAtendimento")
public class CadAtendimentoController {
    @Autowired
    private AtendimentoRepository repository;
    
    //metodo que mostra o fomulario de atendimentos
    @GetMapping("/atendimento")
    public String formulario(AtendimentoDto atend) {
        return "Formularios/FormularioDeCadastroAtendimento";
    }
    
    //metodo responsavel pelos cadastros de novos atendimentos
    @PostMapping("novoAtendimento")
    public String cadastrar(@Valid AtendimentoDto atend, BindingResult result){
        Atendimento at = atend.toAtendimento();
        repository.save(at);
        return "redirect:/CadastrarPessoas/Pessoas";
    }
}
