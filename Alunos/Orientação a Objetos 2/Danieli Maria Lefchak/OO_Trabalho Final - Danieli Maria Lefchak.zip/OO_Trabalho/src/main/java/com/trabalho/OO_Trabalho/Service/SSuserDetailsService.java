/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Service;

import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Model.Role;
import com.trabalho.OO_Trabalho.Repository.PessoaRepository;
import java.util.HashSet;
import java.util.Set;
import javax.transaction.Transactional;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 *
 * @author danie
 */
@Transactional
@Service
public class SSuserDetailsService implements UserDetailsService{
    private PessoaRepository repository;
    
    public SSuserDetailsService(PessoaRepository repository){
        this.repository = repository;
    }
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try{
           Pessoa pessoa = repository.findBynomeTutor(username);
           
           if(pessoa==null){
               return null;
           }
           
           //retorna um novo sercurity.core.userdetails.User que recebe por parametro as 
           //informações que estão dentro do objeto pessoa
           return new org.springframework.security.core.userdetails.User(pessoa.getNomeTutor(), pessoa.getPassword(), getAuthories(pessoa));
        }catch(Exception e){
            throw new UsernameNotFoundException("User not found");
        }
    }
    
    private Set<GrantedAuthority> getAuthories(Pessoa pessoa){
        Set<GrantedAuthority> authorities = new HashSet<>();
        
        for(Role role: pessoa.getRoles()){
            GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(role.getRole());
            authorities.add(grantedAuthority);
        }
        
        return authorities;
    }
    
}
