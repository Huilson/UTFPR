/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Config;

import com.trabalho.OO_Trabalho.Repository.PessoaRepository;
import com.trabalho.OO_Trabalho.Service.SSuserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 *
 * @author danie
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private SSuserDetailsService userDetail;

    @Autowired
    private PessoaRepository repository;
    
    //configura a criptografia da senha
    @Bean
    public static BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    @Override
    public UserDetailsService userDetailsServiceBean() throws Exception {
        return new SSuserDetailsService(repository);
    }
    
    //Configura a autenticação do usuario
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsServiceBean())
                .passwordEncoder(passwordEncoder());
    }

    //Configura as permissões de acesso para cada role
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests()
                .antMatchers("/home/**").hasAnyAuthority("ADMIN", "USER")
                .antMatchers("/CadastraServicos/**").hasAuthority("ADMIN")
                .antMatchers("/CadastrarPessoas/**").hasAuthority("ADMIN")
                .antMatchers("/CadastrarAtendimento/**").hasAuthority("ADMIN")
                .antMatchers("/CadastrarAnimal/**").hasAuthority("ADMIN")
                .antMatchers("/NaoRealizados/**").hasAuthority("ADMIN")
                .antMatchers("/pesquisaNome").hasAnyAuthority("ADMIN", "USER")
                .and()
                .formLogin().loginPage("/login").permitAll()
                .and().logout()
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/login").permitAll()
                .and().httpBasic();

        http.csrf().disable();
        http.headers().frameOptions().disable();
    }
}

