/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Dto;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Model.Atendimento;
import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Model.Servicos;
import lombok.Data;

/**
 *
 * @author danie
 */
@Data
public class AnimalDto {
    private String nome;
    private String especie;
    private Pessoa tutor;
    private Servicos servico;
    private Atendimento atendimento;
    
    //metodo que converte um dto em animal
    public Animal toAnimal(){
        Animal animal = new Animal();
        animal.setNome(nome);
        animal.setEspecie(especie);
        animal.setTutor(tutor);
        animal.setServico(servico);
        animal.setAtendimento(atendimento);
        
        return animal;
    }
}
