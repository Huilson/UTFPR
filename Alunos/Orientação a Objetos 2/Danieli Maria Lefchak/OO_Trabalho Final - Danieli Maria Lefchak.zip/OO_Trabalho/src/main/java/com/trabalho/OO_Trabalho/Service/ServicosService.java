/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Service;

import com.trabalho.OO_Trabalho.Model.Servicos;
import com.trabalho.OO_Trabalho.Repository.ServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author danie
 */
@Service
public class ServicosService {
    @Autowired
    ServicoRepository repository;
    
    public Servicos execute(Servicos servico){
        Servicos serv = repository.findByservPet(servico.getServPet());
        return serv;
    }
}
