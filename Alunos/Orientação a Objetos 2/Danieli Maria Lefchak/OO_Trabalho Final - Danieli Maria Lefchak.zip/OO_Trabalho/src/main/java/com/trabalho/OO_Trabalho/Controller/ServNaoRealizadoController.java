/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Repository.AnimaisRepository;
import com.trabalho.OO_Trabalho.Service.AnimalService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author danie
 */
@Controller
@RequestMapping("/NaoRealizados")
public class ServNaoRealizadoController {
    @Autowired
    private AnimaisRepository repository;
    
    @Autowired
    private AnimalService service;
    
    //metodo responsavel por mostrar os servicos ainda não realizados 
    //na pagina de servicos ainda não realizados 
    @GetMapping("/servicoNaoRealizado")
    public String servicoNaoRealizado(Model model) {
        List<Animal> animal = service.getData();
        model.addAttribute("animais", animal);
        
        return "servicosAindaNaoRealizados";
    }
}
