/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.trabalho.OO_Trabalho.Repository;

import com.trabalho.OO_Trabalho.Model.Atendimento;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author danie
 */
public interface AtendimentoRepository extends JpaRepository<Atendimento, Long>{
    
}
