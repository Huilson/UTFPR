package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Model.Role;
import com.trabalho.OO_Trabalho.Repository.AnimaisRepository;
import com.trabalho.OO_Trabalho.Repository.PessoaRepository;
import com.trabalho.OO_Trabalho.Repository.RoleRepository;
import com.trabalho.OO_Trabalho.Service.AnimalService;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/home")
public class HomeController {

    @Autowired
    private AnimaisRepository repository;

    @Autowired
    private PessoaRepository pesRep;

    @Autowired
    RoleRepository roleRep;

    @Autowired
    private AnimalService service;

    //metodo responsavel por mostrar todos os animais cadastrados na home
    @GetMapping
    public String home(Model model) {
        Role role = roleRep.findByrole("USER");

        List<Animal> animais = new ArrayList<>();
        //para encontrar o usuario que está logado no momentoo
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        //para filtrar as informações mostradas para cada usuario
        if (principal instanceof UserDetails) {
            String username = ((UserDetails) principal).getUsername();
            //o tutor pelo nime do usuario que esta logado
            Pessoa pess = pesRep.findBynomeTutor(username);
            //System.out.println("PES HOME: " + pess.getIdPes());
             //encontra os animais pelo nome do tutor e adciona eles a lista
            animais = repository.findBytutor(pess);
            //System.out.println("ANIMAIS LIST: " + animais);
            
            //para conferir se o usuario que não tem animais
            //é um usuario ou administrador
            if (animais.isEmpty()) {
                Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                if (auth != null && auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ADMIN"))) {
                    //se for um administrador ele porderá ver todas as informações
                       animais = repository.findAll();
                }
            }
        } else {
            String username = principal.toString();

            Pessoa pess = pesRep.findBynomeTutor(username);

            animais = repository.findBytutor(pess);
        }
        //mostra as informações para os usuarios
        model.addAttribute("animais", animais);
        return "/home";
    }

    //metodo responsavel pro slavar um animal
    @PostMapping("salvar")
    public String salvar(@ModelAttribute("animal") Animal animal) {
        repository.save(animal);
        return "redirect:/home";
    }

    //metodo responsavel por atualizar o registro de um animal
    @GetMapping("/formularioAtualizado/{idAni}")
    public String formularioAtualizado(@PathVariable(value = "idAni") Long id, Model model) {
        Animal animal = service.getAnimalById(id);
        model.addAttribute("animal", animal);
        return "formulario_atualiza";
    }

    //metodo responsavel por excluir um animal
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable(value = "id") Long id) {
        service.deletePedidoById(id);
        return "redirect:/home";
    }

    //metodo que ira pegar o nome digitado no campo da pesquisa
    @GetMapping("/pesquisaNome")
    public String pesquisaNome() {
        return "pesquisaNome";
    }

    //metodo que irá retornar um nome pesquisado na url
    @GetMapping("/findName/{name}")
    public ResponseEntity<Animal> findByName(@PathVariable String name) {
        return ResponseEntity.ok(service.findByname(name));
    }

    //metodo que ira buscar o nome digitado no metodo "pesquisaNome"
    @PostMapping("pesquisaCompleta")
    public String pesquisar(@RequestParam(value = "campoPesquisa") String campoPesquisa, Model model) {
       Role role = roleRep.findByrole("USER");
       String nm = campoPesquisa;
        List<Animal> animais = new ArrayList<>();
        //para encontrar o usuario que está logado no momentoo
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        //para filtrar as informações mostradas para cada usuario
        if (principal instanceof UserDetails) {
            String username = ((UserDetails) principal).getUsername();
            //encontra o tutor pelo nome do usuario que esta logado
            Pessoa pess = pesRep.findBynomeTutor(username);
            //encontra os animais pelo nome do tutor e adciona eles a lista
            animais = repository.findBytutor(pess);
            
            //para conferir se o usuario que não tem animais
            //é um usuario ou administrador
            if (animais.isEmpty()) {
                Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                if (auth != null && auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ADMIN"))) {
                    //se for um administrador ele porderá ver todas as informações
                    animais.add(repository.findBynome(campoPesquisa));
                }
            }
        } else {
            String username = principal.toString();

            Pessoa pess = pesRep.findBynomeTutor(username);

            animais = repository.findBytutor(pess);
        }
        //mostra as informações para os usuarios
        model.addAttribute("animais", animais);
        return "/home";
    }

    //metodo que irá retornar um id pesquisado na url
    @GetMapping("{id}")
    public String buscar(@PathVariable("id") Long id, Model model) {
        Animal animal = repository.findById(id).orElseThrow();
        model.addAttribute("animal", animal);
        return "home";
    }

    //metodo reponsave por mostrar a lista de servicos nao realizados
    @GetMapping("servicosAindaNaoRealizados")
    public String listaAtendimentos(Model model) {
        List<Animal> animais = repository.findAll();
        model.addAttribute("animais", animais);
        return "/servicosAindaNaoRealizados";
    }
}
