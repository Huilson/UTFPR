/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Dto.ServicoDto;
import com.trabalho.OO_Trabalho.Model.Servicos;
import com.trabalho.OO_Trabalho.Repository.ServicoRepository;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author danie
 */
@Controller
@RequestMapping("/CadastraServicos")
public class CadServicosController {
    @Autowired
    private ServicoRepository repository;
    
    //metodo que mostra o fomulario de servicos
    @GetMapping("/Servicos")
    public String formulario(ServicoDto servico) {
        return "Formularios/FormularioDeCadastroServicos";
    }
    
    //metodo responsavel por reslizar um cadastro de um servoico
    @PostMapping("novoServico")
    public String cadastrar(@Valid ServicoDto servico, BindingResult result){
        Servicos serv = servico.toServico();
        
        if(repository.findByservPet(serv.getServPet()) == null){
            System.out.println("CadSERV: " + serv.toString());
            repository.save(serv);
        }
        
        return "redirect:/CadastrarAtendimento/atendimento";
    }
}
