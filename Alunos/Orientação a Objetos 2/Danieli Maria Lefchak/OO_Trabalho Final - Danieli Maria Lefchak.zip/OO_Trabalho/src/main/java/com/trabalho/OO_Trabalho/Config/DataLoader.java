/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Config;

import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Model.Role;
import com.trabalho.OO_Trabalho.Repository.PessoaRepository;
import com.trabalho.OO_Trabalho.Repository.RoleRepository;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 *
 * @author danie
 */
@Component
public class DataLoader implements CommandLineRunner{
    @Autowired
    PessoaRepository repository;
    
    @Autowired
    RoleRepository roleRep;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    
    //metodo responsavel pelos cadastros das roles
    @Override
    public void run(String... args) throws Exception {
        //para ver se a role já existe antes de cadastra-la
        Role findRoleAdm = roleRep.findByrole("ADMIN");
        Role findRoleUser = roleRep.findByrole("USER");
        
        //se ela não existir irá cadastrar
        if(findRoleAdm == null){
            roleRep.save(new Role("ADMIN"));
        }
        
        if(findRoleUser == null){
            roleRep.save(new Role("USER"));
            //Luciana 9876, Thiago 4321, Joana 1234
        }
        
        //encontra a role admin
        Role adminRole = roleRep.findByrole("ADMIN");
        
        //cria um usuario pessoa que será o admin
        Pessoa pessoa = new Pessoa(1L,"dani", "02020002", passwordEncoder.encode("123"));
        //seta a role no usuario criado
        pessoa.setRoles(Arrays.asList(adminRole));
        //salva o usuario
        repository.save(pessoa);
    }
    
}
