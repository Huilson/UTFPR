/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Controller;

import com.trabalho.OO_Trabalho.Model.Animal;
import com.trabalho.OO_Trabalho.Service.AnimalService;
import com.trabalho.OO_Trabalho.Service.ReportService;
import java.io.FileNotFoundException;
import java.util.List;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author danie
 */
@RestController
public class ReportController {
    //criamos com o AutoWired uma injeção de dependencia
    //essa anotação indica um ponto onde a injeção automatica deve ser aplicado
    @Autowired
    private AnimalService service;
    
    @Autowired
    private ReportService geradorRelatorio;
    
    //cria um "mapa" para que o nosso navegador possa acessar tais diretorios
    @GetMapping("/getAnimal")
    public List<Animal> getAnimal(){
        List<Animal> animal = service.getData();
        return animal;
    }
    
    //passa-se via url o valor da variavel format para o metodo de exportação de relatorio
    @GetMapping("/report")//PathVariable faz com que a variavel seja considerada como um caminho
    public String generatedReport() throws FileNotFoundException, JRException{
        return geradorRelatorio.exportReport();
    }
}
