/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.trabalho.OO_Trabalho.Dto;

import com.trabalho.OO_Trabalho.Model.Atendimento;
import java.time.LocalDate;
import java.time.LocalTime;
import lombok.Data;

/**
 *
 * @author danie
 */
@Data
public class AtendimentoDto {
    private LocalDate dt;
    private LocalTime hora;
    
    //metodo que converte um dto em atendimento
    public Atendimento toAtendimento(){
        Atendimento atendimento = new Atendimento();
        atendimento.setDt(dt);
        atendimento.setHora(hora);
        
        return atendimento;
    }
}
