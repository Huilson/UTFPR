/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.trabalho.OO_Trabalho.Repository;

import com.trabalho.OO_Trabalho.Model.Pessoa;
import com.trabalho.OO_Trabalho.Model.Role;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author danie
 */
public interface PessoaRepository extends JpaRepository<Pessoa, Long>{
      Pessoa findBynomeTutor(String nomeTutor);
      Collection<Role> findByroles(Role role);
}
