/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author danie
 */
@Entity
@Table(name="animal")
public class Animal implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private int idAni;
    private String nome;
    private String especie;
    @ManyToOne
    private Pessoa tutor;
    @ManyToOne
    private Servicos servico;
    
    //construtor vazio
    public Animal() {
    }
    
    //construtor que ira receber por parametro o nome, especie, tutor e o servico

    public Animal(String nome, String especie, Pessoa tutor, Servicos servico) {
        this.nome = nome;
        this.especie = especie;
        this.tutor = tutor;
        this.servico = servico;
    }

    public int getIdAni() {
        return idAni;
    }

    public void setIdAni(int idAni) {
        this.idAni = idAni;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public Pessoa getTutor() {
        return tutor;
    }

    public void setTutor(Pessoa tutor) {
        this.tutor = tutor;
    }

    public Servicos getServico() {
        return servico;
    }

    public void setServico(Servicos servico) {
        this.servico = servico;
    }

    @Override
    public String toString() {
        return idAni + " Nome do animal: " + nome + ", especie: " + especie + tutor + servico;
    }
}
