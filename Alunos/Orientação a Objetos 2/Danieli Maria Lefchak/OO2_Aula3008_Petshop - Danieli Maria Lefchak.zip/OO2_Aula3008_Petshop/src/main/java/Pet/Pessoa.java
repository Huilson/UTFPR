/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 *
 * @author danie
 */
@Entity
@Table(name="pessoa")
public class Pessoa implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private int idPes;
    private String nomeTutor;
    @Column(name="telefone")
    private String tel;

    public Pessoa() {
    }

    public Pessoa(String nomeTutor, String tel) {
        this.nomeTutor = nomeTutor;
        this.tel = tel;
    }

    public int getIdPes() {
        return idPes;
    }

    public void setIdPes(int idPes) {
        this.idPes = idPes;
    }

    public String getNomeTutor() {
        return nomeTutor;
    }

    public void setNomeTutor(String nomeTutor) {
        this.nomeTutor = nomeTutor;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
    
    @Override
    public String toString() {
        return "; Nome do Tutor: " + nomeTutor + ", tel: " + tel;
    }
}
