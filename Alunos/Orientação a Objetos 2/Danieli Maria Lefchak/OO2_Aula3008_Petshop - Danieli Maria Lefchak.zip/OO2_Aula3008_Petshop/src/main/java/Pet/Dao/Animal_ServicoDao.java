/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet.Dao;

import Pet.Animal_Servico;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author danie
 */
public class Animal_ServicoDao {
    private EntityManager em;

    public Animal_ServicoDao(EntityManager em) {
        this.em = em;
    }
    
    //CREATE TABLE & INSERT
    public void cadastrar(Animal_Servico aniServ){
        this.em.persist(aniServ);
    }
    
    //UPDATE
    public void atualizar(Animal_Servico aniServ){
        this.em.merge(aniServ);
    }
    
    //REMOVE
    public void remover(Animal_Servico aniServ){
        aniServ = em.merge(aniServ);
        this.em.remove(aniServ);
    }
    
    //SELECT
    public Animal_Servico buscarPorId(int id){
        return em.find(Animal_Servico.class, id);
    }
    
    //SELECT *
    public List<Animal_Servico> buscarTodos(){
        String jpql = "SELECT a FROM Animal_Servico a";
        return em.createQuery(jpql, Animal_Servico.class).getResultList();
    }
    
    //SELECT FILTER ID
    public int buscarPorIds(int idA, int idS){
        String jpql = "SELECT idAS, a, s FROM Animal_Servico idAS, Animal a, Servicos s WHERE a.idAni = ?1 AND s.idServ = ?2";
        return em.createQuery(jpql, Animal_Servico.class).setParameter(1, idA).setParameter(2, idS).getFirstResult();
    }
}
