/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet.Dao;

import Pet.Pessoa;
import javax.persistence.EntityManager;

/**
 *
 * @author danie
 */
public class PessoaDao {
    private EntityManager em;
    
    public PessoaDao(EntityManager em){
        this.em = em;
    }
    
    //CREATE TABLE
    public void cadastrar(Pessoa pessoa){
        this.em.persist(pessoa);
    }
    
    //UPDATE
    public void atualizar(Pessoa pessoa){
        this.em.merge(pessoa);
    }
    
    //REMOVE
    public void remover(Pessoa pessoa){
        pessoa = em.merge(pessoa);
        this.em.remove(pessoa);
    }
    
    //SELECT
    public Pessoa buscarPorId(int id){
        return em.find(Pessoa.class, id);
    }
}
