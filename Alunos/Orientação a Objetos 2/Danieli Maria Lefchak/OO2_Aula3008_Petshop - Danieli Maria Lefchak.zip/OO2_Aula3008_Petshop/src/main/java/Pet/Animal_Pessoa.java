/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author danie
 */
@Entity
@Table(name="animal_Pessoa")
public class Animal_Pessoa implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private int idAP;
    @ManyToOne
    private Animal idAniPes;
    @ManyToOne
    private Pessoa idPesAni;

    public Animal_Pessoa() {
    }

    public Animal_Pessoa(Animal idAniPes, Pessoa idPesAni) {
        this.idAniPes = idAniPes;
        this.idPesAni = idPesAni;
    }

    public int getIdAP() {
        return idAP;
    }

    public void setIdAP(int idAP) {
        this.idAP = idAP;
    }

    public Animal getIdAniPes() {
        return idAniPes;
    }

    public void setIdAniPes(Animal idAniPes) {
        this.idAniPes = idAniPes;
    }

    public Pessoa getIdPesAni() {
        return idPesAni;
    }

    public void setIdPesAni(Pessoa idPesAni) {
        this.idPesAni = idPesAni;
    }

    @Override
    public String toString() {
        return "Animal_Pessoa: " + "idAP=" + idAP + ", idAniPes=" + idAniPes + ", idPesAni=" + idPesAni + "\n";
    }
}
