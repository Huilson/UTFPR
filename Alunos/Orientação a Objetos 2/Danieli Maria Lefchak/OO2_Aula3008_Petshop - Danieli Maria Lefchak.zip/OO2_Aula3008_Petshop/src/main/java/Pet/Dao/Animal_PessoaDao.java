/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet.Dao;

import Pet.Animal_Pessoa;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author danie
 */
public class Animal_PessoaDao {
    private EntityManager em;

    public Animal_PessoaDao(EntityManager em) {
        this.em = em;
    }
    
    //CREATE TABLE & INSERT
    public void cadastrar(Animal_Pessoa aniPes){
        this.em.persist(aniPes);
    }
    
    //UPDATE
    public void atualizar(Animal_Pessoa aniPes){
        this.em.merge(aniPes);
    }
    
    //REMOVE
    public void remover(Animal_Pessoa aniPes){
        aniPes = em.merge(aniPes);
        this.em.remove(aniPes);
    }
    
    //SELECT
    public Animal_Pessoa buscarPorId(int id){
        return em.find(Animal_Pessoa.class, id);
    }
    
    //SELECT * 
    public List<Animal_Pessoa> buscarTodos(){
        String jpql = "SELECT a FROM Animal_Pessoa a";
        return em.createQuery(jpql, Animal_Pessoa.class).getResultList();
    }
    
    //SELECT FILTER ID
    public int buscarPorIds(int idA, int idP){
        String jpql = "SELECT idAP, a ,p FROM Animal_Pessoa idAP, Animal a, Pessoa p WHERE a.idAni = ?1 AND p.idPes = ?2";
        return em.createQuery(jpql, Animal_Pessoa.class).setParameter(1, idA).setParameter(2, idP).getFirstResult();
    }
}
