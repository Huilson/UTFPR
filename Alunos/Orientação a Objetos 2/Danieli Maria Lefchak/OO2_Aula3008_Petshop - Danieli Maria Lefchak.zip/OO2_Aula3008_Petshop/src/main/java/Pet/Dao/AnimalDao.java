/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet.Dao;

import Pet.Animal;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author danie
 */
public class AnimalDao {
    private EntityManager em;
    
    public AnimalDao(EntityManager em){
        this.em = em;
    }
    
    //CREATE TABLE & INSERT
    public void cadastrar(Animal animal){
        this.em.persist(animal);
    }
    
    //UPDATE
    public void atualizar(Animal animal){
        this.em.merge(animal);
    }
    
    //REMOVE
    public void remover(Animal animal){
        animal = em.merge(animal);
        this.em.remove(animal);
    }
    
    //SELECT
    public Animal buscarPorId(int id){
        return em.find(Animal.class, id);
    }
    
    //SELECT * 
    public List<Animal> buscarTodos(){
        String jpql = "SELECT a FROM Animal a";
        return em.createQuery(jpql, Animal.class).getResultList();
    }
    
    //SELECT FILTER
    public List<Animal> buscarPorNome(String nome){
        String jpql = "SELECT a FROM Animal a WHERE a.nome = ?1";
        return em.createQuery(jpql, Animal.class).setParameter(1, nome).getResultList();
    }
}
