/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet.Dao;

import Pet.Servicos;
import javax.persistence.EntityManager;

/**
 *
 * @author danie
 */
public class ServicosDao {
    private EntityManager em;
    
    public ServicosDao(EntityManager em){
        this.em = em;
    }
    
    //CREATE TABLE
    public void cadastrar(Servicos servicos){
        this.em.persist(servicos);
    }
    
    //UPDATE
    public void atualizar(Servicos servicos){
        this.em.merge(servicos);
    }
    
    //REMOVE
    public void remover(Servicos servicos){
        servicos = em.merge(servicos);
        this.em.remove(servicos);
    }
    
    //SELECT
    public Servicos buscarPorId(int id){
        return em.find(Servicos.class, id);
    }
}
