/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pet;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author danie
 */
@Entity
@Table(name="animal_Servico")
public class Animal_Servico implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private int idAS;
    @ManyToOne
    private Animal idAniServ;
    @ManyToOne
    private Servicos idServAni;

    public Animal_Servico() {
    }

    public Animal_Servico(Animal idAniServ, Servicos idServAni) {
        this.idAniServ = idAniServ;
        this.idServAni = idServAni;
    }

    public int getIdAS() {
        return idAS;
    }

    public void setIdAS(int idAS) {
        this.idAS = idAS;
    }

    public Animal getIdAniServ() {
        return idAniServ;
    }

    public void setIdAniServ(Animal idAniServ) {
        this.idAniServ = idAniServ;
    }

    public Servicos getIdServAni() {
        return idServAni;
    }

    public void setIdServAni(Servicos idServAni) {
        this.idServAni = idServAni;
    }

    @Override
    public String toString() {
        return "Animal_Servico: " + "idAS=" + idAS + ", idAniServ=" + idAniServ + ", idServAni=" + idServAni + "\n";
    }
}
