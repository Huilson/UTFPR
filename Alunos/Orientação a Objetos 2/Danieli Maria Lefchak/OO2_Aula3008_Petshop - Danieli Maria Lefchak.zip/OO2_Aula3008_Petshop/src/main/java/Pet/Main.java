/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pet;

import Pet.Dao.AnimalDao;
import Pet.Dao.Animal_PessoaDao;
import Pet.Dao.Animal_ServicoDao;
import Pet.Dao.PessoaDao;
import Pet.Dao.ServicosDao;
import PetUtil.EntityManagerJPA;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public Main() throws SQLException, ClassNotFoundException {
        //Connection conn = ConnectionFactory.recuperaConexao();//metodo que faz a conexao com o banco de dados
        Animal animal;
        String nome;
        String especie;
        Pessoa tutor;        
        Servicos servico;
        Animal_Pessoa aniPes;
        Animal_Servico aniServ;
        LocalTime hora = null;
        LocalDate data = null;
        double val;
        String servPet;
        String tutorNome;
        String tel;
        int num = 0;    
        
        EntityManager em = EntityManagerJPA.getEntityManager();
        AnimalDao animalDao = new AnimalDao(em);
        PessoaDao pesDao = new PessoaDao(em);
        ServicosDao serDao = new ServicosDao(em);
        Animal_PessoaDao aniPesDao = new Animal_PessoaDao(em);
        Animal_ServicoDao aniServDao = new Animal_ServicoDao(em);
        
        em.getTransaction().begin();       
        
        //enquanto for diferente de 1 continuará fazendo o cadastro de animais e seus atendimentos, ou realizar consultas nos atendimentos que ainda não foram realizados
        while (num != 1) {
            int opc = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a opcao desejada:\n 1- Cadastrar,\n 2- Consultar,\n 3- Deletar,\n 4- Atualizar;",
                    "Opcoes", JOptionPane.INFORMATION_MESSAGE));//variavel que irá receber a opcao informada pelo usuario
            
            switch(opc){
                case 1:
                    nome = JOptionPane.showInputDialog(null, "Informe o nome do animal: ", "nome animal", JOptionPane.QUESTION_MESSAGE);
                    especie = JOptionPane.showInputDialog(null, "Informe a especie animal: ", "especie animal", JOptionPane.QUESTION_MESSAGE);
                    DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
                    hora = LocalTime.parse(JOptionPane.showInputDialog(null, "Informe o horario do atendimaneto (hh:mm): ", "Horario atendimento", JOptionPane.QUESTION_MESSAGE));
                    hora.format(timeFormat);//formata o horario
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    data = LocalDate.parse(JOptionPane.showInputDialog(null, "Informe a data de atendimento (aaaa-mm-dd): ", "Data atendimento", JOptionPane.QUESTION_MESSAGE));
                    data.format(dateFormat);//formata a data
                    val = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor R$: ", "Valor", JOptionPane.QUESTION_MESSAGE));

                    //se a especie do animal informado for passaro ira mostrar somente as opções vacinar e poda de asas
                    if ("passaro".equals(especie) || "Passaro".equals(especie) || "pássaro".equals(especie) || "Pássaro".equals(especie)) {
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Poda de asas;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    } else {//caso contrario ira mostrar todas as outras opções menos a opção de poda de asas 
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Banho \n Tosa, \n Tosa Higenica, \n"
                                + "Castrar;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    }

                    tutorNome = JOptionPane.showInputDialog(null, "Informe o nome do tutor: ", "nome tutor", JOptionPane.QUESTION_MESSAGE);
                    tel = JOptionPane.showInputDialog(null, "Informe o telefone do tutor: ", "Telefone tutor", JOptionPane.QUESTION_MESSAGE);

                    tutor = new Pessoa(tutorNome, tel);//insere as informacoes em uma nova pessoa
                    servico = new Servicos(data, hora, val, servPet);//insere as informacoes em um novo servico
                    animal = new Animal(nome, especie, tutor, servico);//insere as informacoes em um novo anomal
                    aniPes = new Animal_Pessoa(animal, tutor);
                    aniServ = new Animal_Servico(animal, servico);
                    
                    pesDao.cadastrar(tutor);
                    serDao.cadastrar(servico);
                    animalDao.cadastrar(animal);
                    aniPesDao.cadastrar(aniPes);
                    aniServDao.cadastrar(aniServ);
                    
                    //em.getTransaction().commit();
                    em.flush();
                    break;
                    
                case 2:
                    System.out.println(animalDao.buscarTodos());
                    em.flush();
                    
                    break;
                case 3:
                    System.out.println(aniPesDao.buscarTodos());
                    System.out.println(aniServDao.buscarTodos());
                    int idaniPes = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o id do dono do animal que deseja excluir: ", "Id animal", JOptionPane.QUESTION_MESSAGE));
                    int idaniServ = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o id do servico do animal que deseja excluir: ", "Id animal", JOptionPane.QUESTION_MESSAGE));
                    int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o id do animal que deseja excluir: ", "Id animal", JOptionPane.QUESTION_MESSAGE));
                    animal = animalDao.buscarPorId(id);
//                    JOptionPane.showMessageDialog(null, aniPesDao.buscarPorIds(animal.getIdAni(), animal.getTutor().getIdPes()));
//                    JOptionPane.showMessageDialog(null, aniPesDao.buscarPorIds(animal.getIdAni(), animal.getServico().getIdServ()));
                    tutor = pesDao.buscarPorId(animal.getTutor().getIdPes());
                    servico = serDao.buscarPorId(animal.getServico().getIdServ());
                    aniPes = aniPesDao.buscarPorId(idaniPes);
                    aniServ = aniServDao.buscarPorId(idaniServ);
                    
                    aniPesDao.remover(aniPes);
                    aniServDao.remover(aniServ);
                    animalDao.remover(animal);//metodo que deleta um cadastro de um animal pelo id
                    pesDao.remover(tutor);
                    serDao.remover(servico);
                    
                    em.flush();
                    break;
                case 4:
                    id = Integer.parseInt(JOptionPane.showInputDialog(null, "Sera possivel atualizar o serviço atribuido ao animal\nInforme o id do animal que deseja atualizar o serviço: ", "Id animal", JOptionPane.QUESTION_MESSAGE));
                    animal = animalDao.buscarPorId(id);
                    servico = serDao.buscarPorId(animal.getServico().getIdServ());
                    
                    timeFormat = DateTimeFormatter.ofPattern("HH:mm");
                    hora = LocalTime.parse(JOptionPane.showInputDialog(null, "Informe o horario (hh:mm): ", "Horario atendimento", JOptionPane.QUESTION_MESSAGE));
                    hora.format(timeFormat);//formata o horario
                    dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    data = LocalDate.parse(JOptionPane.showInputDialog(null, "Informe a data (aaaa-mm-dd): ", "Data atendimento", JOptionPane.QUESTION_MESSAGE));
                    data.format(dateFormat);//formata a data
                    val = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor R$: ", "Valor", JOptionPane.QUESTION_MESSAGE));

                    //se a especie do animal informado for passaro ira mostrar somente as opções vacinar e poda de asas
                    if ("passaro".equals(animal.getEspecie()) || "Passaro".equals(animal.getEspecie()) || "pássaro".equals(animal.getEspecie()) || "Pássaro".equals(animal.getEspecie())) {
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Poda de asas;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    } else {//caso contrario ira mostrar todas as outras opções menos a opção de poda de asas 
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Banho \n Tosa, \n Tosa Higenica, \n"
                                + "Castrar;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    }

                    servico.setData(data);
                    servico.setHora(hora);
                    servico.setVal(val);
                    servico.setServPet(servPet);
                    serDao.atualizar(servico);//função que irá atualizar o serviço que será realizado
                    
                    em.flush();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Está opcao nao existe! Informe uma opcao valida.\n", "Opcao invalida", JOptionPane.WARNING_MESSAGE);
                    //se o usuario informar uma opcao invalida irá aparecer está mensagem para ele
                    break;
            }
            
            num = Integer.parseInt(JOptionPane.showInputDialog(null, "Para seguir fazendo operações digite qualquer outro número\n" +
                    "Para sair digite 1\n", "Sair", JOptionPane.INFORMATION_MESSAGE));
            //a opção para sair do looping apos ter terminado o cadastro de animais
        }
        
        em.getTransaction().commit();//insere as informacoes nas tabelas
        em.close();
    }
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // TODO code application logic here
         new Main();
    }
    
}
