/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oo.atividade.petshop;

import java.math.BigInteger;

/**
 *
 * @author danie
 */
public class Pessoa {

    private String nomeTutor;
    private String tel;

    public Pessoa() {
    }

    public Pessoa(String nomeTutor, String tel) {
        this.nomeTutor = nomeTutor;
        this.tel = tel;
    }

    public String getNomeTutor() {
        return nomeTutor;
    }

    public void setNomeTutor(String nomeTutor) {
        this.nomeTutor = nomeTutor;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    @Override
    public String toString() {
        return "; Nome do Tutor: " + nomeTutor + ", tel: " + tel;
    }
}
