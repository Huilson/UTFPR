/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oo.atividade.petshop;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author danie
 */
public class Servicos {
    private LocalDate data;
    private LocalTime hora;
    private double val;
    private String servPet;

    public Servicos() {
    }

    public Servicos(LocalDate data, LocalTime hora, double val, String servPet) {
        this.data = data;
        this.hora = hora;
        this.val = val;
        this.servPet = servPet;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public double getVal() {
        return val;
    }

    public void setVal(double val) {
        this.val = val;
    }

    public String getServPet() {
        return servPet;
    }

    public void setServPet(String servPet) {
        this.servPet = servPet;
    }

    @Override
    public String toString() {
        return "; Servico: " + servPet + "data: " + data + ", hora: " + hora + ", valor: " + val;
    }
}
