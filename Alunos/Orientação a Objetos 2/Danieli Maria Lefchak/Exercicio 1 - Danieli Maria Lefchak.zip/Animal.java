/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oo.atividade.petshop;

/**
 *
 * @author danie
 */
public class Animal {
    private int idAni;
    private String nome;
    private String especie;
    private Pessoa tutor;
    private Servicos servico;

    //construtor vazio
    public Animal() {
    }
    
    //construtor que ira receber por parametro o nome, especie, tutor e o servico

    public Animal(String nome, String especie, Pessoa tutor, Servicos servico) {
        this.nome = nome;
        this.especie = especie;
        this.tutor = tutor;
        this.servico = servico;
    }

    public int getIdAni() {
        return idAni;
    }

    public void setIdAni(int idAni) {
        this.idAni = idAni;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public Pessoa getTutor() {
        return tutor;
    }

    public void setTutor(Pessoa tutor) {
        this.tutor = tutor;
    }

    public Servicos getServico() {
        return servico;
    }

    public void setServico(Servicos servico) {
        this.servico = servico;
    }

    @Override
    public String toString() {
        return "Nome do animal: " + nome + ", especie: " + especie + tutor + servico;
    }
}
