/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oo.atividade.petshop;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class Crud {
    private PreparedStatement pstm;
    private ResultSet rs;
    
    //metodo que irá criar as tabelas no banco de dados
    void criaTabela() throws SQLException{
        try(Connection conn = ConnectionFactory.recuperaConexao()){
            String tb1 = 
                "CREATE TABLE IF NOT EXISTS pessoa(" +
                "nomeTutor varchar(250) PRIMARY KEY, " +
                "telefone varchar(11));";
            pstm = conn.prepareStatement(tb1);
            pstm.execute();
            //cria a primeira tabela
            //rs = pstm.getGeneratedKeys();
            
            String tb2 = 
                "CREATE TABLE IF NOT EXISTS servico(" +
                "servPet varchar(150) PRIMARY KEY, " +
                "data date, " +
                "hora time, " +
                "val decimal(10,1));";
            pstm = conn.prepareStatement(tb2);
            pstm.execute();
            //cria a segunda tabela
            //rs = pstm.getGeneratedKeys();
            
            String tb3 = 
                "CREATE TABLE IF NOT EXISTS animal(" +
                "nome varchar(150) PRIMARY KEY, " +
                "especie varchar(100), " +
                "nmTutor varchar(250), " +
                "serv varchar(150), " + 
                "CONSTRAINT fkNomeTutor FOREIGN KEY (nmTutor) REFERENCES pessoa(nomeTutor), " + 
                "CONSTRAINT fkServico FOREIGN KEY (serv) REFERENCES servico(servPet));";
            pstm = conn.prepareStatement(tb3);
            pstm.execute();
            //cria a terceira tabela
            //rs = pstm.getGeneratedKeys();
            //tarefa fazer o insert, consultar, deletar
            
        }   
    }
    
    //metodo que recebe por parametro uma pessoa, um servico e um animal para que possa inserir os dados nas tabelas do banco de dados
    public boolean insert(Pessoa pes, Servicos servc, Animal ani){
        try(Connection conn = ConnectionFactory.recuperaConexao()) {
            String nome = ani.getTutor().getNomeTutor();
            String servNm = ani.getServico().getServPet();
            String nomeComp = findByNamePessoa(ani.getTutor().getNomeTutor()).getNomeTutor();
            String servComp = findByNameServico(ani.getServico().getServPet()).getServPet();
            
            //faz uma validação para ver se já foi inserido algum serviço ou nome de tutor
            //se ja foi inserido ele irá pegar os dados diretos do parametro e inserir somente um novo 
            //registro na tabela de animais
            if ((nome.equals(nomeComp) || servNm.equals(servComp))||(nome.equals(nomeComp) && servNm.equals(servComp))) {
                rs = pstm.getGeneratedKeys();
                
                pstm = conn.prepareStatement("INSERT INTO animal(nome, especie, nmTutor, serv) VALUES (?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS);
                pstm.setString(1, ani.getNome());//insere o nome do animal que foi informado na main
                pstm.setString(2, ani.getEspecie());//insere a especie do animal que foi informado na main
                pstm.setString(3, ani.getTutor().getNomeTutor());//insere o nome do tutor que foi informado na main
                pstm.setString(4, ani.getServico().getServPet());//insere o servico escolhido que foi informado na main
                pstm.executeUpdate();
                //executa o insert na tabela animal que irá colocar as informações no banco de dados
                rs = pstm.getGeneratedKeys();
                conn.close();
            } else {
                //caso não tenha um dono ou serviço ensirido ainda ele ira fazer o insert nas tabelas servico e pessoa 
                //dos dados que ainda não foram cadastrado
                pstm = conn.prepareStatement("INSERT INTO pessoa(nomeTutor, telefone) VALUES (?, ?)",
                        Statement.RETURN_GENERATED_KEYS);
                pstm.setString(1, pes.getNomeTutor());//insere o nome do tutor que foi informado na main
                pstm.setString(2, pes.getTel());//insere o telefone que foi informado na main
                pstm.executeUpdate();
                //executa o insert na tabela pessoa que irá colocar as informações no banco de dados
                rs = pstm.getGeneratedKeys();
                
                pstm = conn.prepareStatement("INSERT INTO servico(servPet, data, hora, val) VALUES (?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS);
                pstm.setString(1, servc.getServPet());//insere o servico que foi informado na main
                pstm.setDate(2, Date.valueOf(servc.getData()));//insere a data que foi informado na main
                pstm.setTime(3, Time.valueOf(servc.getHora()));//insere o horario que foi informado na main
                pstm.setDouble(4, servc.getVal());//insere o valor que foi informado na main
                pstm.executeUpdate();
                //executa o insert na tabela servico que irá colocar as informações no banco de dados
                
                pstm = conn.prepareStatement("INSERT INTO animal(nome, especie, nmTutor, serv) VALUES (?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS);
                pstm.setString(1, ani.getNome());//insere o nome do animal que foi informado na main
                pstm.setString(2, ani.getEspecie());//insere a especie do animal que foi informado na main
                pstm.setString(3, ani.getTutor().getNomeTutor());//insere o nome do tutor que foi informado na main
                pstm.setString(4, ani.getServico().getServPet());//insere o servico escolhido que foi informado na main
                pstm.executeUpdate();
                //executa o insert na tabela animal que irá colocar as informações no banco de dados
                rs = pstm.getGeneratedKeys();
                conn.close();
            }
            
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir dados " + ex.getMessage());
            
            return false;
        } 
    }
    
    //metodo que recebe por parametro uma palavra chave que será o nome do animal para que possa deletar os dados
    public boolean delete(String chave) {
        try(Connection conn = ConnectionFactory.recuperaConexao()) {
            //comando que irá receber a palavra chave e apagar os dados
            pstm = conn.prepareStatement("DELETE FROM animal WHERE nome = ? ");
            pstm.setString(1, chave);
            pstm.executeUpdate();
            conn.close();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar animal " + ex.getMessage());
            
            return false;
        } 
    }
    
    //metodo que recebe por parametro uma data para que possa fazer a pesquisar. Ele irá retornar a lista de animais que forma cadastrados nesta data
    public List<Animal> search(LocalDate data){
        List<Animal> listaAnimais = new ArrayList<>();
            
        try(Connection conn = ConnectionFactory.recuperaConexao())  {
            //comando que faz a pesquisa usando a data passada por parametro
                pstm = conn.prepareStatement("SELECT animal.nome, animal.especie, "
                + "pessoa.nomeTutor, pessoa.telefone, "
                + "servico.servPet, servico.data, servico.hora, servico.val " +
                "FROM animal, pessoa, servico "+
                "WHERE animal.serv = servico.servPet "+ 
                "AND pessoa.nomeTutor = animal.nmTutor "+
                "AND servico.data = ? "
                + "ORDER BY pessoa.nomeTutor");
              
               pstm.setDate(1, Date.valueOf(data));//passando a data para o comando
               rs = pstm.executeQuery();
            
                while(rs.next()){//cria a lista de animais que está cadastrado nesta data para depois retorna-la na main
                    Animal ani = new Animal();
                    Pessoa pes = new Pessoa();
                    pes.setNomeTutor(rs.getString("nomeTutor"));
                    pes.setTel(rs.getString("telefone"));
                    Servicos serv = new Servicos();
                    serv.setServPet(rs.getString("servPet"));
                    serv.setData(rs.getDate("data").toLocalDate());
                    serv.setHora(rs.getTime("hora").toLocalTime());
                    serv.setVal(rs.getDouble("val"));
                    ani.setNome(rs.getString("nome"));
                    ani.setEspecie(rs.getString("especie"));
                    ani.setTutor(pes);
                    ani.setServico(serv);
                    
                    listaAnimais.add(ani);
                }
            
            conn.close();   
            return listaAnimais;//retorna a lista de animais
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao pesquisar " + ex.getMessage());
            
            return new ArrayList<>();
            
        }
       
    }
    
    public Pessoa findByNamePessoa(String chave){
        Pessoa pes = new Pessoa();
            
        try(Connection conn = ConnectionFactory.recuperaConexao())  {
            //comando que faz a pesquisa usando a data passada por parametro
                pstm = conn.prepareStatement("SELECT pessoa.* "
                    + "FROM pessoa "
                    + "WHERE pessoa.nomeTutor = ? "
                    + "ORDER BY pessoa.nomeTutor");
              
               pstm.setString(1, chave);//passando nome para o comando
               rs = pstm.executeQuery();
            
                while(rs.next()){//cria uma pessoa que esta cadastrada
                    pes.setNomeTutor(rs.getString("nomeTutor"));
                    pes.setTel(rs.getString("telefone"));
                }
            
            conn.close();   
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao encontrar tutor " + ex.getMessage());
            
            return null;
            
        }
       return pes;//retorna as informações da pessoa
    }
    
    public Servicos findByNameServico(String chave){
        Servicos serv = new Servicos();
            
        try(Connection conn = ConnectionFactory.recuperaConexao())  {
            //comando que faz a pesquisa usando a data passada por parametro
                pstm = conn.prepareStatement("SELECT servico.* "
                    + "FROM servico "
                    + "WHERE servico.servPet = ?");
              
               pstm.setString(1, chave);//passando nome para o comando
               rs = pstm.executeQuery();
            
                while(rs.next()){//cria um novo serviço
                    serv.setServPet(rs.getString("servPet"));
                    serv.setData(rs.getDate("data").toLocalDate());
                    serv.setHora(rs.getTime("hora").toLocalTime());
                    serv.setVal(rs.getDouble("val")); 
                }
            
            conn.close();   
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao encontrar servico " + ex.getMessage());
            
            return null;
            
        }
       return serv;//retorna as informações do serviço
    }
}
