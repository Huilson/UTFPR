/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oo.atividade.petshop;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class Crud {
    private PreparedStatement pstm;
    private ResultSet rs;
    
    //metodo que irá criar as tabelas no banco de dados
    void criaTabela() throws SQLException{
        try(Connection conn = ConnectionFactory.recuperaConexao()){
            String tb1 = 
                "CREATE TABLE IF NOT EXISTS pessoa(" +
                "idPes serial PRIMARY KEY, "+ 
                "nomeTutor varchar(250), " +
                "telefone varchar(11));";
            pstm = conn.prepareStatement(tb1);
            pstm.execute();
            //cria a primeira tabela
            
            String tb2 = 
                "CREATE TABLE IF NOT EXISTS servico(" +
                "idServ serial PRIMARY KEY, " + 
                "servPet varchar(150), " +
                "data date, " +
                "hora time, " +
                "val decimal(10,1));";
            pstm = conn.prepareStatement(tb2);
            pstm.execute();
            //cria a segunda tabela
            
            String tb3 = 
                "CREATE TABLE IF NOT EXISTS animal(" +
                "idAni serial PRIMARY KEY, " + 
                "nome varchar(150), " +
                "especie varchar(100), " +
                "idTutor integer, " +
                "idServico integer, " + 
                "CONSTRAINT fkidTutor FOREIGN KEY (idTutor) REFERENCES pessoa(idPes), " + 
                "CONSTRAINT fkidServico FOREIGN KEY (idServico) REFERENCES servico(idServ));";
            pstm = conn.prepareStatement(tb3);
            pstm.execute();
            //cria a terceira tabela
            
            String tb4 = 
                    "CREATE TABLE IF NOT EXISTS animal_servico("
                    + "idAniServ integer, "
                    + "idServAni integer, "
                    + "CONSTRAINT fkidAniServ FOREIGN KEY (idAniServ) REFERENCES animal(idAni), "
                    + "CONSTRAINT fkidServAni FOREIGN KEY (idServAni) REFERENCES servico(idServ));";
            pstm = conn.prepareStatement(tb4);
            pstm.execute();
            //cria a quarta tabela

            String tb5 = 
                    "CREATE TABLE IF NOT EXISTS animal_pessoa("
                    + "idAniPes integer, "
                    + "idPesAni integer, "
                    + "CONSTRAINT fkidPesAni FOREIGN KEY (idPesAni) REFERENCES pessoa(idPes), "
                    + "CONSTRAINT fkidAniPes FOREIGN KEY (idAniPes) REFERENCES animal(idAni));";
            pstm = conn.prepareStatement(tb5);
            pstm.execute();
            //cria a quinta tabela
            //tarefa fazer o insert, consultar, deletar
        }
    }

    //metodo que recebe por parametro uma pessoa, um servico e um animal para que possa inserir os dados nas tabelas do banco de dados
    public boolean insert(Pessoa pes, Servicos servc, Animal ani) {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {

            pstm = conn.prepareStatement("INSERT INTO pessoa(nomeTutor, telefone) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstm.setString(1, pes.getNomeTutor());//insere o nome do tutor que foi informado na main
            pstm.setString(2, pes.getTel());//insere o telefone que foi informado na main
            pstm.executeUpdate();
            //executa o insert na tabela pessoa que irá colocar as informações no banco de dados
            rs = pstm.getGeneratedKeys();

            if (rs.next()) {
                pes.setIdPes(rs.getInt("idPes"));//insere um id na tabela de pessoas
            }

            pstm = conn.prepareStatement("INSERT INTO servico(servPet, data, hora, val) VALUES (?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstm.setString(1, servc.getServPet());//insere o servico que foi informado na main
            pstm.setDate(2, Date.valueOf(servc.getData()));//insere a data que foi informado na main
            pstm.setTime(3, Time.valueOf(servc.getHora()));//insere o horario que foi informado na main
            pstm.setDouble(4, servc.getVal());//insere o valor que foi informado na main
            pstm.executeUpdate();
            rs = pstm.getGeneratedKeys();
            //executa o insert na tabela servico que irá colocar as informações no banco de dados

            if (rs.next()) {
                servc.setIdServ(rs.getInt("idServ"));//insere um id na tabela de servicos
            }

            pstm = conn.prepareStatement("INSERT INTO animal(nome, especie, idTutor, idServico) VALUES (?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstm.setString(1, ani.getNome());//insere o nome do animal que foi informado na main
            pstm.setString(2, ani.getEspecie());//insere a especie do animal que foi informado na main
            pstm.setInt(3, ani.getTutor().getIdPes());//insere o id do tutor que foi informado na main
            pstm.setInt(4, ani.getServico().getIdServ());//insere o id do servico escolhido que foi informado na main
            pstm.executeUpdate();
            //executa o insert na tabela animal que irá colocar as informações no banco de dados
            rs = pstm.getGeneratedKeys();

            if (rs.next()) {
                ani.setIdAni(rs.getInt("idAni"));//insere um id na tabela de animais
            }

            pstm = conn.prepareStatement("INSERT INTO animal_servico(idAniServ, idServAni) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstm.setInt(1, ani.getIdAni());//insere o id do animal 
            pstm.setInt(2, servc.getIdServ());//insere o id do servico
            pstm.executeUpdate();
            //executa o insert na tabela animal_servico que irá colocar as informações no banco de dados
            rs = pstm.getGeneratedKeys();

            pstm = conn.prepareStatement("INSERT INTO animal_pessoa(idAniPes, idPesAni) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstm.setInt(1, ani.getIdAni());//insere o id do animal 
            pstm.setInt(2, pes.getIdPes());//insere o id do tutor
            pstm.executeUpdate();
            //executa o insert na tabela animal_pessoa que irá colocar as informações no banco de dados
            rs = pstm.getGeneratedKeys();

            conn.close();

            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir dados " + ex.getMessage());

            return false;
        }
    }

    //metodo que recebe por parametro uma palavra chave que será o nome do animal para que possa deletar os dados
    public boolean delete(String chave) {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
            //comando que irá receber a palavra chave e apagar os dados
            pstm = conn.prepareStatement("DELETE FROM animal WHERE nome = ? ");
            pstm.setString(1, chave);
            pstm.executeUpdate();
            conn.close();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar animal " + ex.getMessage());

            return false;
        }
    }

    //metodo que recebe por parametro uma data para que possa fazer a pesquisar. Ele irá retornar a lista de animais que forma cadastrados nesta data
    public List<Animal> search(LocalDate data) {
        List<Animal> listaAnimais = new ArrayList<>();

        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
            //comando que faz a pesquisa usando a data passada por parametro
            pstm = conn.prepareStatement("SELECT animal.nome, animal.especie, "
                    + "pessoa.nomeTutor, pessoa.telefone, "
                    + "servico.servPet, servico.data, servico.hora, servico.val "
                    + "FROM animal, pessoa, servico "
                    + "WHERE animal.idServico = servico.idServ "
                    + "AND pessoa.idPes = animal.idTutor "
                    + "AND servico.data = ? "
                    + "ORDER BY pessoa.nomeTutor");

            pstm.setDate(1, Date.valueOf(data));//passando a data para o comando
            rs = pstm.executeQuery();

            while (rs.next()) {//cria a lista de animais que está cadastrado nesta data para depois retorna-la na main
                Animal ani = new Animal();
                Pessoa pes = new Pessoa();
                pes.setNomeTutor(rs.getString("nomeTutor"));
                pes.setTel(rs.getString("telefone"));
                Servicos serv = new Servicos();
                serv.setServPet(rs.getString("servPet"));
                serv.setData(rs.getDate("data").toLocalDate());
                serv.setHora(rs.getTime("hora").toLocalTime());
                serv.setVal(rs.getDouble("val"));
                ani.setNome(rs.getString("nome"));
                ani.setEspecie(rs.getString("especie"));
                ani.setTutor(pes);
                ani.setServico(serv);

                listaAnimais.add(ani);
            }

            conn.close();
            return listaAnimais;//retorna a lista de animais

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Erro ao pesquisar " + ex.getMessage());

            return new ArrayList<>();

        }

    }
}
