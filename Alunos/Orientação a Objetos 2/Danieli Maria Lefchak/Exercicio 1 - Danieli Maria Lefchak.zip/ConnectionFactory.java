/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oo.atividade.petshop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author danie
 */
public class ConnectionFactory {
    public static Connection recuperaConexao(){
        try{
            System.out.println("\nCriando conexao\n");
            return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Aula02OO",
                    "postgres",
                    "maidml22");
        } catch (SQLException e){
            System.err.println("Erro");
            e.printStackTrace();
            return null;
        }
    }
}
