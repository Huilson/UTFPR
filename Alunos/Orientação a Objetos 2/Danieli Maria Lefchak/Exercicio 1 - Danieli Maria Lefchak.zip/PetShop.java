package oo.atividade.petshop;


//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class PetShop {

    /**
     * @param args the command line arguments
     */
    public PetShop() throws SQLException, ClassNotFoundException {
        //Connection conn = ConnectionFactory.recuperaConexao();//metodo que faz a conexao com o banco de dados
        Animal animal;
        String nome;
        String especie;
        Pessoa tutor;
        Servicos servico;
        LocalTime hora = null;
        LocalDate data = null;
        double val;
        String servPet;
        String tutorNome;
        String tel;
        int num = 0;
        Crud crud = new Crud();
        crud.criaTabela();//cria as tabelas
        
        //enquanto for diferente de 1 continuará fazendo o cadastro de animais e seus atendimentos, ou realizar consultas nos atendimentos que ainda não foram realizados
        while (num != 1) {
            int opc = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a opcao desejada:\n 1- Cadastrar,\n 2- Consultar,\n 3- Deletar;",
                    "Opcoes", JOptionPane.INFORMATION_MESSAGE));//variavel que irá receber a opcao informada pelo usuario
            
            switch(opc){
                case 1:
                    nome = JOptionPane.showInputDialog(null, "Informe o nome do animal: ", "nome animal", JOptionPane.QUESTION_MESSAGE);
                    especie = JOptionPane.showInputDialog(null, "Informe a especie animal: ", "especie animal", JOptionPane.QUESTION_MESSAGE);
                    DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
                    hora = LocalTime.parse(JOptionPane.showInputDialog(null, "Informe o horario do atendimaneto: ", "Horario atendimento", JOptionPane.QUESTION_MESSAGE));
                    hora.format(timeFormat);//formata o horario
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    data = LocalDate.parse(JOptionPane.showInputDialog(null, "Informe a data de atendimento: ", "Data atendimento", JOptionPane.QUESTION_MESSAGE));
                    data.format(dateFormat);//formata a data
                    val = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor R$: ", "Valor", JOptionPane.QUESTION_MESSAGE));

                    //se a especie do animal informado for passaro ira mostrar somente as opções vacinar e poda de asas
                    if ("passaro".equals(especie) || "Passaro".equals(especie)) {
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Poda de asas;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    } else {//caso contrario ira mostrar todas as outras opções menos a opção de poda de asas 
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Banho \n Tosa, \n Tosa Higenica, \n"
                                + "Castrar;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    }

                    tutorNome = JOptionPane.showInputDialog(null, "Informe o nome do tutor: ", "nome tutor", JOptionPane.QUESTION_MESSAGE);
                    tel = JOptionPane.showInputDialog(null, "Informe o telefone do tutor: ", "Telefone tutor", JOptionPane.QUESTION_MESSAGE);

                    tutor = new Pessoa(tutorNome, tel);//insere as informacoes em uma nova pessoa
                    servico = new Servicos(data, hora, val, servPet);//insere as informacoes em um novo servico
                    animal = new Animal(nome, especie, tutor, servico);//insere as informacoes em um novo anomal

                    crud.insert(tutor, servico, animal);//insere as informacoes nas tabelas
                    break;
                case 2:
                    LocalTime tmpAtual = LocalTime.now();//pega o horario atual
                    LocalDate dtAtual = LocalDate.now();//pega a data atual
                    
                    DateTimeFormatter dataFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");//o formato da data
                    data = LocalDate.parse(JOptionPane.showInputDialog(null, "Informe a data de atendimento que deseja consultar: ", 
                            "Data atendimento", JOptionPane.QUESTION_MESSAGE));
                    data.format(dataFormat);//formata a data
                    DateTimeFormatter tempFormat = DateTimeFormatter.ofPattern("HH:mm");//formato da hora
                    hora = LocalTime.parse(JOptionPane.showInputDialog(null, "Informe o horario: ", 
                            "Horario atendimento", JOptionPane.QUESTION_MESSAGE));
                    hora.format(tempFormat);//formata o horario

                    //se a hora informada for após a hora atual e a data for igual ou após a data atual ira mostrar a lista
                    //de atendimentos a serem realizados
                    if (hora.isAfter(tmpAtual) && data.equals(dtAtual) || data.isAfter(dtAtual)) {
                        //faz uma pesquisa mostrando apenas os registros que estão na data informada.
                        
                        List<Animal> filtrados = crud.search(data);
                        //string "filtrados" vai receber a lista retornada pelo metodo search
                        System.out.println("Lista de atendimentos a fazer:\n" + filtrados);
                        //imprime a string mostrando a lista de atendimentos que ainda não foram feitos
                    }
                    break;
                case 3:
                    nome = JOptionPane.showInputDialog(null, "Informe o nome do animal que deseja excluir: ", "nome animal", JOptionPane.QUESTION_MESSAGE);
                    crud.delete(nome);//metodo que deleta um cadastro de um animal pelo nome
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Está opcao nao existe! Informe uma opcao valida.\n", "Opcao invalida", JOptionPane.WARNING_MESSAGE);
                    //se o usuario informar uma opcao invalida irá aparecer está mensagem para ele
                    break;
            }

            num = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite 1 para sair", "Sair", JOptionPane.INFORMATION_MESSAGE));
            //a opção para sair do looping apos ter terminado o cadastro de animais
        }

//        Employee e = new Employee();
//        e.name = "Reyan Ali";
//        e.address = "Phokka Kuan, Ambehta Peer";
//        e.number = 101;
//        
//        try{
//            FileOutputStream fileOut = new FileOutputStream("C:\\Users\\danie\\Desktop\\employee.txt");
//            ObjectOutputStream out = new ObjectOutputStream(fileOut);
//            out.writeObject(e);
//            out.close();
//            fileOut.close();
//            System.out.println("O dado serializado esta salvo em /employee.txt");
//        } catch(IOException i){
//            i.printStackTrace();
//        }
        
//         Employee e = null;
//          
//         try {
//            FileInputStream fileIn = new FileInputStream("C:\\Users\\danie\\Desktop\\employee.txt");
//            ObjectInputStream in = new ObjectInputStream(fileIn);
//            e = (Employee) in.readObject();
//            in.close();
//            fileIn.close();
//        } catch (IOException i) {
//            i.printStackTrace();
//            return;
//        } catch (ClassNotFoundException c){
//             System.out.println("Classe empregado não encontrada");
//             c.printStackTrace();
//             return;
//        }
//         
//         System.out.println("Empregado desserializado");
//         System.out.println("Nome: " + e.name);
//         System.out.println("Endereço: " + e.address);
//         System.out.println("Numero: " + e.number);
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        new PetShop();
    }
}
