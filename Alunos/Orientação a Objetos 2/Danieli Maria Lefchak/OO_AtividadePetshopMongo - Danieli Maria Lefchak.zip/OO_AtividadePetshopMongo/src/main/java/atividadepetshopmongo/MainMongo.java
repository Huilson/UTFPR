/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividadepetshopmongo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class MainMongo {

    /**
     * @param args the command line arguments
     */
        public MainMongo() {
        Animal animal;
        String nome;
        String especie;
        Pessoa tutor;
        Servicos servico;
        LocalTime hora = null;
        LocalDate data = null;
        double val;
        String servPet;
        String tutorNome;
        String tel;
        int num = 0;
        CrudMongo crud = new CrudMongo();
    
        //enquanto for diferente de 1 continuará fazendo o cadastro de animais e seus atendimentos, 
        //ou realizar consultas nos atendimentos que ainda não foram realizados
        while (num != 1) {
            int opc = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a opcao desejada:\n 1- Cadastrar,\n "
                    + "2- Consultar,\n 3- Deletar;", "Opcoes", JOptionPane.INFORMATION_MESSAGE));
            //variavel que irá receber a opcao informada pelo usuario

            switch (opc) {
                //cadastro
                case 1:
                    //variaveis que irão receber as informações que o usuario digitar
                    nome = JOptionPane.showInputDialog(null, "Informe o nome do animal: ",
                            "nome animal", JOptionPane.QUESTION_MESSAGE);
                    especie = JOptionPane.showInputDialog(null, "Informe a especie animal: ",
                            "especie animal", JOptionPane.QUESTION_MESSAGE);
                    DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
                    hora = LocalTime.parse(JOptionPane.showInputDialog(null, "Informe o horario do atendimaneto(hh:mm): ",
                            "Horario atendimento", JOptionPane.QUESTION_MESSAGE));
                    hora.format(timeFormat);//formata o horario
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    data = LocalDate.parse(JOptionPane.showInputDialog(null, "Informe a data de atendimento(aaaa-mm-dd): ",
                            "Data atendimento", JOptionPane.QUESTION_MESSAGE));
                    data.format(dateFormat);//formata a data
                    val = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor R$: ",
                            "Valor", JOptionPane.QUESTION_MESSAGE));

                    //se a especie do animal informado for passaro ira mostrar somente as opções vacinar e poda de asas
                    if ("passaro".equals(especie) || "Passaro".equals(especie) || "pássaro".equals(especie) || "Pássaro".equals(especie)) {
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, \n Poda de asas;",
                                "Servico", JOptionPane.QUESTION_MESSAGE);
                    } else {//caso contrario ira mostrar todas as outras opções menos a opção de poda de asas 
                        servPet = JOptionPane.showInputDialog(null, "Informe o serviso solicitado: \nVacinar, "
                                + "\n Banho \n Tosa, \n Tosa Higenica, \n"
                                + "Castrar;", "Servico", JOptionPane.QUESTION_MESSAGE);
                    }

                    tutorNome = JOptionPane.showInputDialog(null, "Informe o nome do tutor: ",
                            "nome tutor", JOptionPane.QUESTION_MESSAGE);
                    tel = JOptionPane.showInputDialog(null, "Informe o telefone do tutor: ",
                            "Telefone tutor", JOptionPane.QUESTION_MESSAGE);

                    tutor = new Pessoa(tutorNome, tel);//insere as informacoes em uma nova pessoa
                    servico = new Servicos(data, hora, val, servPet);//insere as informacoes em um novo servico
                    animal = new Animal(nome, especie, tutor, servico);//insere as informacoes em um novo anomal
                    
                    //insere as informacoes nas coleções
                    crud.insertsPessoa(tutor);
                    crud.insertsAnimal(tutor, animal, servico);
                    
                    break;
                //consultar
                case 2:
                    nome = JOptionPane.showInputDialog(null, "Informe o nome do animal que deseja pesquisar: ",
                            "Nome animal", JOptionPane.QUESTION_MESSAGE);
                    
                    //Busca informações nas coleções
                    crud.pesquisaAnimais(nome);
                    break;
                //deletar
                case 3:
                    int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o id do animal que deseja excluir: ",
                            "id animal", JOptionPane.QUESTION_MESSAGE));

                    crud.delete(id);//metodo que deleta um cadastro de um animal pelo id
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Está opcao nao existe! Informe uma opcao valida.\n",
                            "Opcao invalida", JOptionPane.WARNING_MESSAGE);
                    //se o usuario informar uma opcao invalida irá aparecer está mensagem para ele
                    break;
            }
            
            num = Integer.parseInt(JOptionPane.showInputDialog(null, "Para seguir fazendo operações digite qualquer outro número\n" +
                    "Para sair digite 1\n", "Sair", JOptionPane.INFORMATION_MESSAGE));
            //a opção para sair do looping apos ter terminado o cadastro de animais
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        new MainMongo();
    }
    
}
