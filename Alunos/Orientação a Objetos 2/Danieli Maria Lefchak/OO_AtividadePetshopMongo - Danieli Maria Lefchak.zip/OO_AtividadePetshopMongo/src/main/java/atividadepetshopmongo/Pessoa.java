/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadepetshopmongo;

/**
 *
 * @author danie
 */
public class Pessoa {
    private int idPes;
    private String nomeTutor;
    private String tel;
    
    //construtor vazio
    public Pessoa() {
    }
    
    //construtor que ira receber por parametro o nome, especie, tutor e o servico
    public Pessoa(String nomeTutor, String tel) {
        this.nomeTutor = nomeTutor;
        this.tel = tel;
    }

    public int getIdPes() {
        return idPes;
    }

    public void setIdPes(int idPes) {
        this.idPes = idPes;
    }

    public String getNomeTutor() {
        return nomeTutor;
    }

    public void setNomeTutor(String nomeTutor) {
        this.nomeTutor = nomeTutor;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
    
    @Override
    public String toString() {
        return "; Nome do Tutor: " + nomeTutor + ", tel: " + tel;
    }
}
