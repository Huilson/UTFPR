/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividadepetshopmongo;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import org.bson.Document;
//entregar 27

/**
 *
 * @author danie
 */
public class CrudMongo {

    //cria uma conexão com o banco
    private MongoClient conexao = new MongoClient();
    //conecta ao database
    private MongoDatabase dbPetShop = conexao.getDatabase("PetShop");
    //conecta as coleções criadas
    private MongoCollection<Document> animal = dbPetShop.getCollection("animal");
    private MongoCollection<Document> pessoa = dbPetShop.getCollection("pessoa");

    //método para gerar um id para a pessoa
    //recebe uma pessoa por parametro e retorna um inteiro
    public int gerarIdPessoa(Pessoa pes) {
        int id = 1;
        //esp irá receber o ultimo id cadastrado
        Document esp = pessoa.find().sort(new Document("_id", -1)).first();
        //se o esp não for nulo (caso a coleção não estiver vazia)
        if (esp != null) {
            id = id + (int) esp.get("_id");//vai somar 1 ao ultimo id
        } else {//caso contrario se a coleção estiver vazia
            id = 1;//vai retornar 1 como valor para o id
        }
        //retorna id
        return id;
    }

    //método para gerar um id para o animal e o servico
    //recebe um Animal e um Servico por parametro e retorna um inteiro
    public int gerarIdAnimal(Animal ani, Servicos serv) {
        int id = 1;
        //esp irá receber o ultimo id cadastrado
        Document esp = animal.find().sort(new Document("_id", -1)).first();
        //se o esp não for nulo (caso a coleção não estiver vazia)
        if (esp != null) {//caso contrario se a coleção estiver vazia
            id = id + (int) esp.get("_id");//vai somar 1 ao ultimo id
        } else {
            id = 50;//vai retornar 50 como valor para o id
        }
        //retorna id
        return id;
    }

    //método que irá inserir uma pessoa na coleção
    public void insertsPessoa(Pessoa pes) {
        //seta a chave gerada para o objeto pessoa
        pes.setIdPes(gerarIdPessoa(pes));

        //cria um novo documento recebendo os valore do objeto pessoa
        Document novaPessoa = new Document("_id", pes.getIdPes())
                .append("nomeTutor", pes.getNomeTutor())
                .append("telefone", pes.getTel());
        //faz o insert desse documento na coleção
        pessoa.insertOne(novaPessoa);

    }

    //método que irá inserir uma animal e um servico na coleção
    public void insertsAnimal(Pessoa pes, Animal ani, Servicos serv) {
        //seta a chave gerada para o objeto animal
        ani.setIdAni(gerarIdAnimal(ani, serv));
        //seta a chave gerada para o objeto servico e acrescenta 1
        serv.setIdServ(gerarIdAnimal(ani, serv) + 1);

        //cria um novo documento recebendo os valore dos objetos animal e servico
        //o servico ser um array dentro do animal
        Document novaAnimal = new Document("_id", ani.getIdAni())
                .append("especie", ani.getEspecie())
                .append("nome", ani.getNome())
                .append("_idDonoAnimal", pes.getIdPes())
                .append("servico", Arrays.asList(
                        new Document()
                                .append("_id", serv.getIdServ())
                                .append("data", serv.getData())
                                .append("hora", serv.getHora())
                                .append("servPet", serv.getServPet())
                                .append("val", serv.getVal())));
        //faz o insert desse documento na coleção
        animal.insertOne(novaAnimal);

    }

    //método que irá realizar uma busca na colleção para 
    //reccebe uma string por parametro e encontrar um documento
    public void pesquisaAnimais(String nome) {
        MongoCursor<Document> animais = animal.find(Filters.eq("nome", nome)).iterator();
        while (animais.hasNext()) {
            System.out.println(animais.next());
        };
    }

    //método que irá deletar um animal e seu respectivo
    //dono recebe um inteiro por parametro
    public void delete(int id) {
        Document doc;

        //acha o documento que tem o id informado
        MongoCursor<Document> ani = animal.find(Filters.eq("_id", id)).iterator();
        while (ani.hasNext()) {
            doc = ani.next();
            //quando achar iá pegar somente o "_idDonoAnimal" que é a 
            //chave estrangeira entre animal e pessoa e irá apagar a pessoa
            //que é dona do animal com esse id
            pessoa.deleteOne(Filters.eq("_id", doc.get("_idDonoAnimal")));
        };
        //deleta o animal que tem o id informado
        animal.deleteOne(Filters.eq("_id", id));
    }
}
