package br.com.java_mongodb.mongodbSpring.model;

import org.bson.types.ObjectId;

public class Animal {

    ObjectId _id;
    ObjectId idFuncionario;
    private String nome;
    private String especie;
    private String descricao;

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public ObjectId getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(ObjectId idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    //MÉTODO QUE GERA UM _ID CASO AINDA NÃO TENHA UM
    public Animal criaId() {
        setId(new ObjectId());
        return this;
    }
}
