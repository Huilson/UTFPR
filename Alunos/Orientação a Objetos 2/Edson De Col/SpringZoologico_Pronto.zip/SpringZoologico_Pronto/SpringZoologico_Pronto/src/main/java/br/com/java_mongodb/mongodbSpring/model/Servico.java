package br.com.java_mongodb.mongodbSpring.model;

import java.util.Date;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

public class Servico {

    private ObjectId _id;
    private ObjectId idA;
    private ObjectId idF;
    private String descricao;
    private String status;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date data;
    @DateTimeFormat(pattern = "HH:mm:ss")
    private String hora;

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public ObjectId getIdA() {
        return idA;
    }

    public void setIdA(ObjectId idA) {
        this.idA = idA;
    }

    public ObjectId getIdF() {
        return idF;
    }

    public void setIdF(ObjectId idF) {
        this.idF = idF;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Servico criaId() {
        setId(new ObjectId());
        return this;
    }
}
