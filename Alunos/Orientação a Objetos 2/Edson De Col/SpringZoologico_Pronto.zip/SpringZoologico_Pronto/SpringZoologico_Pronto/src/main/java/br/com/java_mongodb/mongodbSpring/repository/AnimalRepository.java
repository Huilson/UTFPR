package br.com.java_mongodb.mongodbSpring.repository;
import br.com.java_mongodb.mongodbSpring.codec.AnimalCodec;
import br.com.java_mongodb.mongodbSpring.model.Animal;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

//CLASSE REPOSITORY RESPONSÁVEL POR CONVERSAR COM O BANCO MONGODB
//PARA DAR AS INSTRUÇÕES RELACIONADAS A PERSISTENCIA DO OBJETO "ANIMAL"
//PARA ESTABELECER A CONEXÃO COM A COLLECTION CORRESPONDENTE AO "ANIMAL"


//NOTAÇÃO RESPONSÁVEL POR DIZER QUE SE TRATA DE UM REPOSITÓRIO DO SPRING
//E PERMITE QUE SEJA GERENCIADA PELO CONTAINER DO SPRING
@Repository
public class AnimalRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    
    //ESSE MÉTODO ESTABELE A CONEXÃO COM O BANCO DE DADOS MONGO
    //E CRIA OS CODECS NECESSÁRIOS, NESSE CADO O CODEC PARA O "ANIMAL"
    public void conectaAnimal() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        AnimalCodec animalCodec = new AnimalCodec(codec);

        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(animalCodec));

        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("TesteZoo");
    }
    
    //ESSE MÉTODO É RESPONSÁVEL POR SALVAR UM OBJETO DO TIPO "ANIMAL" 
    //NO BANCO DE DADOS MONGO, VERIFICA SE O OBJETO JÁ POSSUI UM _ID SE JÁ
    //POSSUI ENTÃO APENAS ATUALIZA, SE NÃO POSSUI ENTÃO CRIA UM NOVO DOCUMENTO
    public void salvarAnimal(Animal animal) {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("animal", Animal.class);
        if (animal.getId() == null) {
            animais.insertOne(animal);
        } else {
            animais.updateOne(Filters.eq("_id", animal.getId()), new Document("$set", animal));
        }
        cliente.close();
    }

    //ESSE MÉTODO RETORNA TODOS OS ANIMAIS QUE ESTÁO CADASTRADOS NA COLECTION "ANIMAL"
    //EM FORMA DE LISTA, POR MEIO DE UMA CONSULTA NO BANCO E PERCORRENDO COM UM CURSOR
    public List<Animal> listarTodosAnimais() {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("animal", Animal.class);
        MongoCursor<Animal> resultado = animais.find().iterator();
        List<Animal> animaisLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Animal animal = resultado.next();
            animaisLista.add(animal);
        }
        cliente.close();
        return animaisLista;
    }

    //ESSE MÉTODO É RESPONSÁVEL POR ATUALIZAR UM ANIMAL JÁ EXISTENTE NO BANCO
    //COM BASE NO _ID FORNECIDO COM OS NOVOS VALORES
    public void atualizarAnimal(String id, Animal animal) {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("animal", Animal.class);
        animais.updateOne(Filters.eq("_id", new ObjectId(id)),
                new Document("$set",
                        new Document("nome", animal.getNome())
                                .append("especie", animal.getEspecie())
                                .append("descricao", animal.getDescricao())
                                .append("responsavel", animal.getIdFuncionario())
                )
        );
    }

    //MÉTODO RESPONSÁVEL POR RETORNAR UM "ANIMAL" DO BANCO DE DADOS COM BASE
    //NO _ID RECEBIDO COMO PARÂMETRO
    public Animal obterIdAnimal(String id) {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("animal", Animal.class);
        Animal animal = animais.find(Filters.eq("_id", new ObjectId(id))).first();
        return animal;
    }

    //MÉTODO RESPONSÁVEL POR BUSCAR UM ANIMAL NO BANCO COM BASE
    //NO _ID RECEBIDO POR PARÂMETRO E EXCLUÍ-LO ASSIM QUE ENCONTRADO
    public void excluirAnimal(String id) {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("animal", Animal.class);
        animais.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
}
