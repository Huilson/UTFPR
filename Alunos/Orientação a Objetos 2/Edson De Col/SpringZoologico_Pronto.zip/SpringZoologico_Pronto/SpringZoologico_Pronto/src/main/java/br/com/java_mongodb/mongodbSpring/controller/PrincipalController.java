package br.com.java_mongodb.mongodbSpring.controller;

import br.com.java_mongodb.mongodbSpring.model.Animal;
import br.com.java_mongodb.mongodbSpring.model.Funcionario;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import br.com.java_mongodb.mongodbSpring.repository.AnimalRepository;
import br.com.java_mongodb.mongodbSpring.repository.FuncionarioRepository;
import br.com.java_mongodb.mongodbSpring.repository.servicoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.stereotype.Controller;


//CLASSE CONTROLLER RESPONSÁVEL POR CONTROLAR E ADMINISTRAR TODAS AS REQUISIÇÕES HTTP
//RELACIONADAS AO SISTEMA TODO, COMO OS CADASTROS, AS ATUALIZAÇÕES, AS EXCLUSÕES
//DE ANIMAIS, FUNCIONÁRIOS E SERVIÇOS, MAPEANDO O CAMINHO PARA CADA FUNÇÃO A 
//SER EXECUTADA.

//A NOTAÇÃO "CONTROLLER" DIZ QUE ESSA CLASSE É UM CONTROLADOR DO SPRING E PERMITE QUE 
//SEJA GERENCIADA PELO SPRING
@Controller
public class PrincipalController {

    
    //INSTNÂNCIAS DE SEUS RESPECTIVOS REPOSÍTORYS
    //E INJETADOS POR MEIO DA NOTAÇÃO "AUTOWIRED"
    @Autowired
    AnimalRepository aRepository;
    @Autowired
    FuncionarioRepository fRepository;
    @Autowired
    servicoRepository sRepository;

    //////////////////////////////////////////////////////////////////////////////
    //MAPEANDO O MÉTODO RESPONSÁVEL POR EXIBIR O FORMULÁRIO ONDE SERÁ 
    //REALIZADO O CADASTRO DE ANIMAIS E CARREGAR A LISTA DE FUNCIONÁRIOS 
    //PARA ASSOCIAR AO NOVO CADASTRO DE "ANIMAL"
    @GetMapping("/animal/cadastrar")
    public String cadastrar(Model model) {
        List<Funcionario> funs = fRepository.listarTodosProfissionais();
        model.addAttribute("funs", funs);
        model.addAttribute("animal", new Animal());
        return "animal/cadastrar";
    }

    //MAPEANDO E CRIANDO A ROTA PARA SALVAR UM ANIMAL APÓS OS 
    //DADOS SEREM PREENCHIDOS NO FORMULÁRIO CORRETAMENTE E REDIRECIONANDO
    //PARA A PÁGINA INICIAL APÓS O TRABALHO ESTAR PRONTO
    @PostMapping("/animal/salvar")
    public String salvar(@ModelAttribute Animal animal) {
        aRepository.salvarAnimal(animal);
        return "redirect:/";
    }

    //MAPEANDO O MÉTODO RESPONSÁVEL POR EXIBIR UM FORMULÁRIO COM A LISTA COM 
    //TODOS OS ANIMAIS JÁ CADASTRADOS PRESENTES NO BANCO DE DADOS
    @GetMapping("/animal/listar")
    public String listar(Model model) {
        List<Animal> animais = aRepository.listarTodosAnimais();
        model.addAttribute("animal", animais);
        return "animal/listar";
    }

    //MAPEANDO O MÉTODO RESPONSÁVEL POR EXIBIR O FORMULÁRIO PARA ATUALIZAÇÃO
    //DOS DADOS DO ANIMAL SELECIONADO COM BASE NO _ID DO ANIMAL QUE FOI ESCOLHIDO
    @GetMapping("/animal/atualizar/{id}")
    public String atualizarAnimal(@PathVariable String id, Model model) {
        Animal animal = aRepository.obterIdAnimal(id);
        List<Funcionario> funs = fRepository.listarTodosProfissionais();
        model.addAttribute("funs", funs);
        model.addAttribute("animal", animal);
        return "animal/atualizar";
    }

    //MAPEANDO O MÉTODO PARA EDITAR O CADASTRO DO ANIMAL ESCOLHIDO PELO
    //MÉTODO ACIMA, RECEBENDO O _ID DESSE OBJETO
    @PostMapping("/animal/editar/{id}")
    public String editar(@PathVariable String id, @ModelAttribute Animal animal) {
        aRepository.atualizarAnimal(id, animal);
        return "redirect:/";
    }

    //MAPEIA O MÉTODO RESPONSÁVEL POR APRESENTAR UM FORMULÁRIO COM OS DADOS 
    //DO CADASTRO DO ANIMAL ESCOLHIDO COM BASE NO _ID SELECIONADO DO ANIMAL
    @GetMapping("/animal/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model) {
        List<Funcionario> funs = fRepository.listarTodosProfissionais();
        model.addAttribute("funs", funs);
        Animal animal = aRepository.obterIdAnimal(id);
        model.addAttribute("animal", animal);
        return "animal/visualizar";
    }

    //MAPEIA O MPETODO RESPONSÁVEL POR EXCLUIR UM ANIMAL SELECIONADO 
    //NO MÉTODO ACIMA, POR MEIO DO _ID FORNECIDO
    @GetMapping("/animal/excluir/{id}")
    public String excluir(@PathVariable String id) {
        aRepository.excluirAnimal(id);
        return "redirect:/animal/listar";
    }
    
    //ATÉ AQUI FORAM REALIZADOS OS MÉTODOS RESPONSÁVEIS PELAS TRATATIVAS
    //DO OBJETO "ANIMAL", E AS FUNÇÕES RELACIONADAS A ELE, OS PRÓXIMOS 
    //MÉTODOS, POSSUIEM EXATAMENTE AS MESMAS FUNÇÕES, COM ALTERAÇÕES APENAS
    //NOS OBJETOS QUE SERÃO TRABALHADOS, NO CASO "FUNCIONARIO" E "SERVIÇO"
    //E O CAMINHO QUE SERÁ UTILIZADO NO MOMENTO DE MAPEAR O MÉTODO.
    //////////////////////////////////////////////////////////////////////////////

    @GetMapping("/funcionario/cadastrar")
    public String cadastrarFuncionario(Model model) {
        model.addAttribute("funcionario", new Funcionario());
        return "funcionario/cadastrar";
    }

    @PostMapping("/funcionario/salvar")
    public String salvarFuncionario(@ModelAttribute Funcionario aluno) {
        fRepository.salvarProfissional(aluno);
        return "redirect:/";
    }

    @GetMapping("/funcionario/listar")
    public String listarFuncionario(Model model) {
        List<Funcionario> funcionario = fRepository.listarTodosProfissionais();
        model.addAttribute("profissional", funcionario);
        return "funcionario/listar";
    }

    @GetMapping("/funcionario/atualizar/{id}")
    public String atualizar(@PathVariable String id, Model model) {
        Funcionario funcionario = fRepository.obterIdProfissional(id);

        model.addAttribute("funcionario", funcionario);
        return "funcionario/atualizar";
    }

    @PostMapping("/funcionario/editar/{id}")
    public String editar(@PathVariable String id, @ModelAttribute Funcionario funcionario) {
        fRepository.atualizarFuncionario(id, funcionario);

        return "redirect:/";
    }

    @GetMapping("/funcionario/visualizar/{id}")
    public String visualizarFuncionario(@PathVariable String id, Model model) {
        Funcionario aluno = fRepository.obterIdProfissional(id);
        model.addAttribute("funcionario", aluno);
        return "funcionario/visualizar";
    }

    @GetMapping("/funcionario/excluirFuncionario/{id}")
    public String excluirFuncionario(@PathVariable String id) {
        fRepository.excluirProfissional(id);
        return "redirect:/funcionario/listar";
    }
    //////////////////////////////////////////////////////////////////////////////

    @GetMapping("/servico/cadastrar")
    public String cadastrarServico(Model model) {
        List<Funcionario> funs = fRepository.listarTodosProfissionais();
        model.addAttribute("funs", funs);
        List<Animal> an = aRepository.listarTodosAnimais();
        model.addAttribute("an", an);
        model.addAttribute("servico", new Servico());
        return "servico/cadastrar";
    }

    @PostMapping("/servico/salvar")
    public String salvarServico(@ModelAttribute Servico servico) {
        sRepository.salvarServico(servico);
        return "redirect:/";
    }

    @GetMapping("/servico/listar")
    public String listarServico(Model model) {
        List<Servico> servicos = sRepository.listarTodosServicos();
        model.addAttribute("listaServicoDiario", servicos);
        return "servico/listar";
    }

    @GetMapping("/servico/listarFeitos")
    public String listarServicoFeito(Model model) {
        List<Servico> servicos = sRepository.listarTodosServicosFeitos();
        model.addAttribute("listaServicoDiario", servicos);
        return "servico/listar";
    }

    @GetMapping("/servico/listarPendentes")
    public String listarServicoPendente(Model model) {
        List<Servico> servicos = sRepository.listarTodosServicosPendentes();
        model.addAttribute("listaServicoDiario", servicos);
        return "servico/listar";
    }

    @GetMapping("/servico/visualizar/{id}")
    public String visualizarServico(@PathVariable String id, Model model) {
        Servico servico = sRepository.obterIdServico(id);
        model.addAttribute("listaServicoDiario", servico);
        return "servico/visualizar";
    }

    @GetMapping("/servico/excluirServico/{id}")
    public String excluirServico(@PathVariable String id) {
        sRepository.excluirServico(id);
        return "redirect:/servico/listar";
    }
}
