package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Servico;
import com.mongodb.internal.connection.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

//CLASSE CODEC PARA CONVERTER OBJETO "SERVIÇO" JAVA PARA DOCUMENTOS BSON PRA PODER
//SALVAR EM MONGO E TAMBÉM PARA CONVERTER DO MONGO PARA JAVA
//ANIMLACODEC IMPLEMENTANTO A INTERFACE CollectibleCodec PARA PODER LIDAR
//COM _ID NO MONGO 
public class ServicoCodec implements CollectibleCodec<Servico> {

    //CODEC PARA CODIFICAR E DECODIFICAR DOCUMENTOS BSON
    private Codec<Document> codec;

    public ServicoCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    //MÉTODO QUE RETORNA A CLASSE "SERVIÇO" DIZENDO QUE ESSE CODEC
    //PODE TRABALHAR COM OBJETOS DA CLASSE "SERVIÇO"
    @Override
    public Class<Servico> getEncoderClass() {
        return Servico.class;
    }

    //FAZ A VERIFICAÇÃO SE O OBJETO "SERVIÇO" TEM _ID
    @Override
    public boolean documentHasId(Servico servico) {
        return servico.getId() == null;
    }

    //ESSE MÉTODO RETORNA O VALOR DO _ID DO OBJETO "SERVIÇO" COMO UM 
    //BSONVALUE    
    @Override
    public BsonValue getDocumentId(Servico servico) {
        if (!documentHasId(servico)) {
            throw new IllegalStateException("Esse documento não tem ID");
        } else {
            return new BsonString(servico.getId().toHexString());
        }
    }

    //MÉTODO RESPONSÁVEL POR GERAR UM IDENTIFICADOR PARA O OBJETO "SERVIÇO" 
    //CASO AINDA NÃO TENHA
    @Override
    public Servico generateIdIfAbsentFromDocument(Servico servico) {
        return documentHasId(servico) ? servico.criaId() : servico;
    }

    //MÉTODO RESPONSÁVEL POR CONVERTER UM OBJETO "SERVIÇO" EM UM DOCUMENTO BSON
    //ONDE OS ATRIBUTOS DO OBJETO SÃO MAPEADOS PARA CAMPOS NO DOCUMENTO BSON
    @Override
    public void encode(BsonWriter writer, Servico servico, EncoderContext ec) {

        ObjectId id = servico.getId();
        ObjectId nomeAnimal = servico.getIdA();
        ObjectId nomeFuncionario = servico.getIdF();
        String descricao = servico.getDescricao();
        String status = servico.getStatus();
        Date data = servico.getData();
        String hora = servico.getHora();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nomeAnimal", nomeAnimal);
        doc.put("nomeFuncionario", nomeFuncionario);
        doc.put("descricao", descricao);
        doc.put("status", status);
        doc.put("data", data);
        doc.put("hora", hora);

        codec.encode(writer, doc, ec);

    }

    //ESSE MÉTODO FAZ O PROCESSO INVERSO DO MÉTODO ENCODE
    @Override
    public Servico decode(BsonReader reader, DecoderContext dc) {

        Document doc = codec.decode(reader, dc);
        Servico servico = new Servico();
        servico.setId(doc.getObjectId("_id"));
        servico.setIdA(doc.getObjectId("nomeAnimal"));
        servico.setIdF(doc.getObjectId("nomeFuncionario"));
        servico.setDescricao(doc.getString("descricao"));
        servico.setStatus(doc.getString("status"));
        servico.setData(doc.getDate("data"));
        servico.setHora(doc.getString("hora"));

        return servico;
    }
}
