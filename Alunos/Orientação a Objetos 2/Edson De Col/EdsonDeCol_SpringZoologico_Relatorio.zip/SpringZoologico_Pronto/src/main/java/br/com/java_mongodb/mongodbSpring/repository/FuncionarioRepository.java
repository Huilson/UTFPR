package br.com.java_mongodb.mongodbSpring.repository;

import br.com.java_mongodb.mongodbSpring.codec.FuncionarioCodec;
import br.com.java_mongodb.mongodbSpring.model.Funcionario;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

//CLASSE REPOSITORY RESPONSÁVEL POR CONVERSAR COM O BANCO MONGODB
//PARA DAR AS INSTRUÇÕES RELACIONADAS A PERSISTENCIA DO OBJETO "FUNCIONARIO"
//PARA ESTABELECER A CONEXÃO COM A COLLECTION CORRESPONDENTE AO "FUNCIONARIO"

//NOTAÇÃO RESPONSÁVEL POR DIZER QUE SE TRATA DE UM REPOSITÓRIO DO SPRING
//E PERMITE QUE SEJA GERENCIADA PELO CONTAINER DO SPRING
@Repository
public class FuncionarioRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    //ESSE MÉTODO ESTABELE A CONEXÃO COM O BANCO DE DADOS MONGO
    //E CRIA OS CODECS NECESSÁRIOS, NESSE CADO O CODEC PARA O "FUNCIONARIO"
    public void conectaFuncionario() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        FuncionarioCodec funcionarioCodec = new FuncionarioCodec(codec);

        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(funcionarioCodec));

        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("TesteZoo");
    }

    //ESSE MÉTODO É RESPONSÁVEL POR SALVAR UM OBJETO DO TIPO "FUNCIONARIO" 
    //NO BANCO DE DADOS MONGO, VERIFICA SE O OBJETO JÁ POSSUI UM _ID SE JÁ
    //POSSUI ENTÃO APENAS ATUALIZA, SE NÃO POSSUI ENTÃO CRIA UM NOVO DOCUMENTO
    public void salvarProfissional(Funcionario profissional) {
        conectaFuncionario();
        MongoCollection<Funcionario> profissionais = db.getCollection("profissional", Funcionario.class);
        if (profissional.getId() == null) {
            profissionais.insertOne(profissional);
        } else {
            profissionais.updateOne(Filters.eq("_id", profissional.getId()), new Document("$set", profissional));
        }
        cliente.close();
    }

    //ESSE MÉTODO RETORNA TODOS OS FUNCIONARIOS QUE ESTÁO CADASTRADOS NA COLECTION "FUNCIONARIO"
    //EM FORMA DE LISTA, POR MEIO DE UMA CONSULTA NO BANCO E PERCORRENDO COM UM CURSOR
    public List<Funcionario> listarTodosProfissionais() {
        conectaFuncionario();
        MongoCollection<Funcionario> profissionais = db.getCollection("profissional", Funcionario.class);
        MongoCursor<Funcionario> resultado = profissionais.find().iterator();
        List<Funcionario> profissionalLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Funcionario profissional = resultado.next();
            profissionalLista.add(profissional);
        }
        cliente.close();
        return profissionalLista;
    }

    //MÉTODO RESPONSÁVEL POR RETORNAR UM "FUNCIONARIO" DO BANCO DE DADOS COM BASE
    //NO _ID RECEBIDO COMO PARÂMETRO
    public Funcionario obterIdProfissional(String id) {
        conectaFuncionario();
        MongoCollection<Funcionario> prof = db.getCollection("profissional", Funcionario.class);
        Funcionario func = prof.find(Filters.eq("_id", new ObjectId(id))).first();
        cliente.close();
        return func;
    }

    //ESSE MÉTODO É RESPONSÁVEL POR ATUALIZAR UM FUNCIONARIO JÁ EXISTENTE NO BANCO
    //COM BASE NO _ID FORNECIDO COM OS NOVOS VALORES
    public void atualizarFuncionario(String id, Funcionario funcionario) {
        conectaFuncionario();
        MongoCollection<Funcionario> funcionarios = db.getCollection("profissional", Funcionario.class);
        funcionarios.updateOne(Filters.eq("_id", new ObjectId(id)),
                new Document("$set",
                        new Document("nome", funcionario.getNome())
                                .append("cpf", funcionario.getCpf())
                                .append("cargo", funcionario.getCargo())
                                .append("cidade", funcionario.getCidade())
                                .append("bairro", funcionario.getBairro())
                                .append("rua", funcionario.getRua())
                )
        );
    }

    //MÉTODO RESPONSÁVEL POR BUSCAR UM FUNCIONARIO NO BANCO COM BASE
    //NO _ID RECEBIDO POR PARÂMETRO E EXCLUÍ-LO ASSIM QUE ENCONTRADO
    public void excluirProfissional(String id) {
        conectaFuncionario();
        MongoCollection<Funcionario> funcionarios = db.getCollection("profissional", Funcionario.class);
        funcionarios.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
}
