package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Animal;
import br.com.java_mongodb.mongodbSpring.model.Funcionario;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import br.com.java_mongodb.mongodbSpring.repository.AnimalRepository;
import br.com.java_mongodb.mongodbSpring.repository.FuncionarioRepository;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.DocumentCodec;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

//CLASSE CODEC PARA CONVERTER OBJETO "SERVIÇO" JAVA PARA DOCUMENTOS BSON PRA PODER
//SALVAR EM MONGO E TAMBÉM PARA CONVERTER DO MONGO PARA JAVA
//ANIMLACODEC IMPLEMENTANTO A INTERFACE CollectibleCodec PARA PODER LIDAR
//COM _ID NO MONGO 
public class ServicoCodec implements CollectibleCodec<Servico> {

    //CODEC PARA CODIFICAR E DECODIFICAR DOCUMENTOS BSON
    private Codec<Document> codec;

    public ServicoCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    //MÉTODO QUE RETORNA A CLASSE "SERVIÇO" DIZENDO QUE ESSE CODEC
    //PODE TRABALHAR COM OBJETOS DA CLASSE "SERVIÇO"
    @Override
    public Class<Servico> getEncoderClass() {
        return Servico.class;
    }

    //FAZ A VERIFICAÇÃO SE O OBJETO "SERVIÇO" TEM _ID
    @Override
    public boolean documentHasId(Servico servico) {
        return servico.getId() == null;
    }

    //ESSE MÉTODO RETORNA O VALOR DO _ID DO OBJETO "SERVIÇO" COMO UM 
    //BSONVALUE    
    @Override
    public BsonValue getDocumentId(Servico servico) {
        if (!documentHasId(servico)) {
            throw new IllegalStateException("Esse documento não tem ID");
        } else {
            return new BsonString(servico.getId().toHexString());
        }
    }

    //MÉTODO RESPONSÁVEL POR GERAR UM IDENTIFICADOR PARA O OBJETO "SERVIÇO" 
    //CASO AINDA NÃO TENHA
    @Override
    public Servico generateIdIfAbsentFromDocument(Servico servico) {
        return documentHasId(servico) ? servico.criaId() : servico;
    }

    //MÉTODO RESPONSÁVEL POR CONVERTER UM OBJETO "SERVIÇO" EM UM DOCUMENTO BSON
    //ONDE OS ATRIBUTOS DO OBJETO SÃO MAPEADOS PARA CAMPOS NO DOCUMENTO BSON
    @Override
    public void encode(BsonWriter writer, Servico servico, EncoderContext ec) {

        ObjectId id = servico.getId();
        ObjectId nomeAnimal = servico.getIdAnimal();
        ObjectId nomeFuncionario = servico.getIdFuncionario();
        String descricao = servico.getDescricao();
        String status = servico.getStatus();
        Date data = servico.getData();
        String hora = servico.getHora();

        FuncionarioRepository r = new FuncionarioRepository();
        AnimalRepository a = new AnimalRepository();

        Funcionario fun = new Funcionario();
        fun = r.obterIdProfissional(nomeFuncionario.toString());
        String nomeResponsavel = fun.getNome();

        Animal animal = new Animal();
        animal = a.obterIdAnimal(nomeAnimal.toString());
        String nomedoanimal = animal.getNome();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("id_Animal", nomeAnimal);
        doc.put("id_Funcionario", nomeFuncionario);
        doc.put("nomeAnimal", nomedoanimal);
        doc.put("nomeFuncionario", nomeResponsavel);
        doc.put("descricao", descricao);
        doc.put("status", status);
        doc.put("data", data);
        doc.put("hora", hora);

        codec.encode(writer, doc, ec);

    }

    //ESSE MÉTODO FAZ O PROCESSO INVERSO DO MÉTODO ENCODE
    @Override
    public Servico decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);

        Servico servico = new Servico();
        servico.setId(doc.getObjectId("_id"));
        servico.setIdAnimal(doc.getObjectId("id_Animal"));
        servico.setIdFuncionario(doc.getObjectId("id_Funcionario"));
        servico.setDescricao(doc.getString("descricao"));
        servico.setNomeAnimal(doc.getString("nomeAnimal"));
        servico.setNomeFuncionario(doc.getString("nomeFuncionario"));

        if (doc.getString("status").equals("Feito")) {
            servico.setStatus(doc.getString("status"));
            servico.setHora(doc.getString("hora"));
        } else {
            servico.setStatus(doc.getString("status"));
            servico.setHora("");
        }

        Date data = doc.getDate("data");
        LocalDate localDate = data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        servico.setData(doc.getDate("data"));

        FuncionarioRepository r = new FuncionarioRepository();
        Funcionario fun = r.obterIdProfissional(doc.getObjectId("id_Funcionario").toString());

        AnimalRepository ar = new AnimalRepository();
        Animal animal = ar.obterIdAnimal(doc.getObjectId("id_Animal").toString());

        servico.setFuncionario(fun);
        servico.setAnimal(animal);

        return servico;
    }
}
