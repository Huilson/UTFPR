package br.com.java_mongodb.mongodbSpring.model;

import org.bson.types.ObjectId;

public class Funcionario {

    private ObjectId _id;
    private String nome;
    private String cpf;
    private String cargo;
    private String cidade;
    private String bairro;
    private String rua;

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }
    
    //MÉTODO QUE GERA UM _ID CASO AINDA NÃO TENHA UM
    public Funcionario criaId() {
        setId(new ObjectId());
        return this;
    }

}
