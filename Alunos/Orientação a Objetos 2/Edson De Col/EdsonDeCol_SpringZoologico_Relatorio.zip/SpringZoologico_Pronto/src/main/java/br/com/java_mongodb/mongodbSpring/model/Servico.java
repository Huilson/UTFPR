package br.com.java_mongodb.mongodbSpring.model;

import java.util.Date;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

public class Servico {

    private ObjectId _id;
    private ObjectId idAnimal;
    private ObjectId idFuncionario;
    private String nomeFuncionario;
    private String nomeAnimal;
    private Animal animal;
    private Funcionario funcionario;
    private String descricao;
    private String status;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date data;
    @DateTimeFormat(pattern = "HH:mm:ss")
    private String hora;

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public void setNomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    public ObjectId getIdAnimal() {
        return idAnimal;
    }

    public void setIdAnimal(ObjectId idAnimal) {
        this.idAnimal = idAnimal;
    }

    public ObjectId getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(ObjectId idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Servico criaId() {
        setId(new ObjectId());
        return this;
    }
}
