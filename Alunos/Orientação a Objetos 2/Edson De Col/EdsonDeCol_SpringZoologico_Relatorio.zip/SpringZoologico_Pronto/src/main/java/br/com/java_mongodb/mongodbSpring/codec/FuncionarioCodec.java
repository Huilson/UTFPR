package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Funcionario;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

//CLASSE CODEC PARA CONVERTER OBJETO "FUNCIONARIO" JAVA PARA DOCUMENTOS BSON PRA PODER
//SALVAR EM MONGO E TAMBÉM PARA CONVERTER DO MONGO PARA JAVA
//ANIMLACODEC IMPLEMENTANTO A INTERFACE CollectibleCodec PARA PODER LIDAR
//COM _ID NO MONGO 
public class FuncionarioCodec implements CollectibleCodec<Funcionario> {

    //CODEC PARA CODIFICAR E DECODIFICAR DOCUMENTOS BSON
    private Codec<Document> codec;

    public FuncionarioCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    //MÉTODO QUE RETORNA A CLASSE "FUNCIONARIO" DIZENDO QUE ESSE CODEC
    //PODE TRABALHAR COM OBJETOS DA CLASSE "FUNCIONARIO"
    @Override
    public Class<Funcionario> getEncoderClass() {
        return Funcionario.class;
    }

    //FAZ A VERIFICAÇÃO SE O OBJETO "FUNCIONARIO" TEM _ID
    @Override
    public boolean documentHasId(Funcionario profissional) {
        return profissional.getId() == null;
    }

    //ESSE MÉTODO RETORNA O VALOR DO _ID DO OBJETO "FUNCIONARIO" COMO UM 
    //BSONVALUE
    @Override
    public BsonValue getDocumentId(Funcionario profissional) {
        if (!documentHasId(profissional)) {
            throw new IllegalStateException("Esse documento não tem ID");
        } else {
            return new BsonString(profissional.getId().toHexString());
        }
    }

    //MÉTODO RESPONSÁVEL POR GERAR UM IDENTIFICADOR PARA O OBJETO "FUNCIONARIO" 
    //CASO AINDA NÃO TENHA
    @Override
    public Funcionario generateIdIfAbsentFromDocument(Funcionario profissional) {
        return documentHasId(profissional) ? profissional.criaId() : profissional;
    }

     //MÉTODO RESPONSÁVEL POR CONVERTER UM OBJETO "FUNCIONARIO" EM UM DOCUMENTO BSON
    //ONDE OS ATRIBUTOS DO OBJETO SÃO MAPEADOS PARA CAMPOS NO DOCUMENTO BSON
    @Override
    public void encode(BsonWriter writer, Funcionario profissional, EncoderContext ec) {

        ObjectId id = profissional.getId();
        String nome = profissional.getNome();
        String cpf = profissional.getCpf();
        String cargo = profissional.getCargo();
        String cidade = profissional.getCidade();
        String bairro = profissional.getBairro();
        String rua = profissional.getRua();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("cpf", cpf);
        doc.put("cargo", cargo);
        doc.put("cidade", cidade);
        doc.put("bairro", bairro);
        doc.put("rua", rua);

        codec.encode(writer, doc, ec);

    }
    
   //ESSE MÉTODO FAZ O PROCESSO INVERSO DO MÉTODO ENCODE
    @Override
    public Funcionario decode(BsonReader reader, DecoderContext dc) {

        Document doc = codec.decode(reader, dc);
        Funcionario profissional = new Funcionario();
        profissional.setId(doc.getObjectId("_id"));
        profissional.setNome(doc.getString("nome"));
        profissional.setCpf(doc.getString("cpf"));
        profissional.setCargo(doc.getString("cargo"));
        profissional.setCidade(doc.getString("cidade"));
        profissional.setBairro(doc.getString("bairro"));
        profissional.setRua(doc.getString("rua"));

        return profissional;
    }
}
