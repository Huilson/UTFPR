package br.com.java_mongodb.mongodbSpring.service;

import br.com.java_mongodb.mongodbSpring.model.Servico;
import br.com.java_mongodb.mongodbSpring.repository.servicoRepository;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

@Service
public class ServicoReport {
    
    @Autowired
    private servicoRepository repository;
    
    public String exportaRelatorio (String formato) throws FileNotFoundException, JRException, ParseException{
        List<Servico> servicos = repository.listarServicosDoDia();
        
        //CRIAR E COMPILAR UM ARQUIVO
        
        File arquivo = ResourceUtils.getFile("classpath:relatorio.jrxml");
        JasperReport report = JasperCompileManager.compileReport(arquivo.getAbsolutePath());
        
        //PARÂMETROS DE IMPRESSÃO
        
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("RELATÓRIOS", "EXEMPLO");
        
        //BUSCAR OS DADOS MAPEAR E INSERIR NO ARQUIVO
        
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(servicos);
        
        JasperPrint print = JasperFillManager.fillReport(report, parametros, dataSource);
        
        //CAMINHO DO ARQUIVO
        
        String path = "C:\\Users\\Desktop\\Desktop\\Relatorios";
        
        //TIPO DE SAÍDA
        
        if(formato.equalsIgnoreCase("html")){
            JasperExportManager.exportReportToHtmlFile(print, path + "\\relatorio.html");
        }
        if(formato.equalsIgnoreCase("pdf")){
            JasperExportManager.exportReportToPdfFile(print, path + "\\relatorio.pdf");
        }
        return "relatório gerado em: " + path;
    }
}
