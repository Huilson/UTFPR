package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Animal;
import br.com.java_mongodb.mongodbSpring.model.Funcionario;
import br.com.java_mongodb.mongodbSpring.repository.FuncionarioRepository;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

//CLASSE CODEC PARA CONVERTER OBJETO "ANIMAL" JAVA PARA DOCUMENTOS BSON PRA PODER
//SALVAR EM MONGO E TAMBÉM PARA CONVERTER DO MONGO PARA JAVA
//ANIMLACODEC IMPLEMENTANTO A INTERFACE CollectibleCodec PARA PODER LIDAR
//COM _ID NO MONGO 
public class AnimalCodec implements CollectibleCodec<Animal> {

    //CODEC PARA CODIFICAR E DECODIFICAR DOCUMENTOS BSON
    private Codec<Document> codec;

    public AnimalCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    //MÉTODO QUE RETORNA A CLASSE "ANIMAL" DIZENDO QUE ESSE CODEC
    //PODE TRABALHAR COM OBJETOS DA CLASSE "ANIMAL"
    @Override
    public Class<Animal> getEncoderClass() {
        return Animal.class;
    }

    //FAZ A VERIFICAÇÃO SE O OBJETO "ANIMAL" TEM _ID
    @Override
    public boolean documentHasId(Animal profissional) {
        return profissional.getId() == null;
    }

    //ESSE MÉTODO RETORNA O VALOR DO _ID DO OBJETO "ANIMAL" COMO UM 
    //BSONVALUE
    @Override
    public BsonValue getDocumentId(Animal profissional) {
        if (!documentHasId(profissional)) {
            throw new IllegalStateException("Esse documento não tem ID");
        } else {
            return new BsonString(profissional.getId().toHexString());
        }
    }

    //MÉTODO RESPONSÁVEL POR GERAR UM IDENTIFICADOR PARA O OBJETO "ANIMAL" 
    //CASO AINDA NÃO TENHA
    @Override
    public Animal generateIdIfAbsentFromDocument(Animal animal) {
        return documentHasId(animal) ? animal.criaId() : animal;
    }

    //MÉTODO RESPONSÁVEL POR CONVERTER UM OBJETO "ANIMAL" EM UM DOCUMENTO BSON
    //ONDE OS ATRIBUTOS DO OBJETO SÃO MAPEADOS PARA CAMPOS NO DOCUMENTO BSON
    @Override
    public void encode(BsonWriter writer, Animal animal, EncoderContext ec) {

        ObjectId id = animal.getId();
        String nome = animal.getNome();
        String especie = animal.getEspecie();
        String descricao = animal.getDescricao();
        ObjectId nomeFuncionario = animal.getIdFuncionario();

        FuncionarioRepository r = new FuncionarioRepository();

        Funcionario fun = new Funcionario();
        fun = r.obterIdProfissional(nomeFuncionario.toString());
        String nomeResponsavel = fun.getNome();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("especie", especie);
        doc.put("descricao", descricao);
        doc.put("responsavel", nomeFuncionario);
        doc.put("responsavelNome", nomeResponsavel);

        codec.encode(writer, doc, ec);

    }

    //ESSE MÉTODO FAZ O PROCESSO INVERSO DO MÉTODO ENCODE
    @Override
    public Animal decode(BsonReader reader, DecoderContext dc) {

        Document doc = codec.decode(reader, dc);
        Animal animal = new Animal();
        animal.setId(doc.getObjectId("_id"));
        animal.setNome(doc.getString("nome"));
        animal.setEspecie(doc.getString("especie"));
        animal.setDescricao(doc.getString("descricao"));
        animal.setIdFuncionario(doc.getObjectId("responsavel"));

        FuncionarioRepository r = new FuncionarioRepository();

        Funcionario fun = new Funcionario();
        fun = r.obterIdProfissional((doc.getObjectId("responsavel").toString()));
        animal.setFuncionario(fun);

        return animal;
    }
}
