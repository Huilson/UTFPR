package br.com.java_mongodb.mongodbSpring.repository;

import br.com.java_mongodb.mongodbSpring.codec.ServicoCodec;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Filters.lt;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

//CLASSE REPOSITORY RESPONSÁVEL POR CONVERSAR COM O BANCO MONGODB
//PARA DAR AS INSTRUÇÕES RELACIONADAS A PERSISTENCIA DO OBJETO "SERVIÇO"
//PARA ESTABELECER A CONEXÃO COM A COLLECTION CORRESPONDENTE AO "SERVIÇO"
//NOTAÇÃO RESPONSÁVEL POR DIZER QUE SE TRATA DE UM REPOSITÓRIO DO SPRING
//E PERMITE QUE SEJA GERENCIADA PELO CONTAINER DO SPRING
@Repository
public class servicoRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    //ESSE MÉTODO ESTABELE A CONEXÃO COM O BANCO DE DADOS MONGO
    //E CRIA OS CODECS NECESSÁRIOS, NESSE CADO O CODEC PARA O "SERVIÇO"
    public void conectaServico() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        ServicoCodec servicoCodec = new ServicoCodec(codec);

        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(servicoCodec));

        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("TesteZoo");
    }

    //ESSE MÉTODO É RESPONSÁVEL POR SALVAR UM OBJETO DO TIPO "SERVIÇO" 
    //NO BANCO DE DADOS MONGO, VERIFICA SE O OBJETO JÁ POSSUI UM _ID SE JÁ
    //POSSUI ENTÃO APENAS ATUALIZA, SE NÃO POSSUI ENTÃO CRIA UM NOVO DOCUMENTO
    public void salvarServico(Servico listaServicoDiario) {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("listaServicoDiario", Servico.class);
        if (listaServicoDiario.getId() == null) {
            servicos.insertOne(listaServicoDiario);
        } else {
            servicos.updateOne(Filters.eq("_id", listaServicoDiario.getId()), new Document("$set", listaServicoDiario));
        }
        cliente.close();
    }

    //ESSE MÉTODO RETORNA TODOS OS SERVIÇO QUE ESTÁO CADASTRADOS NA COLECTION "SERVIÇO"
    //EM FORMA DE LISTA, POR MEIO DE UMA CONSULTA NO BANCO E PERCORRENDO COM UM CURSOR
    public List<Servico> listarTodosServicos() {
        conectaServico();
        MongoCollection<Servico> servico = db.getCollection("listaServicoDiario", Servico.class);
        MongoCursor<Servico> resultado = servico.find().iterator();
        List<Servico> servicoLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Servico servicoAux = resultado.next();
            servicoLista.add(servicoAux);
        }
        cliente.close();
        Collections.sort(servicoLista, new Comparator<Servico>() {
            @Override
            public int compare(Servico servico1, Servico servico2) {
                return servico2.getHora().compareTo(servico1.getHora());
            }
        });
        return servicoLista;
    }

    public List<Servico> listarServicosDoDia() throws ParseException {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("listaServicoDiario", Servico.class);
        Date hoje = new Date();

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        String hojeAux = format.format(hoje);

        String inicioAux = hojeAux.substring(0, 10) + "T00:00:00.000+00:00";
        String fimAux = hojeAux.substring(0, 10) + "T23:59:59.999+00:00";

        Date dataInicial;
        Date dataFinal;
        dataInicial = format.parse(inicioAux);
        dataFinal = format.parse(fimAux);

        Bson filtroData = and(gte("data", dataInicial), lt("data", dataFinal));

        MongoCursor<Servico> resultado = servicos.find(filtroData).iterator();
        List<Servico> servicoLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Servico servico = resultado.next();
            servicoLista.add(servico);
        }

        cliente.close();

        Collections.sort(servicoLista, new Comparator<Servico>() {
            @Override
            public int compare(Servico servico1, Servico servico2) {
                return servico2.getHora().compareTo(servico1.getHora());
            }
        });

        return servicoLista;
    }

    //ESSE MÉTODO RETORNA TODOS OS SERVIÇO QUE ESTÁO COM O STATUS = "FEITOS" CADASTRADOS NA COLECTION "SERVIÇO"
    //EM FORMA DE LISTA, POR MEIO DE UMA CONSULTA NO BANCO E PERCORRENDO COM UM CURSOR
    public List<Servico> listarTodosServicosFeitos() {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("listaServicoDiario", Servico.class);
        Bson filtro = eq("status", "Feito");
        MongoCursor<Servico> resultado = servicos.find(filtro).iterator();
        List<Servico> servicoLista = new ArrayList<>();
        while (resultado.hasNext()) {
            Servico servico = resultado.next();
            servicoLista.add(servico);
        }
        cliente.close();
        Collections.sort(servicoLista, new Comparator<Servico>() {
            @Override
            public int compare(Servico servico1, Servico servico2) {
                return servico2.getHora().compareTo(servico1.getHora());
            }
        });
        return servicoLista;
    }

    //ESSE MÉTODO RETORNA TODOS OS SERVIÇO QUE ESTÁO COM O STATUS = "PENDENTES" CADASTRADOS NA COLECTION "SERVIÇO"
    //EM FORMA DE LISTA, POR MEIO DE UMA CONSULTA NO BANCO E PERCORRENDO COM UM CURSOR
    public List<Servico> listarTodosServicosPendentes() {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("listaServicoDiario", Servico.class);
        Bson filtro = eq("status", "Pendente");
        MongoCursor<Servico> resultado = servicos.find(filtro).iterator();
        List<Servico> servicoLista = new ArrayList<>();
        while (resultado.hasNext()) {
            Servico servico = resultado.next();
            servicoLista.add(servico);
        }
        cliente.close();
        Collections.sort(servicoLista, new Comparator<Servico>() {
            @Override
            public int compare(Servico servico1, Servico servico2) {
                return servico2.getHora().compareTo(servico1.getHora());
            }
        });
        return servicoLista;
    }

    //MÉTODO RESPONSÁVEL POR RETORNAR UM "SERVIÇO" DO BANCO DE DADOS COM BASE
    //NO _ID RECEBIDO COMO PARÂMETRO
    public Servico obterIdServico(String id) {
        conectaServico();
        MongoCollection<Servico> alunos = db.getCollection("listaServicoDiario", Servico.class);
        Servico aluno = alunos.find(Filters.eq("_id", new ObjectId(id))).first();
        return aluno;
    }

    public void atualizarServico(String id, Servico servico) {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("listaServicoDiario", Servico.class);
        servicos.updateOne(Filters.eq("_id", new ObjectId(id)),
                new Document("$set",
                        new Document("nomeAnimal", servico.getIdAnimal())
                                .append("nomeFuncionario", servico.getIdFuncionario())
                                .append("descricao", servico.getDescricao())
                                .append("status", servico.getStatus())
                                .append("data", servico.getData())
                                .append("hora", servico.getHora())
                )
        );
    }

    //MÉTODO RESPONSÁVEL POR BUSCAR UM SERVIÇO NO BANCO COM BASE
    //NO _ID RECEBIDO POR PARÂMETRO E EXCLUÍ-LO ASSIM QUE ENCONTRADO
    public void excluirServico(String id) {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("listaServicoDiario", Servico.class);
        servicos.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
}
