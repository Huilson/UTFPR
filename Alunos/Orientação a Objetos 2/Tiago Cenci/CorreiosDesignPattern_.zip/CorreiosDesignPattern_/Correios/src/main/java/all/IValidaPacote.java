package all;

public interface IValidaPacote {

    void validarPacote(Pacote pacote);
}
