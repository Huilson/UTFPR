package all;

import java.util.Scanner;

public class ValidaRemetenteExiste implements IValidaPacote {

    private IValidaPacote proximo;

    @Override
    public void validarPacote(Pacote pacote) {
        if (pacote.getNomeRemetente() != null
                && pacote.getEnderecoRemetente() != null) {
            if (proximo != null) {
                proximo.validarPacote(pacote);
            }
        } else {
            Scanner sc1 = new Scanner(System.in);
            System.out.println("Pacote " + pacote.getId() + " reprovado pela não existência do remetente!");
            System.out.println("Deseja informar"
                    + "do pacote? (sim/nao)");
            String escolha = sc1.nextLine();
            if (escolha.toLowerCase().equals("sim")) {
                pacote.setPago(true);
                validarPacote(pacote);
            } else {
                System.out.println("Pacote" + pacote.getId() + " reprovado!");
            }
        }
    }

    public void setProximo(IValidaPacote proximo) {
        this.proximo = proximo;
    }
}
