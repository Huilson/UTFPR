package all;

public class Pacote {

    private long id;
    private String nomeRemetente;
    private String enderecoRemetente;
    private String nomeDestinatario;
    private String enderecoDestinatario;
    private boolean pago;

//    public Pacote(String nomeEmissor, String enderecoEmissor, String nomeDestinatario, String enderecoDestinatario, boolean pago) {
//        this.nomeRemetente = nomeEmissor;
//        this.enderecoRemetente = enderecoEmissor;
//        this.nomeDestinatario = nomeDestinatario;
//        this.enderecoDestinatario = enderecoDestinatario;
//        this.pago = pago;
//    }
    public Pacote() {
    }

    public String getNomeRemetente() {
        return nomeRemetente;
    }

    public void setNomeRemetente(String nomeRemetente) {
        this.nomeRemetente = nomeRemetente;
    }

    public String getEnderecoRemetente() {
        return enderecoRemetente;
    }

    public void setEnderecoRemetente(String enderecoRemetente) {
        this.enderecoRemetente = enderecoRemetente;
    }

    public String getNomeDestinatario() {
        return nomeDestinatario;
    }

    public void setNomeDestinatario(String nomeDestinatario) {
        this.nomeDestinatario = nomeDestinatario;
    }

    public String getEnderecoDestinatario() {
        return enderecoDestinatario;
    }

    public void setEnderecoDestinatario(String enderecoDestinatario) {
        this.enderecoDestinatario = enderecoDestinatario;
    }

    public boolean isPago() {
        return pago;
    }

    public void setPago(boolean pago) {
        this.pago = pago;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

}
