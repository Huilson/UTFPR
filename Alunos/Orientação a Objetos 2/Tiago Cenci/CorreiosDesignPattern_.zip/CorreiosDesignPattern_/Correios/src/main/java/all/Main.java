package all;

public class Main {

    public static void main(String[] args) {
        ValidaTaxa validaTaxa = new ValidaTaxa();
        ValidaRemetenteExiste validaRemetenteExiste = new ValidaRemetenteExiste();
        ValidaDestinatarioExistente validaDestinatarioExistente = new ValidaDestinatarioExistente();

        validaTaxa.setProximo(validaRemetenteExiste);
        validaRemetenteExiste.setProximo(validaDestinatarioExistente);

        //Pacote com todos os dados corretos
        Pacote pacote1 = new Pacote();
        pacote1.setId(1);
        pacote1.setNomeRemetente("Tiago");
        pacote1.setEnderecoRemetente("Rua 1");
        pacote1.setNomeDestinatario("João");
        pacote1.setEnderecoDestinatario("Rua 2");
        pacote1.setPago(true);

        //Pacote sem pagar a taxa
        Pacote pacote2 = new Pacote();
        pacote2.setId(2);
        pacote2.setNomeRemetente("Tiago");
        pacote2.setEnderecoRemetente("Rua 1");
        pacote2.setNomeDestinatario("João");
        pacote2.setEnderecoDestinatario("Rua 2");

        //Pacote sem remetente
        Pacote pacote3 = new Pacote();
        pacote3.setId(3);
        pacote3.setEnderecoRemetente("Rua 1");
        pacote3.setNomeDestinatario("João");
        pacote3.setEnderecoDestinatario("Rua 2");
        pacote3.setPago(true);

        //Pacote sem destinatario
        Pacote pacote4 = new Pacote();
        pacote4.setId(4);
        pacote4.setNomeRemetente("Tiago");
        pacote4.setEnderecoRemetente("Rua 1");
        pacote4.setNomeDestinatario("João");
        pacote4.setPago(true);

        System.out.println("VALIDANDO PACOTE 1:");
        validaTaxa.validarPacote(pacote1);

        System.out.println("VALIDANDO PACOTE 2:");
        validaTaxa.validarPacote(pacote2);

        System.out.println("VALIDANDO PACOTE 3:");
        validaTaxa.validarPacote(pacote3);

        System.out.println("VALIDANDO PACOTE 4:");
        validaTaxa.validarPacote(pacote4);
    }
}
