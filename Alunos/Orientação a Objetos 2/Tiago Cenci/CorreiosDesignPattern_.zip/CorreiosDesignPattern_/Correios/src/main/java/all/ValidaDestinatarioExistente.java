package all;

public class ValidaDestinatarioExistente implements IValidaPacote {

    private IValidaPacote proximo;

    @Override
    public void validarPacote(Pacote pacote) {
        if (pacote.getNomeDestinatario() != null
                && pacote.getEnderecoDestinatario() != null) {
            System.out.println("Pacote " + pacote.getId() + " aprovado!");
        } else {
            System.out.println("Pacote reprovado pela não existência do destinatário!");
        }
    }

    public void setProximo(IValidaPacote proximo) {
        this.proximo = proximo;
    }
}
