package all;

import java.util.Scanner;

public class ValidaTaxa implements IValidaPacote {

    private IValidaPacote proximo;

    @Override
    public void validarPacote(Pacote pacote) {
        if (pacote.isPago()) {
            if (proximo != null) {
                proximo.validarPacote(pacote);
            }
        } else {
            Scanner sc1 = new Scanner(System.in);
            System.out.println("Pacote " + pacote.getId() + " reprovado pelo não pagamento da "
                    + "taxa de transporte!");
            System.out.println("Deseja pagar a taxa e continuar com o envio"
                    + "do pacote? (sim/nao)");
            String escolha = sc1.nextLine();
            if (escolha.toLowerCase().equals("sim")) {
                pacote.setPago(true);
                validarPacote(pacote);
            } else {
                System.out.println("Pacote" + pacote.getId() + " reprovado!");
            }
        }
    }

    public void setProximo(IValidaPacote proximo) {
        this.proximo = proximo;
    }
}
