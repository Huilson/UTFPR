package br.com.java_mongodb.mongodbSpring.repository;

import br.com.java_mongodb.mongodbSpring.codec.ServicoCodec;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ServicoRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    public void conecta() {
        // Instanciar um codec
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry().get(Document.class);

        // Qual classe irá sofrer o encode/decode
        ServicoCodec servicoCodec = new ServicoCodec(codec);

        // Instanciar um registro para o codec
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(servicoCodec)
        );

        // Criar as opções do cliente MongoDB
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro)
                .build();

        // Conectar ao cliente MongoDB e obter a referência ao banco de dados
        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("Zoologico");
    }

    public void salvar(Servico servico) {
        conecta();
        MongoCollection<Servico> servicos = db.getCollection("servico", Servico.class);
        if (servico.get_id() == null) {
            servicos.insertOne(servico);
        } else {
            servicos.updateOne(Filters.eq("_id", servico.get_id()), new Document("$set", servico));
        }
        cliente.close();
    }

    public List<Servico> listarTodos() {
        conecta();
        MongoCollection<Servico> servicos = db.getCollection("servico", Servico.class);
        MongoCursor<Servico> resultado = servicos.find().iterator();
        List<Servico> servicosLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Servico servico = resultado.next();
            servicosLista.add(servico);
        }
        cliente.close();
        return servicosLista;
    }

    public List<Servico> filtrar(String descricao) {
        conecta();
        MongoCollection<Servico> servicos = db.getCollection("servico", Servico.class);
        MongoCursor<Servico> resultado = servicos.find(Filters.eq("descricao", descricao)).iterator();
        List<Servico> servicosLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Servico servico = resultado.next();
            servicosLista.add(servico);
        }
        cliente.close();
        return servicosLista;
    }

    public Servico obterId(String id) {
        conecta();
        MongoCollection<Servico> servicos = db.getCollection("servico", Servico.class);
        Servico servico = servicos.find(Filters.eq("_id", new ObjectId(id))).first();
        cliente.close();
        return servico;
    }

    public void excluir(String id) {
        conecta();
        MongoCollection<Servico> servicos = db.getCollection("servico", Servico.class);
        servicos.deleteOne(Filters.eq("_id", new ObjectId(id)));
        cliente.close();
    }
}
