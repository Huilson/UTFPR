package br.com.java_mongodb.mongodbSpring.controller;

import br.com.java_mongodb.mongodbSpring.model.Animal;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import br.com.java_mongodb.mongodbSpring.repository.AnimalRepository;
import br.com.java_mongodb.mongodbSpring.repository.ServicoRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class ServicoController {

    @Autowired
    ServicoRepository repository;

    @Autowired
    AnimalRepository animalRepository;

    @GetMapping("/servico/cadastrar")
    public String cadastrar(Model model) {
        model.addAttribute("servico", new Servico());
        model.addAttribute("animais", animalRepository.listarTodos()); // Adiciona a lista de animais ao modelo
        return "servico/cadastrar";
    }

    @PostMapping("/servico/salvar")
    public String salvar(@ModelAttribute Servico servico) {
        System.out.println("Data do Serviço: " + servico.getDataServico());
        repository.salvar(servico);
        return "redirect:/";
    }

    @GetMapping("/servico/listar")
    public String listar(Model model) {
        List<Servico> servicos = repository.listarTodos();
        model.addAttribute("servicos", servicos);
        return "servico/listar";
    }

    @GetMapping("/servico/filtrar/{nome}")
    public String filtrar(Model model, @PathVariable String nome) {
        List<Servico> servicos = repository.filtrar(nome);
        model.addAttribute("servicos", servicos);
        return "servico/listar";
    }

    @GetMapping("/servico/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model) {
        Servico servico = repository.obterId(id);
        model.addAttribute("servico", servico);
        model.addAttribute("animais", animalRepository.listarTodos()); // Adiciona a lista de animais ao modelo
        return "servico/visualizar";
    }

    @GetMapping("/servico/excluir/{id}")
    public String excluir(@PathVariable String id) {
        repository.excluir(id);
        return "redirect:/servico/listar";
    }

    @GetMapping("/servico/atualizar/{id}")
    public String atualizar(@PathVariable String id, Model model) {
        Servico servico = repository.obterId(id);
        model.addAttribute("servico", servico);
        model.addAttribute("animais", animalRepository.listarTodos());
        return "servico/atualizar";
    }

    @PostMapping("/servico/update/{id}")
    public String update(@ModelAttribute Servico servico, @PathVariable String id) {
        ObjectId _id = new ObjectId(id);
        servico.set_id(_id);
        repository.salvar(servico);
        return "redirect:/";
    }
}
