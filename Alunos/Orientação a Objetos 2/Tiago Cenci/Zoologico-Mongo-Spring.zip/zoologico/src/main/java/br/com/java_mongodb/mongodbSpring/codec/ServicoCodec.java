package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Animal;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import br.com.java_mongodb.mongodbSpring.repository.AnimalRepository;
import org.bson.*;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ServicoCodec implements CollectibleCodec<Servico> {

    private Codec<Document> codec;

    public ServicoCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Servico> getEncoderClass() {
        return Servico.class;
    }//Esse metodo diz qual classe será codificada

    @Override
    public boolean documentHasId(Servico Servico) {
        return Servico.get_id() == null;
    }//Esse metodo só verifica se o objeto chamado tem ID

    @Override
    public BsonValue getDocumentId(Servico Servico) {
        if (!documentHasId(Servico))//Verifica se o ID foi criado
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else//Para que o ID possa ser lido é preciso converter para a base hexadecimal
        {
            return new BsonString(Servico.get_id().toHexString());
        }
    }

    @Override
    public Servico generateIdIfAbsentFromDocument(Servico Servico) {
        return documentHasId(Servico) ? Servico.criaId() : Servico;
    }

    @Override
    public void encode(BsonWriter writer, Servico servico, EncoderContext ec) {
        ObjectId id = servico.get_id();
        String descricao = servico.getDescricao();
        String profissional = servico.getProfissional();
        LocalDateTime dataServico = servico.getDataServico();
        Boolean realizado = servico.isRealizado();
        ObjectId animal = servico.getAnimal();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("descricao", descricao);
        doc.put("profissional", profissional);
        if (dataServico != null) {
            Instant instant = dataServico.atZone(ZoneId.systemDefault()).toInstant();
            doc.put("dataServico", Date.from(instant));
        }
        doc.put("realizado", realizado);
        doc.put("animal", animal);

        codec.encode(writer, doc, ec);
    }

    @Override
    public Servico decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Servico servico = new Servico();
        servico.set_id(doc.getObjectId("_id"));
        servico.setDescricao(doc.getString("descricao"));
        servico.setProfissional(doc.getString("profissional"));

        Date dataServico = doc.getDate("dataServico");
        if (dataServico != null) {
            Instant instant = dataServico.toInstant();
            LocalDateTime localDateTime = instant.atZone(ZoneId.systemDefault()).toLocalDateTime();
            servico.setDataServico(localDateTime);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            String dataFormatada = localDateTime.format(formatter);
            servico.setDataServicoFormatada(dataFormatada);
        }


        servico.setRealizado(doc.getBoolean("realizado"));
        ObjectId animalId = doc.getObjectId("animal");
        servico.setAnimal(animalId);

        AnimalRepository animalRepository = new AnimalRepository();
        Animal animal = animalRepository.obterId(animalId.toString());

        if (animal != null) {
            servico.setNomeAnimal(animal.getNome());
        }

        return servico;
    }



}
