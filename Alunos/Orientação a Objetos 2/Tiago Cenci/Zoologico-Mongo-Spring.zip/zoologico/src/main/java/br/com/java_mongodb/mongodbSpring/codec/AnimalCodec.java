package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Animal;
import br.com.java_mongodb.mongodbSpring.model.Servico;
import org.bson.*;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AnimalCodec implements CollectibleCodec<Animal> {

    private Codec<Document> codec;

    public AnimalCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Animal> getEncoderClass() {
        return Animal.class;
    }//Esse metodo diz qual classe será codificada

    @Override
    public boolean documentHasId(Animal animal) {
        return animal.get_id() == null;
    }//Esse metodo só verifica se o objeto chamado tem ID

    @Override
    public BsonValue getDocumentId(Animal animal) {
        if (!documentHasId(animal))//Verifica se o ID foi criado
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else//Para que o ID possa ser lido é preciso converter para a base hexadecimal
        {
            return new BsonString(animal.get_id().toHexString());
        }
    }

    @Override
    public Animal generateIdIfAbsentFromDocument(Animal animal) {
        return documentHasId(animal) ? animal.criaId() : animal;
    }

    @Override
    public void encode(BsonWriter writer, Animal animal, EncoderContext ec) {
        ObjectId id = animal.get_id();
        String nome = animal.getNome();
        String profissional = animal.getProfissional();
        String especie = animal.getEspecie();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("profissional", profissional);
        doc.put("especie", especie);

        codec.encode(writer,doc,ec);
    }

    @Override
    public Animal decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Animal animal = new Animal();
        animal.set_id(doc.getObjectId("_id"));
        animal.setNome(doc.getString("nome"));
        animal.setProfissional(doc.getString("profissional"));
        animal.setEspecie(doc.getString("especie"));

        return animal;
    }
}
