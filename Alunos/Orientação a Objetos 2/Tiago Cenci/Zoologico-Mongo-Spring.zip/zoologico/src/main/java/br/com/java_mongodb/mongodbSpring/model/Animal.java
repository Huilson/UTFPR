package br.com.java_mongodb.mongodbSpring.model;

import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;

public class Animal {
    private ObjectId _id;
    private String nome;
    private String profissional;
    private String especie;

    public Animal() {
    }

    public ObjectId get_id() {
        return _id;
    }

    public void set_id(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfissional() {
        return profissional;
    }

    public void setProfissional(String profissional) {
        this.profissional = profissional;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }
    public Animal criaId() {
        set_id(new ObjectId());
        return this;
    }


}
