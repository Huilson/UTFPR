package br.com.java_mongodb.mongodbSpring.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Date;

public class Servico {
    private ObjectId _id;
    private String descricao;
    private String profissional;
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") // Define o padrão de formatação da data e hora
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm") // Define o padrão de serialização para JSON
    private LocalDateTime dataServico;
    private String dataServicoFormatada;
    private boolean realizado;
    private ObjectId animal;

    private String nomeAnimal;
    public Servico() {
    }

    public Servico(ObjectId _id, String descricao, String profissional, LocalDateTime dataServico, boolean realizado, ObjectId animal) {
        this._id = _id;
        this.descricao = descricao;
        this.profissional = profissional;
        this.dataServico = dataServico;
        this.realizado = realizado;
        this.animal = animal;
    }

    public String getDataServicoFormatada() {
        return dataServicoFormatada;
    }

    public void setDataServicoFormatada(String dataServicoFormatada) {
        this.dataServicoFormatada = dataServicoFormatada;
    }

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public void setNomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    public ObjectId getAnimal() {
        return animal;
    }

    public void setAnimal(ObjectId animal) {
        this.animal = animal;
    }

    public ObjectId get_id() {
        return _id;
    }

    public void set_id(ObjectId _id) {
        this._id = _id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getProfissional() {
        return profissional;
    }

    public void setProfissional(String profissional) {
        this.profissional = profissional;
    }

    public LocalDateTime getDataServico() {
        return dataServico;
    }

    public void setDataServico(LocalDateTime dataServico) {
        this.dataServico = dataServico;
    }

    public boolean isRealizado() {
        return realizado;
    }

    public void setRealizado(boolean realizado) {
        this.realizado = realizado;
    }

    public Servico criaId() {
        set_id(new ObjectId());
        return this;
    }
}
