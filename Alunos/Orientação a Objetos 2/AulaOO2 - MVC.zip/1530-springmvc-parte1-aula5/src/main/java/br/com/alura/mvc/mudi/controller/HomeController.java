package br.com.alura.mvc.mudi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import br.com.alura.mvc.mudi.model.Pedido;
import br.com.alura.mvc.mudi.repository.PedidoRepository;
import br.com.alura.mvc.mudi.service.PedidoService;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/home")
public class HomeController {

    @Autowired
    private PedidoRepository repository;

    @Autowired
    private PedidoService service;

    @GetMapping
    public String home(Model model) {
        List<Pedido> pedidos = repository.findAll();
        model.addAttribute("pedidos", pedidos);
        return "home";
    }

    @PostMapping("salvar")
    public String salvar(@ModelAttribute("pedido") Pedido pedido) {
        repository.save(pedido);
        return "redirect:/home";
    }

    @GetMapping("/formularioAtualizado/{id}")
    public String formularioAtualizado(@PathVariable(value = "id") String id, Model model) {
        Pedido pedido = service.getPedidoById(id);
        model.addAttribute("pedido", pedido);
        return "formulario_atualiza";
    }
    
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable (value="id") String id){
        service.deletePedidoById(id);
        return "redirect:/home";
    }
}