package br.com.alura.mvc.mudi.service;

import br.com.alura.mvc.mudi.model.Pedido;
import br.com.alura.mvc.mudi.repository.PedidoRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PedidoService {

    @Autowired
    PedidoRepository pedidoRepository;

    public Pedido getPedidoById(String id) {
        Optional<Pedido> op = pedidoRepository.findById(id);
        Pedido pedido = null;
        if (op.isPresent()) {
            pedido = op.get();
        } else {
            throw new RuntimeException("Pedido não encontrado, o id: " + id + " não foi encontrado.");
        }
        return pedido;
    }
    
    public void deletePedidoById(String id){
        pedidoRepository.deleteById(id);        
    }
}
