/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula1oo2;

import java.util.Scanner;
        
public class Menu {

    Scanner scan = new Scanner(System.in);
    int op = scan.nextInt();
    switch(scan){
        case 1:
            System.out.println("Acessar cadastro do animal");
            break;
        case 2:
            System.out.println("Acessar cadastro da pessoa");
            break;
        case 3:
            System.out.println("Acessar gerenciamento do hotel");
            break;
}
            }