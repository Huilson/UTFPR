package com.mycompany.aula1oo2;

public class Cachorro extends Animal {

    public Cachorro(String nome, int idade, String especie, int codigo) {
        this.nome = nome;
        this.especie = "Cachorro";
        this.idade = idade;
        this.especie = especie;
        this.codigo = codigo;
    }  
}