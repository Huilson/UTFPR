/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.aula1oo2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author User
 */
public class Aula1OO2 {

    private static Animal encontrarAnimalPorCodigo(int codigo, Map<String, List<Animal>> andares) {
        for (List<Animal> animaisNoAndar : andares.values()) {
            for (Animal animal : animaisNoAndar) {
                if (animal.getCodigo() == codigo) {
                    return animal;
                }
            }
        }
        return null;
    }

    Map<String, List<Animal>> andares = new HashMap<>(); //map de animais
    List<Pessoas> pessoas = new ArrayList<>(); // lista de pessoas
    List<Map<String, Object>> despesas = new ArrayList<>(); // lista de despesas

    public Aula1OO2() {

        andares.put("Andar1", new ArrayList<>()); //cria os andares
        andares.put("Andar2", new ArrayList<>());
        andares.put("Andar3", new ArrayList<>());
    }

    public void checkIn(Animal animal, String andar) {
        List<Animal> animaisNoAndar = andares.getOrDefault(andar, new ArrayList<>());// Verifica se o andar já possui uma lista de animais, caso contrário, inicializa uma nova lista.
        animaisNoAndar.add(animal);// Adiciona o animal à lista de animais do andar.
        andares.put(andar, animaisNoAndar);// Atualiza o mapa de andares com a nova lista de animais.
    }

    public void checkOut(Animal animal, String andar) {
        andares.get(andar).remove(animal);//puxa os dados do animal conforme andar e retira ele
    }

    public void addDespesa(String descricao, double valor) {
        Map<String, Object> despesa = new HashMap<>(); //cria um map de despesas
        despesa.put("descricao", descricao);
        despesa.put("valor", valor);
        despesas.add(despesa);
    }

    public static void addPessoa(List<Map<String, Object>> pessoasLista, Pessoas pessoa) {
        Map<String, Object> pessoaMap = new HashMap<>();
        pessoaMap.put("nome", pessoa.getNome());
        pessoaMap.put("documento", pessoa.getDocumento());

    }

    public void listarAnimais() {
        for (String andar : andares.keySet()) {//laço de repeticao por cada andar
            System.out.println("Animais no " + andar + ":");
            for (Animal animal : andares.get(andar)) { //laço de repetição dentro do outro for, para visualizar cada animal dentro de cada andar
                System.out.println(animal.nome + " - " + animal.especie + " - id: "+ animal.codigo);
            }
        }
    }

    public void listarPessoas() {
        for (Pessoas pessoa : pessoas) { //laço de repetição que irá percorrer por todas as pessoas, e logo abaixo irá apresentar cada uma delas
            System.out.println(pessoa.nome + " - " + pessoa.documento);
        }
    }

    public void listarDespesas() {
        for (Map<String, Object> despesa : despesas) {//laço de repetição que irá passar por todo o map de despesas, e dentro dele fará a apresentação de cada uma delas.
            System.out.println(despesa.get("descricao") + " - R$" + String.format("%.2f", despesa.get("valor")));
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Aula1OO2 hotel = new Aula1OO2();

        while (true) {//para que o menu fique sempre repetindo automaticamente
            System.out.println("\nMenu:");
            System.out.println("1. Check-in Pet");
            System.out.println("2. Check-out Pet");
            System.out.println("3. Adicionar despesa");
            System.out.println("4. Listar animais");
            System.out.println("5. Listar pessoas");
            System.out.println("6. Listar despesas");
            System.out.println("7. Sair");
            System.out.println("8. Adicionar Pessoas");

            System.out.print("Escolha uma opção: ");
            String escolha = scanner.nextLine();

            switch (escolha) {
                case "1": //operação de check-in
                    Set<Integer> idsUsados = new HashSet<>();
                    System.out.print("Nome do animal: ");
                    String nome = scanner.nextLine(); //solicita o nome do animal
                    System.out.print("Espécie do animal: ");
                    String especie = scanner.nextLine(); //solicita a espécie do animal
                    System.out.print("Idade do animal: ");
                    int idade = Integer.parseInt(scanner.nextLine()); //solicita a idade do animal
                    System.out.print("Andar de acomodação(1 a 3): ");
                    String andar = scanner.nextLine(); //solicita o andar de acomodação
                    int codigo;  
                    do {
                    System.out.print("Código do pet: ");
                    codigo = Integer.parseInt(scanner.nextLine());
                    } while (idsUsados.contains(codigo)); // Verifica se o ID já foi usado

                    idsUsados.add(codigo); // Adiciona o ID usado ao conjunto

                    System.out.println("ID do Pet: " + codigo);
  
                    Animal animal = null; // Crie um objeto Animal válido

                    //condições para criar um objeto Animal com base na espécie informada
                    if (especie.equalsIgnoreCase("cachorro")) {
                        System.out.print("Raça do cachorro: ");
                        String raca = scanner.nextLine();
                        animal = new Cachorro(nome, idade, raca, codigo);
                    } else if (especie.equalsIgnoreCase("gato")) {
                        System.out.print("Qual a cor do gato? ");
                        String pelagem = scanner.nextLine();
                        animal = new Gato(nome, idade, especie, pelagem, codigo);

                      } else if (especie.equalsIgnoreCase("passaro")) {
                        System.out.print("Cor do pássaro: ");
                        String cor = scanner.nextLine();
                        animal = new Passaro(nome, idade, cor, codigo);
                    } else {
                        System.out.println("Espécie não suportada.");
                        continue; //se a espécie não for suportada, pula para a próxima iteração do loop
                    }

                    hotel.checkIn(animal, andar); //realiza o check-in para o animal e andar especificados

                    System.out.println(animal.nome + " foi feito o check-in no " + andar + ".");
                    break;

                case "2": // Operação de checkout
                    System.out.print("Nome do animal: ");
                    String nomeAnimal = scanner.nextLine(); // Solicita o nome do animal a ser feito o check-out
                    System.out.print("Andar de acomodação: ");
                    String andarCheckOut = scanner.nextLine(); // Solicita o andar de acomodação

                    boolean encontrado = false; // Variável para rastrear se o animal foi encontrado no andar

                    // Percorre a lista de animais no andar especificado para encontrar o animal pelo nome
                    for (Animal animalNoAndar : hotel.andares.get(andarCheckOut)) {
                        if (animalNoAndar.nome.equals(nomeAnimal)) { // Verifica se o nome corresponde
                            hotel.checkOut(animalNoAndar, andarCheckOut); // Realiza o check-out para o animal e andar especificados
                            System.out.println(animalNoAndar.nome + " foi feito o check-out do " + andarCheckOut + ".");
                            encontrado = true; // Marca que o animal foi encontrado
                            break; // Sai do loop, pois o check-out foi realizado
                        }
                    }

                    if (!encontrado) { // Se o animal não foi encontrado
                        System.out.println(nomeAnimal + " não foi encontrado no " + andarCheckOut + ".");
                    }
                    break;

                case "3"://cadastro de despesas
                    System.out.print("Descrição da despesa: ");
                    String descricao = scanner.nextLine();//solicitação para a descrição de despesas
                    System.out.print("Valor da despesa: ");
                    double valor = Double.parseDouble(scanner.nextLine());//converte para que a entrada seja do tipo double
                    hotel.addDespesa(descricao, valor);//adciiona descricao e valor para hotel
                    System.out.println("Despesa '" + descricao + "' no valor de R$" + String.format("%.2f", valor) + " foi adicionada.");
                    break;

                case "4"://listar animais
                    hotel.listarAnimais();//chama a função existente
                    break;

                case "5"://listar pessoas
                    hotel.listarPessoas();//puxa a lista de pessoas
                    break;

                case "6"://listar despesas
                    hotel.listarDespesas();//puxa a lista (map) de despesas
                    break;

                case "7":
                    System.out.println("Encerrando o programa.");
                    scanner.close();
                    System.exit(0);
                    break;

                case "8":
                    System.out.println("Criando pessoa");
                    System.out.print("Nome da pessoa: ");
                    String nomePessoa = scanner.nextLine();
                    System.out.print("Documento da pessoa: ");
                    String documentoPessoa = scanner.nextLine();

                    System.out.println("Escolha o tipo de pessoa:");
                    System.out.println("1. Tutor");
                    System.out.println("2. Funcionário");
                    System.out.print("Escolha (1/2): ");
                    int tipoPessoa = Integer.parseInt(scanner.nextLine());

                    Pessoas novaPessoa = null;

                    if (tipoPessoa == 1) {
                        System.out.print("Código do animal do tutor: ");
                        int CodigoA = Integer.parseInt(scanner.nextLine());
                        Animal animalTutor = encontrarAnimalPorCodigo(CodigoA, hotel.andares);
                        novaPessoa = new Tutor(nomePessoa, documentoPessoa, animalTutor);
                    } else if (tipoPessoa == 2) {
                        System.out.print("Cargo do funcionário: ");
                        String cargoPessoa = scanner.nextLine();
                        novaPessoa = new Funcionario(nomePessoa, documentoPessoa, cargoPessoa);
                    } else {
                        System.out.println("Não Encontrado");
                    }

                    hotel.pessoas.add(novaPessoa);
                    System.out.println("Pessoa adicionada com sucesso.");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}
