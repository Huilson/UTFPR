/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.turma.salaDeAula.codec.CodecTutor;
import com.turma.salaDeAula.model.Tutor;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class TutorRepository {

    public MongoDatabase connect() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry().get(Document.class);
        CodecTutor tutorCodec = new CodecTutor(codec);

        CodecRegistry registry = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(tutorCodec)
        );

        MongoClientOptions options = MongoClientOptions.builder().codecRegistry(registry).build();
        MongoClient client = new MongoClient("localhost:27017", options);

        MongoDatabase db = client.getDatabase("Aula"); //
        return db;
    }

    public void salvar(Tutor tutor) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);

        if (tutor.getId() == null) {
            tutors.insertOne(tutor);
        } else {
            tutors.updateOne(Filters.eq("_id", tutor.getId()), new Document("$set", tutor));
        }
    }

    public List<Tutor> listarTodos() {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        MongoCursor<Tutor> result = tutors.find().iterator();

        List<Tutor> tutorList = new ArrayList<>();

        while (result.hasNext()) {
            Tutor tutor = result.next();
            tutorList.add(tutor);
        }

        return tutorList;
    }

    public Tutor pesquisaPorId(String id) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        Tutor tutor = tutors.find(Filters.eq("_id", new ObjectId(id))).first();
        return tutor;
    }

    public void excluir(String id) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        tutors.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }

}
