/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.types.ObjectId;

public class Animal {

    private ObjectId id;
    private String nome;
    private String especie;
    private String tipo;
    private List<Date> entradas;

    public Animal(String nome, String especie, String tipo, List<Date> entradas) {

        this.nome = nome;
        this.especie = especie;
        this.tipo = tipo;
        this.entradas = entradas;
    }

    public Animal() {

    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public List<Date> getEntradas() {
        if (entradas == null) {
            entradas = new ArrayList<Date>();
        }

        return entradas;
    }

    public void setEntradas(List<Date> entradas) {
        this.entradas = entradas;
    }

}
