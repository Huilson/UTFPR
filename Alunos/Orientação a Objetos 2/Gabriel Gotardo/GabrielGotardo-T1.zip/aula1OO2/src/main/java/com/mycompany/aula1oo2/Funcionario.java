/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula1oo2;

/**
 *
 * @author User
 */
class Funcionario extends Pessoas {
    private String cargo;

    public Funcionario(String nome, String documento, String cargo) {
        this.nome = nome;
        this.documento = documento;
        this.cargo = cargo; // Adicionar o cargo ao construtor
    }

    // Getter para o cargo
    public String getCargo() {
        return cargo;
    }
}


