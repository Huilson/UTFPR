/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula1oo2;

/**
 *
 * @author User
 */
public class Gato extends Animal {

    private final String pelagem;

    public Gato(String nome, int idade, String especie, String pelagem, int codigo) {
        this.nome = nome;
        this.especie = "Gato";
        this.idade = idade;
        this.especie = especie;
        this.pelagem = pelagem;
        this.codigo = codigo;
    }
}

