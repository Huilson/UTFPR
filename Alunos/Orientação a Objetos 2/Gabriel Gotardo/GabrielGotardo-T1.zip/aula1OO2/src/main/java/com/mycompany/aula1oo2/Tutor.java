/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula1oo2;

/**
 *
 * @author User
 */
class Tutor extends Pessoas {
    private Animal pet;
    private int codPet; // Adicionando o campo codPet

    public Tutor(String nome, String documento, Animal pet, int codPet) {
        this.nome = nome;
        this.documento = documento;
        this.pet = pet;
        this.codPet = codPet; // Inicializando o campo codPet
    }

    public Animal getPet() {
        return pet;
    }

    public void setPet(Animal pet) {
        this.pet = pet;
    }

    public int getCodPet() {
        return codPet;
    }

    public void setCodPet(int codPet) {
        this.codPet = codPet;
    }
}

