package com.mycompany.aula1oo2;


import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Sorts;
import java.util.Arrays;
import org.bson.Document;
import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;
import org.bson.types.ObjectId;

public class Aula1OO2 {
    public MongoClient mongoClient = new MongoClient("localhost", 27017);
    public MongoDatabase db = mongoClient.getDatabase("hotelpet");
    public MongoCollection<Document> pet = db.getCollection("animais");
    public MongoCollection<Document> despesas = db.getCollection("despesas");
    public MongoCollection<Document> pessoas = db.getCollection("pessoas");
    public Set<Integer> idsUsados = new HashSet<>();
    public Scanner scanner = new Scanner(System.in);

   public void checkIn(String nome, String especie, int idade, String andar) {
    int codigo;

    // Solicitar que o usuário digite o código do pet
    do {
        System.out.print("Digite o código do pet: ");
        codigo = Integer.parseInt(scanner.nextLine());

        if (idsUsados.contains(codigo)) {
            System.out.println("Código utilizado, escolha outro.");
        }
    } while (idsUsados.contains(codigo));

    Animal animal = null;

    if (!Arrays.asList("cachorro", "gato", "passaro").contains(especie.toLowerCase())) {
        System.out.println("Espécie não suportada.");
        return;
    }

    if (idade < 0) {
        System.out.println("Idade não pode ser negativa.");
        return;
    }

    if (especie.equalsIgnoreCase("cachorro")) {
        System.out.print("Raça do cachorro: ");
        String raca = scanner.nextLine();
        animal = new Cachorro(nome, idade, raca, codigo);
    } else if (especie.equalsIgnoreCase("gato")) {
        System.out.print("Qual a cor do gato? ");
        String cor = scanner.nextLine();
        animal = new Gato(nome, idade, especie, cor, codigo);
    } else if (especie.equalsIgnoreCase("passaro")) {
        System.out.print("Cor do pássaro: ");
        String corPassaro = scanner.nextLine();
        animal = new Passaro(nome, idade, corPassaro, codigo);
    } else {
        System.out.println("Espécie não suportada.");
        return;
    }

    idsUsados.add(codigo);

    System.out.println(animal.nome + " foi feito o check-in no " + andar + ".");

    org.bson.Document novoPet = new org.bson.Document("_id", codigo)
            .append("nomepet", nome)
            .append("espécie", especie)
            .append("idade", idade)
            .append("andar", andar);
    pet.insertOne(novoPet);
}


    public void listarAnimais() {
        MongoCursor<Document> cursor = pet.find().iterator();

        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                System.out.println("ID: " + doc.getInteger("_id"));
                System.out.println("Nome: " + doc.getString("nomepet"));
                System.out.println("Espécie: " + doc.getString("espécie"));
                System.out.println("Idade: " + doc.getInteger("idade"));
                System.out.println("Andar: " + doc.getString("andar"));
            }
        } finally {
            cursor.close();
        }
    }

    public void addDespesa(String descricao, double valor) {
        Document despesaDoc = new Document("descricao", descricao)
                .append("valor", valor);
        despesas.insertOne(despesaDoc);
    }

    public void listarDespesas() {
        MongoCursor<Document> cursor = despesas.find().iterator();

        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                System.out.println("Descrição: " + doc.getString("descricao"));
                System.out.println("Valor: " + doc.getDouble("valor"));
            }
        } finally {
            cursor.close();
        }
    }

   public void addPessoa(String nome, String tipo, String cargo) {
    ObjectId novoCodigo = new ObjectId();

    if (tipo.equals("tutor")) {
        int codigoPet;

        while (true) {
            System.out.print("Código do pet: ");
            codigoPet = Integer.parseInt(scanner.nextLine());

            // Verifique se o código do pet existe no banco de dados
            Document petDoc = pet.find(new Document("_id", codigoPet)).first();
            if (petDoc != null) {
                // Após a validação do código do pet, continue com a adição da pessoa
                Document pessoaDoc = new Document("_id", novoCodigo)
                        .append("nome", nome)
                        .append("tipo", tipo)
                        .append("cargo", cargo)
                        .append("codPet", codigoPet);
                pessoas.insertOne(pessoaDoc);
                System.out.println("Pessoa adicionada com sucesso.");
                break;  // Saia do loop após a conclusão bem-sucedida
            } else {
                System.out.println("Código do pet não existe. Tente novamente.");
            }
        }
    } else {
        // Se não for tutor, apenas adicione a pessoa
        Document pessoaDoc = new Document("_id", novoCodigo)
                .append("nome", nome)
                .append("tipo", tipo)
                .append("cargo", cargo);
        pessoas.insertOne(pessoaDoc);
        System.out.println("Pessoa adicionada com sucesso.");
    }
}

    

    public void listarPessoas() {
        MongoCursor<Document> cursor = pessoas.find().iterator();

        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                System.out.println("Nome: " + doc.getString("nome"));
                System.out.println("Tipo: " + doc.getString("tipo"));
                if (doc.getString("tipo").equals("funcionario")) {
                    System.out.println("Cargo: " + doc.getString("cargo"));
                } else if (doc.getString("tipo").equals("tutor")) {
                    System.out.println("Pet: " + doc.getString("codigoPet"));
                }
                System.out.println();
            }
        } finally {
            cursor.close();
        }
    }

    public static void main(String[] args) {
        Aula1OO2 hotel = new Aula1OO2();

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Check-in Pet");
            System.out.println("2. Check-out Pet");
            System.out.println("3. Adicionar despesa");
            System.out.println("4. Listar animais");
            System.out.println("5. Listar despesas");
            System.out.println("6. Sair");
            System.out.println("7. Adicionar Pessoa");
            System.out.println("8. Listar Pessoas");

            System.out.print("Escolha uma opção: ");
            String escolha = hotel.scanner.nextLine();

            switch (escolha) {
                case "1":
                    System.out.print("Nome do animal: ");
                    String nome = hotel.scanner.nextLine();
                    System.out.print("Espécie do animal: ");
                    String especie = hotel.scanner.nextLine();
                    System.out.print("Idade do animal: ");
                    int idade;
                    try {
                        idade = Integer.parseInt(hotel.scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Idade deve ser um número inteiro.");
                        continue;
                    }
                    System.out.print("Andar de acomodação (1 a 3): ");
                    String andar = hotel.scanner.nextLine();

                    hotel.checkIn(nome, especie, idade, andar);
                    break;

                case "2":
                    // Implemente a operação de check-out aqui
                    break;

                case "3":
                    System.out.print("Descrição da despesa: ");
                    String descricao = hotel.scanner.nextLine();
                    double valor;
                    try {
                        System.out.print("Valor da despesa: ");
                        valor = Double.parseDouble(hotel.scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Valor deve ser um número válido.");
                        continue;
                     }
                    hotel.addDespesa(descricao, valor);
                    System.out.println("Despesa '" + descricao + "' no valor de R$" + String.format("%.2f", valor) + " foi adicionada.");
                    break;

                case "4":
                    hotel.listarAnimais();
                    break;

                case "5":
                    hotel.listarDespesas();
                    break;

                case "6":
                    System.out.println("Encerrando o programa.");
                    hotel.scanner.close();
                    System.exit(0);
                    break;

                case "7":
                    System.out.print("Nome da pessoa: ");
                    String nomePessoa = hotel.scanner.nextLine();
                    System.out.print("Tipo da pessoa (tutor/funcionario): ");
                    String tipoPessoa = hotel.scanner.nextLine();
                    if (!tipoPessoa.equals("tutor") && !tipoPessoa.equals("funcionario")) {
                        System.out.println("Tipo de pessoa inválido. Use 'tutor' ou 'funcionario'.");
                        continue;
                    }

                    String cargoPessoa = null;
                    if (tipoPessoa.equals("funcionario")) {
                        System.out.print("Cargo do funcionário: ");
                        cargoPessoa = hotel.scanner.nextLine();
                    }

                    hotel.addPessoa(nomePessoa, tipoPessoa, cargoPessoa);
                    System.out.println("Pessoa adicionada com sucesso.");
                    break;

                case "8":
                    hotel.listarPessoas();
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}








