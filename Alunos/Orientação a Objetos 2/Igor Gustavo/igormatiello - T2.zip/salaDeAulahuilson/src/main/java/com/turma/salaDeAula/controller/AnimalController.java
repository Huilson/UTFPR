/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.controller;

import com.turma.salaDeAula.model.Animal;
import com.turma.salaDeAula.model.Entrada;
import com.turma.salaDeAula.model.Tutor;
import com.turma.salaDeAula.repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author Igor
 */
@Controller
public class AnimalController {

    @Autowired
    private TutorRepository repository;

    @GetMapping("/animal/cadastrar/{id}")
    public String cadastrar(@PathVariable String id, Model model) {
        Tutor tutor = repository.findById(id);
        model.addAttribute("tutor", tutor);
        model.addAttribute("animal", new Animal());
        return "animal/cadastrar";
    }

    @PostMapping("/animal/salvar/{id}")
    public String salvar(@PathVariable String id, @ModelAttribute Animal animal) {
        Tutor tutor = repository.findById(id);
        repository.save(tutor.addAnimal(tutor, animal));
        return "redirect:/tutor/listar";
    }

    
}
