/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author Igor
 */
public class Tutor {
  
    
     private ObjectId id;
    private String nome;
    private Integer idade;
    private List<Animal> animais;


public List<Animal> getAnimais() {
        if (animais == null) {
            animais = new ArrayList<Animal>();
        }
        return animais;
    }
    
    public void setAnimais(List<Animal> animais) {
        this.animais = animais;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public ObjectId getId() {
        return id;
    }
    public void setId(ObjectId id) {
        this.id = id;
    }
     public Tutor criarId() {
        setId(new ObjectId());
        return this;
    }
    
    public Tutor addAnimal(Tutor tutor, Animal animal) {
        List<Animal> animais = getAnimais();
        animais.add(animal);
        tutor.setAnimais(animais);
        return tutor;
    }
    
      public Tutor addEntrada(Tutor tutor, Entrada entrada){
        List<Animal> animais = tutor.getAnimais();
        List<Date> entradas = new ArrayList<Date>();
        
        for(Animal animal : animais){
            if(entrada.getDescricao().equalsIgnoreCase(animal.getNome())){
                entradas = animal.getEntradas();
                entradas.add(entrada.getData());
                animal.setEntradas(entradas);
            }
        }        
            return tutor;
    }
   
}
