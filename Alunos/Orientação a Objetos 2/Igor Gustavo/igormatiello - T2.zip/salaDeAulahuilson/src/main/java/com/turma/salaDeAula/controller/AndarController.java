/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.controller;

import com.turma.salaDeAula.model.Andar;
import com.turma.salaDeAula.model.Animal;
import com.turma.salaDeAula.repository.AndarRepository;
import com.turma.salaDeAula.repository.TutorRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
/**
 *
 * @author Igor
 */
@Controller
public class AndarController {
 @Autowired
    private AndarRepository andarRepository;

 @Autowired
    private TutorRepository tutorRepository;

 
 
    @GetMapping("/andar/cadastrar")
    public String cadastrar(Model model) {
        Andar andar = new Andar();

        model.addAttribute("andar", andar);

        return "andar/cadastrar";
    }

    @PostMapping("/andar/salvar")
    public String salvar(@ModelAttribute Andar andar) {
        andarRepository.save(andar);
        return "redirect:/andar/listar";
    }

    @GetMapping("/andar/listar")
    public String listar(Model model) {
        List<Andar> andares = andarRepository.getAll();
        model.addAttribute("andares", andares);
        return "andar/listar";
    }

    @GetMapping("/andar/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model) {
        Andar andar = andarRepository.getById(id);
      List<Animal> animais = tutorRepository.findAnimaisByAndar(andar.getAndar());
        
         model.addAttribute("animais", animais);
        return "andar/visualizar";
    }
    
      
    

    @GetMapping("/andar/vincular/{id}")
    public String vincular(@PathVariable String id,
            Model model){
        Andar andar = andarRepository.getById(id);
        model.addAttribute("andar", andar);
        return "andar/vincular";        
    }
    
    @PostMapping("/andar/editar/{id}")
    public String editar(@ModelAttribute Andar andar){
        andarRepository.save(andar);
        return"redirect:/andar/listar";
    }

    @GetMapping("/andar/excluir/{id}")
    public String excluir(@PathVariable String id) {
        andarRepository.delete(id);
        return "redirect:/andar/listar";
    }
     
   
    
    
}
