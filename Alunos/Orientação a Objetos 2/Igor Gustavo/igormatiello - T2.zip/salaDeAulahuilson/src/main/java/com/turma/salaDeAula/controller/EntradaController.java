/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.controller;
import com.turma.salaDeAula.model.Entrada;
import com.turma.salaDeAula.model.Tutor;
import com.turma.salaDeAula.repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
/**
 *
 * @author Igor
 */
@Controller
public class EntradaController {
     @Autowired
    private TutorRepository repository;

    @GetMapping("/entrada/cadastrar/{id}")
    public String cadastrar(@PathVariable String id, Model model) {
        Tutor tutor = repository.findById(id);
        model.addAttribute("tutor", tutor);
        model.addAttribute("entrada", new Entrada());
        return "entrada/cadastrar";
    }

    @PostMapping("/entrada/salvar/{id}")
    public String salvar(@PathVariable String id, @ModelAttribute Entrada entrada) {
        Tutor tutor = repository.findById(id);
        repository.save(tutor.addEntrada(tutor, entrada));
        return "redirect:/tutor/listar";
    }

     @GetMapping("/entrada/excluir/{id}")
    public String excluir(@PathVariable String id, Model model) {
        Tutor tutor = repository.findById(id);
        model.addAttribute("tutor", tutor);
        model.addAttribute("entrada", new Entrada());
        return "entrada/excluir";
    }
    
    @PostMapping("/entrada/excluir/{tutorId}")
    public String excluirEntradas(@PathVariable String tutorId, @ModelAttribute Entrada entrada) {
        repository.deleteEntradas(tutorId, entrada.getDescricao());
        return "redirect:/tutor/listar"; // ou redirecione para onde desejar após a exclusão
    }
}
