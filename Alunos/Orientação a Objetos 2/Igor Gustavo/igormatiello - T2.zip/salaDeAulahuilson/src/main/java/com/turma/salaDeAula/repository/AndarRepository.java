/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.repository;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.turma.salaDeAula.codec.CodecAndar;
import com.turma.salaDeAula.codec.CodecTutor;
import com.turma.salaDeAula.model.Andar;
import com.turma.salaDeAula.model.Tutor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;
/**
 *
 * @author Igor
 */
@Repository
public class AndarRepository {
    
    public MongoDatabase connect() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry().get(Document.class);
        CodecAndar andarCodec = new CodecAndar(codec);

        CodecRegistry registry = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(andarCodec)
        );

        MongoClientOptions options = MongoClientOptions.builder().codecRegistry(registry).build();
        MongoClient client = new MongoClient("localhost:27017", options);

        MongoDatabase db = client.getDatabase("Aula");
        return db;
    }

    public Andar getById(String id) {
        MongoDatabase db = connect();
        MongoCollection<Andar> andares = db.getCollection("andares", Andar.class);
        Andar andar = andares.find(Filters.eq("_id", new ObjectId(id))).first();
        return andar;
    }

    public void save(Andar andar) {
        MongoDatabase db = connect();
        MongoCollection<Andar> andares = db.getCollection("andares", Andar.class);

        if (andar.getId() == null) {
            andares.insertOne(andar);
        } else {
            andares.updateOne(Filters.eq("_id", andar.getId()), new Document("$set", andar));
        }
    }

    public List<Andar> getAll() {
        MongoDatabase db = connect();
        MongoCollection<Andar> andares = db.getCollection("andares", Andar.class);
        MongoCursor<Andar> result = andares.find().iterator();

        List<Andar> andarList = new ArrayList<>();

        while (result.hasNext()) {
            Andar andar = result.next();
            andarList.add(andar);
        }

        return andarList;
    }

    public void delete(String id) {
        MongoDatabase db = connect();
        MongoCollection<Andar> andares = db.getCollection("andares", Andar.class);
        andares.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }
}
