/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import com.turma.salaDeAula.codec.CodecTutor;
import com.turma.salaDeAula.model.Animal;
import com.turma.salaDeAula.model.Tutor;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;
import static org.springframework.ui.ModelExtensionsKt.set;

/**
 *
 * @author Igor
 */
@Repository
public class TutorRepository {

    public MongoDatabase connect() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry().get(Document.class);
        CodecTutor tutorCodec = new CodecTutor(codec);

        CodecRegistry registry = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(tutorCodec)
        );

        MongoClientOptions options = MongoClientOptions.builder().codecRegistry(registry).build();
        MongoClient client = new MongoClient("localhost:27017", options);

        MongoDatabase db = client.getDatabase("Aula"); // Substitua "Aula" pelo nome do seu banco de dados
        return db;
    }

    public void save(Tutor tutor) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);

        if (tutor.getId() == null) {
            tutors.insertOne(tutor);
        } else {
            tutors.updateOne(Filters.eq("_id", tutor.getId()), new Document("$set", tutor));
        }
    }

    public List<Tutor> findAll() {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        MongoCursor<Tutor> result = tutors.find().iterator();

        List<Tutor> tutorList = new ArrayList<>();

        while (result.hasNext()) {
            Tutor tutor = result.next();
            tutorList.add(tutor);
        }

        return tutorList;
    }

    public Tutor findById(String id) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        Tutor tutor = tutors.find(Filters.eq("_id", new ObjectId(id))).first();
        return tutor;
    }

    public void delete(String id) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        tutors.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }

    public List<Tutor> findAnimals(String especie) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        MongoCursor<Tutor> result = tutors.find(Filters.eq("animais.especie", especie)).iterator();

        List<Tutor> tutorList = new ArrayList<>();
        while (result.hasNext()) {
            Tutor tutor = result.next();
            tutorList.add(tutor);
        }
        return tutorList;
    }

    public List<Animal> findAnimaisByAndar(String andar) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);

        Bson filter = Filters.eq("animais.andar", andar);
        MongoCursor<Tutor> result = tutors.find(filter).iterator();

        List<Animal> animalList = new ArrayList<>();
        while (result.hasNext()) {
            Tutor tutor = result.next();
            List<Animal> animaisDoTutor = tutor.getAnimais();
            if (animaisDoTutor != null) {
                for (Animal animal : animaisDoTutor) {
                    if (andar.equals(animal.getAndar())) {
                        animalList.add(animal);
                    }
                }
            }
        }
        return animalList;
    }

    public void deleteEntradas(String tutorId, String animalNome) {
        MongoDatabase db = connect();
        MongoCollection<Tutor> tutors = db.getCollection("tutores", Tutor.class);
        
        tutors.updateOne(Filters.and(Filters.eq("_id",tutorId), 
                Filters.eq("tutores.animais", animalNome)), Updates.set("tutores.animais.entradas",0));

    }
}
