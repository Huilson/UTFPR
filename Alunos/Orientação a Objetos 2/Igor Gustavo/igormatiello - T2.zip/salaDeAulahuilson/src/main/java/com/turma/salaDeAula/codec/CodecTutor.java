/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.codec;

import com.turma.salaDeAula.model.Animal;
import com.turma.salaDeAula.model.Tutor;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.codecs.CollectibleCodec;

/**
 *
 * @author Igor
 */
public class CodecTutor implements CollectibleCodec<Tutor>{
        private Codec<Document> codec;

    public CodecTutor(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Tutor generateIdIfAbsentFromDocument(Tutor tutor) {
        return documentHasId(tutor) ? tutor : tutor.criarId();
    }

    @Override
    public boolean documentHasId(Tutor tutor) {
        return tutor.getId() != null;
    }

    @Override
    public BsonValue getDocumentId(Tutor tutor) {
        if (!documentHasId(tutor)) {
            throw new IllegalStateException("Esse documento não tem um Id");
        } else {
            return new BsonString(tutor.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Tutor tutor, EncoderContext ec) {
        ObjectId id = tutor.getId();
        String nome = tutor.getNome();
        Integer idade = tutor.getIdade();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("idade", idade);

        List<Animal> animais = tutor.getAnimais();
        if (animais != null) {
            List<Document> animaisDoc = new ArrayList<>();
            for (Animal animal : animais) {
                animaisDoc.add(new Document("nome", animal.getNome())
                        .append("especie", animal.getEspecie())
                        .append("andar", animal.getAndar())
                        .append("tipo", animal.getTipo())
                        .append("entradas", animal.getEntradas()));
            }
            doc.put("animais", animaisDoc);
        }

        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Tutor> getEncoderClass() {
        return Tutor.class;
    }

    @Override
    public Tutor decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Tutor tutor = new Tutor();
        tutor.setId(doc.getObjectId("_id"));
        tutor.setNome(doc.getString("nome"));
        tutor.setIdade(doc.getInteger("idade"));

        List<Document> animais = (List<Document>) doc.get("animais");
        if (animais != null) {
            List<Animal> animaisDoTutor = new ArrayList<>();
            for (Document docAnimal : animais) {
                animaisDoTutor.add(new Animal(
                        docAnimal.getString("nome"),
                        docAnimal.getString("especie"),
                        docAnimal.getString("andar"),
                        docAnimal.getString("tipo"),
                        docAnimal.getList("entradas", Date.class)
                ));
            }
            tutor.setAnimais(animaisDoTutor);
        }

        return tutor;
    }

}
