/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.salaDeAula.controller;
import com.turma.salaDeAula.model.Tutor;
import com.turma.salaDeAula.repository.TutorRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
/**
 *
 * @author Igor
 */
@Controller
public class TutorController {

    @Autowired
    private TutorRepository tutorRepository;

    @GetMapping("/tutor/cadastrar")
    public String cadastrar(Model model) {
        model.addAttribute("tutor", new Tutor());
        return "tutor/cadastrar";
    }

    @PostMapping("/tutor/salvar")
    public String salvar(@ModelAttribute Tutor tutor) {
        System.out.println("Salvando tutor");
        tutorRepository.save(tutor);
        return "redirect:/tutor/listar";
    }

    @GetMapping("/tutor/listar")
    public String listar(Model model) {
        List<Tutor> tutors = tutorRepository.findAll();
        model.addAttribute("tutores", tutors);
        return"tutor/listar";
    }

    @GetMapping("/tutor/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model) {
        Tutor tutor = tutorRepository.findById(id);
        model.addAttribute("tutor", tutor);
        return "tutor/visualizar";
    }

    @GetMapping("/tutor/excluir/{id}")
    public String excluir(@PathVariable String id) {
        tutorRepository.delete(id);
        return "redirect:/tutor/listar";
    }

    @GetMapping("/tutor/atualizar/{id}")
    public String atualizar(@PathVariable String id, Model model) {
        Tutor tutor = tutorRepository.findById(id);
        model.addAttribute("tutor", tutor);
        return "tutor/atualizar";
    }

    @PostMapping("/tutor/editar/{id}")
    public String editar(@ModelAttribute Tutor tutor) {
        tutorRepository.save(tutor);
        return "redirect:/tutor/listar";
    }

 

}
