/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.model.pessoa;

import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;

/**
 *
 * @author User
 */
public class PessoaFuncionario extends Pessoa{
    String funcao;

    public PessoaFuncionario() {
    }
    
    public PessoaFuncionario(String funcao, String nome, String documento) {
        super(nome, documento);
        this.funcao = funcao;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }



    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String getDocumento() {
        return documento;
    }

    @Override
    public void setDocumento(String documento) {
        this.documento = documento;
    }
}
