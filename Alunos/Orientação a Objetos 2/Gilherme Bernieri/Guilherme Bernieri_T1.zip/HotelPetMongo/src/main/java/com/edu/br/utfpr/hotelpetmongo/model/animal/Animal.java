/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.model.animal;

/**
 *
 * @author User
 */
public class Animal {
    int cod;
    String nome;
    String especie;
    int idadeAnos;
    int idadeMeses;

    public Animal(int cod, String nome, String especie, int idadeAnos, int idadeMeses) {
        this.cod = cod;
        this.nome = nome;
        this.especie = especie;
        this.idadeAnos = idadeAnos;
        this.idadeMeses = idadeMeses;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    

    public Animal() {
    }

    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getIdadeAnos() {
        return idadeAnos;
    }

    public void setIdadeAnos(int idadeAnos) {
        this.idadeAnos = idadeAnos;
    }

    public int getIdadeMeses() {
        return idadeMeses;
    }

    public void setIdadeMeses(int idadeMeses) {
        this.idadeMeses = idadeMeses;
    }
     
     
    
}
