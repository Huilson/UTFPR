/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.model.pessoa;

import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;

/**
 *
 * @author User
 */
public class PessoaTutor extends Pessoa{
    Animal animal;

    public PessoaTutor(Animal animal, String nome, String documento) {
        super(nome, documento);
        this.animal = animal;
    }

    public PessoaTutor() {
    }

    
    
    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }



    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String getDocumento() {
        return documento;
    }

    @Override
    public void setDocumento(String documento) {
        this.documento = documento;
    }
    
    
    
}
