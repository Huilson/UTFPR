/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.model;

import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;
import com.edu.br.utfpr.hotelpetmongo.model.pessoa.Pessoa;
import java.time.LocalDate;

/**
 *
 * @author User
 */
public class Hospedagem {
    Pessoa tutor;
    Pessoa funcionario;
    Animal pet;
    LocalDate entrada;
    LocalDate saida;
    String despesas;
    float despesaTotal;

    public Hospedagem(Pessoa tutor, Pessoa funcionario, Animal pet, LocalDate entrada, LocalDate saida, String despesas, float despesaTotal) {
        this.tutor = tutor;
        this.funcionario = funcionario;
        this.pet = pet;
        this.entrada = entrada;
        this.saida = saida;
        this.despesas = despesas;
        this.despesaTotal = despesaTotal;
    }

    public Hospedagem() {
    }

    public Pessoa getTutor() {
        return tutor;
    }

    public void setTutor(Pessoa tutor) {
        this.tutor = tutor;
    }

    public Pessoa getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Pessoa funcionario) {
        this.funcionario = funcionario;
    }

    public Animal getPet() {
        return pet;
    }

    public void setPet(Animal pet) {
        this.pet = pet;
    }

    public LocalDate getEntrada() {
        return entrada;
    }

    public void setEntrada(LocalDate entrada) {
        this.entrada = entrada;
    }

    public LocalDate getSaida() {
        return saida;
    }

    public void setSaida(LocalDate saida) {
        this.saida = saida;
    }

    public String getDespesas() {
        return despesas;
    }

    public void setDespesas(String despesas) {
        this.despesas = despesas;
    }

    public float getDespesaTotal() {
        return despesaTotal;
    }

    public void setDespesaTotal(float despesaTotal) {
        this.despesaTotal = despesaTotal;
    }
    
    
    
}
