/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.dao;

import com.edu.br.utfpr.hotelpetmongo.model.pessoa.PessoaTutor;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalDao;
import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;

/**
 *
 * @author User
 */
public class PessoaTutorDao {
    public static PessoaTutor tutor = new PessoaTutor();
    public static AnimalDao ad = new AnimalDao();
    MongoClient conecta = new MongoClient();
    MongoDatabase db = conecta.getDatabase("hotelpet");
    MongoCollection<Document> pessoaTutor = db.getCollection("pessoaTutor");
    
    public PessoaTutor buscarTutor(String documento){
        //consultar com filtro
        Document tutorMongo = pessoaTutor.find(Filters.eq("documento",documento)).first();
        tutor.setNome(tutorMongo.getString("nome"));
        tutor.setDocumento(tutorMongo.getString("documento"));
        tutor.setAnimal(ad.buscarAnimal(Integer.parseInt(tutorMongo.getString("pet"))));
        return tutor;
    }
}
