/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.dao;

import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalAve;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalCachorro;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalGato;
import com.edu.br.utfpr.hotelpetmongo.model.pessoa.PessoaTutor;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalDao;
import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;
/**
 *
 * @author User
 */
public class AnimalDao {
    public Animal animal = new Animal();
    public AnimalGato gato = new AnimalGato();
    public AnimalCachorro cachorro = new AnimalCachorro();
    public AnimalAve ave = new AnimalAve();
    MongoClient conecta = new MongoClient();
    MongoDatabase db = conecta.getDatabase("hotelpet");
    MongoCollection<Document> animalm = db.getCollection("animal");
    
    public Animal buscarAnimal(int id){
        Document animalMongo = animalm.find(Filters.eq("_id",id)).first();
        animal.setCod(Integer.parseInt(animalMongo.getString("_id")));
        animal.setNome(animalMongo.getString("nome"));
        animal.setIdadeAnos(Integer.parseInt(animalMongo.getString("idadeAnos")));
        animal.setIdadeMeses(Integer.parseInt(animalMongo.getString("idadeMeses")));
        animal.setEspecie(animalMongo.getString("especie"));
        return animal;
    }
    public void listarAnimais(String nome){
        MongoCursor<Document> animais = animalm.find(Filters.eq("nome",nome)).iterator();
        while(animais.hasNext()){
            System.out.println(animais.next());
        }
    }
    
    public void cadastrarAnimal(Animal animal){
        Long tamanhoColecao = animalm.countDocuments();
        Document novoAnimal = new Document("_id", (tamanhoColecao + 1))
                .append("nome", animal.getNome())
                .append("especie", animal.getEspecie())
                .append("idadeAnos", animal.getIdadeAnos())
                .append("idadeMeses", animal.getIdadeMeses());
        animalm.insertOne(novoAnimal);
    }
    
    public Long getMaxTam(){
        Long maxTam = animalm.countDocuments();
        return maxTam;
    }
}
