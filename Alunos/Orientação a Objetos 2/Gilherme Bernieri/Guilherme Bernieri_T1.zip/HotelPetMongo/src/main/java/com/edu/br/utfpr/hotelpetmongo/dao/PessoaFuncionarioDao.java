/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.dao;

import com.edu.br.utfpr.hotelpetmongo.model.pessoa.PessoaFuncionario;
import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

/**
 *
 * @author User
 */
public class PessoaFuncionarioDao {
    public PessoaFuncionario funcionario = new PessoaFuncionario();
    MongoClient conecta = new MongoClient();
    MongoDatabase db = conecta.getDatabase("hotelpet");
    MongoCollection<Document> pessoaFuncionario = db.getCollection("pessoaFuncionario");
    
    public PessoaFuncionario buscarFuncionario(String documento){
        Document funcionarioMongo = pessoaFuncionario.find(Filters.eq("documento",documento)).first();
        funcionario.setNome(funcionarioMongo.getString("nome"));
        funcionario.setDocumento(funcionarioMongo.getString("documento"));
        funcionario.setFuncao(funcionarioMongo.getString("funcao"));
        return funcionario;
    }
    
}
