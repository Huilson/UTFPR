/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.dao;

import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalAve;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalCachorro;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalGato;
import com.edu.br.utfpr.hotelpetmongo.model.pessoa.PessoaTutor;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalDao;
import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;
/**
 *
 * @author User
 */
public class AnimalGatoDao {
    public Animal animal = new Animal();
    public AnimalGato gato = new AnimalGato();
    public AnimalCachorro cachorro = new AnimalCachorro();
    public AnimalAve ave = new AnimalAve();
    MongoClient conecta = new MongoClient();
    MongoDatabase db = conecta.getDatabase("hotelpet");
    MongoCollection<Document> animalGato = db.getCollection("animalGato");
    
    public void cadastrarAve(AnimalGato gato, Long id){
        Document novoGato = new Document("_id", id)
                .append("raca", gato.getRaca())
                .append("porte", gato.getPorte().toString())
                .append("alimentacao", gato.getAlimentacao().toString());
        animalGato.insertOne(novoGato);
    }
}
