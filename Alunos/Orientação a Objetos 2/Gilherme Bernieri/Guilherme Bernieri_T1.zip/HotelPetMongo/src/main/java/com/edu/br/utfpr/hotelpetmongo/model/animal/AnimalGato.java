/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.model.animal;

import com.edu.br.utfpr.hotelpetmongo.util.Alimentacao;
import com.edu.br.utfpr.hotelpetmongo.util.Porte;

/**
 *
 * @author User
 */
public class AnimalGato extends Animal {
    int cod;
    String raca;
    Porte porte;
    Alimentacao alimentacao; 

    public AnimalGato() {
    }

    public AnimalGato(int cod, String raca, Porte porte, Alimentacao alimentacao, String nome, String especie, int idadeAnos, int idadeMeses) {
        super(cod, nome, especie, idadeAnos, idadeMeses);
        this.cod = cod;
        this.raca = raca;
        this.porte = porte;
        this.alimentacao = alimentacao;
    }

    @Override
    public int getCod() {
        return cod;
    }

    @Override
    public void setCod(int cod) {
        this.cod = cod;
    }

    

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public Porte getPorte() {
        return porte;
    }

    public void setPorte(Porte porte) {
        this.porte = porte;
    }

    public Alimentacao getAlimentacao() {
        return alimentacao;
    }

    public void setAlimentacao(Alimentacao alimentacao) {
        this.alimentacao = alimentacao;
    }



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getIdadeAnos() {
        return idadeAnos;
    }

    public void setIdadeAnos(int idadeAnos) {
        this.idadeAnos = idadeAnos;
    }

    public int getIdadeMeses() {
        return idadeMeses;
    }

    public void setIdadeMeses(int idadeMeses) {
        this.idadeMeses = idadeMeses;
    }
    
    
}
