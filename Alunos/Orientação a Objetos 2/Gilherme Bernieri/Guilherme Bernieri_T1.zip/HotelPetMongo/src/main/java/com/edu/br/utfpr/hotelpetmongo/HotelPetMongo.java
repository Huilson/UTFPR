/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.edu.br.utfpr.hotelpetmongo;

import com.edu.br.utfpr.hotelpetmongo.util.*;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class HotelPetMongo {

    public static Util util;
    private static Scanner scan = new Scanner(System.in);
    private static int opcao = 0;
    private static int opcao1 = 0;

    public static void main(String[] args) throws IOException {
        util.criaMenuIniciar();
    }
}
