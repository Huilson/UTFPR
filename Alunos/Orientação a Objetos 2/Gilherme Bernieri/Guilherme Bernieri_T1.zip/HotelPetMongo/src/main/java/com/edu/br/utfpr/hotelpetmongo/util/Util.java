/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.util;

import com.edu.br.utfpr.hotelpetmongo.HotelPetMongo;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalAveDao;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalCachorroDao;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalDao;
import com.edu.br.utfpr.hotelpetmongo.dao.AnimalGatoDao;
import com.edu.br.utfpr.hotelpetmongo.dao.HospedagemDao;
import com.edu.br.utfpr.hotelpetmongo.dao.PessoaFuncionarioDao;
import com.edu.br.utfpr.hotelpetmongo.dao.PessoaTutorDao;
import com.edu.br.utfpr.hotelpetmongo.model.Hospedagem;
import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalAve;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalCachorro;
import com.edu.br.utfpr.hotelpetmongo.model.animal.AnimalGato;
import com.edu.br.utfpr.hotelpetmongo.model.pessoa.PessoaFuncionario;
import com.edu.br.utfpr.hotelpetmongo.model.pessoa.PessoaTutor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;
import javax.print.DocFlavor;

/**
 *
 * @author User
 */
public class Util {

    private static int prosseguir = 0;
    private static int opcao = 0, opcao1 = 0;
    private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static Scanner scan = new Scanner(System.in);
    private static PessoaTutorDao ptd = new PessoaTutorDao();
    private static PessoaFuncionarioDao pfd = new PessoaFuncionarioDao();
    private static AnimalDao animalDao = new AnimalDao();
    public static Animal animal = new Animal();
    private static HospedagemDao hospedar = new HospedagemDao();
    public static AnimalAveDao aveDao = new AnimalAveDao();
    public static AnimalCachorroDao caoDao = new AnimalCachorroDao();
    public static AnimalGatoDao gatoDao = new AnimalGatoDao();
    public static AnimalAve ave = new AnimalAve();
    public static AnimalCachorro cao = new AnimalCachorro();
    public static AnimalGato gato = new AnimalGato();

    public static void criaMenuIniciar() throws IOException {
        do {
            System.out.println("Hospedagem");
            System.out.println("===================================");
            System.out.println("1-Entrada");
            System.out.println("2-Saida");
            System.out.println("Menu");
            System.out.println("===================================");
            System.out.println("3-Cadastros");
            System.out.println("4-Editar");
            System.out.println("5-Excluir");
            System.out.println("Digite opcao(0 para sair): ");
            System.out.println(" ");
            prosseguir = Integer.parseInt(reader.readLine());
            switch (prosseguir) {
                case 1:
                    Entrada();
                    break;
                case 2:
                    Saida();
                    break;
                case 3:
                    Cadastrar();
                    break;
                case 4:
                    Editar();
                    break;
                case 5:
                    Excluir();
                    break;
            }
        } while (prosseguir != 0);
    }

    private static void Cadastrar() throws IOException {
        do {
            System.out.println("Cadastros");
            System.out.println("===================================");
            System.out.println("1 - Animais: ");
            System.out.println("2 - Pessoas: ");
            System.out.println("Digite a opcao desejada 0 para sair: ");
            opcao = scan.nextInt();
            switch (opcao) {
                case 1:
                    System.out.println("Animais");
                    System.out.println("===================================");
                    System.out.println("1 - Aves: ");
                    System.out.println("2 - Cachorros: ");
                    System.out.println("3 - Gatos: ");
                    System.out.println("Digite a opcao desejada 0 para sair: ");
                    opcao = scan.nextInt();
                    switch (opcao1) {
                        case 1:
                            System.out.println("Cadastrando Aves");
                            String idave = animalDao.getMaxTam().toString();
                            System.out.println("Informe o nome: ");
                            String nomeave = reader.readLine();
                            System.out.println("Informe a especie: ");
                            String especieave = reader.readLine();
                            System.out.println("Informe a idade em anos: ");
                            int anosave = Integer.parseInt(reader.readLine());
                            System.out.println("Informe a idade em meses: ");
                            int mesesave = Integer.parseInt(reader.readLine());
                            System.out.println("Informe a raca: ");
                            String racaave = reader.readLine();
                            System.out.println("Informe o porte: ");
                            System.out.println("1 - PEQUENO");
                            System.out.println("2 - MEDIO");
                            System.out.println("3 - GRANDE");
                            System.out.println("Digite numero do porte: ");
                            int porteave = Integer.parseInt(reader.readLine());
                            switch(porteave){
                                case 1: 
                                    ave.setPorte(Porte.PEQUENO);
                                    break;
                                case 2:
                                    ave.setPorte(Porte.MEDIO);
                                    break;
                                case 3:
                                    ave.setPorte(Porte.GRANDE);
                                    break;
                            }
                            System.out.println("Informe a alimentacao do pet: ");
                            System.out.println("1 - RACAO CACHORRO");
                            System.out.println("2 - RACAO GATO");
                            System.out.println("3 - ALPISTE");
                            System.out.println("4 - GIRASSOL");
                            System.out.println("5 - CARNE");
                            System.out.println("6 - LEITE");
                            System.out.println("7 - VERDURAS");
                            System.out.println("Digite numero do alimento: ");
                            int alimentoave = Integer.parseInt(reader.readLine());
                            switch(alimentoave){
                                case 1: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 2: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 3: 
                                    ave.setAlimentacao(Alimentacao.ALPISTE);
                                    break;
                                case 4: 
                                    ave.setAlimentacao(Alimentacao.GIRASSOL);
                                    break;
                                case 5: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 6: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 7: 
                                    ave.setAlimentacao(Alimentacao.VERDURAS);
                                    break;
                            }
                            
                            if (especieave.toLowerCase() == "ave") {
                                Animal novoAnimal = new Animal();
                                novoAnimal.setCod(Integer.parseInt(idave));
                                ave.setNome(nomeave);
                                novoAnimal.setNome(nomeave);
                                ave.setEspecie(especieave);
                                novoAnimal.setEspecie(especieave);
                                ave.setIdadeAnos(anosave);
                                novoAnimal.setIdadeAnos(anosave);
                                ave.setIdadeMeses(mesesave);
                                novoAnimal.setIdadeMeses(mesesave);
                                animalDao.cadastrarAnimal(novoAnimal);
                                aveDao.cadastrarAve(ave, animalDao.getMaxTam());
                            }
                            break;
                        case 2:
                            System.out.println("Cadastrando Cachorros");
                            String idcao = animalDao.getMaxTam().toString();
                            System.out.println("Informe o nome: ");
                            String nomecao = reader.readLine();
                            System.out.println("Informe a especie: ");
                            String especiecao = reader.readLine();
                            System.out.println("Informe a idade em anos: ");
                            int anoscao = Integer.parseInt(reader.readLine());
                            System.out.println("Informe a idade em meses: ");
                            int mesescao = Integer.parseInt(reader.readLine());
                            System.out.println("Informe a raca: ");
                            String racacao = reader.readLine();
                            System.out.println("Informe o porte: ");
                            System.out.println("1 - PEQUENO");
                            System.out.println("2 - MEDIO");
                            System.out.println("3 - GRANDE");
                            System.out.println("Digite numero do porte: ");
                            int portecao = Integer.parseInt(reader.readLine());
                            switch(portecao){
                                case 1: 
                                    cao.setPorte(Porte.PEQUENO);
                                    break;
                                case 2:
                                    cao.setPorte(Porte.MEDIO);
                                    break;
                                case 3:
                                    cao.setPorte(Porte.GRANDE);
                                    break;
                            }
                            System.out.println("Informe a alimentacao do pet: ");
                            System.out.println("1 - RACAO CACHORRO");
                            System.out.println("2 - RACAO GATO");
                            System.out.println("3 - ALPISTE");
                            System.out.println("4 - GIRASSOL");
                            System.out.println("5 - CARNE");
                            System.out.println("6 - LEITE");
                            System.out.println("7 - VERDURAS");
                            System.out.println("Digite numero do alimento: ");
                            int alimentocao = Integer.parseInt(reader.readLine());
                            switch(alimentocao){
                                case 1: 
                                    cao.setAlimentacao(Alimentacao.RACAO_CACHORRO);
                                    break;
                                case 2: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 3: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 4: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 5: 
                                    cao.setAlimentacao(Alimentacao.CARNE);
                                    break;
                                case 6: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 7: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                            }
                            
                            if (especiecao.toLowerCase() == "cachorro") {
                                Animal novoAnimal = new Animal();
                                novoAnimal.setCod(Integer.parseInt(idcao));
                                cao.setNome(nomecao);
                                novoAnimal.setNome(nomecao);
                                cao.setEspecie(especiecao);
                                novoAnimal.setEspecie(especiecao);
                                cao.setIdadeAnos(anoscao);
                                novoAnimal.setIdadeAnos(anoscao);
                                cao.setIdadeMeses(mesescao);
                                novoAnimal.setIdadeMeses(mesescao);
                                animalDao.cadastrarAnimal(novoAnimal);
                                caoDao.cadastrarAve(cao, animalDao.getMaxTam());
                            }
                            break;
                        case 3:
                            System.out.println("Cadastrando Cachorros");
                            String idgato = animalDao.getMaxTam().toString();
                            System.out.println("Informe o nome: ");
                            String nomegato = reader.readLine();
                            System.out.println("Informe a especie: ");
                            String especiegato = reader.readLine();
                            System.out.println("Informe a idade em anos: ");
                            int anosgato = Integer.parseInt(reader.readLine());
                            System.out.println("Informe a idade em meses: ");
                            int mesesgato = Integer.parseInt(reader.readLine());
                            System.out.println("Informe a raca: ");
                            String racagato = reader.readLine();
                            System.out.println("Informe o porte: ");
                            System.out.println("1 - PEQUENO");
                            System.out.println("2 - MEDIO");
                            System.out.println("3 - GRANDE");
                            System.out.println("Digite numero do porte: ");
                            int portegato = Integer.parseInt(reader.readLine());
                            switch(portegato){
                                case 1: 
                                    gato.setPorte(Porte.PEQUENO);
                                    break;
                                case 2:
                                    gato.setPorte(Porte.MEDIO);
                                    break;
                                case 3:
                                    gato.setPorte(Porte.GRANDE);
                                    break;
                            }
                            System.out.println("Informe a alimentacao do pet: ");
                            System.out.println("1 - RACAO CACHORRO");
                            System.out.println("2 - RACAO GATO");
                            System.out.println("3 - ALPISTE");
                            System.out.println("4 - GIRASSOL");
                            System.out.println("5 - CARNE");
                            System.out.println("6 - LEITE");
                            System.out.println("7 - VERDURAS");
                            System.out.println("Digite numero do alimento: ");
                            int alimentogato = Integer.parseInt(reader.readLine());
                            switch(alimentogato){
                                case 1: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 2: 
                                    gato.setAlimentacao(Alimentacao.RACAO_GATO);
                                    break;
                                case 3: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 4: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 5: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                                case 6: 
                                    gato.setAlimentacao(Alimentacao.LEITE);
                                    break;
                                case 7: 
                                    System.out.println("Alimento nao disponivel");
                                    break;
                            }
                            
                            if (especiegato.toLowerCase() == "gato") {
                                Animal novoAnimal = new Animal();
                                novoAnimal.setCod(Integer.parseInt(idgato));
                                gato.setNome(nomegato);
                                novoAnimal.setNome(nomegato);
                                gato.setEspecie(especiegato);
                                novoAnimal.setEspecie(especiegato);
                                gato.setIdadeAnos(anosgato);
                                novoAnimal.setIdadeAnos(anosgato);
                                gato.setIdadeMeses(mesesgato);
                                novoAnimal.setIdadeMeses(mesesgato);
                                animalDao.cadastrarAnimal(novoAnimal);
                                gatoDao.cadastrarAve(gato, animalDao.getMaxTam());
                            }
                            break;
                    }
                    break;
                case 2:
                    System.out.println("Pessoas");
                    System.out.println("===================================");
                    System.out.println("1 - Funcionario: ");
                    System.out.println("2 - Tutores: ");
                    System.out.println("Digite a opcao desejada 0 para sair: ");
                    opcao = scan.nextInt();
                    switch (opcao1) {
                        case 1:

                            break;
                        case 2:

                            break;
                    }
                    break;
            }
        } while (opcao != 0);
    }

    private static void Editar() {
        do {
            System.out.println("Edicao");
            System.out.println("===================================");
            System.out.println("1 - Animais: ");
            System.out.println("2 - Pessoas: ");
            System.out.println("Digite a opcao desejada 0 para sair: ");
            opcao = scan.nextInt();
            switch (opcao) {
                case 1:
                    System.out.println("Animais");
                    System.out.println("===================================");
                    System.out.println("1 - Aves: ");
                    System.out.println("2 - Cachorros: ");
                    System.out.println("3 - Gatos: ");
                    System.out.println("Digite a opcao desejada 0 para sair: ");
                    opcao = scan.nextInt();
                    switch (opcao1) {
                        case 1:

                            break;
                        case 2:

                            break;
                        case 3:

                            break;
                    }
                    break;
                case 2:
                    System.out.println("Pessoas");
                    System.out.println("===================================");
                    System.out.println("1 - Funcionario: ");
                    System.out.println("2 - Tutores: ");
                    System.out.println("Digite a opcao desejada 0 para sair: ");
                    opcao = scan.nextInt();
                    switch (opcao1) {
                        case 1:

                            break;
                        case 2:

                            break;
                    }
                    break;
            }
        } while (opcao != 0);
    }

    private static void Excluir() {
        do {
            System.out.println("Exclusao");
            System.out.println("===================================");
            System.out.println("1 - Animais: ");
            System.out.println("2 - Pessoas: ");
            System.out.println("Digite a opcao desejada 0 para sair: ");
            opcao = scan.nextInt();
            switch (opcao) {
                case 1:
                    System.out.println("Animais");
                    System.out.println("===================================");
                    System.out.println("1 - Aves: ");
                    System.out.println("2 - Cachorros: ");
                    System.out.println("3 - Gatos: ");
                    System.out.println("Digite a opcao desejada 0 para sair: ");
                    opcao = scan.nextInt();
                    switch (opcao1) {
                        case 1:

                            break;
                        case 2:

                            break;
                        case 3:

                            break;
                    }
                    break;
                case 2:
                    System.out.println("Pessoas");
                    System.out.println("===================================");
                    System.out.println("1 - Funcionario: ");
                    System.out.println("2 - Tutores: ");
                    System.out.println("Digite a opcao desejada 0 para sair: ");
                    opcao = scan.nextInt();
                    switch (opcao1) {
                        case 1:

                            break;
                        case 2:

                            break;
                    }
                    break;
            }
        } while (opcao != 0);
    }

    private static void Entrada() throws IOException {
        System.out.println("Nova entrada");
        System.out.println("Informe o nome do pet: ");
        String pet;
        pet = reader.readLine();
        LocalDate entrada = LocalDate.now();
        Hospedagem hospedagem = new Hospedagem();
        animalDao.listarAnimais(pet);
        System.out.println("Informe o id do animal: ");
        int codAnimal;
        codAnimal = scan.nextInt();
        Animal animal = animalDao.buscarAnimal(codAnimal);
        hospedagem.setEntrada(entrada);
        hospedagem.setPet(animal);
        System.out.println("Informe o documento do tutor: ");
        String documentoTutor = reader.readLine();
        PessoaTutor tutor;
        tutor = ptd.buscarTutor(documentoTutor);
        hospedagem.setTutor(tutor);
        System.out.println("Informe o documento do funcionario responsavel: ");
        String documentoFuncionario = reader.readLine();
        PessoaFuncionario funcionario;
        funcionario = pfd.buscarFuncionario(documentoFuncionario);
        hospedagem.setFuncionario(funcionario);
        hospedar.novaHospedagem(hospedagem);
    }

    private static void Saida() throws IOException {
        System.out.println("Nova Saida");
        System.out.println("Informe o nome do pet: ");
        String pet = reader.readLine();
        LocalDate saida = LocalDate.now();
        Hospedagem hospedagem = new Hospedagem();
        animalDao.listarAnimais(pet);
        System.out.println("Informe o id do animal: ");
        int codAnimal = scan.nextInt();
        animal = animalDao.buscarAnimal(codAnimal);
        hospedagem = hospedar.buscarHospedagem(codAnimal);
        hospedagem.setSaida(saida);
        System.out.println("Informe a descricao das despesas: ");
        String despesas = reader.readLine();
        System.out.println("Informe o valor das despesas: ");
        float totalDespesa = scan.nextFloat();
        hospedagem.setDespesas(despesas);
        hospedagem.setDespesaTotal(totalDespesa);
        hospedar.novaSaida(hospedagem);
    }

}
