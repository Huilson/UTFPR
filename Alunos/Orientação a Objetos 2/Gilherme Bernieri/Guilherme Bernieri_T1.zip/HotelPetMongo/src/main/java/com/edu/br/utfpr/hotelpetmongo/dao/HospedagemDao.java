/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.br.utfpr.hotelpetmongo.dao;
import com.edu.br.utfpr.hotelpetmongo.model.Hospedagem;
import com.edu.br.utfpr.hotelpetmongo.model.animal.Animal;
import com.edu.br.utfpr.hotelpetmongo.util.Util;
import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.bson.Document;

/**
 *
 * @author User
 */
public class HospedagemDao {
    public Hospedagem hospedagem = new Hospedagem();
    MongoClient conecta = new MongoClient();
    MongoDatabase db = conecta.getDatabase("hotelpet");
    MongoCollection<Document> hospedar = db.getCollection("hospedagem");
    Util util = new Util();
    Animal animal = new Animal();
    PessoaTutorDao ptd = new PessoaTutorDao();
    PessoaFuncionarioDao pfd = new PessoaFuncionarioDao();
    
    public void novaHospedagem(Hospedagem hospedagem){
        Document novaHospedagem = new Document("tutor", hospedagem.getTutor().getDocumento())
                .append("funcionario", hospedagem.getFuncionario().getDocumento())
                .append("pet", hospedagem.getPet().getCod())
                .append("entrada", hospedagem.getEntrada().toString())
                .append("saida", null)
                .append("despesa", null)
                .append("totalDespesa", null);
                
        hospedar.insertOne(novaHospedagem);
    }
    
    public Hospedagem buscarHospedagem(int codPet){
        animal = util.animal;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        Document hospedagemMongo = hospedar.find(Filters.eq("pet",codPet)).first();
        hospedagem.setPet(animal);
        hospedagem.setTutor(ptd.buscarTutor(hospedagemMongo.getString("tutor")));
        hospedagem.setFuncionario(pfd.buscarFuncionario(hospedagemMongo.getString("funcionario")));
        LocalDate entrada = LocalDate.parse(hospedagemMongo.getString("entrada"), formatter);
        hospedagem.setEntrada(entrada);
        LocalDate saida = LocalDate.parse(hospedagemMongo.getString("saida"), formatter);
        hospedagem.setEntrada(saida);
        hospedagem.setDespesas(hospedagemMongo.getString("despesa"));
        hospedagem.setDespesaTotal(Float.parseFloat(hospedagemMongo.getString("totalDespesa")));
        return hospedagem;
    }
    public void novaSaida(Hospedagem hospedagem){
        Hospedagem hospedagemAntiga = new Hospedagem();
        hospedagemAntiga = buscarHospedagem(hospedagem.getPet().getCod());
        LocalDate saida = LocalDate.now();
        if(hospedagemAntiga.getSaida() == null){
            hospedar.updateOne(Filters.eq("pet", hospedagem.getPet().getCod()),
                new Document("$set", new Document("saida", saida)));
            hospedar.updateOne(Filters.eq("pet", hospedagem.getPet().getCod()),
                new Document("$set", new Document("despesa", hospedagem.getDespesas())));
            hospedar.updateOne(Filters.eq("pet", hospedagem.getPet().getCod()),
                new Document("$set", new Document("totalDespesa", hospedagem.getDespesaTotal())));
        }else{
            System.out.println("Nao é possivel encerrar essa hospedagem");
        }
        
    }
}
