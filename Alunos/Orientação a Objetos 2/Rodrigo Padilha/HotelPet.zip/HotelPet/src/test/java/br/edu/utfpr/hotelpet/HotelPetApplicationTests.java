package br.edu.utfpr.hotelpet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelPetApplicationTests {

  @Test
  void contextLoads() {
  }

}
