package br.edu.utfpr.hotelpet.pessoa.controller;

import br.edu.utfpr.hotelpet.pessoa.model.Funcionario;
import br.edu.utfpr.hotelpet.pessoa.model.Pessoa;
import br.edu.utfpr.hotelpet.pessoa.model.PessoaTypeEnum;
import br.edu.utfpr.hotelpet.pessoa.model.Tutor;
import br.edu.utfpr.hotelpet.pessoa.repository.PessoaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("funcionario")
@RequiredArgsConstructor
public class FuncionarioController {
  private final PessoaRepository repository;

  @GetMapping
  String listaFuncionarios(Model model){
    model.addAttribute("funcionarios",repository.findByTipo(PessoaTypeEnum.STAFF));
    return "gerencia/listaStaff";
  }

  @GetMapping("cadastro")
  String telaCadastro(Model model){
    model.addAttribute("funcionario", new Funcionario());
    return "gerencia/cadastroStaff";
  }

  @GetMapping("cadastro/{id}")
  String telaCadastroEdicao(@PathVariable String id, Model model){
    model.addAttribute("funcionario", repository.findById(id).orElse(null));
    return "gerencia/cadastroStaff";
  }

  @PostMapping("salvar")
  String salvarFuncionario(Model model, @ModelAttribute Funcionario funcionario){
    if (funcionario.getCodigo().isBlank()){
      funcionario.setCodigo(null);
    }
    funcionario = repository.save(funcionario);
    return "redirect:/funcionario/cadastro/" + funcionario.getCodigo();
  }

  @GetMapping("remover/{id}")
  String removerUsuario(@PathVariable String id){
    repository.deleteById(id);
    return "redirect:/funcionario";
  }
}
