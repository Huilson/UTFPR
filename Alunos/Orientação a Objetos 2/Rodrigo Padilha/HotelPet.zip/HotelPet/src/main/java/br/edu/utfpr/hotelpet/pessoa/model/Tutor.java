package br.edu.utfpr.hotelpet.pessoa.model;

public class Tutor extends Pessoa {

  public Tutor(){
    super();
    this.tipo = PessoaTypeEnum.TUTOR;
  }
}
