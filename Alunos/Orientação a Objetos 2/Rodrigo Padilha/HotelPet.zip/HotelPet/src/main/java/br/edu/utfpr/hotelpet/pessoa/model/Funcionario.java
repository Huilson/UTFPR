package br.edu.utfpr.hotelpet.pessoa.model;

public class Funcionario extends Pessoa {
  public Funcionario(){
    super();
    this.tipo = PessoaTypeEnum.STAFF;
  }
}
