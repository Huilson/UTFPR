package br.edu.utfpr.hotelpet.animal.model;

public enum AnimalTypeEnum {
  GATO("Gato"),
  CACHORRO("Cachorro"),
  PASSARO("Pássaro");

  private String tipo;

  AnimalTypeEnum(String tipo){
    this.tipo = tipo;
  }

  public String getTipo(){
    return tipo;
  }
}
