package br.edu.utfpr.hotelpet.hospede.controller;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.animal.model.AnimalTypeEnum;
import br.edu.utfpr.hotelpet.animal.repository.AnimalRepository;
import br.edu.utfpr.hotelpet.hospede.model.Hospede;
import br.edu.utfpr.hotelpet.hospede.repository.HospedeRepository;
import br.edu.utfpr.hotelpet.pessoa.model.PessoaTypeEnum;
import br.edu.utfpr.hotelpet.pessoa.repository.PessoaRepository;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("hospede")
@RequiredArgsConstructor
public class HospedeController {

  private final HospedeRepository repository;
  private final AnimalRepository animalRepository;
  private final PessoaRepository pessoaRepository;

  @GetMapping
  public String listHospedes(Model model) {
    var hospedes = repository.findAll();
    Collections.sort(hospedes, (h1, h2) -> h2.getCheckin().compareTo(h1.getCheckin()));
    model.addAttribute("hospedes", repository.findAll());
    return "gerencia/listaHospedagem";
  }

  @GetMapping("cadastro")
  String telaCadastro(Model model) {
    var hospede = new Hospede();
    hospede.setCodigo("");
    model.addAttribute("hospede", hospede);
    List<Animal> animaisDisponiveis = animalRepository.findAll();
    Set<String> animaisHospedados = repository.findByAtivo(true).stream().map(h -> h.getAnimal().getNome()).collect(
        Collectors.toSet());
    animaisDisponiveis.removeIf(a -> { return animaisHospedados.contains(a.getNome());});
    model.addAttribute("animais", animaisDisponiveis);
    model.addAttribute("funcionarios", pessoaRepository.findByTipo(PessoaTypeEnum.STAFF));
    return "gerencia/cadastroHospedagem";
  }

  @GetMapping("cadastro/{id}")
  String telaCadastroEdicao(@PathVariable String id, Model model){
    var hospede = repository.findById(id).orElse(null);
    model.addAttribute("hospede", hospede);
    model.addAttribute("animais", List.of(hospede.getAnimal()));
    model.addAttribute("funcionarios", List.of(hospede.getFuncionario()));
    return "gerencia/cadastroHospedagem";
  }

  @PostMapping("salvar")
  String salvarAnimal(Model model, @ModelAttribute Hospede hospede) {
    if (hospede.getCodigo().isBlank()) {
      hospede.setCodigo(null);
    }
    hospede.setAtivo(true);
    Random rand = new Random();
    do {
      hospede.setAndar(rand.nextLong(100));
    } while (repository.existsHospedeByAndar(hospede.getAndar()));
    hospede.setCheckin(LocalDateTime.now());
    hospede = repository.save(hospede);
    return "redirect:/hospede/cadastro/" + hospede.getCodigo();
  }

  @GetMapping("checkout/{id}")
  String checkout(@PathVariable String id){
    var hospede = repository.findById(id).orElse(null);
    if (hospede != null) {
      hospede.setAtivo(false);
      hospede.setCheckout(LocalDateTime.now());
      repository.save(hospede);
    }
    return "redirect:/hospede";
  }
}
