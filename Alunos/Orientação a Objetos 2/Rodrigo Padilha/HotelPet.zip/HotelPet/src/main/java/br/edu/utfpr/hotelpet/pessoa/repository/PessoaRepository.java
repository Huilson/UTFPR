package br.edu.utfpr.hotelpet.pessoa.repository;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.pessoa.model.Pessoa;
import br.edu.utfpr.hotelpet.pessoa.model.PessoaTypeEnum;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PessoaRepository extends MongoRepository<Pessoa, String>{

//Busca a pessoa pelo tipo especificado
  List<Pessoa> findByTipo(PessoaTypeEnum pessoaTypeEnum);
}
