package br.edu.utfpr.hotelpet.pessoa.model;

public enum PessoaTypeEnum {
  TUTOR("Tutor"),
  STAFF("Staff");

  private String tipo;
  PessoaTypeEnum(String tipo) {this.tipo = tipo;}
  public String getTipo(){return tipo;}

}
