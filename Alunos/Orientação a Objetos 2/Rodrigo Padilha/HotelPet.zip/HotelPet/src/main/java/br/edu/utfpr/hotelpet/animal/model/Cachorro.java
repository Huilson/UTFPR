package br.edu.utfpr.hotelpet.animal.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Cachorro extends Animal {
  public Cachorro(String nome, String especie, Long idade){
    super();
    this.nome = nome;
    this.especie = especie;
    this.idade = idade;
    this.tipo = AnimalTypeEnum.CACHORRO;
  }


}
