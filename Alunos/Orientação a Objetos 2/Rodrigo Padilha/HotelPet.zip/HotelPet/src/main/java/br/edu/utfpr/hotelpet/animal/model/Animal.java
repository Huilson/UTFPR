package br.edu.utfpr.hotelpet.animal.model;

import br.edu.utfpr.hotelpet.pessoa.model.Tutor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

@Getter
@Setter
@NoArgsConstructor
public class Animal {
  @Id
  protected String codigo;
  protected String nome;
  protected String especie;
  protected Long idade;
  protected AnimalTypeEnum tipo;
  protected Tutor tutor;
}
