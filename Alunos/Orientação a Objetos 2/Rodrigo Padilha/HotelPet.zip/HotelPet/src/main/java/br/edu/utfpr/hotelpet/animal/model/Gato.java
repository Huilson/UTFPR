package br.edu.utfpr.hotelpet.animal.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Gato extends Animal{
  public Gato(){
    super();
    this.tipo = AnimalTypeEnum.GATO;
  }
}
