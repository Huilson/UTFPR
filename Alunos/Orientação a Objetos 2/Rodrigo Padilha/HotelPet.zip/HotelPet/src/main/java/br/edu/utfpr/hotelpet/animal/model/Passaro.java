package br.edu.utfpr.hotelpet.animal.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Passaro extends Animal {
  public Passaro(){
    super();
    this.tipo = AnimalTypeEnum.PASSARO;
  }
}
