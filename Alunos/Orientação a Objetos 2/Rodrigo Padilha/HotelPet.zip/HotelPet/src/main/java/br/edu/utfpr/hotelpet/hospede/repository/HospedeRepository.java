package br.edu.utfpr.hotelpet.hospede.repository;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.hospede.model.Hospede;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HospedeRepository extends MongoRepository<Hospede, String> {
  List<Hospede> findByAtivo(boolean ativo);
  Boolean existsHospedeByAndar(Long andar);
}
