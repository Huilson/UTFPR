package br.edu.utfpr.hotelpet.hospede.model;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.pessoa.model.Funcionario;
import br.edu.utfpr.hotelpet.pessoa.model.Tutor;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

@Getter
@Setter
@NoArgsConstructor
public class Hospede {
  @Id
  private String codigo;
  private Animal animal;
  private Funcionario funcionario;
  private LocalDateTime checkin;
  private LocalDateTime checkout;
  private Long andar;
  private Boolean ativo = false;

}
