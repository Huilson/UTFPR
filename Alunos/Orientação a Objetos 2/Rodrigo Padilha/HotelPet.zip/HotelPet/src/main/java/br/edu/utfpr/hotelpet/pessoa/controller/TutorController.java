package br.edu.utfpr.hotelpet.pessoa.controller;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.animal.model.AnimalTypeEnum;
import br.edu.utfpr.hotelpet.animal.repository.AnimalRepository;
import br.edu.utfpr.hotelpet.pessoa.model.PessoaTypeEnum;
import br.edu.utfpr.hotelpet.pessoa.model.Tutor;
import br.edu.utfpr.hotelpet.pessoa.repository.PessoaRepository;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("tutor")
@RequiredArgsConstructor
public class TutorController {
  private final PessoaRepository repository;
  private final AnimalRepository animalRepository;

  @GetMapping
  String listaAnimais(Model model){
    model.addAttribute("tutores", repository.findByTipo(PessoaTypeEnum.TUTOR));
    return "tutor/listaTutor";
  }

  @GetMapping("cadastro")
  String telaCadastro(Model model){
    model.addAttribute("tutor", new Tutor());
    return "tutor/cadastroTutor";
  }

  @GetMapping("cadastro/{id}")
  String telaCadastroEdicao(@PathVariable String id, Model model){
    var tutor = repository.findById(id).orElse(null);
    tutor.setPets(carregaAnimalData((Tutor) tutor));
    model.addAttribute("tutor", tutor);
    return "tutor/cadastroTutor";
  }

  @PostMapping("salvar")
  String salvarTutor(Model model, @ModelAttribute Tutor tutor){
    if (tutor.getCodigo().isBlank()){
      tutor.setCodigo(null);
    }
    tutor = repository.save(tutor);
    return "redirect:/tutor/cadastro/" + tutor.getCodigo();
  }

  @GetMapping("remover/{id}")
  String removerTutor(@PathVariable String id){
    repository.deleteById(id);
    return "redirect:/tutor";
  }

  private List<Animal> carregaAnimalData(Tutor tutor){
    return animalRepository.findAllByTutor(tutor);
  }
}
