package br.edu.utfpr.hotelpet.animal.controller;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.animal.model.AnimalTypeEnum;
import br.edu.utfpr.hotelpet.animal.repository.AnimalRepository;
import br.edu.utfpr.hotelpet.pessoa.model.PessoaTypeEnum;
import br.edu.utfpr.hotelpet.pessoa.model.Tutor;
import br.edu.utfpr.hotelpet.pessoa.repository.PessoaRepository;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("animal")
@RequiredArgsConstructor
public class AnimalController {
  private final AnimalRepository repository;
  private final PessoaRepository pessoaRepository;

  @GetMapping
  String listaAnimais(Model model){
    model.addAttribute("animais", repository.findAll());
    return "animal/listaAnimal";
  }

  @GetMapping("cadastro")
  String telaCadastro(Model model){
    model.addAttribute("animal", new Animal());
    model.addAttribute("tipos", AnimalTypeEnum.values());
    model.addAttribute("tutores", pessoaRepository.findByTipo(PessoaTypeEnum.TUTOR));
    return "animal/cadastroAnimal";
  }

  @GetMapping("cadastro/{id}")
  String telaCadastroEdicao(@PathVariable String id, Model model){
    model.addAttribute("animal", repository.findById(id).orElse(null));
    model.addAttribute("tipos", AnimalTypeEnum.values());
    model.addAttribute("tutores", pessoaRepository.findByTipo(PessoaTypeEnum.TUTOR));
    return "animal/cadastroAnimal";
  }

  @PostMapping("salvar")
  String salvarAnimal(Model model, @ModelAttribute Animal animal){
    if (animal.getCodigo().isBlank()){
      animal.setCodigo(null);
    }
    animal = repository.save(animal);
    return "redirect:/animal/cadastro/" + animal.getCodigo();
  }

  @GetMapping("remover/{id}")
  String removerAnimal(@PathVariable String id){
    var animal = repository.findById(id).orElse(null);
    if (animal != null) {
      repository.deleteById(animal.getCodigo());
    }
    return "redirect:/animal";
  }
}