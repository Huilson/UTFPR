package br.edu.utfpr.hotelpet;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import br.edu.utfpr.hotelpet.animal.model.Cachorro;
import br.edu.utfpr.hotelpet.animal.repository.AnimalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelPetApplication {
  public static void main(String[] args) {
    SpringApplication.run(HotelPetApplication.class, args);
  }
}
