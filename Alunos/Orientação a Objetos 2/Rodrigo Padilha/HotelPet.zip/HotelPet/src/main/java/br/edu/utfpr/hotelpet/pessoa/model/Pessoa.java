package br.edu.utfpr.hotelpet.pessoa.model;

import br.edu.utfpr.hotelpet.animal.model.Animal;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

@Getter
@Setter
@AllArgsConstructor
public class Pessoa {
  @Id
  protected String codigo;
  protected String nome;
  protected PessoaTypeEnum tipo;
  protected List<Animal> pets;

  public Pessoa() {
    this.pets = new ArrayList<>();
  }
}
