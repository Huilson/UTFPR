package br.edu.utfpr.hotelpet.model;

public class Funcionário extends Pessoa {

  public Funcionário() {
    super();
    this.tipo = PessoaTypeEnum.STAFF;
  }
}
