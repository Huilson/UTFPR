package br.edu.utfpr.hotelpet.model;

public enum AnimalTypeEnum {
  GATO, CACHORRO, OVELHA
}
