package br.edu.utfpr.hotelpet;

import br.edu.utfpr.hotelpet.database.AnimalDTO;
import br.edu.utfpr.hotelpet.database.PessoaDTO;
import br.edu.utfpr.hotelpet.model.Animal;
import br.edu.utfpr.hotelpet.model.Cachorro;
import br.edu.utfpr.hotelpet.model.Funcionário;
import br.edu.utfpr.hotelpet.model.Gato;
import br.edu.utfpr.hotelpet.model.Ovelha;
import br.edu.utfpr.hotelpet.model.Tutor;
import br.edu.utfpr.hotelpet.view.MenuPrincipal;
import java.util.List;

public class Main {

  /**
   * Favor validar as configurações em MongoDBSingleton
   */
  public static void main(String[] args) {

//    MenuPrincipal.executaMenuPrincipal();

      testaCrudAnimal();
      testaCrudPessoa();
  }

  private static void testaCrudPessoa() {
    var pessoaDTO = new PessoaDTO();

    var joao = new Tutor();
    joao.setNome("João das Neves");
    joao.setPets(List.of(new Cachorro("Wolfgang", "Pasto Alemão", "8"),
        new Cachorro("Belinha", "Isabela menor", "2")));
    joao.setDocumento("123.456.789-01");

    var jose = new Funcionário();
    jose.setNome("Zé das quantas");
    jose.setDocumento("111.111.111-11");

    pessoaDTO.createPessoa(joao);
    pessoaDTO.createPessoa(jose);
    pessoaDTO.printPessoas();


  }

  private static void testaCrudAnimal(){
    var animalDTO = new AnimalDTO();

    var cachorro = new Cachorro();
    cachorro.setNome("Wolfgang");
    cachorro.setEspecie("Pastor Alemão");
    cachorro.setIdade("8");
    var gato = new Gato();
    gato.setNome("Felix");
    gato.setEspecie("Angorá");
    gato.setIdade("2");
    var ovelha = new Ovelha();
    ovelha.setNome("Watame");
    ovelha.setEspecie("Herdwick");
    ovelha.setIdade("1");

    if (animalDTO.createAnimal(cachorro))
      System.out.println("Cachorro criado com sucesso");
    if (animalDTO.createAnimal(gato))
      System.out.println("Gato criado com sucesso");
    if (animalDTO.createAnimal(ovelha))
      System.out.println("Ovelha criada com sucesso");

    System.out.println();

    animalDTO.printAnimais();

    if (animalDTO.deleteAnimal(ovelha.getNome())) {
      System.out.println("\nWatame foi de arrasta pra cima");
    }

    gato.setEspecie("Persa");
    if (animalDTO.atualizaAnimal(gato)) {
      System.out.println("Espécie do gato alterada");
    }

    var sissel = animalDTO.findAnimal("Felix");
    System.out.println(sissel+"\n");

    animalDTO.printAnimais();
  }
}
