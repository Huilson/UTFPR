package br.edu.utfpr.hotelpet.view;

import java.util.Scanner;

public class MenuPrincipal {

  public static void executaMenuPrincipal(){
    boolean executando = true;
    var scanner = new Scanner(System.in);

    while (executando) {
      imprimeMenuPrincipal();
      var opt = scanner.nextInt();

      switch (opt){
        case 1 -> MenuHospedes.executaMenuHospedes();
//        case 2 -> executaMenuDespesas();
//        case 3 -> executaMenuFuncionarios();
        case 4 -> executando = false;
        default -> System.out.println("Opção inválida, selecione opção de 1 a 4");
      }
    }

    scanner.close();
  }
  private static void imprimeMenuPrincipal(){
    MenuUtils.limpaConsole();
    System.out.println("Bem-vindo ao Sistema do HotelPet");
    System.out.println("Selecione uma opção:");
    System.out.println("1. Controle de Hóspedes");
    System.out.println("2. Controle de Despesas");
    System.out.println("3. Controle de Funcionários");
    System.out.println("4. Sair do Programa");
  }
}
