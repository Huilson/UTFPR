package br.edu.utfpr.hotelpet.model;

public enum PessoaTypeEnum {
  TUTOR, STAFF
}
