package br.edu.utfpr.hotelpet.database;

import br.edu.utfpr.hotelpet.model.Animal;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.InsertOneResult;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bson.types.ObjectId;

public class AnimalDTO {

  private MongoCollection<Animal> getCollection(){
    return MongoDBSingleton.getDBInstance().getCollection("Animal", Animal.class);
  }
  public Boolean createAnimal(Animal animal){
     var result = getCollection().insertOne(animal);
     return result.wasAcknowledged();
  }

  public List<Animal> getAnimais(){
    var animais = new ArrayList<Animal>();
    getCollection().find().into(animais);
    return animais;
  }

  public Boolean atualizaAnimal(Animal animal){
    var result = getCollection().updateOne(
        Filters.eq("nome", animal.getNome()),
        Updates.combine(
            Updates.set("idade", animal.getIdade()),
            Updates.set("especie", animal.getEspecie())));
    return result.wasAcknowledged();
  }

  public Animal findAnimal(String nome) {
    return getCollection().find(Filters.eq("nome", nome)).first();
  }

  public boolean deleteAnimal(String nome){
    return getCollection().deleteOne(Filters.eq("nome", nome)).wasAcknowledged();
  }

  public void printAnimais(){
    System.out.println("Animais");
    System.out.println("=".repeat(80));
    getAnimais().forEach(System.out::println);
  }
}
