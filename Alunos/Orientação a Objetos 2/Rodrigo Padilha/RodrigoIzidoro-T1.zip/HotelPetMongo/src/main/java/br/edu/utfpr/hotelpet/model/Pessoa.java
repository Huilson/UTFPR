package br.edu.utfpr.hotelpet.model;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Pessoa {

  protected String nome;
  protected String documento;
  protected PessoaTypeEnum tipo;
  protected List<Animal> pets;


  public Pessoa() {
    this.pets = new ArrayList<>();
  }

  @Override
  public String toString() {
    var sb = new StringBuilder();
    sb.append(String.format("Documento: %s Nome: %s Profissão: %s Animais: " , this.documento,
        this.nome, this.tipo == PessoaTypeEnum.STAFF ? "Funcionário" : "Tutor"));
    if (pets.isEmpty()) {
      sb.append("Não tem pets");
    } else {
      pets.forEach(p -> sb.append(String.format(" %s ", p.getNome())));
    }
    return sb.toString();
  }
}
