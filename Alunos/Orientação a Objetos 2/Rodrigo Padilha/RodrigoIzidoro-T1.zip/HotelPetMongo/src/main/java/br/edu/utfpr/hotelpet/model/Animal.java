package br.edu.utfpr.hotelpet.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.bson.types.ObjectId;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Animal {
  protected ObjectId id;
  protected String nome;
  protected String especie;
  protected String idade;
  protected AnimalTypeEnum tipo;

  @Override
  public String toString() {
    return String.format("Nome: %s, Raça: %s, Idade: %s, Espécie: %s", nome, especie, idade, tipo.toString());
  }
}

