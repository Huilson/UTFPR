package br.edu.utfpr.hotelpet.view;

public class MenuUtils {

  private MenuUtils() {}

  public static void limpaConsole(){
    System.out.print("\033[H\033[2J");
    System.out.flush();
  }
}
