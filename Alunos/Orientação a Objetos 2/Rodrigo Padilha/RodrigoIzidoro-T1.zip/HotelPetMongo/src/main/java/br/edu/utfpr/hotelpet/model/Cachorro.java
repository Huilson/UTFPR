package br.edu.utfpr.hotelpet.model;

import lombok.Getter;
import lombok.Setter;
import org.bson.types.ObjectId;

@Getter
@Setter
public class Cachorro extends Animal{

  public Cachorro() {
    super();
    this.tipo = AnimalTypeEnum.CACHORRO;
  }

  public Cachorro(String nome, String especie, String idade) {
    super(null, nome, especie, idade, AnimalTypeEnum.CACHORRO);
  }
}
