package br.edu.utfpr.hotelpet.database;

import br.edu.utfpr.hotelpet.model.Animal;
import br.edu.utfpr.hotelpet.model.Pessoa;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import java.util.ArrayList;
import java.util.List;

public class PessoaDTO {
  private MongoCollection<Pessoa> getCollection(){
    return MongoDBSingleton.getDBInstance().getCollection("Pessoa", Pessoa.class);
  }

  public Boolean createPessoa(Pessoa pessoa){
    var result = getCollection().insertOne(pessoa);
    return result.wasAcknowledged();
  }

  public List<Pessoa> getPessoas(){
    var pessoas = new ArrayList<Pessoa>();
    getCollection().find().into(pessoas);
    return pessoas;
  }

  public Pessoa findPessoa(String nome) {
    return getCollection().find(Filters.eq("nome", nome)).first();
  }

  public boolean deletePessoa(String documento){
    return getCollection().deleteOne(Filters.eq("documento", documento)).wasAcknowledged();
  }

  public Boolean atualizaPessoa(Pessoa pessoa){
    return getCollection().updateOne(
        Filters.eq("documento", pessoa.getDocumento()),
        Updates.combine(
            Updates.set("nome", pessoa.getNome()),
            Updates.set("tipo", pessoa.getTipo()),
            Updates.set("pets", pessoa.getPets())
        )).wasAcknowledged();
  }

  public void printPessoas(){
    System.out.println("Contatos");
    System.out.println("=".repeat(80));
    getPessoas().forEach(System.out::println);
  }


}
