package br.edu.utfpr.hotelpet.view;

import br.edu.utfpr.hotelpet.database.AnimalDTO;
import java.util.Scanner;

public class MenuHospedes {
  public static void executaMenuHospedes(){
    boolean executando = true;
    var scanner = new Scanner(System.in);

    while (executando) {
      MenuUtils.limpaConsole();
      scanner.nextInt();
      System.out.println("Selecione a opção desejada: ");
      System.out.println("1 - Listar Hóspedes");
      System.out.println("2 - Buscar Hóspede");
      System.out.println("3 - Editar Hóspede");
      System.out.println("4 - Remover Hóspede");
      System.out.println("5 - Retornar um menu");

      if (scanner.hasNextInt()) {
        var opt = scanner.nextInt();
        switch (opt) {
          case 1 -> ListarHospedes();
//        case 2 -> BuscarHospede();
//        case 3 -> EditarHospede();
//        case 4 -> removerHospede();
          case 5 -> executando = false;
          default -> System.out.println("Opção inválida, selecione opção de 1 a 5");
        }
      }
    }
    scanner.close();
  }

  private static void ListarHospedes() {
    MenuUtils.limpaConsole();
    System.out.println("Lista de Hóspedes Cadastrados\n");
    new AnimalDTO().getAnimais().forEach(System.out::println);

    try (var scanner = new Scanner(System.in)){
      while (true){
        System.out.println("Digite sair para voltar ao menu anterior");
        if (scanner.nextLine().toLowerCase().equals("sair")){
          break;
        }
        scanner.close();
      }
    }
  }
}
