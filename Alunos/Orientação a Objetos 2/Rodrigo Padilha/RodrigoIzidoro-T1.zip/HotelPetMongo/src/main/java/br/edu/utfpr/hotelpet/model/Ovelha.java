package br.edu.utfpr.hotelpet.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Ovelha extends Animal {

  public Ovelha() {
    super();
    this.tipo = AnimalTypeEnum.OVELHA;
  }
}
