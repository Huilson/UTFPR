package br.edu.utfpr.hotelpet.database;

import static com.mongodb.MongoClientSettings.getDefaultCodecRegistry;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.codecs.configuration.CodecProvider;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

public class MongoDBSingleton {
  private static MongoDatabase instance;
  private String uri = "mongodb://localhost:27017";
  private static String db = "hotelpet";

  private MongoDBSingleton(){
    this.uri = uri;
    CodecProvider pojoCodecProvider = PojoCodecProvider.builder().automatic(true).build();
    CodecRegistry pojoCodecRegistry = fromRegistries(getDefaultCodecRegistry(), fromProviders(pojoCodecProvider));

    var mongoClient = MongoClients.create(this.uri);
    this.instance = mongoClient.getDatabase(db).withCodecRegistry(pojoCodecRegistry);
  }

  public static MongoDatabase getDBInstance(){

    if (instance == null) {
      new MongoDBSingleton();
    }

    return instance;
  }

}
