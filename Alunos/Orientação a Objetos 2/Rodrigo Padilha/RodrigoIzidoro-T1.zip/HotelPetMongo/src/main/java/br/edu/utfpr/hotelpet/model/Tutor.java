package br.edu.utfpr.hotelpet.model;

public class Tutor extends Pessoa {

  public Tutor() {
    super();
    this.tipo = PessoaTypeEnum.TUTOR;
  }
}
