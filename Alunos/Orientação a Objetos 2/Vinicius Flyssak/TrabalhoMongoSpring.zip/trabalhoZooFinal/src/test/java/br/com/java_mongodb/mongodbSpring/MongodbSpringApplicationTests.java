package br.com.java_mongodb.mongodbSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
