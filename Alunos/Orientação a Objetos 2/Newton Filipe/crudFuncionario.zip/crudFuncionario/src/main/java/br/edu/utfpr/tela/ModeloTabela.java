/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.tela;

import java.util.List;
import javax.swing.JComboBox;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import br.edu.utfpr.entidades.Pessoa;
import br.edu.utfpr.entidades.Profissao;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 * @author benalian42
 */
public class ModeloTabela implements TableModel {
    
    List<JComboBox> listaProfissoes;
    List<Pessoa> listaPessoas;
    Object[][] data;
    
    enum ColNomes {
        ID ("Id"),
        NOME ("Nome"),
        CPF ("CPF"),
        IDADE ("Idade"),
        CONTATO ("Contato"),
        CIDADE ("Cidade"),
        RUA ("Rua"),
        NUMERO ("Numero"),
        PROFISSAO ("Profissao");
        
        private final String coluna;
        
        ColNomes (String coluna)
        {
            this.coluna = coluna;
        }
    };
    
    public ModeloTabela(List<JComboBox> listaProfissoes, List<Pessoa> listaPessoas) {
        this.listaProfissoes = listaProfissoes;
        this.listaPessoas = listaPessoas;
    }

    public List<JComboBox> getListaProfissoes() {
        return listaProfissoes;
    }

    public void setListaProfissoes(List<JComboBox> listaProfissoes) {
        this.listaProfissoes = listaProfissoes;
    }

    public List<Pessoa> getListaPessoas() {
        return listaPessoas;
    }

    public void setListaPessoas(List<Pessoa> listaPessoas) {
        this.listaPessoas = listaPessoas;
    }    
    
    @Override
    public int getRowCount() {
        return listaPessoas.size();
    }
    
    @Override
    public int getColumnCount() {
        return ColNomes.values().length;
    }

    @Override
    public String getColumnName(int i) {
        return ColNomes.values()[i].toString();
    }

    @Override
    public Class<?> getColumnClass(int i) {
        try{
            if( i < 2 )
                return Class.forName("Profissao");
            return Class.forName("Pessoa");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ModeloTabela.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    

    @Override
    public boolean isCellEditable(int i, int i1) {
        return true;
    }

    @Override
    public Object getValueAt(int i, int i1) {
        if ( i1 == 2 )
        {
            return listaProfissoes.get(i).getSelectedIndex();
        } else if ( i1 == ColNomes.ID.ordinal() ){
            return listaPessoas.get(i).getId();
        } else if ( i1 == ColNomes.NOME.ordinal() )
        {
            return listaPessoas.get(i).getNome();
        } else if ( i1 == ColNomes.CPF.ordinal() )
        {
            return listaPessoas.get(i).getCpf();
        } else if ( i1 == ColNomes.CONTATO.ordinal() )
        {
            return listaPessoas.get(i).getContato();
        } else if ( i1 == ColNomes.CIDADE.ordinal() )
        {
            return listaPessoas.get(i).getCidade();
        } else if ( i1 == ColNomes.RUA.ordinal() )
        {
            return listaPessoas.get(i).getRua();
        } else if ( i1 == ColNomes.NUMERO.ordinal() )
        {
            return listaPessoas.get(i).getNumero();
        } else if ( i1 == ColNomes.PROFISSAO.ordinal() )
        {
            return listaPessoas.get(i).getProfissao();
        }
        return null;
    }

    @Override
    public void setValueAt(Object o, int i, int i1) {
        if ( i1 == 2 )
        {
            listaProfissoes.get(i).setSelectedIndex((int) o);
        } else if ( i1 == ColNomes.ID.ordinal() ){
            listaPessoas.get(i).setId((int) o);
        } else if ( i1 == ColNomes.NOME.ordinal() )
        {
            listaPessoas.get(i).setNome((String) o);
        } else if ( i1 == ColNomes.CPF.ordinal() )
        {
            listaPessoas.get(i).setCpf((String) o);
        } else if ( i1 == ColNomes.CONTATO.ordinal() )
        {
            listaPessoas.get(i).setContato((String) o);
        } else if ( i1 == ColNomes.CIDADE.ordinal() )
        {
            listaPessoas.get(i).setCidade((String) o);
        } else if ( i1 == ColNomes.RUA.ordinal() )
        {
            listaPessoas.get(i).setRua((String) o);
        } else if ( i1 == ColNomes.NUMERO.ordinal() )
        {
            listaPessoas.get(i).setNumero((int) o);
        } else if ( i1 == ColNomes.PROFISSAO.ordinal() )
        {
            listaPessoas.get(i).getProfissao().setNome((String) o);
        }
        //fireTableDataChanged();
    }

    @Override
    public void addTableModelListener(TableModelListener tl) {
    }

    @Override
    public void removeTableModelListener(TableModelListener tl) {
    }
    
}
