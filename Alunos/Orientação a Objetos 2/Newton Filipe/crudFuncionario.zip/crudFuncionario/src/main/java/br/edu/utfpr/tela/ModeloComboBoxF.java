/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.tela;

import br.edu.utfpr.entidades.Profissao;
import java.util.List;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author benalian42
 */
public class ModeloComboBoxF extends DefaultComboBoxModel<Profissao> {
    
    private List<Profissao> profissoes;

    public List<Profissao> getProfissao() {
        return profissoes;
    }

    public void setProfissao(List<Profissao> profissoes) {
        this.profissoes = profissoes;
    }

    public ModeloComboBoxF(List<Profissao> profissoes) {
        this.profissoes = profissoes;
    }
}
