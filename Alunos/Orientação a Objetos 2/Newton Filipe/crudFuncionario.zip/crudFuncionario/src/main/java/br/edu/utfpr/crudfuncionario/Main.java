/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.utfpr.crudfuncionario;

import br.edu.utfpr.tela.CRUD;

/**
 *
 * @author benalian42
 */
public class Main {

    public static void main(String[] args) {
        CRUD c = new CRUD();
        
    }
}
