package com.turma.hotelPet.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.turma.hotelPet.codec.CodecAnimal;
import com.turma.hotelPet.model.Animal;
import com.turma.hotelPet.model.Disciplina;
import com.turma.hotelPet.model.Pessoa;
import com.turma.hotelPet.model.Sala;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class AnimalRepository {

    public MongoDatabase conecta() {
        //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Passar para a classe de codificação qual será o codec usado
        CodecAnimal animalCodec = new CodecAnimal(codec);

        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(animalCodec)
        );

        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();

        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet");
        return db;
    }

    public void salvar( Animal animal ) {
        MongoDatabase db = conecta();
        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
        //Se eu já tiver um animal simplesmente atualizo ele
        if (animal.getId() == null) {
            animais.insertOne(animal);
        } else {
            animais.updateOne(Filters.eq("_id", animal.getId()), new Document("$set", animal));
        }

        //cliente.close();
    }

    public List<Animal> listar() {
        MongoDatabase db = conecta();
        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
        MongoCursor<Animal> resultado = animais.find().iterator();

        //Lista de Iteração
        List<Animal> animalLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Animal animal = resultado.next();
            animalLista.add(animal);
        }

        return animalLista;
    }

    public Animal obterId(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
        Animal animal = animais.find(Filters.eq("_id", new ObjectId(id))).first();
        return animal;
    }

    public void excluir(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
        animais.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }

//    public List<Animal> buscarDisciplinas(String disciplina) {
//        MongoDatabase db = conecta();
//        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
//        MongoCursor<Animal> resultado = animais.find(Filters.eq("disciplinas.nome",disciplina))
//                .iterator();
//
//        //Lista de Iteração        
//        List<Animal> animalLista = new ArrayList<>();
//        while (resultado.hasNext()) {
//            Animal animal = resultado.next();            
//            
//            List<Disciplina> disciplinas = (List<Disciplina>) animal.getDisciplina();
//            for(Disciplina disciplinaAnimal : disciplinas){
//                if(disciplinaAnimal.getNome().equalsIgnoreCase(disciplina))
//                    animalLista.add(animal);
//            }//fim FOR            
//        }//fim WHILE
//        return animalLista;
//    }
}
