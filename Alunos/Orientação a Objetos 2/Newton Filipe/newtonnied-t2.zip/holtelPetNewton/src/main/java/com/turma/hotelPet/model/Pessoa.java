/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;

import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

/**
 *
 * @author benalian42
 */

public class Pessoa {
    private ObjectId id;
    private String nome;
    private String documento;
    private List<Animal> pets;

    public List<Animal> getPets() {
        return pets;
    }

    public void setPets(List<Animal> pets) {
        this.pets = pets;
    }
    
    public Pessoa() {
    }
    
    public Pessoa( String nome, String documento ) {
        this.nome = nome;
        this.documento = documento;

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }
    
    public void setId(ObjectId id) {
        this.id = id;
    }
    
    public ObjectId getId() {
        return this.id;
    }

    public Pessoa criarId(){
        this.setId(new ObjectId());
        return this;
    }

    
    
}
