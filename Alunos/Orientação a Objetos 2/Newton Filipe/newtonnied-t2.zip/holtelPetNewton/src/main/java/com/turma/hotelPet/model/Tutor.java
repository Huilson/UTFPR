/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;

import java.util.List;

/**
 *
 * @author benalian42
 */
//@Document (collection = "Tutores")
public class Tutor extends Pessoa {
    private List<Animal> pets;

    public Tutor(String nome, String documento) {
        super(nome, documento);
    }

    public Tutor(List<Animal> pets, String nome, String documento) {
        super(nome, documento);
        this.pets = pets;
    }
    
    
    public List<Animal> getPets() {
        return pets;
    }

    public void setPets(List<Animal> pets) {
        this.pets = pets;
    }
    
}
