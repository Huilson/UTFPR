package com.turma.hotelPet.codec;

import com.turma.hotelPet.model.Animal;
import com.turma.hotelPet.model.Animal;
import com.turma.hotelPet.model.AnimalGenerico;
import com.turma.hotelPet.model.Cachorro;
import com.turma.hotelPet.model.Disciplina;
import com.turma.hotelPet.model.Gato;
import com.turma.hotelPet.model.Pessoa;
import com.turma.hotelPet.model.Vaca;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecAnimal implements CollectibleCodec<Animal>{
    //Atributo para criação de documento
    private Codec<Document> codec;
    
    //Construtor
    public CodecAnimal ( Codec<Document> codec ) {
        this.codec = codec;
    }

    @Override
    public Animal generateIdIfAbsentFromDocument(Animal animal) {
        return documentHasId(animal) ? animal.criarId() : animal;
    }

    @Override
    public boolean documentHasId(Animal animal) {
        //esse método só verifica se o objeto chamado tem ID
        return animal.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Animal animal) {
        //Verifica se o ID foi criado
        if(!documentHasId(animal)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(animal.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Animal animal, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = animal.getId();
        Pessoa dono = null;
        
        try {
            dono = animal.getDono();
        } catch (Exception ex) {
            System.out.println("animal sem dono temporariamente");
        }
        
        String nome = animal.getNome();
        Date nascimento = animal.getNasc();
        int idadeAnos = animal.getIdadeAnos();
        String especie = animal.getEspecie();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("dono", dono);
        doc.put("nome",nome);
        doc.put("dono",dono);
        doc.put("idadeAnos",idadeAnos);
        doc.put("especie", especie);
        
        /*List<Disciplina> disciplinas = animal.getDisciplina();
        if(disciplinas != null){
            //Se não tiver uma disciplina cadastrada, cria-se uma lista para
            //não tomar um NPE
            List<Document> disDoc = new ArrayList<>();
            
            //Se houver uma disciplina cadastrada, cria-se um array de 
            //disciplina no MONGODB
            /*for(Disciplina disciplina : disciplinas){
                disDoc.add(new Document("nome", disciplina.getNome())
                        .append("professor", disciplina.getProfessor())
                        .append("semestre", disciplina.getSemestre())
                        .append("notas",disciplina.getNotas())
                );                
            }//FIM DO FOR
            doc.put("disciplinas",disDoc);
        }*/
        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Animal> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Animal.class;
    }

    @Override
    public Animal decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        
        Animal animal = new AnimalGenerico();
        
        animal.setId(doc.getObjectId( "_id" ));
        animal.setNome(doc.getString( "nome" ));
        animal.setIdadeAnos(doc.getInteger( "idadeAnos" ));
        animal.setEspecie(doc.getString("especie"));
        animal.setNasc(doc.getDate( "nasc" ) == null ? new Date(): doc.getDate( "nascimento" ) );
        animal.setCheckIn(doc.getDate("checkIn"));
        animal.setCheckOut(doc.getDate("checkOut"));
        animal.setAndar(doc.getInteger("andar") == null ? -1 : doc.getInteger("andar") );
        animal.setQuarto(doc.getInteger("quarto")== null ? -1 : doc.getInteger("quarto") );
        animal.setDono(animal, (Pessoa) doc.get("dono"));
        
//        List<Document> disciplinas = (List<Document>) doc.get("disciplinas");
//        if(disciplinas != null){
//            List<Disciplina> discDoAnimal = new ArrayList<>();
//            
//            for(Document docDisciplina : disciplinas){
//                discDoAnimal.add(new Disciplina(
//                        docDisciplina.getString("nome"),
//                        docDisciplina.getString("professor"),
//                        docDisciplina.getInteger("semestre"),
//                        docDisciplina.getList("notas", Double.class)));
//            }
//            animal.setDisciplina(discDoAnimal);
//        }        
        return animal;
    }    
}
