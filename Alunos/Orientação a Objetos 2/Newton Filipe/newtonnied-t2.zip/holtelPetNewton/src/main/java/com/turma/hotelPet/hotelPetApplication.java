package com.turma.hotelPet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class hotelPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(hotelPetApplication.class, args);
	}   

}
