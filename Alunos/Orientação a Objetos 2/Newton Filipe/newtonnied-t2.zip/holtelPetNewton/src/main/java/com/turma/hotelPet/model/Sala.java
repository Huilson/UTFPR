package com.turma.hotelPet.model;

import org.bson.types.ObjectId;

public class Sala {

    private ObjectId id;
    private String nome;
    private String disciplina;

    //GETTERS E SETTERS
    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    //CONSTRUTORES
    public Sala(String nome, String disciplina) {
        this.nome = nome;
        this.disciplina = disciplina;
    }

    public Sala() {
    }

    //AUXILIARES
    public Sala criarId() {
        setId(new ObjectId());
        return this;
    }
}
