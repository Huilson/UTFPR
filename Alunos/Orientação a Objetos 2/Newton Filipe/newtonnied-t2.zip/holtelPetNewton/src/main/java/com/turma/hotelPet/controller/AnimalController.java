package com.turma.hotelPet.controller;

import com.turma.hotelPet.model.Animal;
import com.turma.hotelPet.model.AnimalGenerico;
import com.turma.hotelPet.model.Cachorro;
import com.turma.hotelPet.model.Gato;
import com.turma.hotelPet.model.Pessoa;
import com.turma.hotelPet.model.PessoaGenerica;
import com.turma.hotelPet.model.Vaca;
import com.turma.hotelPet.repository.AnimalRepository;
import com.turma.hotelPet.repository.PessoaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AnimalController {
    
//Injeções de dependência
    @Autowired
    private AnimalRepository repository;
    @Autowired
    private PessoaRepository pessoaRepository;
    
    @ModelAttribute("animal")
    public Animal criaAnimal (  )
    {
        return new Animal();
    }
    
    @GetMapping("/animal/cadastrar")
    public String cadastrar( Model model /*, @RequestParam("type") String type*/ ){
        List<Pessoa> pessoas = pessoaRepository.listar();
        model.addAttribute("animal", criaAnimal() );
        model.addAttribute("pessoas", pessoas );
        System.out.println(pessoas.toString());
        return "animal/cadastrar";
    }
    
//    @ModelAttribute("tipoAnimal")
//    public Animal criaAnimal ( String type )
//    {
//        switch (type)
//        {
//            case "Gato":
//                return new Gato();
//            case "Cachorro":
//                return new Cachorro();
//            case "Vaca":
//                return new Vaca();
//            default:
//                return new AnimalGenerico();
//        }
//    }
    
    @PostMapping("/animal/salvar")
    public String salvar(@ModelAttribute Animal animal, 
                        @RequestParam("pessoaId")String pessoaId ){
        
        Pessoa pessoa = pessoaRepository.obterId(pessoaId);
        animal.setDono(animal, pessoa);
        
        System.out.println("Salvando");
        repository.salvar( animal );
        
        return"redirect:/";
    }
    
    @GetMapping("/animal/listar")
    public String listar(Model model){
        List<Animal> animais = repository.listar();
        model.addAttribute("animais", animais);
        return"animal/listar";
    }
    
    @GetMapping("/animal/visualizar/{id}")
    public String visualizar(@PathVariable String id,
            Model model){
        Animal animal = repository.obterId(id);
        model.addAttribute("animal", animal);
        return "animal/visualizar";
    }
    
    @GetMapping("/animal/excluir/{id}")
    public String excluir(@PathVariable String id){        
        repository.excluir(id);
        return"redirect:/animal/listar";
    }
    
    @GetMapping("/animal/atualizar/{id}")
    public String atualizar( @PathVariable String id, Model model ){
        Animal animal = repository.obterId(id);
        model.addAttribute("animal", animal);
        return "animal/atualizar";        
    }
    
    @PostMapping("/animal/editar/{id}")
    public String editar(@ModelAttribute Animal animal, @ModelAttribute Pessoa pessoa){
        repository.salvar( animal );
        return"redirect:/animal/listar";
    }
    
    @GetMapping("/animal/cadastrarTutor/")
    public String vincular( Model model )
    {
        
        return"redirect:/animal/cadastrarTutor";
    }
    
}
