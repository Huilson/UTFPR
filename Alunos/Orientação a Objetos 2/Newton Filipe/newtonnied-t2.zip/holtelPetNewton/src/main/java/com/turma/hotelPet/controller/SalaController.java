//package com.turma.hotelPet.controller;
//
//import com.turma.hotelPet.model.Aluno;
//import com.turma.hotelPet.model.Disciplina;
//import com.turma.hotelPet.model.Sala;
//import com.turma.hotelPet.model.SalaDao;
//import com.turma.hotelPet.repository.AlunoRepository;
//import com.turma.hotelPet.repository.SalaRepository;
//import java.util.ArrayList;
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//
////@Controller
//public class SalaController {
//    
//    @Autowired
//    private SalaRepository repository;
//    
//    @Autowired
//    private AlunoRepository alunoRepository;
//    
//    @GetMapping("/sala/cadastrar")
//    public String cadastrar(Model model) {
//        Sala sala = new Sala();
//        
//        model.addAttribute("sala", new Sala());
//        
//        return "sala/cadastrar";
//    }
//    
//    @PostMapping("/sala/salvar")
//    public String salvar(@ModelAttribute Sala sala){
//        repository.salvar(sala);
//        return"redirect:/";
//    }
//    
//    @GetMapping("/sala/listar")
//    public String listar(Model model){
//        List<Sala> salas = repository.listar();
//        model.addAttribute("salas", salas);
//        return"sala/listar";
//    }
//    
//    @GetMapping("/sala/visualizar/{id}")
//    public String verAlunos(@PathVariable String id, Model model){
//        Sala sala = repository.obterId(id);
//        List<Aluno> alunos = alunoRepository.buscarDisciplinas(sala.getDisciplina());
//        model.addAttribute("alunos", alunos);
//        return"sala/visualizar";
//    }
//    
//    @GetMapping("/sala/vincular/{id}")
//    public String vincular(@PathVariable String id,
//            Model model){
//        Sala sala = repository.obterId(id);
//        model.addAttribute("sala", sala);
//        return "sala/vincular";        
//    }
//    
//    @PostMapping("/sala/editar/{id}")
//    public String editar(@ModelAttribute Sala sala){
//        repository.salvar(sala);
//        return"redirect:/sala/listar";
//    }
//    
//    @GetMapping("/sala/excluir/{id}")
//    public String excluir(@PathVariable String id){        
//        repository.excluir(id);
//        return"redirect:/sala/listar";
//    }
//}
