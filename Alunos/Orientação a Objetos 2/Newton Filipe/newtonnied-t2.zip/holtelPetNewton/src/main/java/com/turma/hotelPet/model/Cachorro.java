/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;

import java.time.LocalDate;
import java.util.Date;
import java.util.Map;
import org.bson.types.ObjectId;

/**
 *
 * @author benalian42
 */
public class Cachorro extends Animal{

    public Cachorro(ObjectId id, String nome, Date nasc, String especie, Date checkIn, Date checkOut, int quarto, int andar, Pessoa dono, String tipo) {
        super(id, nome, nasc, especie, checkIn, checkOut, quarto, andar, dono, tipo);
    }

    public Cachorro() {
    }
    
}