/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author benalian42
 */

public class Animal {
    private ObjectId id;
    
    private String nome;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date nasc;
    
    private int idadeAnos;
    private String especie; 
    private String tipo;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date checkIn;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date checkOut;
    
    private int quarto;
    private int andar;
    private Pessoa dono;
    //Map despesasAdicionais = new HashMap<String,Float>();

    public Animal(ObjectId id, String nome, Date nasc, String especie, Date checkIn,
            Date checkOut, int quarto, int andar, Pessoa dono, String tipo/*, Map despesasAdicionais*/)
    {
        this.id = id;
        this.nome = nome;
        this.nasc = nasc;
        this.especie = especie;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.quarto = quarto;
        this.andar = andar;
        this.dono = dono;
        this.tipo = tipo;
//        this.despesasAdicionais = despesasAdicionais;
        
        
    }
    
    public Animal (){}

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public int getQuarto() {
        return quarto;
    }

    public void setQuarto(int quarto) {
        this.quarto = quarto;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }
    
    
    
    public Date getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(Date checkIn) {
        this.checkIn = checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(Date checkOut) {
        this.checkOut = checkOut;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getNasc() {
        return nasc;
    }

    public void setNasc(Date nasc){
        this.nasc = nasc;
        this.idadeAnos = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()).getYear() - this.nasc.getYear();
    }

    public int getIdadeAnos() {
        return idadeAnos;
    }

    public void setIdadeAnos(int idadeAnos) {
        this.idadeAnos = idadeAnos;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }
    
    public Animal criarId(){
        setId(new ObjectId());
        return this;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    public Pessoa setDono( Animal a, Pessoa p )
    {
        a.dono = p;
        return p;
    }
    public Pessoa getDono() throws Exception
    {
        if ( dono != null )
            return dono;
        else
            throw new Exception ("Nao ha dono no pet operado (getDono())");
    }
    
}