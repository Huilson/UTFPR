/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;

/**
 *
 * @author Aburugudu
 */
public class ConexaoMongo {
    private static ConexaoMongo c = null;
    
    public static ConexaoMongo criaConexao ()
    {
        if ( c != null )
            return c;
        else
            return c = new ConexaoMongo();
    }
}
