/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.turma.hotelPet.model;

/**
 *
 * @author benalian42
 */
public enum EnumAnimais {
    VACA (1),
    CACHORRO (2),
    GATO (3);
    
    EnumAnimais ( int andar )
    {
    }
}
