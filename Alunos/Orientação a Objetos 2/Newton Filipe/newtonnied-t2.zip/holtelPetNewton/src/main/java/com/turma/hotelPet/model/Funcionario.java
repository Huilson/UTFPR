/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;

import java.util.List;

/**
 *
 * @author benalian42
 */
//@Document (collection = "Funcionarios")
public class Funcionario extends Pessoa {
    
    public Funcionario(String nome, String documento) {
        super(nome, documento);
    }
    
}
