/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.turma.hotelPet.model;

import org.springframework.stereotype.Component;

/**
 *
 * @author Aburugudu
 */
@Component
public class PessoaGenerica extends Pessoa{
    
    public PessoaGenerica(String nome, String documento) {
        super(nome, documento);
    }
    public PessoaGenerica()
    {
    }
    
}
