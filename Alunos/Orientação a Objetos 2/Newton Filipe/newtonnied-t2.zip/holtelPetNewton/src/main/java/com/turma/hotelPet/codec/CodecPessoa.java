package com.turma.hotelPet.codec;

import com.turma.hotelPet.model.Aluno;
import com.turma.hotelPet.model.Disciplina;
import com.turma.hotelPet.model.Pessoa;
import com.turma.hotelPet.model.PessoaGenerica;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecPessoa implements CollectibleCodec<Pessoa> {
//Atributo para criação de documento

    private Codec<Document> codec;

    //Construtor
    public CodecPessoa(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Pessoa generateIdIfAbsentFromDocument(Pessoa pessoa) {
        return documentHasId(pessoa) ? pessoa.criarId() : pessoa;
    }

    @Override
    public boolean documentHasId(Pessoa pessoa) {
        //esse método só verifica se o objeto chamado tem ID
        return pessoa.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Pessoa pessoa) {
        //Verifica se o ID foi criado
        if (!documentHasId(pessoa)) {
            throw new IllegalStateException("Esse documento não tem um Id");
        } else {
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(pessoa.getId().toHexString());
        }
    }

    @Override
    public Class<Pessoa> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Pessoa.class;
    }

    @Override
    public void encode(BsonWriter writer, Pessoa pessoa, EncoderContext ec) {
        ObjectId id = pessoa.getId();
        String nome = pessoa.getNome();
        String docu = pessoa.getDocumento();
        
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("documento",docu);
                
        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Pessoa decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Pessoa pessoa = new Pessoa();
        pessoa.setId(doc.getObjectId("_id"));
        pessoa.setNome(doc.getString("nome"));
        pessoa.setDocumento(doc.getString("documento"));
        

        return pessoa;
    }
}
