package com.turma.hotelPet.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.turma.hotelPet.codec.CodecSala;
import com.turma.hotelPet.model.Aluno;
import com.turma.hotelPet.model.Sala;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class SalaRepository {
    public MongoDatabase conecta(){
                //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        //Passar para a classe de codificação qual será o codec usado
        CodecSala salaCodec = new CodecSala(codec);
        
        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(), 
                CodecRegistries.fromCodecs(salaCodec)
        );
        
        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();
        
        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("Aula");
        return db;
    }
    
        public Sala obterId(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Sala> salas = db.getCollection("salas", Sala.class);
        Sala sala = salas.find(Filters.eq("_id", new ObjectId(id))).first();
        return sala;
    }
    
    public void salvar(Sala sala) {
        MongoDatabase db = conecta();
        MongoCollection<Sala> salas = db.getCollection("salas", Sala.class);
        //Se eu já tiver um aluno simplesmente atualizo ele
        if(sala.getId() == null){
            salas.insertOne(sala);
        }else{
            salas.updateOne(Filters.eq("_id",sala.getId()), new Document("$set",sala));
        }        
        //cliente.close();
    }
    
    public List<Sala> listar (){
        MongoDatabase db = conecta();
        MongoCollection<Sala> salas = db.getCollection("salas", Sala.class);
        MongoCursor<Sala> resultado = salas.find().iterator();
        System.out.println("Entrou no listar");
        //Lista de Iteração
        List<Sala> salaLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Sala sala = resultado.next();
            salaLista.add(sala);
        }
        
        return salaLista;
    }   

    public void excluir(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Sala> salas = db.getCollection("salas", Sala.class);
        salas.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }
}