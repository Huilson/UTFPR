//package com.turma.hotelPet.controller;
//
//import com.turma.hotelPet.model.Aluno;
//import com.turma.hotelPet.model.Nota;
//import com.turma.hotelPet.repository.AlunoRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//
////@Controlle
//public class NotaController {
//    
//    @Autowired
//    AlunoRepository repository;
//    
//    @GetMapping("/nota/cadastrar/{id}")
//    public String cadastar(@PathVariable String id,
//            Model model){
//        Aluno aluno = repository.obterId(id);
//        model.addAttribute("aluno", aluno);
//        model.addAttribute("nota", new Nota());
//        return "nota/cadastrar";
//    }
//    
//    @PostMapping("/nota/salvar/{id}")
//    public String salvar(@PathVariable String id,
//            @ModelAttribute Nota nota){
//        Aluno aluno = repository.obterId(id);
//        repository.salvar(aluno.addNota(aluno, nota));
//        return "redirect:/aluno/listar";
//    }
//}
