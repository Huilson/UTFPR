package utfpr.hotelpet.model;

import java.util.List;

public class Andar {
    private String especie;
    private List<Animal> pets;
}
