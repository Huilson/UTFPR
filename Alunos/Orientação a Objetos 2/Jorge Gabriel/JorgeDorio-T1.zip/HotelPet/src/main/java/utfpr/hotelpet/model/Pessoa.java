package utfpr.hotelpet.model;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class Pessoa {
    private final MongoCollection<Document> colecao;
    private String nome;
    private String documento;
    private String tipo;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public MongoCollection<Document> getColecao() {
        return colecao;
    }

    public static void listar(MongoDatabase db) {
        System.out.printf("%-24s%-24s%-24s%-10s\n", "ID", "Nome", "Documento", "Tipo");
        AtomicInteger id = new AtomicInteger(1);
        db.getCollection("pessoas").find().forEach((pessoa) -> {
            String nome = pessoa.getString("nome");
            String documento = pessoa.getString("documento");
            String tipo = pessoa.getString("tipo");
            System.out.printf("%-24s%-24s%-10s\n", id, nome, documento, tipo);
            id.getAndIncrement();
        });
    }

    public String getNome() {
        return nome;
    }

    public String getDocumento() {
        return documento;
    }

    public abstract void criar();

    public void camposPadroes() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Qual o nome da pessoa?");
        this.nome = scanner.nextLine();
        System.out.println("Qual o documento da pessoa?");
        this.documento = scanner.nextLine();
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public Pessoa(MongoDatabase db) {
        this.colecao = db.getCollection("pessoas");
    }

    public static void atualizar (MongoDatabase db){
        System.out.println("Insira o ID do pessoa que deseja atualizar:");
        Scanner scanner = new Scanner(System.in);
        int id = Integer.parseInt(scanner.nextLine());
        var pessoa = db.getCollection("pessoas").find().skip(id - 1).limit(1).first();
        if (pessoa == null) {
            System.out.println("Pessoa não encontrada!");
        } else {
            System.out.println("Qual o nome da pessoa?");
            String nome = scanner.nextLine();
            System.out.println("Qual o documento da pessoa?");
            String documento = scanner.nextLine();
            var documentoAtualizado = new Document("nome", nome)
                    .append("documento", documento);
            db.getCollection("pessoas").updateOne(pessoa, new Document("$set", documentoAtualizado));
            System.out.println("Pessoa atualizada com sucesso!");
        }
    }

    public static void remover(MongoDatabase db) {
        System.out.println("Insira o ID da pessoa que deseja remover:");
        Scanner scanner = new Scanner(System.in);
        int id = Integer.parseInt(scanner.nextLine());
        var pessoa = db.getCollection("pessoas").find().skip(id - 1).limit(1).first();
        if (pessoa == null) {
            System.out.println("Pessoa não encontrada!");
        } else {
            db.getCollection("pessoas").deleteOne(pessoa);
            System.out.println("Pessoa removida com sucesso!");
        }
    }

    public static void cadastrar(MongoDatabase db) {
        Scanner scanner = new Scanner(System.in);
        var repetir = true;
        do {
            System.out.println("Qual o tipo de pessoa?");
            System.out.println("1 - Tutor");
            System.out.println("2 - Funcionario");
            var opcao = scanner.nextInt();
            Pessoa pessoa;
            switch (opcao) {
                case 1:
                    pessoa = new Tutor(db);
                    pessoa.criar();
                    repetir = false;
                    break;
                case 2:
                    pessoa = new Funcionario(db);
                    pessoa.criar();
                    repetir = false;
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }
        } while (repetir);
    }
}
