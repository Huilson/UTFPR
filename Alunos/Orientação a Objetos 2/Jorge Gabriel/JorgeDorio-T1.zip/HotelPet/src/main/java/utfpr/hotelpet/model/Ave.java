package utfpr.hotelpet.model;

import com.mongodb.client.MongoDatabase;

import java.util.Scanner;

public class Ave extends Animal {
    private boolean voa;

    public Ave(MongoDatabase db) {
        super(db);
        this.setAndar(3);
    }

    @Override
    public void criar() {
        Scanner scanner = new Scanner(System.in);
        camposPadroes();
        System.out.println("Sua ave voa? (s/n)");
        this.voa = scanner.nextLine().equals("s");

        var documento = new org.bson.Document("nome", getNome())
                .append("especie", "ave")
                .append("idade", getIdade())
                .append("andar", getAndar())
                .append("voa", this.voa)
                .append("responsavel", this.getResponsavel().getNome());


        getColecao().insertOne(documento);
    }
}
