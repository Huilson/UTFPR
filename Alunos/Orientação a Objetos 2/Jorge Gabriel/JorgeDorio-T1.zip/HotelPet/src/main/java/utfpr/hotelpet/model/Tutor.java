package utfpr.hotelpet.model;

import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Scanner;

public class Tutor extends Pessoa {
    private String especialidade;
    public Tutor(MongoDatabase db) {
        super(db);
        setTipo("tutor");
    }

    @Override
    public void criar() {
        Scanner scanner = new Scanner(System.in);
        camposPadroes();
        System.out.println("Qual a especialidade do tutor?");
        this.especialidade = scanner.nextLine();

        var documento = new Document("nome", getNome())
                .append("especialidade", this.especialidade)
                .append("documento", getDocumento())
                .append("tipo", "tutor");

        getColecao().insertOne(documento);

        System.out.println("Tutor cadastrado com sucesso!");
    }
}
