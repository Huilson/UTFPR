package utfpr.hotelpet.model;

import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Despesa {
    public static void criar(MongoDatabase db) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Qual o valor da despesa?");
        var valor = Double.parseDouble(scanner.nextLine());
        System.out.println("Qual a descricao da despesa?");
        var descricao = scanner.nextLine();
        db.getCollection("despesas").insertOne(new Document("valor", valor).append("descricao", descricao));
    }

    public static void listar(MongoDatabase db) {
        System.out.printf("%-24s%-24s%-10s\n", "ID", "Valor", "Descricao");
        AtomicInteger id = new AtomicInteger(1);
        db.getCollection("despesas").find().forEach((despesa) -> {
            var valor = despesa.getDouble("valor");
            var descricao = despesa.getString("descricao");
            System.out.printf("%-24s%-24s%-10s\n", id, valor, descricao);
            id.getAndIncrement();
        });
    }

    public static void atualizar(MongoDatabase db) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Qual o ID da despesa?");
        var id = Integer.parseInt(scanner.nextLine());
        var despesa = db.getCollection("despesas").find().skip(id - 1).limit(1).first();
        System.out.println("Qual o valor da despesa?");
        var valor = Double.parseDouble(scanner.nextLine());
        System.out.println("Qual a descricao da despesa?");
        var descricao = scanner.nextLine();
        db.getCollection("despesas").updateOne(despesa, new Document("$set", new Document("valor", valor).append("descricao", descricao)));
    }

    public static void remover(MongoDatabase db) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Qual o ID da despesa?");
        var id = Integer.parseInt(scanner.nextLine());
        var despesa = db.getCollection("despesas").find().skip(id - 1).limit(1).first();
        db.getCollection("despesas").deleteOne(despesa);
    }
}
