package utfpr.hotelpet.model;

import com.mongodb.client.MongoDatabase;

import java.util.Scanner;

public class Cachorro extends Animal {
    private String raca;
    private String tamanho;

    public Cachorro(MongoDatabase db) {
        super(db);
        this.setAndar(1);
    }

    @Override
    public void criar() {
        Scanner scanner = new Scanner(System.in);
        camposPadroes();
        System.out.println("Qual a raça do seu Cachorro?");
        this.raca = scanner.nextLine();
        System.out.println("Qual o tamanho do seu Cachorro?");
        this.tamanho = scanner.nextLine();

        var documento = new org.bson.Document("nome", getNome())
                .append("especie", "cachorro")
                .append("idade", getIdade())
                .append("andar", getAndar())
                .append("raca", this.raca)
                .append("tamanho", this.tamanho)
                .append("responsavel", this.getResponsavel().getNome());

        getColecao().insertOne(documento);
        System.out.println("Cachorro criado com sucesso!");
    }
}
