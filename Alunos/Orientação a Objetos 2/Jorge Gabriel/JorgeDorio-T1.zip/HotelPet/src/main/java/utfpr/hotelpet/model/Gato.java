package utfpr.hotelpet.model;

import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Scanner;

public class Gato extends Animal {
    private String cor;

    public Gato(MongoDatabase db) {
        super(db);
        this.setAndar(2);
    }

    @Override
    public void criar() {
        Scanner scanner = new Scanner(System.in);
        camposPadroes();
        System.out.println("Qual a cor do seu Gato?");
        this.cor = scanner.nextLine();

        var documento = new Document("nome", getNome())
                .append("especie", "gato")
                .append("idade", getIdade())
                .append("andar", getAndar())
                .append("cor", this.cor)
                .append("responsavel", this.getResponsavel().getNome());


        getColecao().insertOne(documento);
        System.out.println("Gato cadastrado com sucesso!");
    }
}
