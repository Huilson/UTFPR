package utfpr.hotelpet.model;

import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Scanner;

public class Funcionario extends Pessoa {
    private String cargo;

    public Funcionario(MongoDatabase db) {
        super(db);
        setTipo("funcionario");
    }

    @Override
    public void criar() {
        Scanner scanner = new Scanner(System.in);
        camposPadroes();
        System.out.println("Qual o cargo do funcionario?");
        this.cargo = scanner.nextLine();

        var documento = new Document("nome", getNome())
                .append("cargo", this.cargo)
                .append("documento", getDocumento())
                .append("tipo", "funcionario");


        getColecao().insertOne(documento);

        System.out.println("Funcionario cadastrado com sucesso!");
    }
}
