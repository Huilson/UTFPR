package utfpr.hotelpet.model;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class Animal {
    private String nome;
    private int idade;
    private int andar;
    private final MongoCollection<Document> colecao;
    private Pessoa responsavel;
    private final MongoDatabase db;

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }


    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    public MongoCollection<Document> getColecao() {
        return colecao;
    }

    public Pessoa getResponsavel() {
        return responsavel;
    }

    public Animal(MongoDatabase db) {
        this.colecao = db.getCollection("pets");
        this.db = db;
    }

    public abstract void criar();

    public void camposPadroes() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Qual o nome do seu Pet?");
        this.nome = scanner.nextLine();
        System.out.println("Qual a idade do seu Pet?");
        this.idade = Integer.parseInt(scanner.nextLine());
        String format = "%-24s%-10s\n";
        AtomicInteger id = new AtomicInteger(1);
        db.getCollection("pessoas").find().forEach((pessoa) -> {
            String nome = pessoa.getString("nome");
            System.out.printf(format, id, nome);
            id.getAndIncrement();
        });
        System.out.println("Insira o ID do responsável pelo pet:");
        int idResponsavel = Integer.parseInt(scanner.nextLine());
        var tutor = db.getCollection("pessoas").find().skip(idResponsavel - 1).limit(1).first();
        if (tutor == null) {
            System.out.println("Tutor não encontrado!");
        } else {
            this.responsavel = new Tutor(db);
            this.responsavel.setNome(tutor.getString("nome"));
            this.responsavel.setDocumento(tutor.getString("documento"));
        }
    }

    public static void listar(MongoDatabase db) {
        String format = "%-24s%-24s%-24s%-24s%-24s%-10s\n";
        System.out.printf(format, "ID", "Nome", "Idade", "Espécie", "Responsável", "Andar");

        AtomicInteger id = new AtomicInteger(1);
        db.getCollection("pets").find().forEach((pet) -> {
            String nome = pet.getString("nome");
            int idade = pet.getInteger("idade", -1);
            String especie = pet.getString("especie");
            String responsavel = pet.getString("responsavel");
            int andar = pet.getInteger("andar", -1);

            System.out.printf(format, id, nome, idade, especie, responsavel, andar);
            id.getAndIncrement();
        });
    }

    public static void atualizar(MongoDatabase db) {
        System.out.println("Insira o ID do pet que deseja atualizar:");
        Scanner scanner = new Scanner(System.in);
        int id = Integer.parseInt(scanner.nextLine());
        var pet = db.getCollection("pets").find().skip(id - 1).limit(1).first();
        if (pet == null) {
            System.out.println("Pet não encontrado!");
        } else {
            System.out.println("Insira o novo nome do pet:");
            String nome = scanner.nextLine();
            System.out.println("Insira a nova idade do pet:");
            int idade = Integer.parseInt(scanner.nextLine());
            var documento = new Document("nome", nome)
                    .append("idade", idade);
            db.getCollection("pets").updateOne(pet, new Document("$set", documento));
            System.out.println("Pet atualizado com sucesso!");
        }
    }

    public static void remover(MongoDatabase db) {
        System.out.println("Insira o ID do pet que deseja remover:");
        Scanner scanner = new Scanner(System.in);
        int id = Integer.parseInt(scanner.nextLine());
        var pet = db.getCollection("pets").find().skip(id - 1).limit(1).first();
        if (pet == null) {
            System.out.println("Pet não encontrado!");
        } else {
            db.getCollection("pets").deleteOne(pet);
            System.out.println("Pet removido com sucesso!");
        }
    }


    public static void cadastrar(MongoDatabase db) {
        Scanner scanner = new Scanner(System.in);
        var repetir = true;
        do {
            System.out.println("Qual a espécie do seu Pet? 1 - Cachorro, 2 - Gato, 3 - Ave");
            Animal pet;
            int especie = Integer.parseInt(scanner.nextLine());
            switch (especie) {
                case 1:
                    pet = new Cachorro(db);
                    repetir = false;
                    break;
                case 2:
                    pet = new Gato(db);
                    repetir = false;
                    break;
                case 3:
                    pet = new Ave(db);
                    repetir = false;
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    continue;
            }
            pet.criar();
        } while (repetir);
    }
}