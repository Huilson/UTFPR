package utfpr.hotelpet;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import utfpr.hotelpet.model.Animal;
import utfpr.hotelpet.model.Despesa;
import utfpr.hotelpet.model.Pessoa;

import java.util.Scanner;

public class App {
    private MongoDatabase db;

    public App() {
        var mongoClient = MongoClients.create("mongodb://localhost:27017");
        this.db = mongoClient.getDatabase("hotelpet");
    }

    public static void main(String[] args) {
        var app = new App();
        app.menu();
    }

    private void menu() {
        var repetir = true;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bem vindo ao Hotel Pet!");
        do {
            System.out.println("Selecione uma das opçoes abaixo:");
            System.out.println("0 - Finalizar programa");
            System.out.println("1 - Realizar check-in");
            System.out.println("2 - Listar pets");
            System.out.println("3 - Atualizar pet");
            System.out.println("4 - Realizar check-out");
            System.out.println("5 - Cadastrar pessoa");
            System.out.println("6 - Listar pessoas");
            System.out.println("7 - Atualizar pessoa");
            System.out.println("8 - Remover pessoa");
            System.out.println("9 - Cadastrar despesa");
            System.out.println("10 - Listar despesas");
            System.out.println("11 - Atualizar despesa");
            System.out.println("12 - Remover despesa");

            var opcao = scanner.nextInt();
            switch (opcao) {
                case 0:
                    repetir = false;
                    break;
                case 1:
                    Animal.cadastrar(this.db);
                    break;
                case 2:
                    Animal.listar(this.db);
                    break;
                case 3:
                    Animal.atualizar(this.db);
                    break;
                case 4:
                    Animal.remover(this.db);
                    break;
                case 5:
                    Pessoa.cadastrar(this.db);
                    break;
                case 6:
                    Pessoa.listar(this.db);
                    break;
                case 7:
                    Pessoa.atualizar(this.db);
                    break;
                case 8:
                    Pessoa.remover(this.db);
                    break;
                case 9:
                    Despesa.criar(this.db);
                    break;
                case 10:
                    Despesa.listar(this.db);
                    break;
                case 11:
                    Despesa.atualizar(this.db);
                    break;
                case 12:
                    Despesa.remover(this.db);
                    break;
            }
        } while (repetir);
    }
}
