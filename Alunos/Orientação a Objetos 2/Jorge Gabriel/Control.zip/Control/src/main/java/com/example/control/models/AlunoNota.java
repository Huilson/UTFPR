package com.example.control.models;

public class AlunoNota {
    private String ra;
    private float nota;

    public AlunoNota(String ra, float nota) {
        this.ra = ra;
        this.nota = nota;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }
}
