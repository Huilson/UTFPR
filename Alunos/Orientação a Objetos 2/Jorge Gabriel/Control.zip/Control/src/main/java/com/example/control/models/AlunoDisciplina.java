package com.example.control.models;

import java.util.List;

public class AlunoDisciplina {
    private String disciplina;
    private List<String> alunos;

    public AlunoDisciplina(String disciplina, List<String> alunos) {
        this.disciplina = disciplina;
        this.alunos = alunos;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public List<String> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<String> alunos) {
        this.alunos = alunos;
    }
}
