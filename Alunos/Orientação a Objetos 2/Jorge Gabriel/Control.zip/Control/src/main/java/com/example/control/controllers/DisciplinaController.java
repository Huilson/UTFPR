package com.example.control.controllers;

import com.example.control.models.*;
import com.example.control.repositories.AlunoRepository;
import com.example.control.repositories.DisciplinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/disciplina")
public class DisciplinaController {
    @Autowired
    DisciplinaRepository disciplinaRepository;
    @Autowired
    AlunoRepository alunoRepository;

    @PostMapping("/criar")
    public ResponseEntity<Disciplina> criarDisciplina(@RequestBody Disciplina disciplina) {
        if (disciplina.getNome() != null && disciplina.getSemestre() != 0 && disciplina.getNome() != "") {
            System.out.println(disciplina.getSemestre());
            Disciplina _disciplina = disciplinaRepository.save(new Disciplina(disciplina.getNome(), disciplina.getSemestre()));
            return new ResponseEntity<>(_disciplina, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/listar")
    public ResponseEntity<List<Disciplina>> listarDisciplinas() {
        var disciplinas = disciplinaRepository.findAll();
        return new ResponseEntity<>(disciplinas, HttpStatus.OK);
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity<Disciplina> atualizarDisciplina(@PathVariable("id") String id, @RequestBody Disciplina disciplina) {
        if (disciplina.getNome() != null && disciplina.getSemestre() != 0 && disciplina.getNome() != "") {
            var disciplinaData = disciplinaRepository.findById(id);
            if (disciplinaData.isPresent()) {
                var _disciplina = disciplinaData.get();
                _disciplina.setNome(disciplina.getNome());
                _disciplina.setSemestre(disciplina.getSemestre());
                return new ResponseEntity<>(disciplinaRepository.save(_disciplina), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/listar/alunos")
    public ResponseEntity<List<AlunoDisciplina>> listarAlunosPorDisciplina() {
        var disciplinas = disciplinaRepository.findAll();
        var alunos = alunoRepository.findAll();
        List<AlunoDisciplina> alunosDisciplinas = new ArrayList<>();
        for (Disciplina disciplina : disciplinas) {
            List<String> alunosDisciplina = new ArrayList<>();
            for (Aluno aluno : alunos) {
                for (AlunoNota alunoNota : disciplina.getAlunos()) {
                    if (alunoNota.getRa().equals(aluno.getRa())) {
                        alunosDisciplina.add(aluno.getNome());
                    }
                }
            }
            alunosDisciplinas.add(new AlunoDisciplina(disciplina.getNome(), alunosDisciplina));

        }
        return new ResponseEntity<>(alunosDisciplinas, HttpStatus.OK);
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<HttpStatus> deletarDisciplina(@PathVariable("id") String id) {
        try {
            disciplinaRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/matricular/{alunoId}/{disciplinaId}/{nota}")
    public ResponseEntity<Disciplina> matricularAluno(@PathVariable("alunoId") String alunoId, @PathVariable("disciplinaId") String disciplinaId, @PathVariable("nota") float nota) {
        var alunoData = alunoRepository.findById(alunoId);
        var disciplinaData = disciplinaRepository.findById(disciplinaId);
        if (alunoData.isPresent()) {
            var _aluno = alunoData.get();
            var _disciplina = disciplinaData.get();
            var alunos = _disciplina.getAlunos();
            alunos.add(new AlunoNota(_aluno.getRa(), nota));
            _disciplina.setAlunos(alunos);
            var notas = _aluno.getNota();
            notas.add(new DisciplinaNota(_disciplina.getId(), nota, _disciplina.getNome()));
            alunoRepository.save(_aluno);
            return new ResponseEntity<>(disciplinaRepository.save(_disciplina), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/listar/alunos/{id}")
    public ResponseEntity<List<Aluno>> listarAlunos(@PathVariable("id") String id) {
        var disciplinaData = disciplinaRepository.findById(id);
        if (disciplinaData.isPresent()) {
            var _disciplina = disciplinaData.get();
            List<Aluno> _alunos = new ArrayList<>();
            for (AlunoNota alunos : _disciplina.getAlunos()) {
                var alunoData = alunoRepository.findById(alunos.getRa());
                if (alunoData.isPresent()) {
                    var _aluno = alunoData.get();
                    _alunos.add(_aluno);
                }
            }
            return new ResponseEntity<>(_alunos, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/desmatricular/{alunoId}/{disciplinaId}")
    public ResponseEntity<Disciplina> desmatricularAluno(@PathVariable("alunoId") String alunoId, @PathVariable("disciplinaId") String disciplinaId) {
        var alunoData = alunoRepository.findById(alunoId);
        var disciplinaData = disciplinaRepository.findById(disciplinaId);
        if (alunoData.isPresent()) {
            var _aluno = alunoData.get();
            var _disciplina = disciplinaData.get();
            var alunos = _disciplina.getAlunos();
            alunos.removeIf(aluno -> aluno.getRa().equals(_aluno.getRa()));
            _disciplina.setAlunos(alunos);
            var notas = _aluno.getNota();
            notas.removeIf(nota -> nota.getId().equals(_disciplina.getId()));
            alunoRepository.save(_aluno);
            return new ResponseEntity<>(disciplinaRepository.save(_disciplina), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
