package com.example.control;
import com.example.control.repositories.ProfessorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlApplication {

    @Autowired
    ProfessorRepository professorRepository;

    public static void main(String[] args) {
        SpringApplication.run(ControlApplication.class, args);
    }

}
