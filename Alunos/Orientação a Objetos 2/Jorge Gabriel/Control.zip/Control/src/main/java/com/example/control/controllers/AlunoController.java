package com.example.control.controllers;

import com.example.control.models.Aluno;
import com.example.control.models.Disciplina;
import com.example.control.models.DisciplinaNota;
import com.example.control.repositories.AlunoRepository;
import com.example.control.repositories.DisciplinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/aluno")
public class AlunoController {
    @Autowired
    AlunoRepository alunoRepository;
    @Autowired
    DisciplinaRepository disciplinaRepository;

    @PostMapping("/criar")
    public ResponseEntity<Aluno> criarAluno(@RequestBody Aluno aluno) {
        if (aluno.getNome() != null && aluno.getSemestre() != 0 && aluno.getNome() != "") {
            Aluno _aluno = alunoRepository.save(new Aluno(aluno.getNome(), aluno.getSemestre()));
            return new ResponseEntity<>(_aluno, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/listar")
    public ResponseEntity
            <List<Aluno>> listarAlunos() {
        var alunos = alunoRepository.findAll();
        return new ResponseEntity<>(alunos, HttpStatus.OK);
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity<Aluno> atualizarAluno(@PathVariable("id") String id, @RequestBody Aluno aluno) {
        var alunoData = alunoRepository.findById(id);
        if (alunoData.isPresent()) {
            var _aluno = alunoData.get();
            _aluno.setNome(aluno.getNome());
            _aluno.setSemestre(aluno.getSemestre());
            return new ResponseEntity<>(alunoRepository.save(_aluno), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<HttpStatus> deletarAluno(@PathVariable("id") String id) {
        try {
            alunoRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/listar/notas/{id}")
    public ResponseEntity<List<DisciplinaNota>> listarNotas(@PathVariable("id") String id) {
        var alunoData = alunoRepository.findById(id);

        if (alunoData.isPresent()) {
            var _aluno = alunoData.get();
            return new ResponseEntity<>(_aluno.getNota(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

}
