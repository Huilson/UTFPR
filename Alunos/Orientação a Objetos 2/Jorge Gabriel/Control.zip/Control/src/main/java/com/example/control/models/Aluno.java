package com.example.control.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document(collection = "alunos")
public class Aluno {
    @Id
    private String ra;

    private String nome;
    private int semestre;
    private List<DisciplinaNota> nota = new ArrayList<>();

    public List<DisciplinaNota> getNota() {
        return nota;
    }

    public void setNota(List<DisciplinaNota> nota) {
        this.nota = nota;
    }

    public Aluno(String nome, int semestre) {
        this.nome = nome;
        this.semestre = semestre;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }
}
