package com.example.control.repositories;

import com.example.control.models.Aluno;
import com.example.control.models.Disciplina;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AlunoRepository extends MongoRepository<Aluno, String> {
}
