package com.example.control.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "professores")
public class Professor {
    @Id
    private String matricula;

    private String nome;
//    private
}
