package com.example.control.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document(collection = "disciplinas")
public class Disciplina {
    @Id
    private String id;

    public String nome;
    private int semestre;

    private List<AlunoNota> alunos = new ArrayList<>();

    public List<AlunoNota> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<AlunoNota> alunos) {
        this.alunos = alunos;
    }

    public Disciplina(String nome, int semestre) {
        this.nome = nome;
        this.semestre = semestre;
    }
//    private nomesAlunos


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semeste) {
        this.semestre = semeste;
    }


}
