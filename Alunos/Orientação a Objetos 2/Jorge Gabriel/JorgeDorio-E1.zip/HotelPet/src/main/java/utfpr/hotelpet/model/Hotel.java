package utfpr.hotelpet.model;

import utfpr.hotelpet.model.Expense;
import utfpr.hotelpet.model.people.Person;
import utfpr.hotelpet.model.pets.Animal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hotel {
    private Map<Integer, List<Animal>> floors;
    private List<Animal> guests;
    private List<Expense> expenses;
    private List<Person> persons;

    public Map<Integer, List<Animal>> getFloors() {
        return floors;
    }

    public void setFloors(Map<Integer, List<Animal>> floors) {
        this.floors = floors;
    }

    public List<Animal> getGuests() {
        return guests;
    }

    public void setGuests(List<Animal> guests) {
        this.guests = guests;
    }

    public List<Expense> getExpenses() {
        return expenses;
    }

    public void setExpenses(List<Expense> expenses) {
        this.expenses = expenses;
    }

    public List<Person> getPersons() {
        return persons;
    }

    public Hotel() {
        this.floors = new HashMap<>();
        this.guests = new ArrayList<>();
        this.expenses = new ArrayList<>();
        this.persons = new ArrayList<>();
    }

    public void checkIn(Animal pet, int floor) {
        floors.computeIfAbsent(floor, k -> new ArrayList<>()).add(pet);
        guests.add(pet);
        System.out.println(pet.getName() + " fez check-in no andar " + floor);
    }

    public void checkOut(Animal pet) {
        guests.remove(pet);
        floors.values().forEach(pets -> pets.remove(pet));
        System.out.println(pet.getName() + " fez check-out");
    }

    public void addExpense(String description, double value) {
        expenses.add(new Expense(description, value));
        System.out.println("Despesa adicionada: " + description + " - R$" + value);
    }

    public void listExpenses() {
        System.out.println("Lista de despesas:");
        for (Expense expense : expenses) {
            System.out.println(expense.getDescription() + " - R$" + expense.getValue());
        }
    }

    public void addPerson(Person p) {
        persons.add(p);
        System.out.println(p.getType() + ": " + p.getName() + " adicionado com sucesso.");
    }

    public void listPersons(){
        System.out.println("Pessoas cadastradas::");
        for(Person p : persons){
            System.out.println(p.getType() + " " + p.getName() + " " + p.getDocument());
        }
    }
}
