package utfpr.hotelpet;

import utfpr.hotelpet.model.Hotel;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner scanner = new Scanner(System.in);
        var repeat = true;
        while (repeat) {
            Hud.mainMenu();
            int opt = scanner.nextInt();
            scanner.nextLine();

            switch (opt) {
                case 1 -> Hud.CheckIn(hotel);
                case 2 -> Hud.checkout(hotel);
                case 3 -> Hud.addExpense(hotel);
                case 4 -> hotel.listExpenses();
                case 5 -> Hud.addPerson(hotel);
                case 6 -> hotel.listPersons();
                case 7 -> {
                    System.out.println("Saindo do programa.");
                    repeat = false;
                }
                default -> System.out.println("Opção inválida.");
            }
        }
    }
}
