package utfpr.hotelpet.model.people;

public class Employee extends Person {
    public Employee(String name, String document) {
        super(name, document, "Employee");
    }
}
