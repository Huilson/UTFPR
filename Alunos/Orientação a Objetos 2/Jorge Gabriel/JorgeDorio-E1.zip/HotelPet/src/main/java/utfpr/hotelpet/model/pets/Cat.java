package utfpr.hotelpet.model.pets;

import utfpr.hotelpet.Hud;

public class Cat extends Animal {
    private String color;

    public Cat(String name, int age) {
        super(name, "Gato", age);
        this.getAdditionalData();
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public void getAdditionalData() {
        var c = Hud.getAdditionalDataCat(this);
        this.setColor(c.getColor());
    }
}
