package utfpr.hotelpet.model.pets;

public class Fish extends Animal{

    public Fish(String name, int age) {
        super(name, "Fish", age);
    }

    @Override
    public void getAdditionalData() {

    }
}
