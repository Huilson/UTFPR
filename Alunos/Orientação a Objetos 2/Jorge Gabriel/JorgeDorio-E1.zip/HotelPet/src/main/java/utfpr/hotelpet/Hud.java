package utfpr.hotelpet;

import utfpr.hotelpet.model.people.Employee;
import utfpr.hotelpet.model.people.Person;
import utfpr.hotelpet.model.people.Tutor;
import utfpr.hotelpet.model.pets.Animal;
import utfpr.hotelpet.model.pets.Cat;
import utfpr.hotelpet.model.pets.Dog;
import utfpr.hotelpet.model.Hotel;
import utfpr.hotelpet.model.pets.Fish;

import java.util.Objects;
import java.util.Scanner;

public class Hud {
    static Scanner scanner = new Scanner(System.in);

    public static void mainMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Check-in");
        System.out.println("2. Check-out");
        System.out.println("3. Adicionar Despesa");
        System.out.println("4. Listar Despesas");
        System.out.println("5. Cadastrar pessoa");
        System.out.println("6. Listar Pessoas");
        System.out.println("7. Sair");
    }

    public static Dog getAdditionalDataDog(Dog d) {
        System.out.println("Digite a raça do chachorro:");
        d.setRace(scanner.next());
        System.out.println("Digite o tamanho do chachorro:");
        d.setSize(scanner.next());
        return d;
    }

    public static Cat getAdditionalDataCat(Cat c) {
        System.out.println("Digite cor do gato:");
        c.setColor(scanner.next());
        return c;
    }

    public static void listTutors(Hotel hotel) {
        var persons = hotel.getPersons();
        for (var i = 0; i < persons.size(); i++)
            if (Objects.equals(persons.get(i).getType(), "Tutor")) {
                System.out.println(i + 1 + " - " + persons.get(i).getName());
            }
    }

    public static void CheckIn(Hotel hotel) {
        var repeat = true;
        System.out.println("Digite o nome do pet:");
        var name = scanner.next();
        System.out.println("Digite a idade do pet:");
        var age = scanner.nextInt();
        System.out.println("Selecione um tutor:");
        listTutors(hotel);
        var tutorId = scanner.nextInt();
        var tutor = (Tutor) hotel.getPersons().get(tutorId - 1);

        Animal pet = null;
        do {
            System.out.println("Selecione a espécie do pet:");
            listSpeciesOptions();
            var specie = scanner.nextInt();

            switch (specie) {
                case 1 -> {
                    pet = new Dog(name, age);
                    repeat = false;
                }
                case 2 -> {
                    pet = new Cat(name, age);
                    repeat = false;
                }
                case 3 -> {
                    pet = new Fish(name, age);
                    repeat = false;
                }
                default -> System.out.println("Opção inválida, tente novamente.");
            }
        } while (repeat);

        System.out.println("Em qual andar o pet ficará?");
        int floor = scanner.nextInt();
        scanner.nextLine();
        tutor.addPet(pet);
        hotel.checkIn(pet, floor);
    }

    private static void listSpeciesOptions() {
        System.out.println("1 - Cachorro");
        System.out.println("2 - Gato");
    }

    public static void checkout(Hotel hotel) {
        System.out.println("Digite o nome do pet que deseja fazer o check-out:");
        String name = scanner.nextLine();

        Animal petCheckOut = null;
        for (Animal animal : hotel.getGuests()) {
            if (animal.getName().equalsIgnoreCase(name)) {
                petCheckOut = animal;
                break;
            }
        }

        if (petCheckOut != null) {
            hotel.checkOut(petCheckOut);
        } else {
            System.out.println("Pet não encontrado.");
        }
    }

    public static void addExpense(Hotel hotel) {
        System.out.println("Digite a descrição da despesa:");
        String description = scanner.nextLine();
        System.out.println("Digite o valor da despesa:");
        double value = scanner.nextDouble();
        scanner.nextLine();

        hotel.addExpense(description, value);
    }

    public static void addPerson(Hotel hotel) {
        var opt = 0;
        var repeat = true;
        System.out.println("Digite o nome: ");
        var name = scanner.next();
        System.out.println("Digite o CPF:");
        var document = scanner.next();
        Person person = null;
        do {
            System.out.println("Selecione o tipo a ser adicionado:");
            System.out.println("1 - Empregado");
            System.out.println("2 - Tutor");
            opt = scanner.nextInt();

            switch (opt) {
                case 1 -> {
                    person = new Employee(name, document);
                    hotel.addPerson(person);
                    repeat = false;
                }
                case 2 -> {
                    person = new Tutor(name, document);
                    hotel.addPerson(person);
                    repeat = false;
                }
                default -> System.out.println("Opção inválida.");
            }
        } while (repeat);

    }

}
