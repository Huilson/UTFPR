package utfpr.hotelpet.model.people;

import utfpr.hotelpet.model.pets.Animal;

import java.util.List;

public abstract class Person {
    private String name;
    private String document;

    private String type;

    public String getType() {
        return type;
    }

    public Person(String name, String document) {
        this.name = name;
        this.document = document;

    }

    public Person(String name, String document, String type) {
        this.name = name;
        this.document = document;
        this.type = type;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getName() {
        return name;
    }
}