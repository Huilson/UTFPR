package utfpr.hotelpet.model.people;

import utfpr.hotelpet.model.pets.Animal;

import java.util.ArrayList;
import java.util.List;

public class Tutor extends Person {
    private List<Animal> pets;

    public Tutor(String name, String document) {
        super(name, document, "Tutor");
        this.pets = new ArrayList<>();
    }

    public void addPet(Animal pet) {
        this.pets.add(pet);
    }
}