package utfpr.hotelpet.model.pets;

public abstract class Animal {
    private String name;
    private String specie;
    private int age;

    public Animal() {
    }

    public Animal(String name, String specie, int age) {
        this.name = name;
        this.specie = specie;
        this.age = age;
    }

    public abstract void getAdditionalData();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecie() {
        return specie;
    }

    public void setSpecie(String specie) {
        this.specie = specie;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
