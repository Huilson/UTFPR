package utfpr.hotelpet.model.pets;

import utfpr.hotelpet.Hud;

public class Dog extends Animal {
    private String race;
    private String size;

    public Dog() {
    }

    public Dog(String name, int age) {
        super(name, "Cachorro", age);
        this.getAdditionalData();
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public void getAdditionalData() {
        var d = Hud.getAdditionalDataDog(this);
        this.setRace(d.getRace());
        this.setSize(d.getSize());
    }
}
