package utfpr.classcontrol.model;

public enum Job {
    DOCTOR,
    TEACHER,
    DEVELOPER;
}


