package br.com.repository;

import br.com.codec.FuncionarioCodec;
import br.com.model.Animal;
import br.com.model.Funcionario;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class FuncionarioRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    public void conectaFuncionario() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        FuncionarioCodec funcionarioCodec = new FuncionarioCodec(codec);

        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(funcionarioCodec));

        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("Zoologico");
    }


    public void salvarFuncionario(Funcionario funcionario) {
        conectaFuncionario();
        MongoCollection<Funcionario> funcionarios = db.getCollection("Funcionarios", Funcionario.class);
        if(funcionario.getId() == null){
            funcionarios.insertOne(funcionario);
        }else{
            funcionarios.updateOne(Filters.eq("_id", funcionario.getId()), new Document("$set",funcionario));
        }
        cliente.close();
    }

    public List<Funcionario> listarTodos() {
        conectaFuncionario();
        MongoCollection<Funcionario> funcionarios = db.getCollection("Funcionarios", Funcionario.class);
        MongoCursor<Funcionario> resultado = funcionarios.find().iterator();
        List<Funcionario> funcionarioList = new ArrayList<>();

        while(resultado.hasNext()){
            Funcionario funcionario = resultado.next();
            funcionarioList.add(funcionario);
        }
        cliente.close();
        return funcionarioList;
    }

    public Funcionario obterId(String id){
        conectaFuncionario();
        MongoCollection<Funcionario> funcionarios = db.getCollection("Funcionarios", Funcionario.class);
        Funcionario funcionario = funcionarios.find(Filters.eq("_id", new ObjectId(id))).first();
        return funcionario;
    }

    public void excluir(String id) {
        conectaFuncionario();
        MongoCollection<Funcionario> funcionarios = db.getCollection("Funcionarios", Funcionario.class);
        funcionarios.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
}
