package br.com;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.springframework.boot.SpringApplication;
import br.com.model.Animal;
import br.com.model.Funcionario;
import br.com.model.Servico;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@SpringBootApplication
public class TrabalhoFinalApplication {

	public static void main(String[] args) throws ParseException {

		SpringApplication.run(TrabalhoFinalApplication.class, args);
	}


}
