/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controller;

import br.com.model.Animal;
import br.com.model.Funcionario;
import br.com.model.Servico;
import br.com.repository.AnimalRepository;
import br.com.repository.FuncionarioRepository;
import br.com.repository.ServicoRepository;

import java.io.FileNotFoundException;
import java.util.List;

import br.com.service.ServicoReport;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ServicoController {
    
    @Autowired
    ServicoRepository repository;

    @Autowired
    AnimalRepository repositoryA;

    @Autowired
    FuncionarioRepository repositoryF;

    @Autowired
    ServicoReport relatorio;

    @GetMapping("/servico/cadastrar")
    public String cadastrar(Model model){
        List<Animal> animais = repositoryA.listarTodos();
        List<Funcionario> funcionarios = repositoryF.listarTodos();
        model.addAttribute("servico", new Servico());
        model.addAttribute("a", animais);
        model.addAttribute("f", funcionarios);


        return"servico/cadastrar";
    }
    
    @PostMapping("/servico/salvar")
    public String salvar(@ModelAttribute Servico servico){
        repository.salvarServico(servico);
        return"redirect:/";
    }
    
    @GetMapping("/servico/listar")
    public String listar(Model model){
        List<Servico> servicos = repository.listarTodos();
        model.addAttribute("servicos", servicos);
        return"servico/listar";
    }

    @GetMapping("/servico/excluir/{id}")
    public String excluir(@PathVariable String id){
       repository.excluir(id);       
       return "redirect:/servico/listar";
   }

    @PostMapping("/servico/atualizar/{id}")
    public String atualizar(@ModelAttribute Servico servico){
        repository.salvarServico(servico);
        return "redirect:/servico/listar";
    }

    @GetMapping("/servico/relatorio")
    public String gerarRelatorio() throws FileNotFoundException, JRException {
        relatorio.exportaRelatorio();
        return "redirect:/";
    }
}
