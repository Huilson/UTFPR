/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controller;

import br.com.model.Animal;
import br.com.model.Servico;
import br.com.repository.ServicoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ServicoController {
    
    @Autowired
    ServicoRepository repository;
   
    @GetMapping("/servico/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("servico", new Servico());
        return"servico/cadastrar";
    }
    
    @PostMapping("/servico/salvar")
    public String salvar(@ModelAttribute Servico servico){
        repository.salvarServico(servico);
        return"redirect:/";
    }
    
    @GetMapping("/servico/listar")
    public String listar(Model model){
        List<Servico> servicos = repository.listarTodos();
        model.addAttribute("servicos", servicos);
        return"servico/listar";
    }

    @GetMapping("/servico/excluir/{id}")
    public String excluir(@PathVariable String id){
       repository.excluir(id);       
       return "redirect:/servico/listar";
   }

    @PostMapping("/servico/atualizar/{id}")
    public String atualizar(@ModelAttribute Servico servico){
        repository.salvarServico(servico);
        return "redirect:/servico/listar";
    }
}
