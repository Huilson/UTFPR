/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.model;

import org.bson.types.ObjectId;

public class Funcionario {
    private ObjectId _id;
    private String nome;
    private String funcao;

    @Override
    public String toString() {
        return "Funcionario{" + "_id=" + _id + ", nome=" + nome + ", funcao=" + funcao + '}';
    }

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public Funcionario criaId() {
        setId(new ObjectId());
        return this;
    }
    
    
}