package br.com.service;

import br.com.model.Servico;
import br.com.repository.ServicoRepository;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

@Service
public class ServicoReport {

    @Autowired
    private ServicoRepository repository;

    public String exportaRelatorio () throws FileNotFoundException, JRException{
        List<Servico> servicos = repository.listarTodos();

        //criar e compilar um arquivo
        File arquivo = ResourceUtils.getFile("classpath:relatorio.jrxml");
        JasperReport report = JasperCompileManager.compileReport(arquivo.getAbsolutePath());

        //Parametros de impressao
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("Relatorio de Serviços", "Parametros");

        //Buscar os dados, mapea-los e inserir no arquivo
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(servicos);
        JasperPrint print = JasperFillManager.fillReport(report, parametros, dataSource);

        //Caminho do Arquivo
        String path = "C:\\Users\\David\\Desktop\\Relatorios";

        JasperExportManager.exportReportToPdfFile(print, path+"\\relatorio.pdf");

        return "relatorio gerado em: "+path;
    }
}
