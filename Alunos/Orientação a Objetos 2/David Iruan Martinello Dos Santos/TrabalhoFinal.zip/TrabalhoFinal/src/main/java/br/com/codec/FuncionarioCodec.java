/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.codec;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.com.model.Animal;
import br.com.model.Funcionario;
import br.com.model.Servico;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;
        
public class FuncionarioCodec implements CollectibleCodec<Funcionario> {

    private Codec<Document> codec;

    public FuncionarioCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Funcionario> getEncoderClass() {
        return Funcionario.class;
    }

    @Override
    public boolean documentHasId(Funcionario funcionario) {
        return funcionario.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Funcionario funcionario) {
        if (!documentHasId(funcionario))
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else
        {
            return new BsonString(funcionario.getId().toHexString());
        }
    }

    @Override
    public Funcionario generateIdIfAbsentFromDocument(Funcionario funcionario) {
        return documentHasId(funcionario) ? funcionario.criaId() : funcionario;
    }

    @Override
    public void encode(BsonWriter writer, Funcionario funcionario, EncoderContext ec) {
        
        ObjectId id = funcionario.getId();
        String nome = funcionario.getNome();
        String funcao = funcionario.getFuncao();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("funcao", funcao);

        codec.encode(writer, doc, ec);
    }

    @Override
    public Funcionario decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Funcionario funcionario = new Funcionario();
        funcionario.setId(doc.getObjectId("_id"));
        funcionario.setNome(doc.getString("nome"));
        funcionario.setFuncao(doc.getString("funcao"));

        return funcionario;
    }
}
