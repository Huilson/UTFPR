
package br.com.repository;

import br.com.codec.ServicoCodec;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import br.com.model.Animal;
import br.com.model.Servico;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class ServicoRepository {
    
    private MongoClient cliente;
    private MongoDatabase db;

    public void conectaServico() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        ServicoCodec servicoCodec = new ServicoCodec(codec);

        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(servicoCodec));

        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("Zoologico");
    }
    

    public void salvarServico(Servico servico) {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("Servicos", Servico.class);
        if(servico.getId() == null){
            servicos.insertOne(servico);
        }else{
            servicos.updateOne(Filters.eq("_id", servico.getId()), new Document("$set",servico));
        }        
        cliente.close();
    }

    public List<Servico> listarTodos() {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("Servicos", Servico.class);
        MongoCursor<Servico> resultado = servicos.find().iterator();
        List<Servico> servicoList = new ArrayList<>();
        
        while(resultado.hasNext()){
            Servico servico = resultado.next();
            servicoList.add(servico);
        }
        cliente.close();
        return servicoList;
    }
    
    public Servico obterId(String id){
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("Servicos", Servico.class);
        Servico servico = servicos.find(Filters.eq("_id", new ObjectId(id))).first();
        return servico;
    }

    public void excluir(String id) {
        conectaServico();
        MongoCollection<Servico> servicos = db.getCollection("Servicos", Servico.class);
        servicos.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
}
