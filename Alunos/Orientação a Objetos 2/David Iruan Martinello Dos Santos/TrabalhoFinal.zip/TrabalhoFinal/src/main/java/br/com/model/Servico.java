/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

public class Servico {
    
    private ObjectId _id;
    private String nome;
    private String estadoConclusao;

    @DateTimeFormat (pattern = "yyyy-MM-dd")
    private Date data;
    @DateTimeFormat (pattern = "HH:mm")
    private LocalTime hora;
    private String animal;
    private String funcionario;



    public Servico(String nome, String estadoConclusao, Date data, String animal, String funcionario) {
        this.nome = nome;
        this.estadoConclusao = estadoConclusao;
        this.data = data;
        this.animal = animal;
        this.funcionario = funcionario;
    }

    public Servico() {
    
    }

    @Override
    public String toString() {
        return "Servico :" + " Nome:" + nome + ", Descricao:" + estadoConclusao + '.';
    }
    
    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstadoConclusao() {
        return estadoConclusao;
    }

    public void setEstadoConclusao(String descricao) {
        this.estadoConclusao = descricao;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public String getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(String funcionario) {
        this.funcionario = funcionario;
    }
    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    
    public Servico criaId() {
        setId(new ObjectId());
        return this;
    }

  
}
