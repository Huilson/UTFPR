/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.codec;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.com.model.Animal;
import br.com.model.Servico;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

/**
 *
 * @author David
 */
public class AnimalCodec implements CollectibleCodec<Animal> {

    private Codec<Document> codec;

    public AnimalCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Animal> getEncoderClass() {
        return Animal.class;
    }

    @Override
    public boolean documentHasId(Animal animal) {
        return animal.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Animal animal) {
        if (!documentHasId(animal))
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else
        {
            return new BsonString(animal.getId().toHexString());
        }
    }

    @Override
    public Animal generateIdIfAbsentFromDocument(Animal animal) {
        return documentHasId(animal) ? animal.criaId() : animal;
    }

    @Override
    public void encode(BsonWriter writer, Animal animal, EncoderContext ec) {
        
        ObjectId id = animal.getId();
        String nome = animal.getNome();
        String especie = animal.getEspecie();
        String descricao = animal.getDescricao();


        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("especie", especie);
        doc.put("descricao", descricao);


        codec.encode(writer, doc, ec);
    }

    @Override
    public Animal decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Animal animal = new Animal();
        animal.setId(doc.getObjectId("_id"));
        animal.setNome(doc.getString("nome"));
        animal.setEspecie(doc.getString("especie"));
        animal.setDescricao(doc.getString("descricao"));

        return animal;
    }
}