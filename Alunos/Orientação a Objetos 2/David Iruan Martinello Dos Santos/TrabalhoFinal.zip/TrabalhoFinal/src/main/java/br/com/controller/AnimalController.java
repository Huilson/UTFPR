
package br.com.controller;

import br.com.model.Animal;
import br.com.repository.AnimalRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AnimalController {
    
    @Autowired
    AnimalRepository repository;

    @GetMapping("/animal/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("animal", new Animal());
        return "/animal/cadastrar";
    }
    
    @PostMapping("/animal/salvar")
    public String salvar(@ModelAttribute Animal animal){
        repository.salvarAnimal(animal);
        return"redirect:/";
    }
    
    @GetMapping("/animal/listar")
    public String listar(Model model){
        List<Animal> animais = repository.listarTodos();
        model.addAttribute("animais", animais);
        return"animal/listar";
    }

    @GetMapping("/animal/excluir/{id}")
    public String excluir(@PathVariable String id){
       repository.excluir(id);       
       return "redirect:/animal/listar";
   }

    @PostMapping("/animal/atualizar/{id}")
    public String atualizar(@ModelAttribute Animal animal){
        repository.salvarAnimal(animal);
        return "redirect:/animal/listar";
    }
}