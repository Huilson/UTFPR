/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.codec;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.com.model.Animal;
import br.com.model.Servico;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

/**
 *
 * @author David
 */
public class ServicoCodec implements CollectibleCodec<Servico> {

    private Codec<Document> codec;

    public ServicoCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Servico> getEncoderClass() {
        return Servico.class;
    }

    @Override
    public boolean documentHasId(Servico servico) {
        return servico.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Servico servico) {
        if (!documentHasId(servico))
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else
        {
            return new BsonString(servico.getId().toHexString());
        }
    }

    @Override
    public Servico generateIdIfAbsentFromDocument(Servico servico) {
        return documentHasId(servico) ? servico.criaId() : servico;
    }

    @Override
    public void encode(BsonWriter writer, Servico servico, EncoderContext ec) {
        
        ObjectId id = servico.getId();
        String nome = servico.getNome();
        String estadoConclusao = servico.getEstadoConclusao();
        Date data = servico.getData();
        ObjectId codAnimal = servico.getCodAnimal();
        ObjectId codFuncionario = servico.getCodFuncionario();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("estadoConclusao", estadoConclusao);
        doc.put("data", data);
        doc.put("codAnimal", codAnimal);
        doc.put("codFuncionario", codFuncionario);


        codec.encode(writer, doc, ec);
    }

    @Override
    public Servico decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Servico servico = new Servico();
        servico.setId(doc.getObjectId("_id"));
        servico.setNome(doc.getString("nome"));
        servico.setEstadoConclusao(doc.getString("estadoConclusao"));
        servico.setData(doc.getDate("data"));  
        servico.setCodAnimal(doc.getObjectId("codAnimal"));
        servico.setCodAnimal(doc.getObjectId("codFuncionario"));

        return servico;
    }
}
