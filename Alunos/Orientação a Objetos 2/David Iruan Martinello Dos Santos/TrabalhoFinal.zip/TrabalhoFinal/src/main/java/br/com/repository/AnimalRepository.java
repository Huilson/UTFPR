
package br.com.repository;

import br.com.codec.AnimalCodec;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import br.com.model.Animal;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class AnimalRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    public void conectaAnimal() {
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        AnimalCodec animalCodec = new AnimalCodec(codec);

        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(animalCodec));

        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("Zoologico");
    }
    

    public void salvarAnimal(Animal animal) {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("Animais", Animal.class);
        if(animal.getId() == null){
            animais.insertOne(animal);
        }else{
            animais.updateOne(Filters.eq("_id", animal.getId()), new Document("$set",animal));
        }        
        cliente.close();
    }

    public List<Animal> listarTodos() {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("Animais", Animal.class);
        MongoCursor<Animal> resultado = animais.find().iterator();
        List<Animal> animalList = new ArrayList<>();
        
        while(resultado.hasNext()){
            Animal animal = resultado.next();
            animalList.add(animal);
        }
        cliente.close();
        return animalList;
    }
    
    public Animal obterId(String id){
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("Animais", Animal.class);
        Animal animal = animais.find(Filters.eq("_id", new ObjectId(id))).first();
        return animal;
    }

    public void excluir(String id) {
        conectaAnimal();
        MongoCollection<Animal> animais = db.getCollection("Animais", Animal.class);
        animais.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
}
