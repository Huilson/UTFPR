/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.model;

import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

public class Animal {

    private ObjectId _id;
    private String nome;
    private String especie;
    private String descricao;
    private ObjectId codProfissional;

    @Override
    public String toString() {
        return "Animal{" + "_id=" + _id + ", nome=" + nome + ", especie=" + especie + ", descri\u00e7\u00e3o=" + descricao + ", codProfissional=" + codProfissional + '}';
    }

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descrição) {
        this.descricao = descrição;
    }

    public ObjectId getCodProfissional() {
        return codProfissional;
    }

    public void setCodProfissional(ObjectId codProfissional) {
        this.codProfissional = codProfissional;
    }
    
    public Animal criaId() {
        setId(new ObjectId());
        return this;
    }
    
}

