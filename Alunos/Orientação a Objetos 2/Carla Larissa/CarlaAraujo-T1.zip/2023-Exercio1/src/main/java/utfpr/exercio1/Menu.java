package utfpr.exercio1;

import java.text.ParseException;
import java.util.Scanner;

public class Menu {

    Scanner scan = new Scanner(System.in);
    int op;
    int acao;
    boolean loop;
    String s;
    String especie;

    public void menu() throws ParseException {
        this.s = "n";
        do {
            
            System.out.println("Escolha uma opção: ");
            System.out.println("1 - Cadastro Animal");
            System.out.println("2 - Cadastro Pessoa");
            System.out.println("3 - Gerenciar Hotel");
            System.out.println("4 - Sair");
            op = scan.nextInt();
            switch (op) {
                case 1:                    
                    System.out.println("Escolha a ação desejada: ");
                    System.out.println("1 - Criar");
                    System.out.println("2 - Editar");
                    System.out.println("3 - Consultar");
                    System.out.println("4 - Excluir");
                    acao = scan.nextInt();
                    //opção abre a tela para um novo cadastro de animal 
                    if (acao == 1) {
                        cadastroAnimal();
                    } else if (acao == 2) {
                        //verifica se esse animal já possui cadastro para ser editado, comparando especie do animal 
                        //e nome do tutor cadastrado. Caso não possua encerra o if 
                        System.out.println("Informe a especie do animal e o nome do tutor que consta no cadastro do pet: ");
                        String e = scan.nextLine();
                        String t = scan.nextLine();
                        if (e == "gato") {
                            

                        } else if (e == "cachorro") {

                        } else {
                            System.out.println("Cadastro não encontrado");
                        }
                    } else if (acao == 3) {
                        //consulta os cadastros existentes filtrando pela especie
                        System.out.println("Informe a especie e o nome do animal que deseja consultar: ");
                        String e = scan.nextLine();                        
                        if (e == "gato") {
                            

                        } else if (e == "cachorro") {

                        } else {
                            System.out.println("não há animais para consulta");
                        }
                    }else if (acao == 4) {
                        //verifica se esse animal já possui cadastro para ser excluido, comparando especie do animal 
                        //e nome do tutor cadastrado. Caso não encontre os dados informados encerra o if 
                        System.out.println("Informe a especie do animal e o nome do tutor que consta no cadastro do pet: ");
                        String e = scan.nextLine();
                        String t = scan.nextLine();
                        if (e == "gato") {
                            AnimalDao ad = new AnimalDao();
                            ad.consultar();
                        } else if (e == "cachorro") {
                            AnimalDao ad = new AnimalDao();
                            ad.consultar();
                        } else {
                            System.out.println("Cadastro não encontrado");
                        }
                    }else{
                        System.out.println("Opção inválida!");
                    }
                    break;
                case 2:
                    System.out.println("Escolha a ação desejada: ");
                    System.out.println("1 - Criar");                    
                    System.out.println("2 - Editar");
                    System.out.println("3 - Consultar");
                    System.out.println("4 - Excluir");
                    System.out.println("\n");
                    acao = scan.nextInt();
                    //opção abre a tela para um novo cadastro de pessoa 
                    if (acao == 1) {
                        cadatroPessoa();
                    }else if(acao == 2){
                        
                    }else if(acao == 3){
                        PessoaDao pd = new PessoaDao();
                        pd.consultar();
                    }else if(acao == 4){
                        
                    }else{
                        System.out.println("Opção inválida!");
                    }
                    break;
                case 3:
                    System.out.println("Escolha a ação desejada: ");
                    System.out.println("1 - Fazer check-in");
                    System.out.println("2 - Fazer check-out");
                    System.out.println("\n\n");
                    acao = scan.nextInt();
                    if(acao == 1){                        
                        //verificação se o animal já esta cadastrado
                        System.out.println("O animal já possui cadastro?");
                        System.out.println("1 - Sim");
                        System.out.println("2 - Não");
                        System.out.println("\n\n");
                        acao = scan.nextInt();
                        if(acao==1){
                            Checkin checkin = new Checkin();
                            System.out.println("Informe o nome do Animal:");
                            String animal = scan.nextLine();
                            System.out.println("Informe o nome do Tutor:");
                            String tutor = scan.nextLine();
                            System.out.println("Informe a data do Check-in (DD/MM/AAAA):");
                            String dataCheckin = scan.nextLine();
                            checkin.lerData(dataCheckin);
                            System.out.println("Check-in definido:");
                        }else if(acao==2){
                            cadastroAnimal();
                        }else{
                            System.out.println("Opção inválida!");
                        }                        
                    }else if(acao == 2){
                        Checkout checkout = new Checkout(); 
                        System.out.println("Informe o nome do Animal:");
                        String animal = scan.nextLine();
                        System.out.println("Informe o nome do Tutor:");
                        String tutor = scan.nextLine();
                        System.out.println("Possui despesas adicionais?");
                        System.out.println("1 - Sim");
                        System.out.println("2 - Não");
                        System.out.println("\n\n");
                        int despesas = scan.nextInt();
                        if(despesas == 1){
                            System.out.println("Valor do banho:");
                            double banho = scan.nextDouble();
                            System.out.println("Valor da ração:");
                            double racao = scan.nextDouble();
                            System.out.println("Valor do brinquedo:");
                            double brinquedo = scan.nextDouble();
                            checkout.despesas.setBanho(banho);
                            checkout.despesas.setRacao(racao);
                            checkout.despesas.setBrinquedos(brinquedo);
                        }else if(despesas == 2){
                            System.out.println("Nenhuma despesa adicional");
                        }else{
                            System.out.println("Opção inválida!");
                        }
                        System.out.println("Informe a data do Check-in (DD/MM/AAAA):");
                        String dataCheckout = scan.nextLine();
                        checkout.lerData(dataCheckout);
                        System.out.println("Informe o valor da estadia:");
                        double estadia = scan.nextDouble();
                        checkout.setTotal(estadia+despesas);
                        System.out.println("------------------------------------");
                        System.out.println(checkout.toString());
                    }else{
                        System.out.println("Opção inválida!");
                    }
                    break;
                case 4:
                    System.out.println("Deseja sair? s/n");
                    s = scan.next();
            }
            if (s.equalsIgnoreCase("s")) {
                loop = false;
            } else {
                loop = true;
            }
        } while (loop == true);
    }
    
    public void cadastroAnimal() {
        AnimalDao ad = new AnimalDao();
        System.out.println("Informe a especie do seu animal (gato ou cachorro): ");
        especie = scan.nextLine();
        if ("gato".equals(especie)) {
            Gato gato = new Gato();
            gato.setEspecie(especie);
            System.out.println("Informe o nome do seu animal: ");
            String nome = scan.nextLine();
            gato.setNome(nome);
            System.out.println("Informe a idade do seu animal: ");
            int idade = scan.nextInt();
            gato.setIdade(idade);
            System.out.println("Informe a pelagem do seu animal: ");
            String cor = scan.nextLine();
            gato.setPelagem(cor);
            System.out.println("Informe o nome do tutor do animal: ");
            String tutor = scan.nextLine();
            gato.setTutor(tutor);
            gato.setAndar(2); 
            ad.insert(gato);
            System.out.println("Gatinho cadastrado com sucesso!");
        } else if ("cachorro".equals(especie)) {
            Cachorro cachorro = new Cachorro();
            cachorro.setEspecie(especie);
            System.out.println("Informe o nome do seu animal: ");
            String nome = scan.nextLine();
            cachorro.setNome(nome);
            System.out.println("Informe a idade do seu animal: ");
            int idade = scan.nextInt();
            cachorro.setIdade(idade);
            System.out.println("Informe a pelagem do seu animal: ");
            String cor = scan.nextLine();
            cachorro.setPelagem(cor);
            System.out.println("Informe o nome do tutor do animal: ");
            String tutor = scan.nextLine();
            cachorro.setTutor(tutor);
            cachorro.setAndar(1); 
            ad.insert(cachorro);
            System.out.println("Cachorro cadastrado com sucesso!");
        } else {
            System.out.println("Especie não cadastrada");
        }    
    }
    
    public void cadatroPessoa(){
        PessoaDao pd = new PessoaDao();
        System.out.println("Informe qual cadastro deseja criar(tutor ou funcionario): ");
        String pessoa = scan.nextLine();
        //verifica qual cadastro deseja criar, tutor ou funcionario
        if ("tutor".equals(pessoa)) {
            Tutor tutor = new Tutor();
            System.out.println("Informe o nome do Tutor: ");
            String nome = scan.nextLine();
            tutor.setNome(nome);
            System.out.println("Informe o numero do CPF: ");
            String documento = scan.nextLine();
            tutor.setDocumento(documento);
            System.out.println("Informe o numero de telefone: ");
            int telefone = scan.nextInt();
            tutor.setTelefone(telefone);
            System.out.println("Informe a quantidades de pes que possui: ");
            int qtde = scan.nextInt();
            tutor.setTelefone(qtde);
            for (int i = 0; i < qtde; i++) {
                cadastroAnimal();
            }
            pd.insertT(tutor);
            System.out.println("Tutor cadastrado com sucesso!");
        } else if ("funcionario".equals(pessoa)) {
            Funcionario funcionario = new Funcionario();
            System.out.println("Informe o nome do Funcionário: ");
            String nome = scan.nextLine();
            funcionario.setNome(nome);
            System.out.println("Informe o numero do CPF: ");
            String documento = scan.nextLine();
            funcionario.setDocumento(documento);
            System.out.println("Informe o numero de telefone: ");
            int telefone = scan.nextInt();
            funcionario.setTelefone(telefone);
            System.out.println("Informe o turno de trabalho(comercial ou plantao): ");
            String turno = scan.nextLine();
            funcionario.setTurno(turno);
            pd.insertF(funcionario);
            System.out.println("Funcionário cadastrado com sucesso!");
        } else {
            System.out.println("Categoria não cadastrada");
        }
    }
}
