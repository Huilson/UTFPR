package utfpr.exercio1;

import java.sql.SQLException;
import java.text.ParseException;

//public class App {
//
//    public static void main(String[] args) throws SQLException, ClassNotFoundException, ParseException {
//        Menu menu = new Menu();
//        menu.menu();
//        //Coneccao conecta = new Coneccao();
//        //conecta.conecta();
//    }
//}
