/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1;

/**
 *
 * @author karla
 */
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.text.ParseException;
import org.bson.Document;

public class ConexaoMongo {

    public static void main(String[] args) throws ParseException {
//        MongoClient conecta = new MongoClient();
//        Animal a = new Animal();
        Menu menu = new Menu();
        menu.menu();
        //Conectar com o Database
//        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
//        MongoCollection<Document> animais = db.getCollection("animais");     

        //Atualizar Documento com Filtro
//        animais.updateOne(Filters.eq("nome", "Maria da Fonseca"), new Document("$set", new Document("discplinas", "Aplicações Distribuídas")));

        //Excluir Documento com Filtro
//        animais.deleteOne(Filters.eq("_id", 1));
    
    }
}
