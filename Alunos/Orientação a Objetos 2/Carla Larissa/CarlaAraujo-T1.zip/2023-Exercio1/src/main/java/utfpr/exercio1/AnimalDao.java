/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

/**
 *
 * @author karla
 */
public class AnimalDao {
    
    public static MongoCollection<Document> conexao(){
        MongoClient conecta = new MongoClient();
        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
        MongoCollection<Document> animais = db.getCollection("animais");
        
        return animais;
    }
    
    public void insert(Animal animal){
        MongoCollection<Document> animais = conexao();
        //Criar um novo documento
        Document novoAnimal = new Document("nome", animal.getNome())
                .append("especie", animal.getEspecie())
                .append("idade", animal.getIdade())
                .append("pelagem", animal.getPelagem())
                .append("tutor", animal.getTutor())
                .append("andar", animal.getAndar());
                //fim append do documento principal
        //Inserir um Documento Novo
        animais.insertOne(novoAnimal);
    }
    
    public void consultar(){
        MongoCollection<Document> animais = conexao();
        
        Document animal = animais.find().first();
        System.out.print(animal);
        
        //Consutlar com Filtro
//        MongoCursor<Document> cursor = animais.find(Filters.eq("especie", animal.getEspecie())).iterator();
//        
//        while (cursor.hasNext()) {
//            System.out.println(cursor.next());
//        } 
    }
}
