/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author karla
 */
public class Checkin {
    Animal animal;
    Tutor tutor;
    String dataCheckin;

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public Tutor getTutor() {
        return tutor;
    }

    public void setTutor(Tutor tutor) {
        this.tutor = tutor;
    }

//    public String getDataEntrada() {
//        return dataCheckin;
//    }
//
//    public void setDataEntrada(String dataCheckin) {
//        this.dataCheckin = dataCheckin;
//    }
    
    // função que lê a data informada pelo usuário, faz
    // a validação e retorna um novo objeto Date contendo a
    // data informada
    public Date lerData(String dataCheckin) throws ParseException {
        //cria um objeto da classe SimpleDateFormat com o formato desejado
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        // recusa datas inválidas
        sdf.setLenient(false);
        // checamos se o tamanho da data está correto 
        if (dataCheckin.length() != 10) {
            throw new ParseException("Tamanho inválido: " + dataCheckin, 0);
        }
        // retornamos a data construída
        return (Date) sdf.parse(dataCheckin);
    }
}

