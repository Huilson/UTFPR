/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

/**
 *
 * @author karla
 */
public class PessoaDao {
    
    public static MongoCollection<Document> conexao(){
        MongoClient conecta = new MongoClient();
        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
        MongoCollection<Document> pessoas = db.getCollection("pessoas");
        
        return pessoas;
    }
    
    public void insertT(Tutor tutor){
        MongoCollection<Document> pessoas = conexao();
        
        //Criar um novo documento
        Document novaPessoa = new Document("nome", tutor.getNome())
                .append("documento", tutor.getDocumento())
                .append("telefone", tutor.getTelefone())
                .append("quantidade pets", tutor.getQtdePets())
                .append("quantidade pets", tutor.getEspecie());
        //Inserir um Documento Novo
        pessoas.insertOne(novaPessoa);
    }
    
    public void insertF(Funcionario funcionario){
        MongoCollection<Document> pessoas = conexao();
        
        //Criar um novo documento
        Document novaPessoa = new Document("nome", funcionario.getNome())
                .append("documento", funcionario.getDocumento())
                .append("telefone", funcionario.getTelefone())
                .append("quantidade pets", funcionario.getTurno());
        //Inserir um Documento Novo
        pessoas.insertOne(novaPessoa);
    }
    
    public void consultar(){
        MongoCollection<Document> pessoas = conexao();
        Document pessoa = pessoas.find().first();
        System.out.print(pessoa);
    }
}
