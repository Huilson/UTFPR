/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author karla
 */
public class Checkout {
    private double valorEstadia;
    Date dataSaida;
    private double total;
    DespesasAdicionais despesas;

    public double getValorEstadia() {
        return valorEstadia;
    }

    public void setValorEstadia(double valorEstadia) {
        this.valorEstadia = valorEstadia;
    }

//    public Date getDataSaida() {
//        return dataSaida;
//    }
//
//    public void setDataSaida(Date dataSaida) {
//        this.dataSaida = dataSaida;
//    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public DespesasAdicionais getDespesas() {
        return despesas;
    }

    public void setDespesas(DespesasAdicionais despesas) {
        this.despesas = despesas;
    }
    
    public Date lerData(String dataCheckout) throws ParseException {
        //cria um objeto da classe SimpleDateFormat com o formato desejado
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        // recusa datas inválidas
        sdf.setLenient(false);
        // checamos se o tamanho da data está correto 
        if (dataCheckout.length() != 10) {
            throw new ParseException("Tamanho inválido: " + dataCheckout, 0);
        }
        // retornamos a data construída
        return (Date) sdf.parse(dataCheckout);
    }

    @Override
    public String toString() {
        return "O valor total da hospedagem é: " + total;
    }
    
}
