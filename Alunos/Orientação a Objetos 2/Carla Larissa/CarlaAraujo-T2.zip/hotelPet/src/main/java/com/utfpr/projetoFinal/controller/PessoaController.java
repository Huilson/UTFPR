package com.utfpr.projetoFinal.controller;

import com.utfpr.projetoFinal.model.Pessoa;
import com.utfpr.projetoFinal.repository.PessoaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PessoaController {

//Injeções de dependência
    @Autowired
    private PessoaRepository repository;

    @GetMapping("/pessoa/cadastrar")
    public String cadastrar(Model model) {
        model.addAttribute("pessoa", new Pessoa());
        return "pessoa/cadastrar";
    }

    @PostMapping("/pessoa/salvar")
    public String salvar(@ModelAttribute Pessoa pessoa) {
        System.out.println("Salvando");
        repository.salvar(pessoa);
        return "redirect:/";
    }

    @GetMapping("/pessoa/listar")
    public String listar(Model model) {
        List<Pessoa> pessoas = repository.listar();
        model.addAttribute("pessoas", pessoas);
        return "pessoa/listar";
    }

    @GetMapping("/pessoa/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model) {
        Pessoa pessoa = repository.obterId(id);
        model.addAttribute("pessoa", pessoa);
        return "pessoa/visualizar";
    }

    @GetMapping("/pessoa/excluir/{id}")
    public String excluir(@PathVariable String id) {
        repository.excluir(id);
        return "redirect:/pessoa/listar";
    }

    @GetMapping("/pessoa/atualizar/{id}")
    public String atualizar(@PathVariable String id,Model model) {
        Pessoa pessoa = repository.obterId(id);
        model.addAttribute("pessoa", pessoa);
        return "pessoa/atualizar";
    }

    @PostMapping("/pessoa/editar/{id}")
    public String editar(@ModelAttribute Pessoa pessoa) {
        repository.salvar(pessoa);
        return "redirect:/pessoa/listar";
    }

}
