package com.utfpr.projetoFinal.model;

import org.bson.types.ObjectId;

public class Despesa {

    private ObjectId id;
    private String nome;
    private Double valor;
    private Double soma;

    public Despesa() {
    }

    public Despesa(String nome, Double valor) {
        this.nome = nome;
        this.valor = valor;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getSoma() {
        return soma;
    }

    public void setSoma(Double soma) {
        this.soma = soma;
    }

}
