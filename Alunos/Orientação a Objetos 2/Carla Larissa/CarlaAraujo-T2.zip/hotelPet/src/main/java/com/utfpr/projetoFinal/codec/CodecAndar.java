package com.utfpr.projetoFinal.codec;

import com.utfpr.projetoFinal.model.Andar;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecAndar implements CollectibleCodec<Andar> {

    private Codec<Document> codec;

    public CodecAndar(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Andar generateIdIfAbsentFromDocument(Andar andar) {
        return documentHasId(andar) ? andar.criarId() : andar;
    }

    @Override
    public boolean documentHasId(Andar andar) {
        return andar.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Andar andar) {

        if (!documentHasId(andar)) {
            throw new IllegalStateException("Esse documento não tem um Id");
        } else {

            return new BsonString(andar.getId().toHexString());
        }
    }

    @Override
    public Class<Andar> getEncoderClass() {

        return Andar.class;
    }

    @Override
    public void encode(BsonWriter writer, Andar andar, EncoderContext ec) {
        ObjectId id = andar.getId();
        String nome = andar.getNome();
        String tipo = andar.getTipo();
        
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("tipo",tipo);
                
        codec.encode(writer, doc, ec);
    }

    @Override
    public Andar decode(BsonReader reader, DecoderContext dc) {

        Document doc = codec.decode(reader, dc);
        Andar andar = new Andar();
        andar.setId(doc.getObjectId("_id"));
        andar.setNome(doc.getString("nome"));
        andar.setTipo(doc.getString("tipo"));
        
        return andar;
    }
}
