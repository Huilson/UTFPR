package com.utfpr.projetoFinal.codec;

import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Despesa;
import com.utfpr.projetoFinal.model.Pessoa;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecPessoa implements CollectibleCodec<Pessoa> {

    //Atributo para criação de documento
    private Codec<Document> codec;

    //Construtor
    public CodecPessoa(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Pessoa generateIdIfAbsentFromDocument(Pessoa pessoa) {
        return documentHasId(pessoa) ? pessoa.criarId() : pessoa;
    }

    @Override
    public boolean documentHasId(Pessoa pessoa) {
        return pessoa.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Pessoa pessoa) {
        if (!documentHasId(pessoa)) {
            throw new IllegalStateException("Esse documento não tem um Id");
        } else {
            return new BsonString(pessoa.getId().toHexString());
        }
    }
    
    @Override
    public void encode(BsonWriter writer, Pessoa pessoa, EncoderContext ec) {
        ObjectId id = pessoa.getId();
        String nome = pessoa.getNome();
        String documento = pessoa.getDocumento();
        String telefone = pessoa.getTelefone();
        String tipo = pessoa.getTipo();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("documento", documento);
        doc.put("telefone", telefone);
        doc.put("tipo", tipo);

        List<Animal> pets = pessoa.getPets();
        if (pets != null) {
            //Se não tiver uma disciplina cadastrada, cria-se uma lista para
            //não tomar um NPE
            List<Document> desDoc = new ArrayList<>();

            //Se houver uma disciplina cadastrada, cria-se um array de 
            //disciplina no MONGODB
            for (Animal animal : pets) {
                desDoc.add(new Document("nome", animal.getNome())
                        .append("idade", animal.getIdade())
                        .append("tipo", animal.getTipo())
                        .append("tutor", animal.getTutor())
                );
            }//FIM DO FOR
            doc.put("animais", desDoc);
        }
        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }


    @Override
    public Class<Pessoa> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Pessoa.class;
    }

    @Override
    public Pessoa decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Pessoa pessoa = new Pessoa();
        pessoa.setId(doc.getObjectId("_id"));
        pessoa.setNome(doc.getString("nome"));
        pessoa.setDocumento(doc.getString("documento"));
        pessoa.setTelefone(doc.getString("telefone"));
        pessoa.setTipo(doc.getString("tipo"));

        List<Animal> animais = (List<Animal>) doc.get("animais");
        if(animais != null){
            List<Animal> pets = new ArrayList<>();
            
            for(Animal docPets : animais){
                pets.add(new Animal());               
            }
            pessoa.setPets(pets);
        }  
        return pessoa;
    }   
}
