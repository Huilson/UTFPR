package com.utfpr.projetoFinal.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.utfpr.projetoFinal.codec.CodecCheckout;
import com.utfpr.projetoFinal.model.Checkout;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class CheckoutRepository {

    public MongoDatabase conecta() {
        //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Passar para a classe de codificação qual será o codec usado
        CodecCheckout checkoutCodec = new CodecCheckout(codec);

        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(checkoutCodec)
        );

        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder().codecRegistry(registro).build();

        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet");
        return db;
    }

    public Checkout obterId(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Checkout> check = db.getCollection("checkout", Checkout.class);
        Checkout checkout = check.find(Filters.eq("_id", new ObjectId(id))).first();
        return checkout;
    }

    public void salvar(Checkout checkout) {
        MongoDatabase db = conecta();
        MongoCollection<Checkout> check = db.getCollection("checkout", Checkout.class);

        if (checkout.getId() == null) {
            check.insertOne(checkout);
            
        } else {
            check.updateOne(Filters.eq("_id", checkout.getId()), new Document("$set", checkout));
            
        }
        //cliente.close();  
    }

//    public List<Andar> listar() {
//        MongoDatabase db = conecta();
//        MongoCollection<Andar> andares = db.getCollection("andares", Andar.class);
//        MongoCursor<Andar> resultado = andares.find().iterator();
//        System.out.println("Entrou no listar");
//        //Lista de Iteração
//        List<Andar> andarLista = new ArrayList<>();
//
//        while (resultado.hasNext()) {
//            Andar andar = resultado.next();
//            andarLista.add(andar);
//        }
//
//        return andarLista;
//    }

    public void excluir(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Checkout> checkout = db.getCollection("checkout", Checkout.class);
        checkout.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }
    
}
