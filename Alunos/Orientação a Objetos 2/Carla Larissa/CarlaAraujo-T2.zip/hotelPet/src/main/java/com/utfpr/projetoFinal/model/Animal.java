package com.utfpr.projetoFinal.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

public class Animal {
    private ObjectId id;
    private String nome;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date idade;
    private String tipo;
    private String tutor;
    private List<Despesa> despesas;
    private Double somaDespesas; 
                            
//    Outros dados serão add posteriormente

    public Animal() {
    }

    
    public List<Despesa> getDespesa() {
        if(despesas == null)
            despesas = new ArrayList<Despesa>();
        return despesas;
    }

    public void setDespesa(List<Despesa> despesas) {
        this.despesas = despesas;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getIdade() {
        return idade;
    }

    public void setIdade(Date idade) {
        this.idade = idade;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTutor() {
        return tutor;
    }

    public void setTutor(String tutor) {
        this.tutor = tutor;
    }    

    public List<Despesa> getDespesas() {
        return despesas;
    }

    public void setDespesas(List<Despesa> despesas) {
        this.despesas = despesas;
    }

    public Double getSomaDespesas() {
        return somaDespesas;
    }

    public void setSomaDespesas(Double somaDespesas) {
        this.somaDespesas = somaDespesas;
    }
   
    public Animal criarId(){
        setId(new ObjectId());
        return this;
    }
    
    public Animal addDespesa(Animal animal, Despesa despesa){
        List<Despesa> despesas = animal.getDespesa();
        despesas.add(despesa);
        animal.setDespesa(despesas);
        return animal;
    }
    
    public void somaDespesas(){
        List<Despesa> despesas = getDespesas();
        Double valor, soma = 0.0;
    
        for(Despesa despesa : despesas){
            if(despesa.getNome().equalsIgnoreCase(despesa.getNome())){
               valor = despesa.getValor();
               soma += valor; 
               
            }
        }    
        setSomaDespesas(soma);
    }
}
