/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.utfpr.projetoFinal.model;

import org.bson.types.ObjectId;

/**
 *
 * @author karla
 */
public class Checkout {

    private ObjectId id;
    private String status = "Em aberto";
    private Double valor;
    private String pet; 

    public Checkout() {
    }

    public Checkout(ObjectId id, String status, Double valor) {
        this.id = id;
        this.status = status;
        this.valor = valor;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getPet() {
        return pet;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }
    
    public Checkout criarId() {
        setId(new ObjectId());
        return this;
    }
}
