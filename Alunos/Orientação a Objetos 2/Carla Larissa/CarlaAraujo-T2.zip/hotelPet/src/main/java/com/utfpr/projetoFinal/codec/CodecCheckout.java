package com.utfpr.projetoFinal.codec;

import com.utfpr.projetoFinal.model.Checkout;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecCheckout implements CollectibleCodec<Checkout> {

    private Codec<Document> codec;

    public CodecCheckout(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Checkout generateIdIfAbsentFromDocument(Checkout checkout) {
        return documentHasId(checkout) ? checkout.criarId() : checkout;
    }

    @Override
    public boolean documentHasId(Checkout checkout) {
        return checkout.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Checkout checkout) {

        if (!documentHasId(checkout)) {
            throw new IllegalStateException("Esse documento não tem um Id");
        } else {

            return new BsonString(checkout.getId().toHexString());
        }
    }

    @Override
    public Class<Checkout> getEncoderClass() {

        return Checkout.class;
    }

    @Override
    public void encode(BsonWriter writer, Checkout checkout, EncoderContext ec) {
        ObjectId id = checkout.getId();
        String status = checkout.getStatus();
        Double valorTotal = checkout.getValor();
        String pet = checkout.getPet();
        
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("status",status);
        doc.put("valor",valorTotal);
        doc.put("pet",pet);
                
        codec.encode(writer, doc, ec);
    }

    @Override
    public Checkout decode(BsonReader reader, DecoderContext dc) {

        Document doc = codec.decode(reader, dc);
        Checkout checkout = new Checkout();
        checkout.setId(doc.getObjectId("_id"));
        checkout.setStatus(doc.getString("status"));
        checkout.setValor(doc.getDouble("valor"));
        checkout.setPet(doc.getString("pet"));
        
        return checkout;
    }
}
