package com.utfpr.projetoFinal.controller;

import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Despesa;
import com.utfpr.projetoFinal.repository.AnimalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DespesasController {
    
    @Autowired
    private AnimalRepository repository;
    
    @GetMapping("/despesa/cadastrar/{id}")
    public String cadastrar(@PathVariable String id, Model model){
        Animal animal = repository.obterId(id);
        model.addAttribute("animal",animal);
        model.addAttribute("despesa", new Despesa());
        return"despesa/cadastrar";
    }
    
    @PostMapping("/despesa/salvar/{id}")
    public String salvar(@PathVariable String id, @ModelAttribute Despesa despesa){
        Animal animal = repository.obterId(id);
        repository.salvar(animal.addDespesa(animal, despesa));
        return"redirect:/checkout/listar";
    }
}
