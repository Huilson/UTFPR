package com.utfpr.projetoFinal.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.utfpr.projetoFinal.codec.CodecPessoa;
import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Despesa;
import com.utfpr.projetoFinal.model.Andar;
import com.utfpr.projetoFinal.model.Pessoa;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class PessoaRepository {

    public MongoDatabase conecta() {
        //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Passar para a classe de codificação qual será o codec usado
        CodecPessoa pessoaCodec = new CodecPessoa(codec);

        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(),
                CodecRegistries.fromCodecs(pessoaCodec)
        );

        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();

        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("HotelPet");
        return db;
    }

    public void salvar(Pessoa pessoa) {
        MongoDatabase db = conecta();
        MongoCollection<Pessoa> pessoas = db.getCollection("pessoas", Pessoa.class);
        //Se eu já tiver um aluno simplesmente atualizo ele
        if (pessoa.getId() == null) {
            pessoas.insertOne(pessoa);
        } else {
            pessoas.updateOne(Filters.eq("_id", pessoa.getId()), new Document("$set", pessoa));
        }
        //cliente.close();
    }

    public List<Pessoa> listar() {
        MongoDatabase db = conecta();
        MongoCollection<Pessoa> pessoas = db.getCollection("pessoas", Pessoa.class);
        MongoCursor<Pessoa> resultado = pessoas.find().iterator();

        //Lista de Iteração
        List<Pessoa> pessoaLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Pessoa pessoa = resultado.next();
            pessoaLista.add(pessoa);
        }

        return pessoaLista;
    }

    public Pessoa obterId(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Pessoa> pessoas = db.getCollection("pessoas", Pessoa.class);
        Pessoa pessoa = pessoas.find(Filters.eq("_id", new ObjectId(id))).first();
        return pessoa;
    }

    public void excluir(String id) {
        MongoDatabase db = conecta();
        MongoCollection<Pessoa> pessoas = db.getCollection("pessoas", Pessoa.class);
        pessoas.findOneAndDelete(Filters.eq("_id", new ObjectId(id)));
    }

//    public List<Animal> buscarDespesas(String despesa) {
//        MongoDatabase db = conecta();
//        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
//        MongoCursor<Animal> resultado = animais.find(Filters.eq("despesas.nome",despesa))
//                .iterator();
//
//        //Lista de Iteração        
//        List<Animal> animalLista = new ArrayList<>();
//        while (resultado.hasNext()) {
//            Animal animal = resultado.next();            
//            
//            List<Despesa> despesas = (List<Despesa>) animal.getDespesa();
//            for(Despesa despesaAnimal : despesas){
//                if(despesaAnimal.getNome().equalsIgnoreCase(despesa))
//                    animalLista.add(animal);
//            }//fim FOR            
//        }//fim WHILE
//        return animalLista;
//    }
//    
//      public Animal obterTipo(String tipo) {
//        MongoDatabase db = conecta();
//        MongoCollection<Animal> animais = db.getCollection("animais", Animal.class);
//        Animal animal = animais.find(Filters.eq("animais.tipo",tipo)).first();
//        return animal;
//    }
    
    public List<Pessoa> listarTutores() {
        MongoDatabase db = conecta();
        MongoCollection<Pessoa> pessoas = db.getCollection("pessoas", Pessoa.class);
        
        MongoCursor<Pessoa> resultado = pessoas.find(Filters.eq("tipo", "tutor")).iterator();

        //Lista de Iteração
        List<Pessoa> pessoaLista = new ArrayList<>();

        while (resultado.hasNext()) {
            Pessoa pessoa = resultado.next();
            pessoaLista.add(pessoa);
        }
        
        return pessoaLista;
    }
}
