package com.utfpr.projetoFinal.codec;

import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Despesa;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecAnimal implements CollectibleCodec<Animal>{
    //Atributo para criação de documento
    private Codec<Document> codec;
    
    //Construtor
    public CodecAnimal(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Animal generateIdIfAbsentFromDocument(Animal animal) {
        return documentHasId(animal) ? animal.criarId() : animal;
    }

    @Override
    public boolean documentHasId(Animal animal) {
        //esse método só verifica se o objeto chamado tem ID
        return animal.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Animal animal) {
        //Verifica se o ID foi criado
        if(!documentHasId(animal)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(animal.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Animal animal, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = animal.getId();
        String nome = animal.getNome();
        Date idade = animal.getIdade();
        String tipo = animal.getTipo();
        String tutor = animal.getTutor();
        List<Despesa> despesas = animal.getDespesa();
        animal.somaDespesas();
        Double somaDespesas = animal.getSomaDespesas();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("idade",idade);
        doc.put("tipo", tipo);
        doc.put("tutor", tutor);
        
        
        if(despesas != null){
            
            List<Document> desDoc = new ArrayList<>();            
          
            for(Despesa despesa : despesas){
                desDoc.add(new Document("nome", despesa.getNome())
                        .append("valor", despesa.getValor())                        
                ); 
                
            }//FIM DO FOR
            doc.put("despesas",desDoc);            
        }
        doc.put("somaDespesas", somaDespesas);
        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Animal> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Animal.class;
    }

    @Override
    public Animal decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Animal animal = new Animal();
        animal.setId(doc.getObjectId("_id"));
        animal.setNome(doc.getString("nome"));
        animal.setIdade(doc.getDate("idade"));
        animal.setTipo(doc.getString("tipo"));
        animal.setTutor(doc.getString("tutor"));
        
        List<Document> despesas = (List<Document>) doc.get("despesas");
        if(despesas != null){
            List<Despesa> despDoPet = new ArrayList<>();
            
            for(Document docDespesa : despesas){
                despDoPet.add(new Despesa(
                        docDespesa.getString("nome"),                        
                        docDespesa.getDouble("valor")));               
            }
            animal.setDespesa(despDoPet);
        }  
        animal.setSomaDespesas(doc.getDouble("somaDespesas"));
        return animal;
    } 
    
    
}
