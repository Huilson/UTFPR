package com.utfpr.projetoFinal.controller;

import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Andar;
import com.utfpr.projetoFinal.repository.AnimalRepository;
import com.utfpr.projetoFinal.repository.AndarRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AndarController {
    
    @Autowired
    private AndarRepository repository;
    
    @Autowired
    private AnimalRepository animalRepository;
    
    @GetMapping("/andar/cadastrar")
    public String cadastrar(Model model) {
        Andar andar = new Andar();
        
        model.addAttribute("andar", new Andar());
        
        return "andar/cadastrar";
    }
    
    @PostMapping("/andar/salvar")
    public String salvar(@ModelAttribute Andar andar){
        repository.salvar(andar);
        return"redirect:/";
    }
    
    @GetMapping("/andar/listar")
    public String listar(Model model){
        List<Andar> andares = repository.listar();
        model.addAttribute("andares", andares);
        return"andar/listar";
    }
    
    @GetMapping("/andar/visualizar/{tipo}")
    public String verAnimais(@PathVariable String tipo, Model model){
//         String id,
//        Andar andar = repository.obterId(id);
        List<Animal> animais = animalRepository.listarPorTipo(tipo);
        model.addAttribute("animais", animais);
        model.addAttribute("tipo", tipo);
        return"andar/visualizar";
    }
    
    @GetMapping("/andar/vincular/{id}")
    public String vincular(@PathVariable String id,
            Model model){
        Andar andar = repository.obterId(id);
        model.addAttribute("andar", andar);
        return "andar/vincular";        
    }
    
    @PostMapping("/andar/editar/{id}")
    public String editar(@ModelAttribute Andar andar){
        repository.salvar(andar);
        return"redirect:/andar/listar";
    }
    
    @GetMapping("/andar/excluir/{id}")
    public String excluir(@PathVariable String id){        
        repository.excluir(id);
        return"redirect:/andar/listar";
    }
}
