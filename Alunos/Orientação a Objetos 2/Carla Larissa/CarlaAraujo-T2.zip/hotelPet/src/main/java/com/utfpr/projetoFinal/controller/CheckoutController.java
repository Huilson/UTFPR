package com.utfpr.projetoFinal.controller;

import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Checkout;
import com.utfpr.projetoFinal.repository.AnimalRepository;
import com.utfpr.projetoFinal.repository.CheckoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CheckoutController {
    
    @Autowired
    private AnimalRepository repository;
    
    @Autowired
    private CheckoutRepository checkoutRepository;
    
    @GetMapping("/checkout/pagamento/{id}")
    public String cadastrar(@PathVariable String id, Model model){
        Animal animal = repository.obterId(id);
        model.addAttribute("animal",animal);
        model.addAttribute("checkout", new Checkout());
        return"checkout/pagamento";
    }
    
    @PostMapping("/checkout/salvar")
    public String salvar(@ModelAttribute Checkout checkout, @ModelAttribute Animal animal){
        checkout.setValor(animal.getSomaDespesas());
        checkoutRepository.salvar(checkout);
        return"redirect:/";
    }
}
