package com.utfpr.projetoFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelPetApplication.class, args);
	}

}
