package com.utfpr.projetoFinal.controller;

import com.utfpr.projetoFinal.model.Animal;
import com.utfpr.projetoFinal.model.Pessoa;
import com.utfpr.projetoFinal.repository.AnimalRepository;
import com.utfpr.projetoFinal.repository.PessoaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AnimalController {

//Injeções de dependência
    @Autowired
    private AnimalRepository repository;

    @Autowired
    private PessoaRepository pessoaRepository;

    @GetMapping("/animal/cadastrar")
    public String cadastrar(Model model) {
        List<Pessoa> tutores = pessoaRepository.listarTutores();
        model.addAttribute("animal", new Animal());
        model.addAttribute("tutores", tutores);
        return "animal/cadastrar";
    }

    @PostMapping("/animal/salvar")
    public String salvar(@ModelAttribute Animal animal) {
        System.out.println("Salvando");
        repository.salvar(animal);
        return "redirect:/";
    }

    @GetMapping("/checkout/listar")
    public String listar(Model model) {
        List<Animal> animais = repository.listar();
        model.addAttribute("animal", animais);
        return "checkout/listar";
    }

    @GetMapping("/animal/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model) {
        Animal animal = repository.obterId(id);
        model.addAttribute("animal", animal);
        return "animal/visualizar";
    }

    @GetMapping("/animal/excluir/{id}")
    public String excluir(@PathVariable String id) {
        repository.excluir(id);
        return "redirect:/animal/listar";
    }

    @GetMapping("/animal/atualizar/{id}")
    public String atualizar(@PathVariable String id, Model model) {
        Animal animal = repository.obterId(id);
        model.addAttribute("animal", animal);
        return "animal/atualizar";
    }

    @PostMapping("/animal/editar/{id}")
    public String editar(@ModelAttribute Animal animal) {
        repository.salvar(animal);
        return "redirect:/animal/listar";
    }

}
