package com.utfpr.projetoFinal.model;

import java.util.List;

public class AndarDao {
    List<String> nome;

    public List<String> getNome() {
        return nome;
    }

    public void setNome(List<String> nome) {
        this.nome = nome;
    }
}
