package com.utfpr.projetoFinal.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

public class Pessoa {
    private ObjectId id;
    private String nome;
    private String documento;
    private String telefone;
    private String tipo;
    private List<Animal> pets;
                            
//    Outros dados serão add posteriormente

    public List<Animal> getPets() {
        if(pets == null)
            pets = new ArrayList<Animal>();
        return pets;
    }

    public void setPets(List<Animal> pets) {
        this.pets = pets;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }  
      
    public Pessoa criarId(){
        setId(new ObjectId());
        return this;
    }
    
    public Pessoa addPet(Pessoa pessoa, Animal pet){
        List<Animal> pets = pessoa.getPets();
        pets.add(pet);
        pessoa.setPets(pets);
        return pessoa;
    }
    
//    public Animal addNota(Animal aluno, Nota nota){
//        List<Disciplina> disciplinas = aluno.getDisciplina();
//        List<Double> notas = new ArrayList<Double>();
//        
//        for(Disciplina disciplina : disciplinas){
//            if(nota.getNome().equalsIgnoreCase(disciplina.getNome())){
//                notas = disciplina.getNotas();
//                notas.add(nota.getValor());
//                disciplina.setNotas(notas);
//            }
//        }        
//            return aluno;
//    }
}
