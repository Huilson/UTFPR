package com.utfpr.projetoFinal.model;

import org.bson.types.ObjectId;

public class Andar {

    private ObjectId id;
    private String nome;
    private String tipo;

    //GETTERS E SETTERS
    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //CONSTRUTORES
    public Andar(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    public Andar() {
    }

    //AUXILIARES
    public Andar criarId() {
        setId(new ObjectId());
        return this;
    }
}
