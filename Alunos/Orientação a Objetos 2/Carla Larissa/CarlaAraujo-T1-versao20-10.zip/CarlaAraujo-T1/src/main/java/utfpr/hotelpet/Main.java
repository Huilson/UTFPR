/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.hotelpet;

/**
 *
 * @author karla
 */
import java.text.ParseException;

public class Main {

    public static void main(String[] args) throws ParseException {
//        MongoClient conecta = new MongoClient();
//        Animal a = new Animal();
        Menu menu = new Menu();
        menu.menu();
        //Conectar com o Database
//        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
//        MongoCollection<Document> animais = db.getCollection("animais");     

        //Atualizar Documento com Filtro
//        animais.updateOne(Filters.eq("nome", "Maria da Fonseca"), new Document("$set", new Document("discplinas", "Aplicações Distribuídas")));

        //Excluir Documento com Filtro
//        animais.deleteOne(Filters.eq("_id", 1));
    
    }
}
