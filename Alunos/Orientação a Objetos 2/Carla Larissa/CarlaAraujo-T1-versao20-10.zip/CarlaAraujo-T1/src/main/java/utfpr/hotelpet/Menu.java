package utfpr.hotelpet;

import java.text.ParseException;
import java.util.Scanner;

public class Menu {

    Scanner scan = new Scanner(System.in);
    int op;
    int acao;
    boolean loop;
    String s;
    String especie="";

    public void menu() throws ParseException {
        this.s = "n";
        do {
            
            System.out.println("Escolha uma opção: ");
            System.out.println("1 - Cadastro Animal");
            System.out.println("2 - Cadastro Pessoa");
            System.out.println("3 - Gerenciar Hotel");
            System.out.println("4 - Sair");
            op = scan.nextInt();
            switch (op) {
                case 1:                    
                    System.out.println("Escolha a ação desejada: ");
                    System.out.println("1 - Criar");
                    System.out.println("2 - Editar");
                    System.out.println("3 - Consultar");
                    System.out.println("4 - Excluir");
                    acao = scan.nextInt();
                    //opção abre a tela para um novo cadastro de animal 
                    if (acao == 1) {
                        cadastroAnimal();
                    } else if (acao == 2) {
                        //verifica se esse animal já possui cadastro para ser editado, comparando especie do animal 
                        //e nome do tutor cadastrado. Caso não possua encerra o if 
                        System.out.println("Informe a especie do animal que consta no cadastro do pet: ");
                        String e = scan.next();
                        System.out.println("Informe o nome do tutor que consta no cadastro do pet: ");
                        String t = scan.nextLine();
                        if (e == "gato") {
                            

                        } else if (e == "cachorro") {

                        } else {
                            System.out.println("Cadastro não encontrado");
                        }
                    } else if (acao == 3) {
                        
                        //consulta os cadastros existentes filtrando por nome e especie
                        System.out.println("Informe a especie do animal que deseja consultar: ");
                        String e = scan.next(); 
                        System.out.println("Informe o nome do animal que deseja consultar: ");
                        String n = scan.next(); 
                        if ("gato".equals(e)) { 
                            AnimalDao ad = new AnimalDao();
                            System.out.println("\nCadastros encontrados:\n");
                            ad.consultaEspecieNome(e,n);
                        } else if ("cachorro".equals(e)) {
                            AnimalDao ad = new AnimalDao();
                            System.out.println("\nCadastros encontrados:\n");
                            ad.consultaEspecieNome(e,n);
                        } else {
                            System.out.println("não há animais para consulta");
                        }
                    }else if (acao == 4) {
                        //verifica se esse animal já possui cadastro para ser excluido, comparando especie do animal 
                        
                        //e nome do tutor cadastrado. Caso não encontre os dados informados encerra o if 
                        System.out.println("Informe a especie do animal que consta no cadastro do pet: ");
                        String e = scan.next();
                        System.out.println("Informe o nome do tutor que consta no cadastro do pet: ");
                        String t = scan.next();
                        if (e == "gato") {
                            AnimalDao ad = new AnimalDao();
                            ad.excluirCadastro(e, t);
                        } else if (e == "cachorro") {
                            
                        } else {
                            System.out.println("Cadastro não encontrado");
                        }
                    }else{
                        System.out.println("Opção inválida!");
                    }
                    break;
                case 2:
                    System.out.println("Escolha a ação desejada: ");
                    System.out.println("1 - Criar");                    
                    System.out.println("2 - Editar");
                    System.out.println("3 - Consultar");
                    System.out.println("4 - Excluir");                    
                    acao = scan.nextInt();
                    //opção abre a tela para um novo cadastro de pessoa 
                    if (acao == 1) {
                        cadatroPessoa();
                    }else if(acao == 2){
                        
                    }else if(acao == 3){
                        
                        //consulta os cadastros existentes filtrando por nome e tipo
                        System.out.println("Informe o cadastro desejado tutor ou funcionário: ");
                        String t = scan.next(); 
                        System.out.println("Informe o nome para consulta: ");
                        String n = scan.next(); 
                        if ("tutor".equals(t)) { 
                            PessoaDao pd = new PessoaDao();
                            System.out.println("\nCadastros encontrados:\n");
                            pd.consultaTipoNome(t,n);
                        } else if ("funcionario".equals(t)) {
                            PessoaDao pd = new PessoaDao();
                            System.out.println("\nCadastros encontrados:\n");
                            pd.consultaTipoNome(t,n);
                        } else {
                            System.out.println("não há animais para consulta");
                        }
                    }else if(acao == 4){
                        
                    }else{
                        System.out.println("Opção inválida!");
                    }
                    break;
                case 3:
                    System.out.println("Escolha a ação desejada: ");
                    System.out.println("1 - Fazer check-in");
                    System.out.println("2 - Fazer check-out");                    
                    acao = scan.nextInt();
                    if(acao == 1){                        
                        //verificação se o animal já esta cadastrado
                        System.out.println("O animal já possui cadastro?");
                        System.out.println("1 - Sim");
                        System.out.println("2 - Não");
                        System.out.println("\n");
                        acao = scan.nextInt();
                        if(acao==1){
                            Checkin checkin = new Checkin();
//                            CheckinDao cd = new CheckinDao();
                            System.out.println("Informe o nome do Animal:");
                            String animal = scan.next();                            
                            System.out.println("Informe o nome do Tutor:");
                            String tutor = scan.next();
                            System.out.println("Informe a data do Check-in (DD/MM/AAAA):");
                            String dataCheckin = scan.next();
//                            checkin.lerData(dataCheckin);
                            System.out.println("Check-in definido:" + dataCheckin);
//                            cd.insert(checkin);
                        }else if(acao==2){
                            cadastroAnimal();
                        }else{
                            System.out.println("Opção inválida!");
                        }                        
                    }else if(acao == 2){
                        Checkout checkout = new Checkout(); 
                        DespesasAdicionais despesas = new DespesasAdicionais();
                        double somaDespesa = 0;
                        System.out.println("Informe o nome do Animal:");
                        String animal = scan.next();
                        System.out.println("Informe o nome do Tutor:");
                        String tutor = scan.next();
                        System.out.println("Possui despesas adicionais?");
                        System.out.println("1 - Sim");
                        System.out.println("2 - Não");
                        System.out.println("\n");
                        int d = scan.nextInt();
                        if(d == 1){
                            System.out.println("Valor do banho:");
                            double banho = scan.nextDouble();
                            System.out.println("Valor da ração:");
                            double racao = scan.nextDouble();
                            System.out.println("Valor do brinquedo:");
                            double brinquedo = scan.nextDouble();
                            despesas.setBanho(banho);
                            despesas.setRacao(racao);
                            despesas.setBrinquedos(brinquedo);
                            somaDespesa = despesas.getBanho() + despesas.getRacao()+despesas.getBrinquedos();
                        }else if(d == 2){
                            System.out.println("Nenhuma despesa adicional");
                        }else{
                            System.out.println("Opção inválida!");
                        }
                        System.out.println("Informe a data do Check-in (DD/MM/AAAA):");
                        String dataCheckout = scan.next();
//                        checkout.lerData(dataCheckout);
                        System.out.println("Informe o valor da estadia:");
                        double estadia = scan.nextDouble();
                        checkout.setTotal(estadia + somaDespesa);
                        System.out.println("------------------------------------");
                        String total = String.valueOf(checkout.getTotal());
                        System.out.println("O valor total da hospedagem com as despesas adicionais é de: "+ total);
                    }else{
                        System.out.println("Opção inválida!");
                    }
                    break;
                case 4:
                    System.out.println("Deseja sair? (s/n)");
                    s = scan.next();
            }
            if (s.equalsIgnoreCase("s")) {
                loop = false;
            } else {
                loop = true;
            }
        } while (loop == true);
    }
    
    public void cadastroAnimal() {
        AnimalDao ad = new AnimalDao();
        System.out.println("Informe a especie do seu animal (gato ou cachorro): ");
        especie = scan.next();
        if ("gato".equals(especie)) {
            Gato gato = new Gato();
            gato.setEspecie(especie);
            System.out.println("Informe o nome do seu animal: ");
            String nome = scan.next();
            gato.setNome(nome);
            System.out.println("Informe a idade do seu animal: ");
            int idade = scan.nextInt();
            gato.setIdade(idade);
            System.out.println("Informe a pelagem do seu animal: ");
            String cor = scan.next();
            gato.setPelagem(cor);
            System.out.println("Informe o nome do tutor do animal: ");
            String tutor = scan.next();
            gato.setTutor(tutor);
            gato.setAndar(2); 
            ad.insert(gato);
            System.out.println("\nGatinho cadastrado com sucesso!\n");
        } else if ("cachorro".equals(especie)) {
            Cachorro cachorro = new Cachorro();
            cachorro.setEspecie(especie);
            System.out.println("Informe o nome do seu animal: ");
            String nome = scan.next();
            cachorro.setNome(nome);
            System.out.println("Informe a idade do seu animal: ");
            int idade = scan.nextInt();
            cachorro.setIdade(idade);
            System.out.println("Informe a pelagem do seu animal: ");
            String cor = scan.next();
            cachorro.setPelagem(cor);
            System.out.println("Informe o nome do tutor do animal: ");
            String tutor = scan.next();
            cachorro.setTutor(tutor);
            cachorro.setAndar(1); 
            ad.insert(cachorro);
            System.out.println("\nCachorro cadastrado com sucesso!\n");
        } else {
            System.out.println("Especie não cadastrada");
        }    
    }
    
    public void cadatroPessoa(){
        PessoaDao pd = new PessoaDao();
        System.out.println("Informe qual cadastro deseja criar(tutor ou funcionario): ");
        String pessoa = scan.next();
        //verifica qual cadastro deseja criar, tutor ou funcionario
        if ("tutor".equals(pessoa)) {
            Tutor tutor = new Tutor();
            System.out.println("Informe o nome do Tutor: ");
            String nome = scan.next();
            tutor.setNome(nome);
            System.out.println("Informe o numero do CPF: ");
            String documento = scan.next();
            tutor.setDocumento(documento);
            System.out.println("Informe o numero de telefone: ");
            int telefone = scan.nextInt();
            tutor.setTelefone(telefone);
            System.out.println("Informe a quantidades de pes que possui: ");
            int qtde = scan.nextInt();
            tutor.setQtdePets(qtde);
//            for (int i = 0; i < qtde; i++) {
//                cadastroAnimal();
//            }
            tutor.setTipo("tutor");
            pd.insertT(tutor);
            System.out.println("\nTutor cadastrado com sucesso!\n");
        } else if ("funcionario".equals(pessoa)) {
            Funcionario funcionario = new Funcionario();
            System.out.println("Informe o nome do Funcionário: ");
            String nome = scan.next();
            funcionario.setNome(nome);
            System.out.println("Informe o numero do CPF: ");
            String documento = scan.next();
            funcionario.setDocumento(documento);
            System.out.println("Informe o numero de telefone: ");
            int telefone = scan.nextInt();
            funcionario.setTelefone(telefone);
            System.out.println("Informe o turno de trabalho(comercial ou plantao): ");
            String turno = scan.next();
            funcionario.setTurno(turno);
            funcionario.setTipo("funcionario");
            pd.insertF(funcionario);
            System.out.println("\nFuncionário cadastrado com sucesso!\n");
        } else {
            System.out.println("Categoria não cadastrada");
        }
    }
}
