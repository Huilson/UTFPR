/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.hotelpet;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

/**
 *
 * @author karla
 */
public class CheckinDao {
    public static MongoCollection<Document> conexao(){
        MongoClient conecta = new MongoClient();
        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
        MongoCollection<Document> checkin = db.getCollection("checkin");
        
        return checkin;
    }
    
    public void insert(Checkin check){
        MongoCollection<Document> checkin = conexao();
        //Criar um novo documento
        Document novoCheckin = new Document("nome", check.getAnimal().getNome())
                .append("especie", check.getDataEntrada())  
                .append("tutor", check.getTutor().getNome());
                //fim append do documento principal
        //Inserir um Documento Novo
        checkin.insertOne(novoCheckin);
    }
}
