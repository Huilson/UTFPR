/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.hotelpet;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.conversions.Bson;

/**
 *
 * @author karla
 */
public class AnimalDao {
    
    public static MongoCollection<Document> conexao(){
        MongoClient conecta = new MongoClient();
        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
        MongoCollection<Document> animais = db.getCollection("animais");
        
        return animais;
    }
    
    public void insert(Animal animal){
        MongoCollection<Document> animais = conexao();
        //Criar um novo documento
        Document novoAnimal = new Document("nome", animal.getNome())
                .append("especie", animal.getEspecie())
                .append("idade", animal.getIdade())
                .append("pelagem", animal.getPelagem())
                .append("tutor", animal.getTutor())
                .append("andar", animal.getAndar());
                //fim append do documento principal
        //Inserir um Documento Novo
        animais.insertOne(novoAnimal);
    }
    
    public void consultar(){
        MongoCollection<Document> animais = conexao();
        
        Document animal = animais.find().first();
        System.out.print(animal);
           
    }
    
    public void consultaEspecieNome(String especie, String nome){
        MongoCollection<Document> animais = conexao();
        Bson filter = Filters.and(Filters.eq("especie", especie),Filters.eq("nome",nome));
        //Consutlar com Filtro
        FindIterable<Document> documents = animais.find(filter);
        
        MongoCursor<Document> cursor = documents.iterator();
        
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        } 
    }
    
    public void consultaEspecieTutor(String especie, String tutor){
        MongoCollection<Document> animais = conexao();
        Bson filter = Filters.and(Filters.eq("especie", especie),Filters.eq("nome",tutor));
        //Consutlar com Filtro
        FindIterable<Document> documents = animais.find(filter);
        
        MongoCursor<Document> cursor = documents.iterator();
        
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        } 
    }
    
    public void excluirCadastro(String especie, String tutor){
        //Excluir Documento com Filtro
        MongoCollection<Document> animais = conexao();
        Bson filter = Filters.and(Filters.eq("especie", especie),Filters.eq("tutor",tutor));
        System.out.println(animais.findOneAndDelete(filter).toJson());
    }
}
