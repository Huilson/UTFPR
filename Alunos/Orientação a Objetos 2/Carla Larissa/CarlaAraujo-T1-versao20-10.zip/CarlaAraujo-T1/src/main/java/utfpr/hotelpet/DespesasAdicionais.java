package utfpr.hotelpet;

public class DespesasAdicionais {
    private double banho; 
    private double racao; 
    private double brinquedos; 

    public double getBanho() {
        return banho;
    }

    public void setBanho(double banho) {
        this.banho = banho;
    }

    public double getRacao() {
        return racao;
    }

    public void setRacao(double racao) {
        this.racao = racao;
    }

    public double getBrinquedos() {
        return brinquedos;
    }

    public void setBrinquedos(double brinquedos) {
        this.brinquedos = brinquedos;
    }

    @Override
    public String toString() {
        Double soma = banho + brinquedos + racao;
        return "Despesas Adicionais: " + soma;
    }
    
    
}
