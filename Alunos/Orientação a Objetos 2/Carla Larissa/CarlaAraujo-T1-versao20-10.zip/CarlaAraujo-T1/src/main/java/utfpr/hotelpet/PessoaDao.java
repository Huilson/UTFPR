/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.hotelpet;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.conversions.Bson;
import static utfpr.hotelpet.AnimalDao.conexao;

/**
 *
 * @author karla
 */
public class PessoaDao {
    
    public static MongoCollection<Document> conexao(){
        MongoClient conecta = new MongoClient();
        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
        MongoCollection<Document> pessoas = db.getCollection("pessoas");
        
        return pessoas;
    }
    
    public void insertT(Tutor tutor){
        MongoCollection<Document> pessoas = conexao();
        
        //Criar um novo documento
        Document novaPessoa = new Document("nome", tutor.getNome())
                .append("documento", tutor.getDocumento())
                .append("telefone", tutor.getTelefone())
                .append("quantidade pets", tutor.getQtdePets())
                .append("tipo", tutor.getTipo());
        //Inserir um Documento Novo
        pessoas.insertOne(novaPessoa);
    }
    
    public void insertF(Funcionario funcionario){
        MongoCollection<Document> pessoas = conexao();
        
        //Criar um novo documento
        Document novaPessoa = new Document("nome", funcionario.getNome())
                .append("documento", funcionario.getDocumento())
                .append("telefone", funcionario.getTelefone())
                .append("turno", funcionario.getTurno())
                .append("tipo", funcionario.getTipo());
        //Inserir um Documento Novo
        pessoas.insertOne(novaPessoa);
    }
    
    public void consultar(){
        MongoCollection<Document> pessoas = conexao();
        Document pessoa = pessoas.find().first();
        System.out.print(pessoa);
    }
    
    public void consultaTipoNome(String tipo, String nome){
        MongoCollection<Document> pessoas = conexao();
        Bson filter = Filters.and(Filters.eq("tipo", tipo),Filters.eq("nome",nome));
        //Consutlar com Filtro
        FindIterable<Document> documents = pessoas.find(filter);
        
        MongoCursor<Document> cursor = documents.iterator();
        
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        } 
    }
}
