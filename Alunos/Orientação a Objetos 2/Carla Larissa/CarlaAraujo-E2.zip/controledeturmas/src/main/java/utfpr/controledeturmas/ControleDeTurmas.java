//package utfpr.controledeturmas;
//
//import utfpr.controledeturmas.model.Pessoa;
//import javax.persistence.EntityManager;
//import utfpr.controledeturmas.dao.PessoaDao;
//import utfpr.controledeturmas.model.Profissao;
//import utfpr.controledeturmas.util.Factory;
//
//public class ControleDeTurmas {        
//
//    public static void main(String[] args) {
//        EntityManager em = Factory.getEntityManager();
//        PessoaDao dao = new PessoaDao(em);
//        
//        //Pessoa pessoa = new Pessoa("Larissa","10329619969",25,"42988690652","Pato Branco","Assis brasil",650);
//        //pessoa.setProfissao(Profissao.ANALISTA);
//        dao.conecta();
//        
//        //Pessoa p = dao.consultarId(1);
//        
//        //dao.excluir(p);
//        
////p.setNome("Carla");
//        //dao.atualizar(p);
//        
////        //dao.salvar(pessoa);     
//        
//        dao.encerrar();
//        System.out.println("Ok");
//    }
//    
//    
//}
