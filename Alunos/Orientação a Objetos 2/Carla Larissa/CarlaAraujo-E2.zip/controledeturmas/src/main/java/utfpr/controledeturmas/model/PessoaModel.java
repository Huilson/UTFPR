package utfpr.controledeturmas.model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PessoaModel extends AbstractTableModel{

    private final List<Pessoa> listaPessoa;
    private final String[] colunas = new String[]{"id","nome", "documento", "idade", "contato", "cidade", "rua", "numero", "profissao"};
    
    
    private final int ID = 0;
    private final int NOME = 1;
    private final int DOCUMENTO = 2;
    private final int IDADE = 3;
    private final int CONTATO = 4;
    private final int CIDADE = 5;
    private final int RUA = 6;
    private final int NUMERO = 7;
    private final int PROFISSAO = 8;
    
    public PessoaModel(List<Pessoa> listaPessoa){
        this.listaPessoa = listaPessoa;
    }
    
    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex){
        Pessoa p = listaPessoa.get(rowIndex);
        
        if (ID == columnIndex) {
            p.setId((Integer) aValue);
        } else if (NOME == columnIndex) {
            p.setNome((String) aValue);
        } else if (DOCUMENTO == columnIndex) {
            p.setCpf((String) aValue);
        } else if (IDADE == columnIndex) {
            p.setIdade((Integer) aValue);
        } else if (CONTATO == columnIndex) {
            p.setContato((String) aValue);
        } else if (CIDADE == columnIndex) {
            p.setCidade((String) aValue);
        } else if (RUA == columnIndex) {
            p.setRua((String) aValue);
        } else if (NUMERO == columnIndex) {
            p.setNumero((Integer) aValue);
        } else if (PROFISSAO == columnIndex) {
            p.setProfissao((String) aValue);
        }
    }
    
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }    
    
    @Override
    public int getRowCount() {
        return listaPessoa.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Pessoa pessoa = listaPessoa.get(rowIndex);
        switch(columnIndex){ 
            case ID: return pessoa.getId();
            case NOME: return pessoa.getNome();
            case DOCUMENTO: return pessoa.getCpf();
            case IDADE: return pessoa.getIdade();
            case CONTATO: return pessoa.getContato();
            case CIDADE: return pessoa.getCidade();
            case RUA: return pessoa.getRua();
            case NUMERO: return pessoa.getNumero();
            case PROFISSAO: return pessoa.getProfissao();
            default:break;
        }
        return pessoa;
    }
    
    public void inserirModel(Pessoa pessoa){
        listaPessoa.add(pessoa);
        int ultimoIndice = getRowCount();
        fireTableRowsInserted(ultimoIndice, ultimoIndice);
    }
    
    public void removerModel(int indiceLinha){
        listaPessoa.remove(indiceLinha);
        fireTableRowsDeleted(indiceLinha, indiceLinha);
    }
    
    public void atualizarModel(int indiceLinha, Pessoa pessoa){
        listaPessoa.set(indiceLinha, pessoa);
        fireTableRowsUpdated(indiceLinha, indiceLinha);
    }
}
