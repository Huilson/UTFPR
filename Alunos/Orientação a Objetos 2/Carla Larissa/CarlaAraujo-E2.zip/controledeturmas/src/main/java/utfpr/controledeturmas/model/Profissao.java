package utfpr.controledeturmas.model;

public enum Profissao {
    MEDICO("Médico(a)"),
    PROFESSOR("Professor(a)"),
    DESENVOLVEDOR("Desenvolvedor(a)"), 
    ADVOGADO("Advogado(a)"), 
    ANALISTA("Analista"), 
    VETERINARIO("Veterinário(a)"), 
    PERSONAL("Personal"), 
    MOTORISTA("Motorista"), 
    COZINHEIRO("Cozinheiro(a)"), 
    POLICIAL("Policial"), 
    BOMBEIRO("Bombeiro"), 
    ENFERMEIRO("Enfermeiro(a)"), 
    SECRETARIA("Secretário(a)"), 
    ADMINISTRADOR("Administrador(a)"), 
    CONTADOR("Contador(a)"), 
    CORRETOR("Corretor(a)"), 
    MUSICO("Musico"),
    NUTRICIONISTA("Nutricionaista"), 
    FISIOTERAPEUTA("Fisioterapeuta"), 
    AGRONOMO("Agronomo(a)"), 
    ESTETICISTA("Esteticista");  
    
    //passando os dados como String pra exibir no combobox da tela de cadastro
    private final String profissao;
    
    private Profissao(String profissao) {
        this.profissao = profissao;
    }

    public String getProfissao() {
        return this.profissao;
    }

    @Override
    public String toString() {
        return this.profissao;
    }
}


    
