/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.controledeturmas.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.swing.JOptionPane;
import utfpr.controledeturmas.model.Pessoa;

/**
 *
 * @author karla
 */
public class PessoaDao {
    private EntityManager em;
        
    public PessoaDao(EntityManager em){
        this.em = em;
    }
    
    public void conecta(){
        this.em.getTransaction().begin();
    }
    
    public void encerrar(){
        this.em.close();
    }
    
    public void salvar(Pessoa pessoa){
        this.em.persist(pessoa);
        this.em.getTransaction().commit();
        JOptionPane.showMessageDialog(null, "cadatro salvo com sucesso");
    }    
    
    public void excluir(Pessoa pessoa){
        pessoa = em.merge(pessoa);
        em.remove(pessoa);
        em.getTransaction().commit();
        JOptionPane.showMessageDialog(null, "cadatro excluído com sucesso");
    }
    
    public List<Pessoa> consultar(){
        TypedQuery<Pessoa> consulta = em.createQuery("FROM Pessoa p", Pessoa.class);
        //String jpql = "SELECT * FROM pessoa";
        return consulta.getResultList();
    }
    
    public List<Pessoa> consultarNome(String nome){
        TypedQuery<Pessoa> consultaNome = em.createQuery("FROM Pessoa p WHERE p.nome = :nome", Pessoa.class)
                .setParameter("nome", nome);
        return consultaNome.getResultList();
    }
    
    public List<Pessoa> consultarId(int id){
        TypedQuery<Pessoa> consultaId= em.createQuery("FROM Pessoa p WHERE p.id = :id", Pessoa.class)
                .setParameter("id", id);
        return consultaId.getResultList();
        //return em.find(Pessoa.class,id);
    }
    
    public void atualizar(Pessoa pessoa){
        this.em.merge(pessoa);
    }
    
    public void apagaTransacao(){
        this.em.getTransaction().rollback();
    }
}
