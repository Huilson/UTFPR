package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Cliente;
import br.com.java_mongodb.mongodbSpring.model.Musica;
import java.sql.Time;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class ClienteCodec implements CollectibleCodec<Cliente> {

    private Codec<Document> codec;

    public ClienteCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Cliente> getEncoderClass() {
        return Cliente.class;
    }//Esse metodo diz qual classe será codificada

    @Override
    public boolean documentHasId(Cliente aluno) {
        return aluno.getId() == null;
    }//Esse metodo só verifica se o objeto chamado tem ID

    @Override
    public BsonValue getDocumentId(Cliente aluno) {
        if (!documentHasId(aluno))//Verifica se o ID foi criado
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else//Para que o ID possa ser lido é preciso converter para a base hexadecimal
        {
            return new BsonString(aluno.getId().toHexString());
        }
    }

    @Override
    public Cliente generateIdIfAbsentFromDocument(Cliente aluno) {
        return documentHasId(aluno) ? aluno.criaId() : aluno;
    }

    @Override
    public void encode(BsonWriter writer, Cliente cliente, EncoderContext ec) {
        /*Esse metodo pega um Objeto e o envia para o Mongodb, um bom exemplo
        seria dizer para o mongodb qual a receita ele deve seguir para poder 
        salvar o Objeto Cliente em sua base de dados*/
        ObjectId id = cliente.getId();
        String nome = cliente.getNome();
        Integer idade = cliente.getIdade();
        String cpf = cliente.getCpf();        
        //List<Musica> musicas = cliente.getMusicas();      
        
        Document doc = new Document();
      //  Document docMusica = new Document();
        
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("idade", idade);
        doc.put("cpf", cpf);
        
     /*   List<Document> musicaDoc = new ArrayList<>();
        if (musicas != null) {
            //Se não tiver uma musica cadastrada, 
            //cria-se uma lista para não um NPE          

            //se houver musicas itera sobre elas para criar
            //um array de disciplinas no MONGODB
            for (Musica musica : musicas) {
                musicaDoc.add(new Document(
                                "nome", musica.getNome())
                        .append("genero", musica.getGenero())
                        .append("letra", musica.getLetra())
                        .append("duracao", musica.getDuracao())
                        .append("compositor", musica.getCompositor())
                        .append("gravadora", musica.getGravadora())
                        .append("ano", musica.getAno())
                        .append("notas", musica.getNotas())                        
                );
                
                
            }
            doc.put("Musicas",musicaDoc);
        }
        */
        codec.encode(writer, doc, ec);
        
        //Essa função é quem traduz o que escrevemos na VIEW
    }

    @Override
    public Cliente decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Cliente cliente = new Cliente();
        cliente.setId(doc.getObjectId("_id"));
        cliente.setNome(doc.getString("nome"));
        cliente.setIdade(doc.getInteger("idade"));        
        cliente.setCpf(doc.getString("cpf"));

       /* List<Document> musicas = (List<Document>) doc.get("Musicas");

        if (musicas != null) {
            List<Musica> musicasDoCliente = new ArrayList<>();

            for (Document document : musicas){
                musicasDoCliente.add(new Musica(
                    document.getString("nome"           ),
                    document.getString("genero"         ),
                    document.getString("letra"          ), 
                    document.getString("duracao"        ),
                    document.getString("compositor"     ),
                    document.getString("gravadora"      ),
                    document.getInteger("ano"           ),
                    document.getList("notas"             , Double.class)
                    ));
            }
            cliente.setMusicas(musicasDoCliente);
        }*/
        return cliente;
    }
}
