package br.com.java_mongodb.mongodbSpring.controller;

import br.com.java_mongodb.mongodbSpring.model.Cliente;
import br.com.java_mongodb.mongodbSpring.repository.ClienteRepository;
import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class ClienteController {
    
    @Autowired
    ClienteRepository repository;
   
    @GetMapping("/cliente/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("cliente", new Cliente());
        return"cliente/cadastrar";
    }
    
    @PostMapping("/cliente/salvar")
    public String salvar(@ModelAttribute Cliente cliente){
        repository.salvar(cliente);
        return"redirect:/";
    }
    
    @GetMapping("/cliente/listar")
    public String listar(Model model){
        List<Cliente> clientes = repository.listarTodos();
        model.addAttribute("Clientes", clientes);
        return"cliente/listar";
    }
    
   @GetMapping("/cliente/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model){
       Cliente cliente = repository.obterId(id);
       model.addAttribute("cliente", cliente);
       return "cliente/visualizar";
   }
    
    @GetMapping("/cliente/excluir/{id}")
    public String excluir(@PathVariable String id){
       repository.excluir(id);       
       return "redirect:/cliente/listar";
   }
    
    @GetMapping("/cliente/atualizar/{id}")
    public String atualizar(@PathVariable String id, Model model) {
        Cliente cliente = repository.obterId(id);
        model.addAttribute("cliente", cliente);
        return "cliente/atualizar";
    }
    @PostMapping("/cliente/editar/{id}")
    public String update(@ModelAttribute Cliente cliente, @PathVariable String id) {
        ObjectId idCli = new ObjectId(id);
        cliente.setId(idCli);
        repository.salvar(cliente);
        return "redirect:/";
    }
    
   

}
