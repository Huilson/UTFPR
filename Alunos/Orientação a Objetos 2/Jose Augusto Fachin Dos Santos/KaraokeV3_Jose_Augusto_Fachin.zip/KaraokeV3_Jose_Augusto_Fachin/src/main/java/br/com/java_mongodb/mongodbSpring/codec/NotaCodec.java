package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Nota;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class NotaCodec implements CollectibleCodec<Nota> {

    private Codec<Document> codec;

    public NotaCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Nota> getEncoderClass() {
        return Nota.class;
    }//Esse metodo diz qual classe será codificada

    @Override
    public boolean documentHasId(Nota nota) {
        return nota.getId() == null;
    }//Esse metodo só verifica se o objeto chamado tem ID

    @Override
    public BsonValue getDocumentId(Nota nota) {
        if (!documentHasId(nota))//Verifica se o ID foi criado
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else//Para que o ID possa ser lido é preciso converter para a base hexadecimal
        {
            return new BsonString(nota.getId().toHexString());
        }
    }

    @Override
    public Nota generateIdIfAbsentFromDocument(Nota nota) {
        return documentHasId(nota) ? nota.criaId() : nota;
    }

    @Override
    public void encode(BsonWriter writer, Nota nota, EncoderContext ec) {
        /*Esse metodo pega um Objeto e o envia para o Mongodb, um bom exemplo
        seria dizer para o mongodb qual a receita ele deve seguir para poder 
        salvar o Objeto Cliente em sua base de dados*/
        ObjectId id = nota.getId();
        String cliente = nota.getNome_cliente();
        String musica = nota.getNome_musica();
        double nt = nota.getNota();
                
        Document doc = new Document();
        
        doc.put("_id", id);
        doc.put("nome_cliente", cliente);
        doc.put("nome_musica", musica);
        doc.put("nota", nt);
        
        codec.encode(writer, doc, ec);
        
        //Essa função é quem traduz o que escrevemos na VIEW
    }

    @Override
    public Nota decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        
        Nota nota = new Nota();
        
        nota.setId(doc.getObjectId("_id"));
        nota.setNome_cliente(doc.getString("nome_cliente"));
        nota.setNome_musica(doc.getString("nome_musica"));
        nota.setNota(doc.getDouble("nota"));
        
        return nota;
    }
}
