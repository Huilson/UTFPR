package br.com.java_mongodb.mongodbSpring.repository;

import br.com.java_mongodb.mongodbSpring.codec.MusicaCodec;
import br.com.java_mongodb.mongodbSpring.codec.NotaCodec;
import br.com.java_mongodb.mongodbSpring.model.Cliente;
import br.com.java_mongodb.mongodbSpring.model.Musica;
import br.com.java_mongodb.mongodbSpring.model.Nota;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;
@Repository
public class NotaRepository {

    private MongoClient nota;
    private MongoClient cliente;
    private MongoClient musica;
    private MongoDatabase db;

    public void conecta() {
        //Instaciar um codec
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Qual classe ira sofrer o encode/decode
        NotaCodec notaCodec = new NotaCodec(codec);

        //Instanciar um registro para o codec
        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(notaCodec));

        //Dar um build no registro
        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.nota = new MongoClient("localhost:27017", op);
        this.db = nota.getDatabase("KaraokeV3");
    }
     
    public void salvar(Nota nt) { conecta();
        MongoCollection<Nota> notas = db.getCollection("Notas", Nota.class);
        
        if(nt.getId() == null){//se não tiver um nota cria
            notas.insertOne(nt);
        }else{//se a nota já existir salva somente as alterações
            notas.updateOne(Filters.eq("_id", nt.getId()), new Document("$set",nt));
        }        
        nota.close();
    }
    public Map<String, Double> calcularMediaNotas() {
    List<Nota> notas = listarTodos();

    return notas.stream()
            .collect(Collectors.groupingBy(Nota::getNome_cliente,
                    Collectors.averagingDouble(Nota::getNota)))
            .entrySet()
            .stream()
            .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                    (oldValue, newValue) -> oldValue, LinkedHashMap::new));
}
           /*      
    public Map<String, Double> calcularMediaNotas() {
        List<Nota> notas = listarTodos();

        return notas.stream()
                .collect(Collectors.groupingBy(Nota::getNome_cliente,
                        Collectors.averagingDouble(Nota::getNota)));
    }
*/
    public List<Nota> obterRankingMelhoresMedias() {

            return listarTodos().stream()
                .sorted(Comparator.comparing(Nota::getNome_cliente))
                .collect(Collectors.toList());
    }

    public List<Nota> listarTodos() {
        conecta();
        MongoCollection<Nota> notas = db.getCollection("Notas", Nota.class);
        MongoCursor<Nota> resultado = notas.find().iterator();
        List<Nota> notaLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Nota nt = resultado.next();
            notaLista.add(nt);
        }
        nota.close();
        return notaLista;
    }
    
    public Nota obterId(String id){
        conecta();
        MongoCollection<Nota> notas = db.getCollection("Notas", Nota.class);
        Nota nota = notas.find(Filters.eq("_id", new ObjectId(id))).first();
        return nota;
    }

    public void excluir(String id) {
        conecta();
        MongoCollection<Nota> notas = db.getCollection("Notas", Nota.class);
        notas.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
    
    public List<Cliente> listarClientes() {
        conecta();
        MongoCollection<Cliente> clien = db.getCollection("Clientes", Cliente.class);
        MongoCursor<Cliente> resultado = clien.find().iterator();
        List<Cliente> clienteLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Cliente  cli = resultado.next();
            clienteLista.add(cli);
        }
        cliente.close();
        return clienteLista;
    }
    
     public List<Musica> listarMusicas() {
        conecta();
        MongoCollection<Musica> musicas = db.getCollection("Musicas", Musica.class);
        MongoCursor<Musica> resultado = musicas.find().iterator();
        List<Musica> musicasLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Musica musi = resultado.next();
            musicasLista.add(musi);
        }
        musica.close();
        return musicasLista;
    }
    
    
}