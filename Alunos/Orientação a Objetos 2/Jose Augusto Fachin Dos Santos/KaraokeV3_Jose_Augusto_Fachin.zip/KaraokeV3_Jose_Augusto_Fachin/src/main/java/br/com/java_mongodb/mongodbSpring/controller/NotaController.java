package br.com.java_mongodb.mongodbSpring.controller;


import br.com.java_mongodb.mongodbSpring.model.Cliente;
import br.com.java_mongodb.mongodbSpring.model.Musica;
import br.com.java_mongodb.mongodbSpring.model.Nota;
import br.com.java_mongodb.mongodbSpring.repository.ClienteRepository;
import br.com.java_mongodb.mongodbSpring.repository.MusicaRepository;
import br.com.java_mongodb.mongodbSpring.repository.NotaRepository;
import java.util.List;
import java.util.Map;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class NotaController {
    @Autowired
    NotaRepository repository;
    @Autowired
    ClienteRepository cliente_repository;
    @Autowired
    MusicaRepository musica_repository;
   
   
    @GetMapping("/nota/cadastrar")
    public String cadastrar(Model model){  
        
        Nota nota = new Nota();
        List<Musica> musicas = musica_repository.listarTodos();
        List<Cliente> clientes = cliente_repository.listarTodos();
        
        nota.setMusicas(musicas);
        nota.setClientes(clientes);
        nota.setNota(0);      
           
        
        model.addAttribute("nota", nota);
        return"nota/cadastrar";
    }
    
    @PostMapping("/nota/salvar")
    public String salvar(@ModelAttribute Nota nota){         
        
        repository.salvar(nota);
        return"redirect:/";
    }
          
    
    @GetMapping("/nota/visualizar_ranking")
    public String exibirRanking(Model model){
       Map<String, Double> mediaNotasPorCliente = repository.calcularMediaNotas();
        model.addAttribute("ranking", mediaNotasPorCliente);

        List<Nota> ranking = repository.obterRankingMelhoresMedias();
        model.addAttribute("listaDasNotas", ranking);
       return "nota/visualizar_ranking";
   }
       
}
