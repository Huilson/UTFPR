package br.com.java_mongodb.mongodbSpring.repository;

import br.com.java_mongodb.mongodbSpring.codec.ClienteCodec;
import br.com.java_mongodb.mongodbSpring.codec.MusicaCodec;
import br.com.java_mongodb.mongodbSpring.model.Musica;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class MusicaRepository {

    private MongoClient musica;
    private MongoDatabase db;

    public void conecta() {
        //Instaciar um codec
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Qual classe ira sofrer o encode/decode
        MusicaCodec musicaCodec = new MusicaCodec(codec);

        //Instanciar um registro para o codec
        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(musicaCodec));

        //Dar um build no registro
        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.musica = new MongoClient("localhost:27017", op);
        this.db = musica.getDatabase("KaraokeV3");
    }

    public void salvar(Musica musi) {
        conecta();
        MongoCollection<Musica> musicas = db.getCollection("Musicas", Musica.class);
        if(musi.getId() == null){//se não tiver um aluno, crio uma aluno
            musicas.insertOne(musi);
        }else{//se o aluno já existir salva somente as alterações
            musicas.updateOne(Filters.eq("_id", musi.getId()), new Document("$set",musi));
        }        
        musica.close();
    }

    public List<Musica> listarTodos() {
        conecta();
        MongoCollection<Musica> musicas = db.getCollection("Musicas", Musica.class);
        MongoCursor<Musica> resultado = musicas.find().iterator();
        List<Musica> musicasLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Musica musi = resultado.next();
            musicasLista.add(musi);
        }
        musica.close();
        return musicasLista;
    }
    
    public Musica obterId(String id){
        conecta();
        MongoCollection<Musica> musicas = db.getCollection("Musicas", Musica.class);
        Musica musi = musicas.find(Filters.eq("_id", new ObjectId(id))).first();
        return musi;
    }

    public void excluir(String id) {
        conecta();
        MongoCollection<Musica> musicas = db.getCollection("Musicas", Musica.class);
        musicas.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }

}