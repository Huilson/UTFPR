package br.com.java_mongodb.mongodbSpring.repository;

import br.com.java_mongodb.mongodbSpring.codec.ClienteCodec;
import br.com.java_mongodb.mongodbSpring.model.Cliente;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class ClienteRepository {

    private MongoClient cliente;
    private MongoDatabase db;

    public void conecta() {
        //Instaciar um codec
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);

        //Qual classe ira sofrer o encode/decode
        ClienteCodec alunoCodec = new ClienteCodec(codec);

        //Instanciar um registro para o codec
        CodecRegistry registro = CodecRegistries
                .fromRegistries(MongoClient.getDefaultCodecRegistry(),
                        CodecRegistries.fromCodecs(alunoCodec));

        //Dar um build no registro
        MongoClientOptions op = MongoClientOptions.builder().
                codecRegistry(registro).build();

        this.cliente = new MongoClient("localhost:27017", op);
        this.db = cliente.getDatabase("KaraokeV3");
    }

    public void salvar(Cliente cli) {
        conecta();
        MongoCollection<Cliente> clientes = db.getCollection("Clientes", Cliente.class);
        if(cli.getId() == null){//se não tiver um aluno, crio uma aluno
            clientes.insertOne(cli);
        }else{//se o aluno já existir salva somente as alterações
            clientes.updateOne(Filters.eq("_id", cli.getId()), new Document("$set",cli));
        }        
        cliente.close();
    }
 /*   
    public void atualizar(Cliente cli) {
        conecta();
        MongoCollection<Cliente> clientes = db.getCollection("Clientes", Cliente.class);
        if(cli.getId() == null){//se não tiver um aluno, crio uma aluno
            clientes.insertOne(cli);
        }else{//se o aluno já existir salva somente as alterações
            clientes.updateOne(Filters.eq("_id", cli.getId()), new Document("$set",cli));
        }        
        cliente.close();
    }
*/
    public List<Cliente> listarTodos() {
        conecta();
        MongoCollection<Cliente> clientes = db.getCollection("Clientes", Cliente.class);
        MongoCursor<Cliente> resultado = clientes.find().iterator();
        List<Cliente> clienteLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Cliente cli = resultado.next();
            clienteLista.add(cli);
        }
        cliente.close();
        return clienteLista;
    }
    
    public Cliente obterId(String id){
        conecta();
        MongoCollection<Cliente> clientes = db.getCollection("Clientes", Cliente.class);
        Cliente cli = clientes.find(Filters.eq("_id", new ObjectId(id))).first();
        return cli;
    }

    public void excluir(String id) {
        conecta();
        MongoCollection<Cliente> clientes = db.getCollection("Clientes", Cliente.class);
        clientes.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }

}