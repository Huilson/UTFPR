package br.com.java_mongodb.mongodbSpring.controller;

import br.com.java_mongodb.mongodbSpring.model.Musica;
import br.com.java_mongodb.mongodbSpring.repository.ClienteRepository;
import br.com.java_mongodb.mongodbSpring.repository.MusicaRepository;
import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MusicaController {
    
    @Autowired
    MusicaRepository repository;
   
    @GetMapping("/musica/cadastrar")
    public String cadastrar(Model model){
        model.addAttribute("musica", new Musica());
        return"musica/cadastrar";
    }     
    
    @PostMapping("/musica/salvar")
    public String salvar(@ModelAttribute Musica musica){
        repository.salvar(musica);
        return"redirect:/";
    }
    
    @GetMapping("/musica/listar")
    public String listar(Model model){
        List<Musica> musicas = repository.listarTodos();
        model.addAttribute("Musicas", musicas);
        return"musica/listar";
    }
    
   @GetMapping("/musica/visualizar/{id}")
    public String visualizar(@PathVariable String id, Model model){
       Musica musica = repository.obterId(id);
       model.addAttribute("musica", musica);
       return "musica/visualizar";
   }
    
    @GetMapping("/musica/excluir/{id}")
    public String excluir(@PathVariable String id){
       repository.excluir(id);       
       return "redirect:/musica/listar";
   }
    
    @GetMapping("/musica/atualizar/{id}")
    public String atualizar(@PathVariable String id, Model model) {
        Musica musica = repository.obterId(id);
        model.addAttribute("musica", musica);
        return "musica/atualizar";
    }
    @PostMapping("/musica/editar/{id}")
    public String update(@ModelAttribute Musica musica, @PathVariable String id) {
        ObjectId idMusica = new ObjectId(id);
        musica.setId(idMusica);
        repository.salvar(musica);
        return "redirect:/";
    }
}

