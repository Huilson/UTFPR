package br.com.java_mongodb.mongodbSpring.model;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

public class Musica {
    private ObjectId id;
    private String nome;
    private String genero;
    private String letra;
    private String duracao;
    private String compositor;
    private String gravadora;
    private int ano;
    private List<Double> notas;

    public Musica(String nome, String genero, String letra, String duracao, String compositor, String gravadora, int ano, List<Double> notas) {
        this.nome = nome;
        this.genero = genero;
        this.letra = letra;
        this.duracao = duracao;
        this.compositor = compositor;
        this.gravadora = gravadora;
        this.ano = ano;
        this.notas = notas;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }
    
    
    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getCompositor() {
        return compositor;
    }

    public void setCompositor(String compositor) {
        this.compositor = compositor;
    }

    public String getGravadora() {
        return gravadora;
    }

    public void setGravadora(String gravadora) {
        this.gravadora = gravadora;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    } 

    public Musica() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getLetra() {
        return letra;
    }

    public void setLetra(String letra) {
        this.letra = letra;
    }   
   

    public List<Double> getNotas() {
        if(notas == null)
            notas = new ArrayList<Double>();
        return notas;
    }

    public void setNotas(List<Double> notas) {
        this.notas = notas;
    }   

    public Musica criaId() {
       setId(new ObjectId());
        return this;
    }
}