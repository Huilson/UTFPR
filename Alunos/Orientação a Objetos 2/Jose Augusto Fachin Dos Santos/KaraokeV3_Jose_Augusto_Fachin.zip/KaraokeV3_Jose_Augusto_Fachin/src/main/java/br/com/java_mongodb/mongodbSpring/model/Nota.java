package br.com.java_mongodb.mongodbSpring.model;

import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

public class Nota {
    private ObjectId id;
    private String nome_cliente;
    private String nome_musica;
    private double nota;
    
    private List<Cliente> clientes;
    private List<Musica> musicas;

    public Nota(ObjectId id, String nome_cliente, String nome_musica, double nota) {
        this.id = id;
        this.nome_cliente = nome_cliente;
        this.nome_musica = nome_musica;
        this.nota = nota;
    }

    public Nota(List<Cliente> clientes, List<Musica> musicas) {
        this.clientes = clientes;
        this.musicas = musicas;
    }

    
    
    public List<Cliente> getClientes() {
        if(clientes == null)
            clientes = new ArrayList<Cliente>();
        return clientes;
    }
    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }
    
    public List<Musica> getMusicas() {
        if(musicas == null)
            musicas = new ArrayList<Musica>();
        return musicas;
    }
    
    public void setMusicas(List<Musica> musicas) {
        this.musicas = musicas;
    }
    public Nota() {
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getNome_musica() {
        return nome_musica;
    }

    public void setNome_musica(String nome_musica) {
        this.nome_musica = nome_musica;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    

    public Nota criaId() {
        setId(new ObjectId());
        return this;        
    }

    
}