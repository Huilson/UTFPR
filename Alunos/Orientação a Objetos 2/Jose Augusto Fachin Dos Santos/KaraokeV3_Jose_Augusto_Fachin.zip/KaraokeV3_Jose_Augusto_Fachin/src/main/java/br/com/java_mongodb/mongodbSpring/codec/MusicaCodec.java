package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Musica;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class MusicaCodec implements CollectibleCodec<Musica> {

    private Codec<Document> codec;

    public MusicaCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Musica> getEncoderClass() {
        return Musica.class;
    }//Esse metodo diz qual classe será codificada

    @Override
    public boolean documentHasId(Musica musica) {
        return musica.getId() == null;
    }//Esse metodo só verifica se o objeto chamado tem ID

    @Override
    public BsonValue getDocumentId(Musica musica) {
        if (!documentHasId(musica))//Verifica se o ID foi criado
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else//Para que o ID possa ser lido é preciso converter para a base hexadecimal
        {
            return new BsonString(musica.getId().toHexString());
        }
    }

    @Override
    public Musica generateIdIfAbsentFromDocument(Musica musica) {
        return documentHasId(musica) ? musica.criaId() : musica;
    }

    @Override
    public void encode(BsonWriter writer, Musica musica, EncoderContext ec) {
        /*Esse metodo pega um Objeto e o envia para o Mongodb, um bom exemplo
        seria dizer para o mongodb qual a receita ele deve seguir para poder 
        salvar o Objeto Cliente em sua base de dados*/
        ObjectId id = musica.getId();
        String nome = musica.getNome();
        String genero = musica.getGenero();
        String letra = musica.getLetra();
        String duracao = musica.getDuracao();
        String compositor = musica.getCompositor();
        String gravadora = musica.getGravadora();
        Integer ano = musica.getAno();             
        
        Document doc = new Document();
        
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("genero", genero);
        doc.put("letra", letra);
        doc.put("duracao", duracao);
        doc.put("compositor", compositor);
        doc.put("gravadora", gravadora);
        doc.put("ano", ano);


        codec.encode(writer, doc, ec);
        
        //Essa função é quem traduz o que escrevemos na VIEW
    }

    @Override
    public Musica decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Musica musica = new Musica();
        musica.setId(doc.getObjectId("_id"));
        musica.setNome(doc.getString("nome"));
        musica.setGenero(doc.getString("genero"));        
        musica.setLetra(doc.getString("letra"));
        musica.setDuracao(doc.getString("duracao"));
        musica.setCompositor(doc.getString("compositor"));
        musica.setGravadora(doc.getString("gravadora"));
        musica.setAno(doc.getInteger("ano"));     
        return musica;
    }
}
