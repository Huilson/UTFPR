package utfpr.karaoke_V2;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import javax.swing.JOptionPane;
import utfpr.karaoke.dao.ClienteDAO;
import utfpr.karaoke.dao.MusicaDAO;
import utfpr.karaoke.dao.VotacaoDAO;

/**
 *
 * @author josea
 */

public class App {

    public static void main(String[] args) {
        MongoClient client = new MongoClient();

        //conectar a database
        MongoDatabase db = client.getDatabase("KaraokeTeste_1");

        //conectar as coleções
        MongoCollection<Document> clienteCollection = db.getCollection("Clientes");
        MongoCollection<Document> musicaCollection = db.getCollection("Musicas");
        MongoCollection<Document> votacaoCollection = db.getCollection("Votacoes");

        ClienteDAO clienteDao = new ClienteDAO();
        MusicaDAO musicaDao = new MusicaDAO();
        VotacaoDAO votacaoDao = new VotacaoDAO();

        String nome;
        String cpf;
        String fone;

        String descricao;
        String genero;
        String tempo;
        String compositor;
        String ano;
        String gravadora;

        String nomeEditar;
        String descricaoEditar;

        Integer nota;

        Integer opcao;

        do {
            do {

                String resp = JOptionPane.showInputDialog(
                        "Digite uma opção:"
                        + "\n1. Cadastrar cliente"
                        + "\n2. Editar cliente"
                        + "\n3. Excluir cliente"
                        + "\n4. Cadastrar música"
                        + "\n5. Editar música"
                        + "\n6. Excluir música"
                        + "\n7. Votação"
                        + "\n8. Exibir Ranking"
                        + "\n0. Sair");

                opcao = Integer.valueOf(resp);
                if (opcao > 8) {
                    JOptionPane.showMessageDialog(null, "Valor invalido! Escolha uma opção acima!");
                }

            } while (Integer.valueOf(opcao) > 8);

            if (opcao == 0) {
                break;
            }

            switch (opcao) {
                case 1:
                    nome = JOptionPane.showInputDialog("Nome:");

                    if (clienteDao.pesquisaCliente(clienteCollection, nome)) {
                        JOptionPane.showMessageDialog(null, "Já existe um cliente com este nome!");
                        break;
                    }

                    cpf = JOptionPane.showInputDialog("CPF:");
                    fone = JOptionPane.showInputDialog("Fone:");

                    clienteDao.cadastrarCliente(clienteCollection, nome, cpf, fone);

                    break;
                case 2:
                    nomeEditar = JOptionPane.showInputDialog("Nome do cliente a Editar:");

                    if (!clienteDao.pesquisaCliente(clienteCollection, nomeEditar)) {
                        JOptionPane.showMessageDialog(null, "Cliente não localizado!");
                        break;
                    }

                    nome = JOptionPane.showInputDialog("Nome:");
                    cpf = JOptionPane.showInputDialog("CPF:");
                    fone = JOptionPane.showInputDialog("Fone:");

                    clienteDao.editarCliente(clienteCollection, nomeEditar, nome, cpf, fone);
                    JOptionPane.showMessageDialog(null, "Cliente " + nomeEditar + " editado com sucesso!");

                    break;
                case 3: //
                    nome = JOptionPane.showInputDialog("Nome do cliente a Excluir:");

                    if (!clienteDao.pesquisaCliente(clienteCollection, nome)) {
                        JOptionPane.showMessageDialog(null, "Cliente não localizado!");
                        break;
                    }

                    clienteDao.excluirCliente(clienteCollection, nome);
                    JOptionPane.showMessageDialog(null, "Cliente " + nome + " excluir com sucesso!");

                    break;
                case 4: // Cadastrar Musica

                    descricao = JOptionPane.showInputDialog("Descrição:");

                    if (musicaDao.pesquisaMusica(musicaCollection, descricao)) {
                        JOptionPane.showMessageDialog(null, "Musica já Cadastrada!");
                        break;
                    }

                    genero = JOptionPane.showInputDialog("Genero:");
                    tempo = JOptionPane.showInputDialog("Duração no formato mm:ss :");
                    compositor = JOptionPane.showInputDialog("Compositor:");
                    ano = JOptionPane.showInputDialog("Ano de Lançamento:");
                    gravadora = JOptionPane.showInputDialog("Gravadora:");

                    musicaDao.cadastrarMusica(musicaCollection, descricao, genero, tempo, compositor, ano, gravadora);
                    JOptionPane.showMessageDialog(null, "Musica " + descricao + " cadastrada com sucesso!");

                    break;
                case 5: // Editar Musica

                    descricaoEditar = JOptionPane.showInputDialog("Descrição da musica a Editar:");

                    if (!musicaDao.pesquisaMusica(musicaCollection, descricaoEditar)) {
                        JOptionPane.showMessageDialog(null, "Musica não encontrada!");
                        break;
                    }

                    descricao = JOptionPane.showInputDialog("Descrição:");
                    genero = JOptionPane.showInputDialog("Genero:");
                    tempo = JOptionPane.showInputDialog("Duração no formato mm:ss :");
                    compositor = JOptionPane.showInputDialog("Compositor:");
                    ano = JOptionPane.showInputDialog("Ano de Lançamento:");
                    gravadora = JOptionPane.showInputDialog("Gravadora:");

                    musicaDao.editarMusica(musicaCollection, descricaoEditar, descricao, genero, tempo, compositor, ano, gravadora);
                    JOptionPane.showMessageDialog(null, "Musica " + descricaoEditar + " Editada com sucesso!");
                    break;
                case 6: // Excluir Musica
                    descricao = JOptionPane.showInputDialog("Descrição:");

                    if (!musicaDao.pesquisaMusica(musicaCollection, descricao)) {
                        JOptionPane.showMessageDialog(null, "Musica não encontrada!");
                        break;
                    }

                    musicaDao.excluirMusica(musicaCollection, descricao);
                    JOptionPane.showMessageDialog(null, "Musica " + descricao + " Excluida com sucesso!");

                    break;
                case 7: // Votar
                    nome = JOptionPane.showInputDialog("Nome do Cliente: ");

                    if (!clienteDao.pesquisaCliente(clienteCollection, nome)) {
                        JOptionPane.showMessageDialog(null, "Cliente não encontrado!");
                        break;
                    }

                    descricao = JOptionPane.showInputDialog("Descrição da Musica:");

                    if (!musicaDao.pesquisaMusica(musicaCollection, descricao)) {
                        JOptionPane.showMessageDialog(null, "Musica não encontrada!");
                        break;
                    }

                    nota = Integer.parseInt(JOptionPane.showInputDialog("Nota:"));
                    //votacaoDao.votar(clienteCollection, musicaCollection, nome, descricao, nota);
                    votacaoDao.adicionarVoto(clienteCollection, nome,descricao,  nota);
                    JOptionPane.showMessageDialog(null, "Voto Registrado!");
                    break;
                case 8: // Exibir Ranking

                    JOptionPane.showMessageDialog(null,votacaoDao.exibirRanking(clienteCollection));

                    break;
                default:
                    JOptionPane.showMessageDialog(null,"Opção inválida");
                    break;
            }

        } while (opcao != 0);

    }

}
