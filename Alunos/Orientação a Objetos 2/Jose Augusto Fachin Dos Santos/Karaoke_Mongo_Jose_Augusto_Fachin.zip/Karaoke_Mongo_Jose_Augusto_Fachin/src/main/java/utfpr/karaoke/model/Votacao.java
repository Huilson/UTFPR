
package utfpr.karaoke.model;

/**
 *
 * @author josea
 */
public class Votacao {
    private Cliente cliente;
    private Musica musica;
    private int nota;

    public Votacao(Cliente cliente, Musica musica, int nota) {
        this.cliente = cliente;
        this.musica = musica;
        this.nota = nota;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Musica getMusica() {
        return musica;
    }

    public void setMusica(Musica musica) {
        this.musica = musica;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
    
    
}

