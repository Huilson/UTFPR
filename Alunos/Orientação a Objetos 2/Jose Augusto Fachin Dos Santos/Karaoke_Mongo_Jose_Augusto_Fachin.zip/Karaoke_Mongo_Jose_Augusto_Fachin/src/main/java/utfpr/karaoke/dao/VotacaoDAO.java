
package utfpr.karaoke.dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.bson.Document;
import org.bson.types.ObjectId;
import utfpr.karaoke.model.Musica;
import utfpr.karaoke.model.Votacao;

/**
 *
 * @author josea
 */
public class VotacaoDAO {
    
    public VotacaoDAO() {
      
    }
    
    public void adicionarVoto(MongoCollection<Document> clienteCollection, String nome,String musica, Integer nota){
        // adiciona um item no array 
        clienteCollection.updateOne(
            Filters.eq("nome", nome.toUpperCase()), // filtra pelo nome
            Updates.push("notas", nota) // com push add mesmo se já existir 
               // tinha testado com Updates.addToSet("notas", novaNota) antes, nesse caso ele add so se não existe no array
        );
     
        // grava um registro em Votacoes
        Document document = new Document();
        document.append("cliente", nome.toUpperCase());
        document.append("musica", musica.toUpperCase());
        document.append("nota", nota);

        clienteCollection.insertOne(document);
     
    }
    
    public String exibirRanking(MongoCollection<Document> clienteCollection){
        
        String Ranking = "Ranking:";
        Integer i = 1;
       
        // cria um cursor com base no resultado da busca
        MongoCursor<Document> doc = clienteCollection.find().iterator();
        
        Document aux = null;
        
        // converte o iterator em document
        Document alunoDoc = (Document) doc;
        
        while (doc.hasNext()) {
           String nome = alunoDoc.getString("nome");
           // pega a nota
            List<Integer> notas = (List<Integer>) alunoDoc.get("notas");
            Double media = notas.stream().mapToDouble(Integer::doubleValue).average().orElse(0.0);
            Ranking = Ranking +i.toString()+ "º - "+nome +": "+media+"\n";         
            
           
            aux = doc.next();
            i++;
        }
      
        return Ranking;

    }
}
   
    

