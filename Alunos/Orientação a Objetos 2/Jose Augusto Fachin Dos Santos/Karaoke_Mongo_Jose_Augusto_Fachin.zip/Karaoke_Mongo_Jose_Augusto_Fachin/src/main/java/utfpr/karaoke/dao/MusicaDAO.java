
package utfpr.karaoke.dao;

import com.mongodb.client.MongoCollection;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.bson.Document;
import org.bson.types.ObjectId;

/**
 *
 * @author josea
 */
public class MusicaDAO {

    public MusicaDAO() {

    }

    public boolean pesquisaMusica(MongoCollection<Document> collection, String descricao) {
        // verifica se existe uma musica com a mesma descrição
        Document document = collection.find(new Document("descricao", descricao.toUpperCase())).first();

        if (document == null) {
            return false;
        }
        return true;
    }
    
    public void cadastrarMusica(MongoCollection<Document> collection, String descricao, String genero,
                                String tempo, String compositor, String ano, String gravadora) {
        // cadastra uma musica
        Document document = new Document();
        document.append("descricao", descricao.toUpperCase());
        document.append("genero", genero.toUpperCase());
        document.append("tempo", tempo);
        document.append("compositor", compositor.toUpperCase());
        document.append("ano", ano);
        document.append("gravadora", gravadora.toUpperCase());

        collection.insertOne(document);

    }

    public void editarMusica(MongoCollection<Document> collection,String descricao,String novoDescricao, String genero,
                             String tempo, String compositor, String ano, String gravadora) {
        // edita uma musica
        Document document = collection.find(new Document("descricao", descricao.toUpperCase())).first();
 
        document.put("descricao", novoDescricao.toUpperCase());
        document.put("genero", genero.toUpperCase());
        document.put("tempo", tempo);
        document.put("compositor", compositor.toUpperCase());
        document.put("ano", ano);
        document.put("gravadora", gravadora.toUpperCase());

        collection.replaceOne(new Document("descricao", descricao.toUpperCase()), document);

    }

    public void excluirMusica(MongoCollection<Document> collection,String descricao) {
        // exclui uma musica
        Document document = collection.find(new Document("descricao", descricao.toUpperCase())).first();

        collection.deleteOne(new Document("descricao", descricao.toUpperCase()));

    }

}
