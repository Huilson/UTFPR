
package utfpr.karaoke.dao;

import com.mongodb.BasicDBList;
import com.mongodb.client.MongoCollection;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.bson.Document;
import org.bson.types.ObjectId;
import utfpr.karaoke.model.Votacao;

/**
 *
 * @author josea
 */
public class ClienteDAO {

    public ClienteDAO() {

    }

    public boolean pesquisaCliente(MongoCollection<Document> collection, String nome) {

        // verifica se encontoru um cliente com o mesmo nome
        Document document = collection.find(new Document("nome", nome.toUpperCase())).first();

        if (document == null) {
            return false;
        }
        return true;
    }

    public void cadastrarCliente(MongoCollection<Document> collection, String nome, String cpf, String fone) {
        // cadastra um cliente
        Document document = new Document();
        document.append("nome", nome.toUpperCase());
        document.append("cpf", cpf);
        document.append("fone", fone);

        collection.insertOne(document);

    }

    public void editarCliente(MongoCollection<Document> collection, String nome, String novoNome, String cpf, String fone) {
        // edita um cliente
        Document document = collection.find(new Document("nome", nome.toUpperCase())).first();

        document.put("nome", novoNome.toUpperCase());
        document.put("cpf", cpf);
        document.put("fone", fone);

        collection.replaceOne(new Document("nome", nome.toUpperCase()), document);

    }

    public void excluirCliente(MongoCollection<Document> collection, String nome) {
        // exclui um cliente
        Document document = collection.find(new Document("nome", nome.toUpperCase())).first();

        collection.deleteOne(new Document("nome", nome.toUpperCase()));

    }
}
