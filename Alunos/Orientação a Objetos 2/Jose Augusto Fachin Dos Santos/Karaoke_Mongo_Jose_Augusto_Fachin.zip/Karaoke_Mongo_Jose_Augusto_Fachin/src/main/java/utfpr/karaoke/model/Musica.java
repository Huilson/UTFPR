package utfpr.karaoke.model;

import java.util.List;
import org.bson.types.ObjectId;
/**
 *
 * @author josea
 */

public class Musica {
    private ObjectId _id;
    private String descricao;
    private String genero;
    private String tempo;
    private String compositor;
    private Integer ano;
    private String gravadora;
   // private double notaMedia;
   // private List<Votacao> votacoes;

    public Musica(ObjectId _id, String descricao, String genero, String tempo, String compositor, Integer ano, String gravadora/*, double notaMedia, List<Votacao> votacoes*/) {
        this._id = _id;
        this.descricao = descricao;
        this.genero = genero;
        this.tempo = tempo;
        this.compositor = compositor;
        this.ano = ano;
        this.gravadora = gravadora;
        //this.notaMedia = notaMedia;
       // this.votacoes = votacoes;
    }

    public Musica() {
    }

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }

    public String getCompositor() {
        return compositor;
    }

    public void setCompositor(String compositor) {
        this.compositor = compositor;
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public String getGravadora() {
        return gravadora;
    }

    public void setGravadora(String gravadora) {
        this.gravadora = gravadora;
    }
    /*
    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(double notaMedia) {
        this.notaMedia = notaMedia;
    }

    public List<Votacao> getVotacoes() {
        return votacoes;
    }

    public void setVotacoes(List<Votacao> votacoes) {
        this.votacoes = votacoes;
    }
*/
    
    
}
