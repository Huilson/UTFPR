package utfpr.karaoke.model;

import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

/**
 *
 * @author josea
 */

public class Cliente {

    private ObjectId _id;
    private String nome;
    private String cpf;
    private String fone;
    private List<Integer> notaMedia;


    public Cliente(ObjectId _id, String nome, String cpf, String fone, Integer notaMedia) {
        this._id = _id;
        this.nome = nome;
        this.cpf = cpf;
        this.fone = fone;
        this.notaMedia = new ArrayList<>();
        
    }

    public List<Integer> getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(List<Integer> notaMedia) {
        this.notaMedia = notaMedia;
    }

   

    public Cliente() {
    }

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

}
