package utfpr.aulajpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;
import utfpr.aulajpa.dao.AlunoDAO;
import utfpr.aulajpa.dao.DisciplinaDAO;
import utfpr.aulajpa.model.Aluno;
import utfpr.aulajpa.model.Disciplina;
import utfpr.aulajpa.util.Factory;

public class App {

    public static void main(String[] args) {
       
        //Como possuo um factory posso instanciar quantos managers forem precisos
        EntityManager em = Factory.getEntityManager();
        
        AlunoDAO alunoDAO = new AlunoDAO(em);
        DisciplinaDAO disDAO = new DisciplinaDAO(em);    
      
        Integer iresp;
        
         do{
            String resp = JOptionPane.showInputDialog("1- Cadastrar Disciplina \n2- Cadastrar Aluno"
                    + "\n3- Atualizar Media\n4- Atualizar Nome Disciplina\n5- Excluir Aluno"
                    +"\n6- COnsultar Alunos\n0- Sair");
            
        
            iresp = Integer.valueOf(resp);
            switch (iresp) {
                case 1: // Disciplina 
                    
                    String nome = JOptionPane.showInputDialog("Descrição da Disciplina:");
                    int qnt = 0;
                    
                    qnt = Integer.parseInt(JOptionPane.showInputDialog("Qtde Alunos:"));
                    
                    Disciplina dis = new Disciplina(nome,qnt);              
                    
                    
                    em.getTransaction().begin();
                    disDAO.salvar(dis);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Disciplina "+nome+" criada com sucesso");       
                              
                break;
                
                case 2: // Aluno
                    String nomeAluno = JOptionPane.showInputDialog("Nome do Aluno:");
                    int RA= 0;
                    Long idDis;
                    double media;
                    
                    media = Double.parseDouble(JOptionPane.showInputDialog("Média:"));
                    RA = Integer.parseInt(JOptionPane.showInputDialog("RA Aluno:"));
                    idDis = Long.parseLong(JOptionPane.showInputDialog("Id, DIsciplina:"));
                    
                    Disciplina disLocal = new Disciplina();                    
                                      
                    disLocal = disDAO.buscaDisciplina(idDis);                                     
                    
                    Aluno aluno = new Aluno(nomeAluno,RA, media,disLocal);                                   
                    
                    em.getTransaction().begin();
                    alunoDAO.salvar(aluno);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Aluno "+nomeAluno+" criad com sucesso");       
                              
                break;               
                 
                case 3: // Atualizar Media 
                     Long idAluno1;
                     double media1 =0;
                    
                    idAluno1 = Long.parseLong(JOptionPane.showInputDialog("Id Aluno:")); 
                    media1 = Double.parseDouble(JOptionPane.showInputDialog("Média:"));
                   
                    Aluno alunoLoc1 = alunoDAO.buscaAluno(idAluno1);
                    alunoLoc1.setMedia(media1);
                    
                    em.getTransaction().begin();
                    alunoDAO.atualizar(alunoLoc1);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Media atualizado com sucesso");       
                              
                break;
                
                case 4: // Atualizar nome disc 
                     Long idDis1;
                     idDis1 = Long.parseLong(JOptionPane.showInputDialog("Id disciplina:"));                    
                     String nomeDis = JOptionPane.showInputDialog("Descrição da Disciplina:");                 
                    
                    Disciplina disLoc1 = disDAO.buscaDisciplina(idDis1);
                    disLoc1.setNome(nomeDis);
                    
                    em.getTransaction().begin();
                    disDAO.atualizar(disLoc1);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Descrição atualizado com sucesso");       
                              
                break;
                
                case 5: // Excluir Aluno
                    
                    Long idAluno;
                    
                    idAluno = Long.parseLong(JOptionPane.showInputDialog("Id, Aluno:"));                    
                   
                    Aluno alunoLoc = alunoDAO.buscaAluno(idAluno);
                    
                    em.getTransaction().begin();
                    alunoDAO.excluir(alunoLoc);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Aluno excluirdo com sucesso");                           
                              
                break;
                
                case 6: // Consultar Alunos 
                    Long idAluno2;
                    
                    idAluno2 = Long.parseLong(JOptionPane.showInputDialog("Id, Aluno:"));                    
                    Aluno alunoLoc2 = alunoDAO.buscaAluno(idAluno2);
                    
                    em.getTransaction().begin();
                    alunoDAO.buscaAluno(idAluno2);                    
                    JOptionPane.showMessageDialog(null, alunoLoc2.getNome());                    
                    em.getTransaction().commit();                   
                              
                break;

            }        
        }while(iresp != 0);
     
         em.close();
    }
}
