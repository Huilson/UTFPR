/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.karaoke.dao;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.karaoke.model.Notas;
import utfpr.karaoke.model.Ranking;

/**
 *
 * @author josea
 */
public class RankingDAO {
    private EntityManager em;

    public RankingDAO(EntityManager em) {
        this.em = em;
    }
    
    public String buscaRanking(){
        String jpql = "select n.id_cliente,c.nome,avg(n.nota)as media from notas n "
                     +"left join clientes c on c.id = n.id_cliente group by n.id_cliente,c.nome";
        em.createQuery(jpql, Notas.class).getResultList();
          
                
        List<Ranking> ranking = em.createQuery(jpql, Ranking.class).getResultList();
        
        StringBuilder sb = new StringBuilder();
        
        for (Ranking rk : ranking) {
            sb.append(rk.getNome()).append(" ")
              .append(rk.getMedia()).append("\n");
        }
        
       return sb.toString();              
    }
    
    public List<Ranking> getRanking(){
        String jpql = "select n.id_cliente,c.nome,avg(n.nota)as media from notas n "
                     +"left join clientes c on c.id = n.id_cliente group by n.id_cliente,c.nome";
        em.createQuery(jpql, Notas.class).getResultList();
        
       return em.createQuery(jpql, Ranking.class).getResultList();
    }
    
    
}
