package utfpr.karaoke;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;
import utfpr.karaoke.dao.ClienteDAO;
import utfpr.karaoke.dao.HistoricoDAO;
import utfpr.karaoke.dao.MusicaDAO; 
import utfpr.karaoke.dao.NotasDAO;
import utfpr.karaoke.dao.RankingDAO;
import utfpr.karaoke.model.Cliente;
import utfpr.karaoke.model.Historico;
import utfpr.karaoke.model.Musica;
import utfpr.karaoke.model.Notas;
import utfpr.karaoke.model.Ranking;
import utfpr.karaoke.util.Factory;

public class App {

    public static void main(String[] args) {
       
        //Como possuo um factory posso instanciar quantos managers forem precisos
        EntityManager em = Factory.getEntityManager();
        
        ClienteDAO clienteDao = new ClienteDAO(em);
        MusicaDAO musicaDao = new MusicaDAO(em);
        NotasDAO notasDao = new NotasDAO(em);
      
        Integer iresp;
        String resp = "";
        
         do{
             do{
                  resp = JOptionPane.showInputDialog("1- Cadastrar Cliente \n2- Cadastrar Musica"
                    + "\n3- Votar\n4- Consultar Cliente\n5- Consultar Musica"
                    +"\n6- Ranking Diario\n0- Sair");
                
                
                    if( Integer.valueOf(resp) > 6){
                        JOptionPane.showMessageDialog(null, "Valor invalido! Escolha uma opção acima!");
                    }
           
                }while(Integer.valueOf(resp) > 6 );
            
        
            iresp = Integer.valueOf(resp);
            switch (iresp) {
                case 1: //Cad Cliente 
                    
                    String nome = JOptionPane.showInputDialog("Nome:"   );
                    String cpf  = JOptionPane.showInputDialog("CPF:"    );
                    String fone = JOptionPane.showInputDialog("Fone:"   );                                    
                    
                    Cliente cliente = new Cliente(nome,cpf,fone);             

                    em.getTransaction().begin();
                    clienteDao.salvar(cliente);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Cliente "+nome+" cadatrado com sucesso!");       
                              
                break;
                
                case 2: // Cad Musica
                    String descricao  = JOptionPane.showInputDialog("Descrição:"                        );
                    String genero     = JOptionPane.showInputDialog("Genero:"                           );
                    String tempo      = JOptionPane.showInputDialog("Duração no formato mm:ss :"        );                   
                    String compositor = JOptionPane.showInputDialog("Compositor:"                       );
                    Integer ano       = Integer.valueOf(JOptionPane.showInputDialog("Ano de Lançamento:"));
                    String gravadora  = JOptionPane.showInputDialog("Gravadora:"                        );                                     
                                                           
                    Musica musica = new Musica(descricao,genero,tempo,compositor,ano,gravadora);                                                                                                        
                    
                    em.getTransaction().begin();
                    musicaDao.salvar(musica);
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Musica "+descricao+" cadastrada com sucesso!");       
                              
                break;               
                 
                case 3: // Votar 
                     Long idCliente_votacao = Long.parseLong(JOptionPane.showInputDialog("Id do Cliente:")); 
                     Long idMusica_votacao  = Long.parseLong(JOptionPane.showInputDialog("Id da Musica:"));                                                                 
                     double nota_votacao = Double.parseDouble(JOptionPane.showInputDialog("Nota:"));                                        
                    /*
                     LocalDate data = LocalDate.now();
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    String dataAtual= formato.format(data);   */ 
                     
                    Cliente cli_pesq = new ClienteDAO(em).buscaCliente(idCliente_votacao);                    
                            
                    HistoricoDAO historicoDao = new HistoricoDAO(em);
                    Notas votacao = new Notas(idCliente_votacao,cli_pesq.getNome(),idMusica_votacao,nota_votacao);               
                  //  Historico hist = new Historico(idCliente_votacao,idMusica_votacao);               
                    
                    em.getTransaction().begin();
                    notasDao.salvar(votacao);
                    //historicoDao.salvar(hist);
                    
                    em.getTransaction().commit();
                    
                    JOptionPane.showMessageDialog(null, "Sua votação foi gravada com sucesso!");       
                              
                break;
                
                case 4: // Consultar CLiente 
                     Long idCliente_Consulta;
                    
                    idCliente_Consulta = Long.parseLong(JOptionPane.showInputDialog("Id do Cliente:"));                    
                    Cliente cliente_consulta = clienteDao.buscaCliente(idCliente_Consulta);
                    
                    em.getTransaction().begin();
                    clienteDao.buscaCliente(idCliente_Consulta);                 
                    JOptionPane.showMessageDialog(null, "Nome: "+cliente_consulta.getNome()+"\nCPF: "
                                                    +cliente_consulta.getCpf()+"\nFone: "+cliente_consulta.getFone());                    
                    em.getTransaction().commit(); 
                     
                              
                break;
                  
                case 5: // Consultar Musica
                    
                    Long idMusica_consulta;
                    
                    idMusica_consulta = Long.parseLong(JOptionPane.showInputDialog("Id do Cliente:"));                    
                    Musica musica_consulta = musicaDao.buscaMusica(idMusica_consulta);
                    
                    em.getTransaction().begin();
                    musicaDao.buscaMusica(idMusica_consulta);
                    JOptionPane.showMessageDialog(null, "Descrição: "+musica_consulta.getDescricao()
                                                    +"\nGenero: "+musica_consulta.getGenero()
                                                    +"\nDuração: "+musica_consulta.getTempo()
                                                    +"\nCompositor: "+musica_consulta.getCompositor()
                                                    +"\nGravadora:"+musica_consulta.getGravadora()
                                                    +"\nAno: "+musica_consulta.getAno());                    
                    em.getTransaction().commit();  
            
                break;
  /*            
                case 6: // Consultar Alunos 
                    Long idMusica_consulta;
                    
                    idMusica_consulta = Long.parseLong(JOptionPane.showInputDialog("Id Música:"));                    
                    Musica musicaLoc_consulta = musicaDao.buscaMusica(idMusica_consulta);
                    
                    em.getTransaction().begin();
                    musicaDao.buscaMusica(idMusica_consulta);                    
                    JOptionPane.showMessageDialog(null, "Descrição: "+musicaDao.get);                    
                    em.getTransaction().commit();                   
                              
                break;
*/
            }        
        }while(iresp != 0);
/*
         0,'
        RankingDAO rankingDAO = new RankingDAO(em);        
        
        String rankingList = rankingDAO.buscaRanking();
        StringBuilder sb = new StringBuilder();      
                    
        em.getTransaction().begin();
                   
        JOptionPane.showMessageDialog(null, "Ranking Atual:\n"+sb.toString());                    
        em.getTransaction().commit();   
         
         
         */
     

         em.close();
    }
}
