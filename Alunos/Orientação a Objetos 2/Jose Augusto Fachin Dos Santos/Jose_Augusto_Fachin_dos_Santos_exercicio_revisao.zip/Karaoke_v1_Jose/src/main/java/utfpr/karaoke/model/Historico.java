/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.karaoke.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author josea
 */
@Entity
@Table(name="historico")
public class Historico {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private Long idCliente;  
    //private String dta;

    public Historico(Long id, Long idCliente /*,String dta*/) {
        this.id = id;
        this.idCliente = idCliente;        
       // this.dta = dta;
    }
    
    public Historico() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Long idCliente) {
        this.idCliente = idCliente;
    }   
/*
    public String getDta() {
        return dta;
    }

    public void setDta(String dta) {
        this.dta = dta;
    }
    */
    

    
}
