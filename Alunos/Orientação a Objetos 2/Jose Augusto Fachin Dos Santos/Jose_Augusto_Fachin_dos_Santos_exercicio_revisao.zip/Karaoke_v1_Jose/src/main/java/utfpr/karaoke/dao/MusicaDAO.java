package utfpr.karaoke.dao;

import javax.persistence.EntityManager;
import utfpr.karaoke.model.Musica;

public class MusicaDAO {

    /*Instancio uma injeção de dependência*/
    private EntityManager em;
    
    /*Como só queremos usar o EM, não precisa inicia ou fecha a coneção*/
    public MusicaDAO(EntityManager em){
        this.em = em;
    }
    
    /*Métodos relacionados ao CRUD*/
    public void salvar(Musica disciplina){
        this.em.persist(disciplina);
    }
    
    public void excluir(Musica disciplina){
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
            this.em.merge(disciplina);
            this.em.remove(disciplina);
    }
    
    public void atualizar (Musica disciplina){
        this.em.merge(disciplina);
    }
    
    public Musica buscaMusica(Long id){
        return this.em.find(Musica.class, id);
    }
}
