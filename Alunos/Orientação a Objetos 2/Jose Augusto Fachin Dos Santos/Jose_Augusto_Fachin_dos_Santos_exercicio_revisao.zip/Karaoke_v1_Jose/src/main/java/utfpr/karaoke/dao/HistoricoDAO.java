/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.karaoke.dao;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.karaoke.model.Historico;

/**
 *
 * @author joseaa
 */
public class HistoricoDAO {
private EntityManager em;
    
    public HistoricoDAO(EntityManager em){
        this.em = em;
    }
   
    public void salvar(Historico historico){
        this.em.persist(historico);
    }
    
}
