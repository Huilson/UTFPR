package utfpr.karaoke.dao;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.karaoke.model.Cliente;
import utfpr.karaoke.model.Musica;

public class ClienteDAO {

    private EntityManager em;
    
    public ClienteDAO(EntityManager em){
        this.em = em;
    }
    
    public void salvar(Cliente cliente){
        this.em.persist(cliente);
    }
    
    public void excluir(Cliente cliente){        
            this.em.merge(cliente);
            this.em.remove(cliente);
    }
    
    public void atualizar (Cliente cliente){
        this.em.merge(cliente);
    }
    
    public Cliente buscaCliente(Long id){
        return this.em.find(Cliente.class, id);        
    }
    
    public List<Cliente> buscaTodos(){
        String jpql = "SELECT c FROM cliente c";
        return em.createQuery(jpql, Cliente.class).getResultList();
    }
   /*
    public List<Cliente> buscaAlunosReprovados(){        
        String jpql = "SELECT a FROM Aluno a WHERE a.media <6 ";
        return em.createQuery(jpql, Cliente.class).getResultList();
    }*/
}
