/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.karaoke.dao;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.karaoke.model.Notas;
import utfpr.karaoke.model.Ranking;

/**
 *
 * @author josea
 */
public class NotasDAO {
    private EntityManager em;
    
    public NotasDAO(EntityManager em){
        this.em = em;
    }
    
    public void salvar(Notas nota){
        this.em.persist(nota);
    }
    
    
    
}
