package utfpr.exercio1.entity;

import org.bson.Document;

public class Animals implements IBaseEntity {

    private String name;
    private String specie;
    private int age;

    public Animals() {
    }

    public Animals(String name, String specie, int age) {
        this.name = name;
        this.specie = specie;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecie() {
        return specie;
    }

    public void setSpecie(String specie) {
        this.specie = specie;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Animal{" + "name=" + name + ", specie=" + specie + ", age=" + age + '}';
    }

    @Override
    public Document toDocument() {

        final Document document = new Document();
        
        document.append("name", name);
        document.append("specie", specie);
        document.append("age", age);

        return document;
    }

}
