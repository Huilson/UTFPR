package utfpr.exercio1.entity;

import org.bson.Document;

public interface IBaseEntity {
    
    Document toDocument();
   
}
