package utfpr.exercio1.conection;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class MongoDB {
    private static final MongoDB INSTANCE = new MongoDB();
    private final MongoClient mongoClient;
    private final MongoDatabase database;
    
        //Conectar com o MongoDB
//        MongoClient conecta = new MongoClient();

        //Conectar com o Database
//        MongoDatabase db = conecta.getDatabase("hotelpet");

    public MongoDB() {
        this.mongoClient = new MongoClient();
        this.database = mongoClient.getDatabase("hotelpet");
    }
    
    public static MongoDB instance() {
        return INSTANCE;
    }
         
    public MongoDatabase getDatabase() {
        return database;
    }
} 

