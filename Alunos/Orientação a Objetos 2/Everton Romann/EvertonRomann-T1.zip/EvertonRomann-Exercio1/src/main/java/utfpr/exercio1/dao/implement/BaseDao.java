package utfpr.exercio1.dao.implement;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoDatabase;
import utfpr.exercio1.conection.MongoDB;
import utfpr.exercio1.dao.IBaseDao;
import utfpr.exercio1.entity.IBaseEntity;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.types.ObjectId;

public abstract class BaseDao<T extends IBaseEntity> implements IBaseDao<T> {

    protected final MongoDatabase database;
    protected final Class<T> clazz;

    public BaseDao(final Class<T> clazz) {
        this.database = MongoDB.instance().getDatabase();
        this.clazz = clazz;
    }

    @Override
    public T save(T entity) {
        database.getCollection(getCollectionName()).insertOne(entity.toDocument());
        return entity;
    }

    @Override
    public void deleteAll() {
        database.getCollection(getCollectionName()).deleteMany(new BasicDBObject());
    }

    @Override
    public void deleteOne(String name) {
        database.getCollection(getCollectionName()).deleteOne(Filters.eq("name", name));
    }


}
