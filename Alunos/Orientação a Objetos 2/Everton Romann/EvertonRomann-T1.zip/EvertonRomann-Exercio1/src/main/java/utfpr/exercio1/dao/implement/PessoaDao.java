/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1.dao.implement;

import org.bson.Document;
import utfpr.exercio1.entity.IBaseEntity;
import utfpr.exercio1.entity.Pessoa;

/**
 *
 * @author evert
 */
public class PessoaDao extends BaseDao<IBaseEntity>{

    public PessoaDao(Class<IBaseEntity> clazz) {
        super(clazz);
    }

    @Override
    public String getCollectionName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public IBaseEntity parseDocument(Document document) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
