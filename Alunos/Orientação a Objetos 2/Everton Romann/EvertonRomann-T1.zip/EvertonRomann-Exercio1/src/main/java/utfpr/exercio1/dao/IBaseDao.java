package utfpr.exercio1.dao;

import org.bson.Document;
import utfpr.exercio1.entity.IBaseEntity;

public interface IBaseDao <T extends IBaseEntity>{
    
    T save(T entity);
    
    String getCollectionName();
    
    void deleteAll();
    
    void deleteOne(String name);
    
    T parseDocument(final Document document);
}
