package utfpr.exercio1.entity;

public class Cachorros {
    
}
