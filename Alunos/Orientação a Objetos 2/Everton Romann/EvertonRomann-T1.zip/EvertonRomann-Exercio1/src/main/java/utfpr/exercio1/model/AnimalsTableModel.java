package utfpr.exercio1.model;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import utfpr.exercio1.entity.Animals;

public class AnimalsTableModel extends AbstractTableModel {

    private final List<Animals> arrayAnimals;
    private final String[] columns = new String[]{"Nome", "Especie", "Idade"};

    public AnimalsTableModel(List<Animals> arrayAnimals) {
        this.arrayAnimals = arrayAnimals;
    }

    @Override
    public int getRowCount() {
        return this.arrayAnimals.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int cIndex) {
        return columns[cIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Animals animals = arrayAnimals.get(rowIndex);
        return switch (columnIndex) {
            case 0 ->
                animals.getName();
            case 1 ->
                animals.getSpecie();
            case 2 ->
                animals.getAge();
            default ->
                null;
        };
    }

    public void addAnimal(Animals animal) {
        arrayAnimals.add(animal);
        int lastIndex = getRowCount() - 1;
        fireTableRowsInserted(lastIndex, lastIndex);
    }

    public void removeAnimal(int rowIndex) {
        arrayAnimals.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
    }
    
    public void updateAnimal(int rowIndex, Animals animal){
        arrayAnimals.set(rowIndex, animal);
        fireTableRowsUpdated(rowIndex, rowIndex);
    }

}
