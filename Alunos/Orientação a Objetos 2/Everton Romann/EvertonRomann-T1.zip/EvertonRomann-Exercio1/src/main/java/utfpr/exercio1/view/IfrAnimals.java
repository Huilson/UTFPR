package utfpr.exercio1.view;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import utfpr.exercio1.dao.implement.AnimalsDao;
import utfpr.exercio1.entity.Animals;
import utfpr.exercio1.model.AnimalsTableModel;

public class IfrAnimals extends javax.swing.JInternalFrame {

    private final ArrayList<Animals> arrayAnimals;
    private AnimalsDao animalsDao;
    private final AnimalsTableModel animalsTableModel;

    public IfrAnimals() {
        initComponents();
        animalsDao = new AnimalsDao();
        arrayAnimals = animalsDao.getAnimals();
        animalsTableModel = new AnimalsTableModel(arrayAnimals);
        tbAnimals.setModel(animalsTableModel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbAnimals = new javax.swing.JTable();
        btnNovo = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 600));

        tbAnimals.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nome", "Espécie", "Idade"
            }
        ));
        jScrollPane1.setViewportView(tbAnimals);

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnNovo)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditar)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluir)
                        .addGap(18, 18, 18)
                        .addComponent(btnSair)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 501, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSair)
                    .addComponent(btnExcluir)
                    .addComponent(btnEditar)
                    .addComponent(btnNovo))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        IfrCadAnimal cadAnimais = new IfrCadAnimal(animalsTableModel);
        getParent().add(cadAnimais);
        cadAnimais.centralizarFrame();
        cadAnimais.setVisible(true);
    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int selectedRow = tbAnimals.getSelectedRow();

        if (selectedRow >= 0) {
            int option = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir este registro?", "", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                String name = (String) tbAnimals.getValueAt(selectedRow, 0);
                animalsDao = new AnimalsDao();
                animalsDao.deleteOne(name);
                animalsTableModel.removeAnimal(selectedRow);
            }

        } else {
            JOptionPane.showMessageDialog(null, "Selecione um registro para excluir!");
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int selectedRow = tbAnimals.getSelectedRow();

        if (selectedRow >= 0) {
            String name = (String) tbAnimals.getValueAt(selectedRow, 0);
            IfrCadAnimal cadAnimais = new IfrCadAnimal(animalsTableModel, name, selectedRow);
            getParent().add(cadAnimais);
            cadAnimais.centralizarFrame();
            cadAnimais.setVisible(true);

        }
    }//GEN-LAST:event_btnEditarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSair;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbAnimals;
    // End of variables declaration//GEN-END:variables

    public void centralizarFrame() {
        this.setLocation(
                (this.getDesktopPane().getSize().width
                - this.getSize().width) / 2,
                (this.getDesktopPane().getSize().height
                - this.getSize().height) / 2);
    }
}
