package utfpr.exercio1.dao.implement;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import org.bson.Document;
import utfpr.exercio1.entity.Animals;

/**
 *
 * @author evert
 */
public class AnimalsDao extends BaseDao<Animals> {

    public AnimalsDao() {
        super(Animals.class);
    }

    @Override
    public String getCollectionName() {
        return "animals";
    }

    @Override
    public Animals parseDocument(Document document) {
        final Animals animals = new Animals();

        animals.setName(document.getString("name"));
        animals.setSpecie(document.getString("Specie"));
        animals.setAge(document.getInteger("age"));

        return animals;
    }

    public ArrayList<Animals> getAnimals() {
        ArrayList<Animals> arrayAnimals = new ArrayList<>();

        //Conectar com o MongoDB
        MongoClient conecta = new MongoClient();

        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("hotelpet");

        //Conectar na Coleção
        MongoCollection<Document> animals = db.getCollection("animals");

        MongoCursor<Document> cursor = animals.find().iterator();
        while (cursor.hasNext()) {
            Document document = cursor.next();

            String animalName = document.getString("name");
            String animalSpecie = document.getString("specie");
            Integer animalAge = document.getInteger("age");

            arrayAnimals.add(new Animals(animalName, animalSpecie, animalAge));
        }

        return arrayAnimals;
    }

    public void updateOneAnimal(String name, String specie, int age) {
        database.getCollection(getCollectionName()).updateOne(Filters.eq("name", name),
                new Document("$set", new Document("specie", specie).append("age", age)));
    }

    public Animals getByName(String name) {
        Animals animal = new Animals();
        
        MongoCursor<Document> cursor = database.getCollection(getCollectionName()).find().iterator();
        while (cursor.hasNext()) {
            Document document = cursor.next();

            animal.setName(document.getString("name"));
            animal.setSpecie(document.getString("specie"));
            animal.setAge(document.getInteger("age"));
        }
        return animal;
    }

}
