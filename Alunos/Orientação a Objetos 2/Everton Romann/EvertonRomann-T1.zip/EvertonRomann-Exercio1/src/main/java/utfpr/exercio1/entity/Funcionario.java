package utfpr.exercio1.entity;

public class Funcionario extends Pessoa{
    
}
