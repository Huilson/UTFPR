package utfpr.exercio1.entity;

public class Gatos extends Animals {

}
