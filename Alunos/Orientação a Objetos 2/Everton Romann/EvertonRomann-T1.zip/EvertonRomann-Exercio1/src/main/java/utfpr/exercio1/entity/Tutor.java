package utfpr.exercio1.entity;

public class Tutor extends Pessoa{
    
}
