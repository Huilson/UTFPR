package utfpr.exercio1.dao;

import utfpr.exercio1.entity.Animals;

public interface IAnimalsDao extends IBaseDao<Animals> {
    
    
}
