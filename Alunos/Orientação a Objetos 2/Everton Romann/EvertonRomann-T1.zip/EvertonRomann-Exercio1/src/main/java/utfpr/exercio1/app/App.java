package utfpr.exercio1.app;

import utfpr.exercio1.view.FrmPrincipal;

public class App {

    public static void main(String[] args) {

        FrmPrincipal menu = new FrmPrincipal();
        menu.setVisible(true);

    }
}
