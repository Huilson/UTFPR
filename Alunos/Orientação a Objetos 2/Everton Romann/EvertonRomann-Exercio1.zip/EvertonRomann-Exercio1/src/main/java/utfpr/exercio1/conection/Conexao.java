package utfpr.exercio1.conection;

import java.sql.*;

public class Conexao {

    public void conecta() throws SQLException, ClassNotFoundException {
        String driverClassName = "org.postgresql.Driver";
        
        String url = "jdbc:postgresql://localhost/hotel_pet";
        String username = "postgres";
        String password = "5432";
        //inserir
        String query = "INSERT INTO pessoa VALUES (2,'111.111.111-10', 'Eva', 'Pepito')";
        
        //excluir
        //String query = "DELETE FROM pessoa WHERE id = 1";
        
        //atualizar
        //String query = "UPDATE pessoa SET nome = 'Fabio' WHERE id = 1";
        
        //consultar
        String queryConsulta = "SELECT * FROM pessoa";
        
        // Carregar Driver 
        Class.forName(driverClassName);

        // Abrir Conexão
        Connection con = DriverManager.getConnection(url, username, password);

        // Obter um statement 
        Statement st = con.createStatement();

        // Executar query 
        int count = st.executeUpdate(query);
        System.out.println("Numero de linha criados por essa query = " + count);

        // Consultar do Banco
        ResultSet resultado = st.executeQuery(queryConsulta);
        
        //iterar sob a pesquisa retornada
        while(resultado.next()){
            System.out.println("\n"+resultado.getInt("id")+"\t");
            System.out.println(resultado.getString("nome")+"\t");
            System.out.println(resultado.getString("documento")+"\t");
        }
        // Fechar conexão 
        con.close();
    }
} // fim da classe

