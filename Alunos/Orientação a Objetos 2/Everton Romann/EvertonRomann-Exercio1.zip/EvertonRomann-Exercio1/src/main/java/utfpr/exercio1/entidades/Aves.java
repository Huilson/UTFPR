package utfpr.exercio1.entidades;

public class Aves extends Animal{
    
}
