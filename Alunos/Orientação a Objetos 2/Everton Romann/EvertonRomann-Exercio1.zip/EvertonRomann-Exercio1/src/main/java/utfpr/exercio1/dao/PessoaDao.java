/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1.dao;

import utfpr.exercio1.entidades.Pessoa;

/**
 *
 * @author evert
 */
public class PessoaDao extends AbstractDao<Pessoa>{
    
}
