package utfpr.exercio1.entidades;

public class Cachorros {
    
}
