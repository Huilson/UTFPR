package utfpr.exercio1.entidades;

public class Funcionario extends Pessoa{
    
}
