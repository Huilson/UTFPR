package utfpr.exercio1.entidades;

public class Gatos extends Animal {

}
