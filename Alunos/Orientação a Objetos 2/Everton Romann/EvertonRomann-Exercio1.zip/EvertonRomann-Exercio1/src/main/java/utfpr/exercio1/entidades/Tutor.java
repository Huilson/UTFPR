package utfpr.exercio1.entidades;

public class Tutor extends Pessoa{
    
}
