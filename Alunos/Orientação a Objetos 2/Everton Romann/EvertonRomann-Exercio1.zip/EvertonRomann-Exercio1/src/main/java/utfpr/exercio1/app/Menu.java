package utfpr.exercio1.app;

import java.util.Scanner;

public class Menu {

    Scanner scan = new Scanner(System.in);
    int op;
    boolean loop;
    String s;

    public void menu() {
        this.s = "n";
        do {
        System.out.println("Escolha uma opção: ");
        System.out.println("1 - Cadastro Animal");
        System.out.println("2 - Cadastro Pessoa");
        System.out.println("3 - Gerenciar Hotel");
        System.out.println("4 - Sair");
        op = scan.nextInt();        
            switch (op) {
                case 1:
                    System.out.println("Acessar cadastro do animal");
                    System.out.println("Coisas relacionadas ao animal");
                    System.out.println("Criar");
                    System.out.println("Editar");
                    System.out.println("Consultar");
                    System.out.println("Excluir");
                    System.out.println("\n\n\n\n");
                    break;
                case 2:
                    System.out.println("Acessar cadastro da pessoa");
                    break;
                case 3:
                    System.out.println("Acessar gerenciamento do hotel");
                    break;
                case 4:
                    System.out.println("Deseja sair? s/n");
                    s = scan.next();
            }
            if (s.equalsIgnoreCase("s")) {
                loop = false;
            } else {
                loop = true;
            }
        } while (loop == true);
    }
}
