/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.exercio1.dao;

import utfpr.exercio1.entidades.Animal;

/**
 *
 * @author evert
 */
public class AnimalDao extends AbstractDao<Animal>{
    
}
