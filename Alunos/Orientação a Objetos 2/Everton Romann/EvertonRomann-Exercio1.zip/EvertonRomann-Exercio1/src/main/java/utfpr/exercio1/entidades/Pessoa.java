package utfpr.exercio1.entidades;

public abstract class Pessoa {
    private String nome;
    private String documento;
    private String pets;

    public Pessoa() {
    }

    public Pessoa(String nome, String documento, String pets) {
        this.nome = nome;
        this.documento = documento;
        this.pets = pets;
    }
    
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getPets() {
        return pets;
    }

    public void setPets(String pets) {
        this.pets = pets;
    }
    
    
}
