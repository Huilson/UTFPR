package utfpr.exercio1.app;

//import java.sql.SQLException;

import utfpr.exercio1.view.FrmPrincipal;

public class App {

//    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        //Menu menu = new Menu();
        //menu.menu();
//        Conexao conecta = new Conexao();
//        conecta.conecta();
    
    public static void main(String[] args) {
        
        FrmPrincipal menu = new FrmPrincipal();
        menu.setVisible(true);

    }
}
