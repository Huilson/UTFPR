/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.utfpr;

import br.edu.utfpr.util.Factory;
import br.edu.utfpr.util.Menu;
import javax.persistence.EntityManager;

/**
 *444
 * @author kagho
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        EntityManager em = Factory.getEntityManager();
        
        Menu menu = new Menu();
        menu.menu();
        
    }
}
