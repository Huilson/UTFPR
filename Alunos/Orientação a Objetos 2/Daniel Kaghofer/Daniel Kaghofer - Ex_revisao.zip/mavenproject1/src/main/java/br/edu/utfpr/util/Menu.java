/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.util;

import br.edu.utfpr.dao.CompositorDao;
import br.edu.utfpr.dao.GeneroDao;
import br.edu.utfpr.dao.GravadoraDao;
import br.edu.utfpr.dao.MusicaDao;
import br.edu.utfpr.dao.PessoaDao;
import br.edu.utfpr.dao.SessaoDao;
import br.edu.utfpr.model.Compositor;
import br.edu.utfpr.model.Genero;
import br.edu.utfpr.model.Gravadora;
import br.edu.utfpr.model.Musica;
import br.edu.utfpr.model.Pessoa;
import br.edu.utfpr.model.Sessao;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;
import javax.persistence.EntityManager;

/**
 *
 * @author kagho
 */
public class Menu {

    private EntityManager em = Factory.getEntityManager();
    PessoaDao pessoaDao = new PessoaDao(em);
    GeneroDao generoDao = new GeneroDao(em);
    GravadoraDao gravadoraDao = new GravadoraDao(em);
    CompositorDao compositorDao = new CompositorDao(em);
    MusicaDao musicaDao = new MusicaDao(em);
    SessaoDao sessaoDao = new SessaoDao(em);
    private Scanner sc = new Scanner(System.in);

    public void menu() {
        Scanner sc = new Scanner(System.in);
        int opcao = 0;
        do {
            System.out.println("Menu Principal");
            System.out.println("1 - Cadastro de Sessão");
            System.out.println("2 - Cadastro de Pessoa");
            System.out.println("3 - Cadastro de Musica");
            System.out.println("4 - Listar Ranking");

            opcao = sc.nextInt();
            switch (opcao) {
                case 1:
                    menuSessao();
                    break;
                case 2:
                    menuPessoa();
                    break;
                case 3:
                    menuMusica();
                    break;
                case 4:
                    listarRanking();
                    break;
                default:
                    menu();
            }
        } while (opcao > 3);
    }

    public void menuSessao() {
        Scanner sc = new Scanner(System.in);
        int opcao = 0;
        do {
            System.out.println("1 - Cadastrar Sessão");
            System.out.println("2 - Voltar");
            opcao = sc.nextInt();
            switch (opcao) {
                case 1:
                    cadastrarSessao();
                    break;
                case 2:
                    menu();
                default:
                    System.out.println("Opcao Invalida");
                    menuSessao();
            }
        } while (opcao > 2 || opcao < 0);

    }

    private void menuPessoa() {
        Scanner sc = new Scanner(System.in);
        int opcao = 0;
        do {
            System.out.println("1 - Cadastrar Pessoa");
            System.out.println("2 - Alterar Pessoa");
            System.out.println("3 - Excluir Pessoa");
            System.out.println("4 - Consultar pessoas cadastradas");
            System.out.println("5 - Voltar");
            opcao = sc.nextInt();
            switch (opcao) {
                case 1:
                    cadastrarPessoa();
                    break;
                case 2:
                    //pessoaAlterar();
                    break;
                case 3:
                    excluirPessoa();
                    break;
                case 4:
                    listarPessoas();
                    break;
                case 5:
                    menu();
                default:
                    System.out.println("Opcao Invalida");
                    menuPessoa();
            }
        } while (opcao > 5 || opcao < 0);
    }

    private void menuMusica() {
        Scanner sc = new Scanner(System.in);
        int opcao = 0;
        do {
            System.out.println("1 - Cadastrar Musica");
            System.out.println("2 - Alterar Musica");
            System.out.println("3 - Excluir Musica");
            System.out.println("4 - Consultar musicas cadastradas");
            System.out.println("5 - Cadastrar Genero");
            System.out.println("6 - Cadastrar Compositor");
            System.out.println("7 - Cadastrar Gravadora");
            System.out.println("8 - Voltar");
            opcao = sc.nextInt();
            switch (opcao) {
                case 1:
                    cadastrarMusica();
                    break;
                case 2:
                    alterarMusica();
                    break;
                case 3:
                    excluirPessoa();
                    break;
                case 4:
                    listarPessoas();
                    break;
                case 5:
                    cadastrarGenero();
                    break;
                case 6:
                    cadastrarCompositor();
                    break;
                case 7:
                    cadastrarGravadora();
                    break;
                case 8:
                    menu();
                default:
                    System.out.println("Opcao Invalida");
                    menuPessoa();
            }
        } while (opcao > 5 || opcao < 0);
    }

    public void cadastrarPessoa() {
        Scanner sc = new Scanner(System.in);

        EntityManager em = Factory.getEntityManager();
        PessoaDao pessoaDao = new PessoaDao(em);
        Pessoa pessoa = new Pessoa();

        pessoa.setId(null);
        System.out.println("Digite o nome");
        pessoa.setNome(sc.nextLine());
        sc.nextLine();
        System.out.println("Digite o CPF");
        pessoa.setCpf(sc.next());

        em.getTransaction().begin();
        pessoaDao.salvar(pessoa);
        em.getTransaction().commit();
        em.close();
        menuPessoa();
        sc.nextLine();
    }

    public void cadastrarSessao() {
//        SessaoDao sessaoDao = new SessaoDao(em);
//        PessoaDao pessoaDao = new PessoaDao(em);
//        MusicaDao musicaDao = new MusicaDao(em);
        List<Pessoa> listaPessoas = pessoaDao.listar();
        List<Musica> listaMusica = musicaDao.listar();
        Sessao sessao = new Sessao();
        
        sessao.setId(null);
        System.out.println("Ex: xx/xx/xxxx xx:xx");
        String str = sc.nextLine();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime dateTime = LocalDateTime.parse(str, formatter);

        sessao.setInicio(dateTime);
        System.out.println("Escolha a Pessoa: ");
        listaPessoas.stream().forEach(p -> {
            System.out.println(p.getId() + " - Nome: " + p.getNome() + " - CPF: " + p.getCpf());
        });
        Long opcao = sc.nextLong();
        sessao.setPessoa(pessoaDao.buscaPessoa(opcao));
        listaMusica.stream().forEach(m -> {
            System.out.println(m.getId() + " - Nome: " + m.getNome());
        });
        Long opMusica = sc.nextLong();
        sessao.setMusica(musicaDao.buscaMusica(opMusica));
        Double media=0.0, soma=0.0;
        for (int i = 1; i <= 2; i++) {
            System.out.println("Nota: "+i);
            Double vl = sc.nextDouble();
            soma += vl;
        }
        
        media = soma / 2;
        sessao.setNota(media);
        
        em.getTransaction().begin();
        sessaoDao.salvar(sessao);
        em.getTransaction().commit();
        em.close();
        sc.nextLine();
    }

    public void excluirPessoa() {
        Scanner sc = new Scanner(System.in);
        EntityManager em = Factory.getEntityManager();
        PessoaDao pessoaDao = new PessoaDao(em);
        System.out.println("Lista de Alunos");

        List<Pessoa> lista = new ArrayList<>();
        lista = pessoaDao.listar();

        lista.stream().forEach(a -> {
            System.out.println(a.getId() + " - " + a.getNome());
        });
        System.out.println("Qual id vai excluir?");
        Long op = sc.nextLong();
        Pessoa pessoa = pessoaDao.buscaPessoa(op);
        em.getTransaction().begin();
        pessoaDao.excluir(pessoa);
        em.getTransaction().commit();
        em.close();
        menuPessoa();
    }

    public void listarPessoas() {
        EntityManager em = Factory.getEntityManager();
        PessoaDao pessoaDao = new PessoaDao(em);
        System.out.println("\n");
        System.out.println("Lista de Pessoas");
        List<Pessoa> lista = pessoaDao.listar();
        lista.stream().forEach(a -> {
            System.out.println(a.getId() + " - " + a.getNome());
        });

        System.out.println("Fim lista\n");
        menuPessoa();

    }

    public void cadastrarMusica() {
        MusicaDao musicaDao = new MusicaDao(em);
        GeneroDao generoDao = new GeneroDao(em);
        GravadoraDao gravadoraDao = new GravadoraDao(em);
        CompositorDao compositorDao = new CompositorDao(em);
        List<Genero> listaGenero = generoDao.listar();
        List<Gravadora> listaGravadora = gravadoraDao.listar();
        List<Compositor> listaCompositor = compositorDao.listar();

        Musica musica = new Musica();
        musica.setId(null);
        System.out.println("Nome da Musica");
        musica.setNome(sc.nextLine());
        System.out.println("Escolha o genero:");
        listaGenero.stream().forEach(g -> {
            System.out.println(g.getId() + " - " + g.getNome());
        });
        Long opcao = sc.nextLong();
        musica.setGenero(generoDao.busca(opcao));
        System.out.println("Escolha a gravadora: ");
        listaGravadora.stream().forEach(g -> {
            System.out.println(g.getId() + " - " + g.getNome());
        });
        opcao = sc.nextLong();
        musica.setGravadora(gravadoraDao.busca(opcao));
        System.out.println("Escolha o compositor: ");
        listaCompositor.stream().forEach(c -> {
            System.out.println(c.getId() + " - " + c.getNome());
        });
        opcao = sc.nextLong();
        musica.setCompositor(compositorDao.busca(opcao));
        System.out.println("Digite a duracao em segundos: ");
        musica.setDuracao(sc.nextInt());
        System.out.println("Ano de lancamento");
        musica.setAnoLancamento(sc.nextInt());

        em.getTransaction().begin();
        musicaDao.salvar(musica);
        em.getTransaction().commit();

    }

    private void alterarMusica() {

        System.out.println("Id Musica para alterar");
        Long opc = sc.nextLong();
        Pessoa pessoa = pessoaDao.buscaPessoa(opc);

        pessoa.setCpf(sc.next());
        pessoa.setNome(sc.next());
        em.getTransaction().begin();
        pessoaDao.salvar(pessoa);
        em.getTransaction().commit();
        em.close();

    }

    private void cadastrarGenero() {
        System.out.println("Nome: ");
        Genero genero = new Genero();
        genero.setId(null);
        genero.setNome(sc.next());

        em.getTransaction().begin();
        generoDao.salvar(genero);
        em.getTransaction().commit();
    }

    private void cadastrarGravadora() {
        System.out.println("Nome: ");
        Gravadora gravadora = new Gravadora();
        gravadora.setId(null);
        gravadora.setNome(sc.nextLine());
        em.getTransaction().begin();
        gravadoraDao.salvar(gravadora);
        em.getTransaction().commit();

    }

    private void cadastrarCompositor() {
        System.out.println("Nome: ");
        Compositor compositor = new Compositor();
        compositor.setId(null);
        compositor.setNome(sc.nextLine());
        em.getTransaction().begin();
        compositorDao.salvar(compositor);
        em.getTransaction().commit();
    }
    
    private void listarRanking()
    {
        List<Sessao> sessoes = sessaoDao.listarRankDiario(LocalDateTime.now());
        //sessoes.stream().sorted(new RankingComparetor());
        Collections.sort(sessoes, new RankingComparetor());
        sessoes.stream().forEach(s -> {
            System.out.println("Nome "+s.getPessoa().getNome()+" - Nota: "+s.getNota());
        });
    }

}
