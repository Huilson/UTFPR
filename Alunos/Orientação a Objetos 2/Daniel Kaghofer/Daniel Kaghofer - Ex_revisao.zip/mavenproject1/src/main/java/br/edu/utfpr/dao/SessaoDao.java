/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.dao;

import br.edu.utfpr.model.Sessao;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author kagho
 */
public class SessaoDao {
    private EntityManager em;

    public SessaoDao(EntityManager em) {
        this.em = em;
    }
    
    public void salvar(Sessao sessao){
        this.em.persist(sessao);
    }
    
    public List<Sessao> listar()
    {
        String sql = "select p from Sessao p";
        return this.em.createQuery(sql, Sessao.class).getResultList();
    }
    
    public void excluir(Sessao sessao){
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
            this.em.merge(sessao);
            this.em.remove(sessao);
    }
    
    public Sessao buscaPessoa(Long id){
        return this.em.find(Sessao.class, id);        
    }
    
    public List<Sessao> listarRankDiario(LocalDateTime data)
    {
//        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy 00:00:00");
//        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy 23:59:59");
//        String data1 = data.format(formatter1);
//        String data2 = data.format(formatter2);
        
        LocalDateTime d1 = LocalDateTime.of(data.getYear(), data.getMonth(), data.getDayOfMonth(), 0, 0, 0);
        LocalDateTime d2 = LocalDateTime.of(data.getYear(), data.getMonth(), data.getDayOfMonth(), 23, 59, 59);
        
        String sql = "select s from Sessao s where s.inicio > :data1 and s.inicio < :data2";
        return this.em.createQuery(sql, Sessao.class).setParameter("data1", d1).setParameter("data2", d2).getResultList();
    }
}
