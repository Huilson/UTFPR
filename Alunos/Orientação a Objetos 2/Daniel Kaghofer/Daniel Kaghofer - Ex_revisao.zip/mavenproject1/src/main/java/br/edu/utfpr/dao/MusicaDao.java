/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.dao;

import br.edu.utfpr.model.Musica;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author kagho
 */
public class MusicaDao {
    private EntityManager em;

    public MusicaDao(EntityManager em) {
        this.em = em;
    }
    
    public void salvar(Musica musica){
        this.em.persist(musica);
    }
    
    public List<Musica> listar()
    {
        String sql = "select p from Musica p";
        return this.em.createQuery(sql, Musica.class).getResultList();
    }
    
    public void excluir(Musica musica){
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
            this.em.merge(musica);
            this.em.remove(musica);
    }
    
    public Musica buscaMusica(Long id){
        return this.em.find(Musica.class, id);        
    }
}
