/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.dao;

import br.edu.utfpr.model.Genero;
import java.util.List;
import javax.persistence.EntityManager;
 
/**
 *
 * @author kagho
 */
public class GeneroDao {
    private EntityManager em;

    public GeneroDao(EntityManager em) {
        this.em = em;
    }
    
    public void salvar(Genero genero) {
        this.em.persist(genero);
    }

    public List<Genero> listar() {
        String sql = "select g from Genero g";
        return this.em.createQuery(sql, Genero.class).getResultList();
    }

    public void excluir(Genero genero) {
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
        this.em.merge(genero);
        this.em.remove(genero);
    }

    public Genero busca(Long id) {
        return this.em.find(Genero.class, id);
    }
}
