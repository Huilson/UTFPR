/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.dao;

import br.edu.utfpr.model.Compositor;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author kagho
 */
public class CompositorDao {

    private EntityManager em;

    public CompositorDao(EntityManager em) {
        this.em = em;
    }

    public void salvar(Compositor compositor) {
        this.em.persist(compositor);
    }

    public List<Compositor> listar() {
        String sql = "select c from Compositor c";
        return this.em.createQuery(sql, Compositor.class).getResultList();
    }

    public void excluir(Compositor compositor) {
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
        this.em.merge(compositor);
        this.em.remove(compositor);
    }

    public Compositor busca(Long id) {
        return this.em.find(Compositor.class, id);
    }
}
