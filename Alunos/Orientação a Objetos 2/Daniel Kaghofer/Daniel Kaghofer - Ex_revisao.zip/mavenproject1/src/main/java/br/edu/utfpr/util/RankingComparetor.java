/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.util;

import br.edu.utfpr.model.Sessao;
import java.util.Comparator;

/**
 *
 * @author kagho
 */
public class RankingComparetor implements Comparator<Sessao> {

    @Override
    public int compare(Sessao y, Sessao x) {
        if(y.getNota() < x.getNota())
        {
            return 1;
        }
        if(y.getNota() > x.getNota())
        {
            return -1;
        }
        return 0;
    }
}
