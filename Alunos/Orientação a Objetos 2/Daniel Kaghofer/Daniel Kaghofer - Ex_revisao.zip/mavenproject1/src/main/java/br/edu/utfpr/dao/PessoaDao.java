/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.dao;

import br.edu.utfpr.model.Pessoa;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author kagho
 */
public class PessoaDao {
    private EntityManager em;

    public PessoaDao(EntityManager em) {
        this.em = em;
    }
    
    public void salvar(Pessoa pessoa){
        this.em.persist(pessoa);
    }
    
    public List<Pessoa> listar()
    {
        String sql = "select p from Pessoa p";
        return this.em.createQuery(sql, Pessoa.class).getResultList();
    }
    
    public void excluir(Pessoa pessoa){
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
            this.em.merge(pessoa);
            this.em.remove(pessoa);
    }
    
    public Pessoa buscaPessoa(Long id){
        return this.em.find(Pessoa.class, id);        
    }
}
