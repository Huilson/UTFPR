/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.dao;

import br.edu.utfpr.model.Gravadora;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author kagho
 */
public class GravadoraDao {

    private EntityManager em;

    public GravadoraDao(EntityManager em) {
        this.em = em;
    }

    public void salvar(Gravadora gravadora) {
        this.em.persist(gravadora);
    }

    public List<Gravadora> listar() {
        String sql = "select g from Gravadora g";
        return this.em.createQuery(sql, Gravadora.class).getResultList();
    }

    public void excluir(Gravadora gravadora) {
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
        this.em.merge(gravadora);
        this.em.remove(gravadora);
    }

    public Gravadora busca(Long id) {
        return this.em.find(Gravadora.class, id);
    }
}
