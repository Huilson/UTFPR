package utfpr.mongocomjava;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;

//Quem assitiu o show do Gustavo Lima terá -1 ponto na média
public class MongoComJava {

    public static void main(String[] args) {
        //Conectar com o MongoDB
        MongoClient conecta = new MongoClient();
        
        //Conectar com o Database
        MongoDatabase db = conecta.getDatabase("aluno");
        
        //Conectar na Coleção
        MongoCollection<Document> alunos = db.getCollection("alunos");
        
        //Consultar única, sem filtros
        Document aluno = alunos.find().first();
        System.out.print(aluno);


        //Atualizar Documento com Filtro
        alunos.updateOne(Filters.eq("nome","Maria da Fonseca"), 
                new Document("$set", new Document("discplinas","Aplicações Distribuídas")));
        
        //Excluir Documento com Filtro
        alunos.deleteOne(Filters.eq("_id",1));
        
        //Consutlar com Filtro
        MongoCursor<Document> cursor = alunos
                .find(Filters.eq("discplinas","Orientação a Objetos 2")).iterator();
        while(cursor.hasNext()){
            System.out.println(cursor.next());        
        }        
        
        //Criar um novo documento
        Document novoAluno = new Document("_id",2)
                .append("nome", "Maria da Fonseca")
                .append("data_nascimento", new Date(2010, 11, 10))
                .append("idade", 21)
                .append("discplinas", "Orientação a Objetos 2")
                .append("notas", Arrays.asList(9.2, 8.1,9.6))
                .append("horas complementares", Arrays.asList(
                        new Document()
                                .append("nome", "estágio")
                                .append("carga horária", 400)
                                .append("categoria", "A"),
                        new Document()
                                .append("nome", "semana acadêmica")
                                .append("carga horária", 20)
                                .append("categoria", "C"),
                        new Document()
                                .append("nome", "serviço comunitário")
                                .append("carga horária", 100)
                                .append("categoria", "B")
                )//fim Arrays.asList
                );//fim append do documento principal
        
        //Inserir um Documento Novo
        alunos.insertOne(novoAluno);
        
    }
}
