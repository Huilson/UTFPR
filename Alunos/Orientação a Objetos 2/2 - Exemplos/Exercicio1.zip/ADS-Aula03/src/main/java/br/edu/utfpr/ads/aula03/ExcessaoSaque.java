package br.edu.utfpr.ads.aula03;
public class ExcessaoSaque extends RuntimeException{
    public ExcessaoSaque(String msg){
        super(msg);
    }
}
