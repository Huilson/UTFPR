package br.edu.utfpr.ads.aula03;
public class CaixaEletronic {
    //atributo
    private double moedaInterna;
    private double limitSake;
    
    //get & set
    public double getMoeda() {
        return moedaInterna;
    }

    public void setMoeda(double cash) {
        this.moedaInterna = cash;
    }

    public double getLimitSake() {
        return limitSake;
    }

    public void setLimitSake(double limitSake) {
        this.limitSake = limitSake;
    }
    
    //construct

    public CaixaEletronic(double cash, double limitSake) {
        this.moedaInterna = cash;
        this.limitSake = limitSake;
    }
    
}
