package br.edu.utfpr.ads.aula03;

public class ContaPessoa {
    //atributos
    private int numConta;
    private String nome;
    private double credito;
    
    //get & set
    public int getNumConta() {
        return numConta;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getCredito() {
        return credito;
    }

    public void setCredito(double credito) {
        this.credito = credito;
    }
    
    //construct
    public ContaPessoa(int numConta, String nome, double credito){
        this.numConta = numConta;
        this.nome = nome;
        this.credito = credito;        
    }

    //metodos
    @Override
    public String toString() {
        return "ContaPessoa{" + "numConta=" + numConta + ", nome=" + nome + ", credito=" + credito + '}';
    }
    
}
