package br.edu.utfpr.ads.aula03;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class ADSAula03 {

    public static void main(String[] args) {
    Menu menu = new Menu();
    menu.menuCaixa();
    }
}