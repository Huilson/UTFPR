package br.edu.utfpr.ads.aula03;
public class Transation {
    
    double saqueConta(int numConta, double dindin, double credito) {
        if(dindin <= credito){
          credito -= dindin;
          return credito;  
        }else{
          //System.out.println("Credito insuficiente");
          //return credito;
          throw new ExcessaoSaque("Credito insuficiente");
        }  
    }
    
    double saqueCaixa(int numConta, double credito, double dindin, double moeda, double limit) {
        if(dindin <= moeda && dindin <= limit){
          moeda -= dindin;
          return moeda;
        }else{
          //System.out.println("Limite exedido ou nao a moeda disponiveis para esse saque");
          //return moeda;
          
          throw new ExcessaoSaque("Limite exedido ou nao a moeda disponiveis para esse saque");
        }  
    }
    
    double deposito(int numConta, double dindin, double credito){
        System.out.println("Credito novo: ");
        System.out.println(credito+dindin);
        return (credito+dindin);
    }

    double depositoCaixa(double dindin, double moeda){
        return (moeda+dindin);
    }
}