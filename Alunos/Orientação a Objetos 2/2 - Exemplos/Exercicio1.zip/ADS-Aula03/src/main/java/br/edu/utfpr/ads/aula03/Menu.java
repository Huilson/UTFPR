package br.edu.utfpr.ads.aula03;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {
    ContaPessoa conta = new ContaPessoa(1, "Fulano", 750.00);
    
    Scanner scan = new Scanner (System.in);
    Transation t = new Transation();
    CaixaEletronic ce = new CaixaEletronic(2000.00, 500.00);
    double dindin;
    double result;
    
    public void menuCaixa(){
        int op=0;
        do{
            System.out.println("Escolha uma opção: ");
            System.out.println("1 - Cria conta");
            System.out.println("2 - Faz deposito");
            System.out.println("3 - Faz saque");
            System.out.println("4 - Faz consulta");
            System.out.println("5 - Sair");
            op = scan.nextInt();
            switch(op){
                case 1: System.out.println("Cria conta");
                this.criaConta();
                break;
                case 2: System.out.println("Faz deposito");
                this.fazDepo();
                break;
                case 3: System.out.println("Faz saque");
                this.fazSake();
                break;
                case 4: System.out.println("Faz consulta");
                this.consultaConta();
                break;
                case 5: System.out.println("Sair");
                break;
                default: System.out.println("Erro, tente novamente");
                break;
            }
        }while(op != 5);
        scan.close();
    }
    
    public void criaConta(){
        ArrayList contas = new ArrayList();        
        ContaPessoa conta = new ContaPessoa(1, "Huilson", 500.00);
        contas.add(conta);
        System.out.println(conta.toString());
    }
        
    public void fazDepo(){
        System.out.println("\nQuanto deseja depositar? ");
        dindin = scan.nextDouble();
        conta.setCredito(t.deposito(conta.getNumConta(), dindin, conta.getCredito()));
        ce.setMoeda(t.depositoCaixa(dindin, ce.getMoeda()));
        System.out.println("\nSeu novo saldo eh: "+conta.getCredito());
        System.out.println("\nSeu novo saldo eh: "+ce.getMoeda());        
    }
        
    public void fazSake(){
        System.out.println("\nQuanto deseja sacar?" );
        dindin = scan.nextDouble();
        
        try{
            System.out.println("Tirando da sua conta");
            result = t.saqueConta(conta.getNumConta(), dindin, conta.getCredito());
            conta.setCredito(result);
            System.out.println("Tirando do caixa");
            result = t.saqueCaixa(conta.getNumConta(), conta.getCredito(), dindin, ce.getMoeda(), ce.getLimitSake());
            ce.setMoeda(result);
        }catch(ExcessaoSaque e){
            conta.setCredito(result+dindin);
            System.out.print(e.getMessage());
        }        
        System.out.println("\nSeu novo saldo eh: "+conta.getCredito());
        System.out.println("\nSeu novo saldo eh: "+ce.getMoeda());
    }
    
    public void consultaConta(){
        System.out.println("\nSeu nome eh: "+conta.getNome());
        System.out.println("\nSeu numero da conta eh: "+conta.getNumConta());
        System.out.println("\nSeu saldo eh: "+conta.getCredito());
        
    }
}