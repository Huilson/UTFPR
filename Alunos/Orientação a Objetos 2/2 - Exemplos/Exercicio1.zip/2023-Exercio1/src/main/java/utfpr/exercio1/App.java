package utfpr.exercio1;

import java.sql.SQLException;

public class App {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        //Menu menu = new Menu();
        //menu.menu();
        Coneccao conecta = new Coneccao();
        conecta.conecta();
    }
}
