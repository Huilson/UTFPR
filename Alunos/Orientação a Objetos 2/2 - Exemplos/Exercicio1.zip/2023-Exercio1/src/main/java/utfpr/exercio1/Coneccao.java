package utfpr.exercio1;

import java.sql.*;

public class Coneccao {

    public void conecta() throws SQLException, ClassNotFoundException {
        String driverClassName = "jdbc:postgresql://localhost:5432/2023-AulaJDBC";
        String url = "org.postgresql.Driver ";
        String username = "postgres";
        String password = "5432";
        String query = "insert into pessoa values ('111.111.111-11', 'Adão')";

        // Carregar Driver 
        Class.forName(driverClassName);

        // Abrir Conexão
        Connection con = DriverManager.getConnection(url, username, password);

        // Obter um statement 
        Statement st = con.createStatement();

        // Executar query 
        int count = st.executeUpdate(query);
        System.out.println("Numero de linha criados por essa query = " + count);

        // Fechar conexão 
        con.close();
    }
} // fim da classe

