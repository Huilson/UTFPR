package com.turma.salaDeAula.repository;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.turma.salaDeAula.codec.CodecAluno;
import com.turma.salaDeAula.model.Aluno;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Repository;

@Repository
public class AlunoRepository {

    public MongoDatabase conecta(){
                //Instânciado o CODEC
        Codec<Document> codec = MongoClient.getDefaultCodecRegistry()
                .get(Document.class);
        
        //Passar para a classe de codificação qual será o codec usado
        CodecAluno alunoCodec = new CodecAluno(codec);
        
        //Regristo do codec usado no MongoClient
        CodecRegistry registro = CodecRegistries.fromRegistries(
                MongoClient.getDefaultCodecRegistry(), 
                CodecRegistries.fromCodecs(alunoCodec)
        );
        
        //Fazer o build
        MongoClientOptions op = MongoClientOptions.builder()
                .codecRegistry(registro).build();
        
        MongoClient cliente = new MongoClient("localhost:27017", op);
        MongoDatabase db = cliente.getDatabase("Aula");
        return db;
    }
    
    public void salvar(Aluno aluno) {
        MongoDatabase db = conecta();
        MongoCollection<Aluno> alunos = db.getCollection("alunos", Aluno.class);
        //Se eu já tiver um aluno simplesmente atualizo ele
        if(aluno.getId() == null){
            alunos.insertOne(aluno);
        }else{
            alunos.updateOne(Filters.eq("_id",aluno.getId()), new Document("$set",aluno));
        }
        
        //cliente.close();
    }
    
    public List<Aluno> listar (){
        MongoDatabase db = conecta();
        MongoCollection<Aluno> alunos = db.getCollection("alunos", Aluno.class);
        MongoCursor<Aluno> resultado = alunos.find().iterator();
        
        //Lista de Iteração
        List<Aluno> alunoLista = new ArrayList<>();
        
        while(resultado.hasNext()){
            Aluno aluno = resultado.next();
            alunoLista.add(aluno);
        }
        
        return alunoLista;
    }
    
    public Aluno obterId(String id){
        MongoDatabase db = conecta();
        MongoCollection<Aluno> alunos = db.getCollection("alunos", Aluno.class);
        Aluno aluno = alunos.find(Filters.eq("_id", new ObjectId(id))).first();
        return aluno;
    }
}


