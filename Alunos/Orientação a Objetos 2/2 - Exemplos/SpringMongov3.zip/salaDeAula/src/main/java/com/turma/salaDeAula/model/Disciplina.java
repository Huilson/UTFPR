package com.turma.salaDeAula.model;

import org.bson.types.ObjectId;

public class Disciplina {
    private ObjectId id;
    private String nome;
    private String professor;
    private int semestre;
    private int n_alunos;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public int getN_alunos() {
        return n_alunos;
    }

    public void setN_alunos(int n_alunos) {
        this.n_alunos = n_alunos;
    }

    public Disciplina(String nome, String professor, int semestre) {
        this.nome = nome;
        this.professor = professor;
        this.semestre = semestre;
    }

    public Disciplina() {
    }  
}
