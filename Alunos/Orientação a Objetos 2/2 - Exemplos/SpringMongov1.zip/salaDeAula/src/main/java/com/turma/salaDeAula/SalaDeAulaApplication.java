package com.turma.salaDeAula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalaDeAulaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalaDeAulaApplication.class, args);
	}

}
