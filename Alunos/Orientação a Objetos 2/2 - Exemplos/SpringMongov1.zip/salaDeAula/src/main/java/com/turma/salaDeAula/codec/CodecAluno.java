package com.turma.salaDeAula.codec;

import com.turma.salaDeAula.model.Aluno;
import java.util.Date;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecAluno implements CollectibleCodec<Aluno>{
    //Atributo para criação de documento
    private Codec<Document> codec;
    
    //Construtor
    public CodecAluno(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Aluno generateIdIfAbsentFromDocument(Aluno aluno) {
        return documentHasId(aluno) ? aluno.criarId() : aluno;
    }

    @Override
    public boolean documentHasId(Aluno aluno) {
        //esse método só verifica se o objeto chamado tem ID
        return aluno.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Aluno aluno) {
        //Verifica se o ID foi criado
        if(!documentHasId(aluno)){
            throw new IllegalStateException("Esse documento não tem um Id");
        }else{
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(aluno.getId().toHexString());
        }
    }

    @Override
    public void encode(BsonWriter writer, Aluno aluno, EncoderContext ec) {
        /*Esse método pega um OBJETO e o envia para o MONGODB, um bom exemplo
        seria dizer que pro MONGODB qual a receita ele deve seguir para poder
        salvar o OBJETO ALUNO em sua base de dados*/
        ObjectId id = aluno.getId();
        String nome = aluno.getNome();
        Date idade = aluno.getIdade();
        String curso = aluno.getCurso();
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("idade",idade);
        doc.put("curso", curso);
        
        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Class<Aluno> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Aluno.class;
    }

    @Override
    public Aluno decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Aluno aluno = new Aluno();
        aluno.setId(doc.getObjectId("_id"));
        aluno.setNome(doc.getString("nome"));
        aluno.setIdade(doc.getDate("idade"));
        aluno.setCurso(doc.getString("curso"));
        
        return aluno;
    }
    
}
