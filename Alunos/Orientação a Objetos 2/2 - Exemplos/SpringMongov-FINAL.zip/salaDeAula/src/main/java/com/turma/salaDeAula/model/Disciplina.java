package com.turma.salaDeAula.model;

import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

public class Disciplina {
    private ObjectId id;
    private String nome;
    private String professor;
    private int semestre;
    private List<Double> notas;
    private int n_alunos;

    public List<Double> getNotas() {
        if(notas == null)
            notas = new ArrayList<Double>();
        return notas;
    }

    public void setNotas(List<Double> notas) {
        this.notas = notas;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public int getN_alunos() {
        return n_alunos;
    }

    public void setN_alunos(int n_alunos) {
        this.n_alunos = n_alunos;
    }

    //DEFAULT
    public Disciplina() {
    }
    
    //USO NO CODEC ALUNO
    public Disciplina(String nome, String professor, int semestre, List<Double> notas) {
        this.nome = nome;
        this.professor = professor;
        this.semestre = semestre;
        this.notas = notas;
    }    

    //USO NO CODEC SALA
    public Disciplina(String nome, String professor, int semestre, int n_alunos) {
        this.nome = nome;
        this.professor = professor;
        this.semestre = semestre;
        this.n_alunos = n_alunos;
    }
}
