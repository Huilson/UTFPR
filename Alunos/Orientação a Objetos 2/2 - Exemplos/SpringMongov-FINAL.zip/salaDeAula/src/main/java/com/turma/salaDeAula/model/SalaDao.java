package com.turma.salaDeAula.model;

import java.util.List;

public class SalaDao {
    List<String> nome;

    public List<String> getNome() {
        return nome;
    }

    public void setNome(List<String> nome) {
        this.nome = nome;
    }
    
    
}
