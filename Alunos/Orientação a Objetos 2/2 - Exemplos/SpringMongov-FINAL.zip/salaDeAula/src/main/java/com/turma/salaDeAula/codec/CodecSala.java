package com.turma.salaDeAula.codec;

import com.turma.salaDeAula.model.Aluno;
import com.turma.salaDeAula.model.Disciplina;
import com.turma.salaDeAula.model.Sala;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class CodecSala implements CollectibleCodec<Sala> {
//Atributo para criação de documento

    private Codec<Document> codec;

    //Construtor
    public CodecSala(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Sala generateIdIfAbsentFromDocument(Sala sala) {
        return documentHasId(sala) ? sala.criarId() : sala;
    }

    @Override
    public boolean documentHasId(Sala sala) {
        //esse método só verifica se o objeto chamado tem ID
        return sala.getId() == null;
    }

    @Override
    public BsonValue getDocumentId(Sala sala) {
        //Verifica se o ID foi criado
        if (!documentHasId(sala)) {
            throw new IllegalStateException("Esse documento não tem um Id");
        } else {
            //Para que o ID possa ser lido é preciso transformar ele
            //em uma base hexadecimal
            return new BsonString(sala.getId().toHexString());
        }
    }

    @Override
    public Class<Sala> getEncoderClass() {
        //É preciso informar a classe a ser interpretada
        return Sala.class;
    }

    @Override
    public void encode(BsonWriter writer, Sala sala, EncoderContext ec) {
        ObjectId id = sala.getId();
        String nome = sala.getNome();
        String disciplina = sala.getDisciplina();
        
        
        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome",nome);
        doc.put("disciplina",disciplina);
                
        //essa função é quem traduz o que escrevemos no método
        codec.encode(writer, doc, ec);
    }

    @Override
    public Sala decode(BsonReader reader, DecoderContext dc) {
        /*Aqui fizemos o processo inverso do decode, vamos dizer para o SPRING
        como o objeto será retornado*/
        Document doc = codec.decode(reader, dc);
        Sala sala = new Sala();
        sala.setId(doc.getObjectId("_id"));
        sala.setNome(doc.getString("nome"));
        sala.setDisciplina(doc.getString("disciplina"));
        

        return sala;
    }
}
