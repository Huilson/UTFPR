package com.turma.salaDeAula.model;

public class Nota {
    private Double valor;
    private String nome;

    //CONSTRUTORES
    public Nota(Double valor, String nome) {
        this.valor = valor;
        this.nome = nome;
    }
        public Nota() {
    }

    //GETTER E SETTER
    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
