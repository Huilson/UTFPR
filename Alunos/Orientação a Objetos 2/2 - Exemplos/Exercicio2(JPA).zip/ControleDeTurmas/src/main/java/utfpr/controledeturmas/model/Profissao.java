package utfpr.controledeturmas.model;

public enum Profissao {
    MEDICO,
    PROFESSOR,
    DESENVOLVEDOR;    
}
