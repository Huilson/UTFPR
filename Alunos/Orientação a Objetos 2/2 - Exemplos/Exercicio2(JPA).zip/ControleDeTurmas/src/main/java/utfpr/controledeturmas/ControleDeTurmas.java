package utfpr.controledeturmas;

import utfpr.controledeturmas.model.Pessoa;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import utfpr.controledeturmas.dao.PessoaDao;
import utfpr.controledeturmas.model.Profissao;
import utfpr.controledeturmas.util.Factory;

public class ControleDeTurmas {

    public static void main(String[] args) {
        EntityManager em = Factory.getEntityManager();
        PessoaDao dao = new PessoaDao(em);
        
        
        Pessoa pessoa = new Pessoa("fulana", "16546548", 22, "fulana@utfpr.edu.br", "Pato Branco", "Avenida Brasil", 11);        
        pessoa.setProfissao(Profissao.PROFESSOR);
        dao.conecta();
        
        //Exemplo de consulta
        //Pessoa p = dao.consultarId(17);
        
        //Exemplo de remover
        //dao.excluir(p);
        
        //Exemplo de atualizar
        //dao.atualizar(p);
        
        //Sempre será preciso salvar as aterações antes de encerrar
        //a conecção com o banco, a menos que seja para excluir
        dao.salvar(pessoa);
        
        dao.encerrar();
        System.out.print("Ok!");
    }
}