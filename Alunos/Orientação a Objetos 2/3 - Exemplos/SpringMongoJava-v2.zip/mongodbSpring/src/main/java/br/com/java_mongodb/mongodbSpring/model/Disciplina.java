package br.com.java_mongodb.mongodbSpring.model;

import java.util.List;

public class Disciplina {
    private String nome;
    private String professor;
    private int semestre;
    private List<Double> notas;

    public Disciplina(String nome, String professor, int semestre) {
        this.nome = nome;
        this.professor = professor;
        this.semestre = semestre;
    }

    public Disciplina() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public List<Double> getNotas() {
        return notas;
    }

    public void setNotas(List<Double> notas) {
        this.notas = notas;
    }
    
    
}