package utfpr.javamongo;

import org.bson.types.ObjectId;

public class Disciplina {
    private ObjectId _id;
    private String nome;
    private String professor;

    @Override
    public String toString() {
        return "Disciplina{" + "id=" + _id + ", nome=" + nome + ", professor=" + professor + '}';
    }

    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId id) {
        this._id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }
}
