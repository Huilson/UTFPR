package utfpr.javamongo;

import com.google.gson.Gson;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;

public class App {

    public static void main(String[] args) {
        //conectar com o mongodb
        MongoClient client = new MongoClient();

        //conectar a database
        MongoDatabase db = client.getDatabase("Aula");

        //conectar a coleção
        MongoCollection<Document> alunos = db.getCollection("alunos");
        MongoCollection<Document> disciplinas = db.getCollection("disciplinas");
        /*
        //CRUD
        
        //inserir
        Document novaDisciplina = new Document("nome","Dispositivos Móveis")
                .append("professor", "Huilson José Lorenzi");        
        
        disciplinas.insertOne(novaDisciplina);
        
        //consulta simples
        Document disciplina1 = disciplinas.find().first();
        System.out.println("Primeiro documento da coleção DISCIPLINA: "+disciplina1);
        
        //consulta complexa
        MongoCursor<Document> resultados = disciplinas.find(Filters.eq("professor","Huilson J. Lorenzi")).iterator();
        int i = 1;
        while(resultados.hasNext()){
            
            System.out.println("Resultado "+i+": "+resultados.next());
            i++;
        }
        
        //atualizar
        disciplinas.updateOne(Filters.eq("nome", "Aplicação Distribuídas"),
                new Document("$set", new Document ("nome", "Aplicação Distribuídas")
                        .append("professor", "Fábio Favarim")));
        
        //excluir
        disciplinas.deleteOne(Filters.eq("nome","Dispositivos Móveis1"));*/

        Disciplina disc = new Disciplina();

        Document aux = disciplinas.find().first();
        Gson gson = new Gson();
        disc = gson.fromJson(aux.toJson(), Disciplina.class);
        System.out.println("Minha disciplina: " + disc.toString());

        Document novoAluno = new Document("nome", "Felipe da Silvasauro")
                .append("semestre", 1)
                .append("media", 9.2)
                .append("id_disciplina", disc.getId())
                .append("disciplina", Arrays.asList
                        (new Document()
                         //.append("chave_disciplina", 1234)       
                        .append("nome", "Orientação a Objetos")
                        .append("professor", "Huilson Lorenzi"),
                        new Document()
                        .append("nome", "Sistemas Distribuídos")
                        .append("professor", "Huilson Lorenzi")));              
        alunos.insertOne(novoAluno);

        //encerra a coneção
        client.close();
    }
}
