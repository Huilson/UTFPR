package br.com.java_mongodb.mongodbSpring.model;

public class Disciplina {
    private String nome;
    private String professor;
    private int semestre;
}
