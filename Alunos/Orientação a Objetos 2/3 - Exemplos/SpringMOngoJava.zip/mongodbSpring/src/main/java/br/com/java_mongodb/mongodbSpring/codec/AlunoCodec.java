package br.com.java_mongodb.mongodbSpring.codec;

import br.com.java_mongodb.mongodbSpring.model.Aluno;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import org.bson.BsonReader;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.CollectibleCodec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.types.ObjectId;

public class AlunoCodec implements CollectibleCodec<Aluno> {

    private Codec<Document> codec;

    public AlunoCodec(Codec<Document> codec) {
        this.codec = codec;
    }

    @Override
    public Class<Aluno> getEncoderClass() {
        return Aluno.class;
    }//Esse metodo diz qual classe será codificada

    @Override
    public boolean documentHasId(Aluno aluno) {
        return aluno.getId() == null;
    }//Esse metodo só verifica se o objeto chamado tem ID

    @Override
    public BsonValue getDocumentId(Aluno aluno) {
        if (!documentHasId(aluno))//Verifica se o ID foi criado
        {
            throw new IllegalStateException("Esse documento não tem ID");
        } else//Para que o ID possa ser lido é preciso converter para a base hexadecimal
        {
            return new BsonString(aluno.getId().toHexString());
        }
    }

    @Override
    public Aluno generateIdIfAbsentFromDocument(Aluno aluno) {
        return documentHasId(aluno) ? aluno.criaId() : aluno;
    }

    @Override
    public void encode(BsonWriter writer, Aluno aluno, EncoderContext ec) {
        /*Esse metodo pega um Objeto e o envia para o Mongodb, um bom exemplo
        seria dizer para o mongodb qual a receita ele deve seguir para poder 
        salvar o Objeto ALUNO em sua base de dados*/
        ObjectId id = aluno.getId();
        String nome = aluno.getNome();
        LocalDate idade = aluno.getIdade();
        String curso = aluno.getCurso();

        Document doc = new Document();
        doc.put("_id", id);
        doc.put("nome", nome);
        doc.put("idade", idade);
        doc.put("curso", curso);

        codec.encode(writer, doc, ec);
        //Essa função é quem traduz o que escrevemos na VIEW
    }

    @Override
    public Aluno decode(BsonReader reader, DecoderContext dc) {
        Document doc = codec.decode(reader, dc);
        Aluno aluno = new Aluno();
        aluno.setId(doc.getObjectId("_id"));
        aluno.setNome(doc.getString("nome"));
        aluno.setCurso(doc.getString("curso"));
        LocalDate dataNova = convertToLocalDateViaInstant(doc.getDate("idade"));
        aluno.setIdade(dataNova);
        
        return aluno;
    }

    public LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
        return dateToConvert.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }
}
