package br.com.java_mongodb.mongodbSpring.model;

import java.time.LocalDate;
import java.util.List;
import org.bson.types.ObjectId;

public class Aluno {

    private ObjectId id;
    private String nome;
    private LocalDate idade;
    private String curso;
    private List<Nota> notas;
    private List<Disciplina> disciplinas;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getIdade() {
        return idade;
    }

    public void setIdade(LocalDate idade) {
        this.idade = idade;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public List<Nota> getNotas() {
        return notas;
    }

    public void setNotas(List<Nota> notas) {
        this.notas = notas;
    }

    public List<Disciplina> getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(List<Disciplina> disciplinas) {
        this.disciplinas = disciplinas;
    }

    public Aluno criaId() {
        setId(new ObjectId());
        return this;
    }
}