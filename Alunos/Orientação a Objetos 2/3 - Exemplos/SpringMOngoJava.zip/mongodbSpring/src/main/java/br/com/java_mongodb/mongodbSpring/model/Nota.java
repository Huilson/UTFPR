package br.com.java_mongodb.mongodbSpring.model;
public class Nota {
    private double valor;
}
