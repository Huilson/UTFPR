package utfpr.aulajpa;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.aulajpa.dao.AlunoDAO;
import utfpr.aulajpa.dao.DisciplinaDAO;
import utfpr.aulajpa.model.Aluno;
import utfpr.aulajpa.model.Disciplina;
import utfpr.aulajpa.util.Factory;

public class App {

    public static void main(String[] args) {
       
        //Como possuo um factory posso instanciar quantos managers forem precisos
        EntityManager em = Factory.getEntityManager();
        
        AlunoDAO alunoDAO = new AlunoDAO(em);
        DisciplinaDAO disDAO = new DisciplinaDAO(em);
        
        //Instancia um objeto
        Disciplina dis = new Disciplina("Sistemas Distribuídos", 12);
        Aluno aluno = new Aluno("José", 3, 4.9, dis);
        
        //Estabelece conecção com o banco
        em.getTransaction().begin();
        
        //Instancia para managed
        alunoDAO.salvar(aluno);
        
        //Instancia para removed
        alunoDAO.excluir(aluno);
        
        //Instancia para merge
        alunoDAO.atualizar(aluno);
        
        //salva as alterações
        em.getTransaction().commit();
        
        List<Aluno> rs = alunoDAO.buscaDisciplina("Sistemas Distribuídos");
        rs.forEach(a -> System.out.println(a.getNome()+" com o RA: " +a.getRA()));        
        
        em.close();
    }
}
