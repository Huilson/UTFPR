package utfpr.aulajpa.dao;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.aulajpa.model.Aluno;
import utfpr.aulajpa.model.Disciplina;

public class AlunoDAO {
    /*Instancio uma injeção de dependência*/
    private EntityManager em;
    
    /*Como só queremos usar o EM, não precisa inicia ou fecha a coneção*/
    public AlunoDAO(EntityManager em){
        this.em = em;
    }
    
    /*Métodos relacionados ao CRUD*/
    public void salvar(Aluno aluno){
        this.em.persist(aluno);
    }
    
    public void excluir(Aluno aluno){
        /*preciso garantir que o objeto excluido esteja sendo gerenciando
        pela JPA*/
            this.em.merge(aluno);
            this.em.remove(aluno);
    }
    
    public Aluno buscaAluno(Long id){
        return this.em.find(Aluno.class, id);        
    }
    
    public List<Aluno> buscaPorNome(String nome){
        String jpql = "SELECT aluno FROM Aluno aluno WHERE aluno.nome =:nome";
        return em.createQuery(jpql, Aluno.class).setParameter("nome",nome).getResultList();
    }
}
