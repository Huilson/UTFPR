package utfpr.aulajpa;

import java.util.List;
import javax.persistence.EntityManager;
import utfpr.aulajpa.dao.AlunoDAO;
import utfpr.aulajpa.dao.DisciplinaDAO;
import utfpr.aulajpa.model.Aluno;
import utfpr.aulajpa.model.Disciplina;
import utfpr.aulajpa.util.Factory;

public class App {

    public static void main(String[] args) {
       
        EntityManager em = Factory.getEntityManager();
        AlunoDAO alunoDAO = new AlunoDAO(em);
        DisciplinaDAO disDAO = new DisciplinaDAO(em);
        
        em.getTransaction().begin();
        //disDAO.salvar(dis);
        //alunoDAO.salvar(aluno);
        
        List<Aluno> rs = alunoDAO.buscaPorNome("Pedro");
        rs.forEach(a -> System.out.println(a.getMedia()));        
        
        //em.getTransaction().commit();
        em.close();
    }
}
