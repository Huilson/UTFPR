package utfpr.javamongo;

import com.google.gson.Gson;
import com.mongodb.BasicDBList;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import org.bson.Document;
import org.bson.types.ObjectId;

public class App {

    public static void main(String[] args) {
        //conectar com o mongodb
        MongoClient client = new MongoClient();

        //conectar a database
        MongoDatabase db = client.getDatabase("Aula");

        //conectar a coleção
        MongoCollection<Document> alunos = db.getCollection("alunos");
        MongoCollection<Document> disciplinas = db.getCollection("disciplinas");

        //CRUD
        //inserir
        /*Document novaDisciplina = new Document("nome","Dispositivos Móveis")
                .append("professor", "Huilson José Lorenzi");        
        
        disciplinas.insertOne(novaDisciplina);
        
        //consulta simples
        Document disciplina1 = disciplinas.find().first();
        System.out.println("Primeiro documento da coleção DISCIPLINA: "+disciplina1);
        
        //consulta complexa
        MongoCursor<Document> resultados = disciplinas.find(Filters.eq("professor","Huilson J. Lorenzi")).iterator();
        int i = 1;
        while(resultados.hasNext()){
            
            System.out.println("Resultado "+i+": "+resultados.next());
            i++;
        }
        
        //atualizar
        disciplinas.updateOne(Filters.eq("nome", "Aplicação Distribuídas"),
                new Document("$set", new Document ("nome", "Aplicação Distribuídas")
                        .append("professor", "Fábio Favarim")));
        
        //excluir
        disciplinas.deleteOne(Filters.eq("nome","Dispositivos Móveis1"));*/
        Disciplina disc = new Disciplina();

        MongoCursor<Document> doc = disciplinas.find(Filters.eq("nome", "Dispositivos Móveis")).iterator();
        System.out.println("-------" + doc.toString());
        int i = 1;
        Document aux = null;
        while (doc.hasNext()) {
            //System.out.println("Resultado " + i + ": " + doc.next());
            aux = doc.next();
            i++;
        }
        disc.setId((ObjectId) aux.get("_id"));
        disc.setNome((String) aux.get("nome"));
        System.out.println("Minha disciplina: " + disc.getNome());

        System.out.println("Minha disciplina: " + disc.toString());
        /*
        int nota1 = 2;
        int nota2 = 7;
        int nota3 = 4;

        BasicDBList notasList = new BasicDBList();
        notasList.add(9.2);
        notasList.add(4.0);
        notasList.add(1.3);

        //inserir um array de documento dentro de um documento
        Document novoAluno = new Document("nome", "Meu Dispositivo Moveis")
                .append("semestre", 1)
                .append("media", 2.2)
                .append("id_disciplina", disc.getId())
                .append("notas", Arrays.asList(nota1, nota2, nota3));
        alunos.insertOne(novoAluno);*/

        //encerra a coneção
        client.close();
    }
}
