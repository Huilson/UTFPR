package utfpr.javamongo;

import org.bson.types.ObjectId;

public class Aluno {
    private ObjectId _id;
    private String nome;
    private int semestre;
    private double media;
    private ObjectId id_disciplina;
    private int[] notas;

    @Override
    public String toString() {
        return "Aluno{" + "_id=" + _id + ", nome=" + nome + ", semestre=" + semestre + ", media=" + media + ", id_disciplina=" + id_disciplina + ", notas=" + notas + '}';
    }
    
    public int[] getNotas() {
        return notas;
    }

    public void setNotas(int[] notas) {
        this.notas = notas;
    }
    
    public ObjectId getId() {
        return _id;
    }

    public void setId(ObjectId _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    public ObjectId getId_disciplina() {
        return id_disciplina;
    }

    public void setId_disciplina(ObjectId id_disciplina) {
        this.id_disciplina = id_disciplina;
    }
    
}
