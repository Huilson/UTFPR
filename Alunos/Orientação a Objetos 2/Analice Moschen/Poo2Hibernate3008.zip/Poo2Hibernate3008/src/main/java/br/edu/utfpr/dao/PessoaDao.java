package br.edu.utfpr.dao;

import br.edu.utfpr.poo2hibernate3008.Conta;
import br.edu.utfpr.poo2hibernate3008.Pessoa;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Analice
 */
public class PessoaDao {

    private EntityManager em;

    public PessoaDao(EntityManager em) {
        this.em = em;
    }
 
    //CREATE TABLE & INSERT
    //Está sendo utilizado o Cadastrar Pessoa somente com o nome, 
    //após isso escolherá se a pessoa será cliente ou funcionário
    public void cadastrar(Pessoa p) {
        this.em.persist(p);
    }
    
    //UPDATE
    public void atualizar(Pessoa p) {
        this.em.merge(p);
    }

    //DELETE
    public void remover(Pessoa p){
        p = em.merge(p);
        this.em.remove(p);
    }
    
    //SELECT
     public Pessoa buscarId (int id){
         return em.find(Pessoa.class, id);
     }
     
     public List<Pessoa>buscaTodos(){
         String jpql = "SELECT p From Pessoa p";
         return em.createQuery(jpql, Pessoa.class).getResultList();
     }
   
     //SELECT FILTER
     public List<Pessoa> buscarPorNome(String nome){
         String jpql = "SELECT p From Pessoa p WHERE p.nome = ?1";
         return em.createQuery(jpql, Pessoa.class)
                 .setParameter(1, nome).getResultList();
     }
     
}
