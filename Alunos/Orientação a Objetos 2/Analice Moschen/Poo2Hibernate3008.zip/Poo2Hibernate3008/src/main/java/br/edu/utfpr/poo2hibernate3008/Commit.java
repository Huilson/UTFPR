package br.edu.utfpr.poo2hibernate3008;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Analice
 */
public class Commit {

    void inserirPessoa() throws SQLException {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
            conn.setAutoCommit(false);
            String pessoa = "INSERT INTO pessoa (nome) "
                    + "VALUES (?) ";

            String nome = "Analice";

            try ( PreparedStatement stm = conn.prepareStatement(pessoa)) {
                stm.setString(1, nome);//ome
                //stm.setString();
                stm.execute();
            } catch (Exception e) {
                System.out.println("ERRO: " + e);
                conn.rollback();
            }

        }

    }

    void inserirCliente() throws SQLException {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
            conn.setAutoCommit(false);
            String cliente = "INSERT INTO cliente (nome, endereco, profissao) "
                    + "VALUES (?, ?, ?) ";

            String nome = "Maria";
            String endereco = "Rua das Abóboras, 666, Monte Castelo";
            String profissao = "Analista";

            try ( PreparedStatement stm = conn.prepareStatement(cliente)) {
                stm.setString(1, nome);//nome
                stm.setString(2, endereco);//endereco
                stm.setString(3, profissao);//profissao

                //stm.setString();
                stm.execute();
            } catch (Exception e) {
                System.out.println("ERRO: " + e);
                conn.rollback();//Se der errado, voltará tudo ao início
            }
        }
    }

    void inserirFuncionario() throws SQLException {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
            conn.setAutoCommit(false);
            String funcionario = "INSERT INTO funcionario (nome, funcao) "
                    + "VALUES (?, ?) ";

            String nome = "Danieli";
            String funcao = "Atendente";

            try ( PreparedStatement stm = conn.prepareStatement(funcionario)) {
                stm.setString(1, nome);//nome
                stm.setString(2, funcao);//funcao
                //stm.setString();
                stm.execute();
            } catch (Exception e) {
                System.out.println("ERRO: " + e);
                conn.rollback();//Se der errado, voltará tudo ao início
            }
        }
    }

    void inserirConta() throws SQLException {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
            conn.setAutoCommit(false);
            String conta = "INSERT INTO conta (saldo, numero, tipo) "
                    + "VALUES (?, ?, ?) ";

            long saldo = 150;
            double numero = 14526;
            String tipo = "Poupança";

            try ( PreparedStatement stm = conn.prepareStatement(conta)) {
                stm.setLong(1, saldo);//saldo
                stm.setDouble(2, numero);//numero
                stm.setString(3, tipo);//tipo
                stm.execute();
            } catch (Exception e) {
                System.out.println("ERRO: " + e);
                conn.rollback();//Se der errado, voltará tudo ao início
            }
        }

    }

}
