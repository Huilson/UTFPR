package br.edu.utfpr.dao;

import br.edu.utfpr.poo2hibernate3008.Funcionario;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Analice
 */
public class FuncionarioDao {

    private EntityManager em;

    public FuncionarioDao(EntityManager em) {
        this.em = em;
    }

    //CREATE TABLE & INSERT
    public void cadastrar(Funcionario f) {
        this.em.persist(f);
    }
    
    //UPDATE
    public void atualizar(Funcionario f) {
        this.em.merge(f);
    }

    //DELETE
    public void remover(Funcionario f){
        f = em.merge(f);
        this.em.remove(f);
    }
    
    //SELECT
    public Funcionario buscarId (int id){
         return em.find(Funcionario.class, id);
     }
     
     public List<Funcionario>buscaTodos(){
         String jpql = "SELECT f From Funcionario f";
         return em.createQuery(jpql, Funcionario.class).getResultList();
     }

      //SELECT FILTER
     public List<Funcionario> buscarPorNome(String nome){
         String jpql = "SELECT f From Funcionario f WHERE f.nome = ?1";
         return em.createQuery(jpql, Funcionario.class)
                 .setParameter(1, nome).getResultList();
     }
}
