package br.edu.utfpr.poo2hibernate3008;

import br.edu.utfpr.dao.ClienteDao;
import br.edu.utfpr.dao.ContaDao;
import br.edu.utfpr.dao.FuncionarioDao;
import br.edu.utfpr.dao.PessoaDao;
import br.edu.utfpr.util.EntityManagerJPA;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Analice
 */
public class Main {

    public static void main(String[] args) throws SQLException {

        //Connection conn = ConnectionFactory.recuperaConexao();
        String nome;
        String profissao;
        String funcao;
        String endereco;
        int idCliente;
        int idFuncionario;
        int idPessoa;
        long numero;
        double saldo;

        //Funcionario func = new Funcionario("Danieli", "Cadastrar clientes");
        Pessoa pessoa = new Pessoa();
        Funcionario funcionario = new Funcionario();
        Conta conta = new Conta();
        Cliente cliente = new Cliente();

        Pessoa p1 = new Pessoa("");
        //Cliente cliente = new Cliente("Dani", "Rua do Caracois", "Estudante");
        //Conta c1 = new Conta(100, "Corrente", cliente);

        EntityManager em = EntityManagerJPA.getEntityManager();
        ContaDao contaDao = new ContaDao(em);
        ClienteDao clienteDao = new ClienteDao(em);
        FuncionarioDao funcionarioDao = new FuncionarioDao(em);
        PessoaDao pessoaDao = new PessoaDao(em);
        em.getTransaction().begin();

        //pessoaDao.cadastrar(p1);
        //em.getTransaction().commit();
        //clienteDao.cadastrar(cliente);
        //em.merge(cliente);
        //em.persist(conta);
        //contaDao.cadastrar(c1);
        //em.getTransaction().commit();
//        em.close();
//        int opcao = 0;
        /* while (opcao != 1) {

            opcao = Integer.parseInt(JOptionPane.showInputDialog("Informe a opcao desejada\n "
                    + "[1] Cadastrar Pessoa\n"));
            //nao tera o cliente para adicionar*/
        // switch (opcao) {
        //   case 1:
        
        //Escolher uma opção
        int opcao2 = 0;
        while (opcao2 != 6) {

            opcao2 = Integer.parseInt(JOptionPane.showInputDialog("Informe a opção desejada\n "
                    + "[1] Cadastra Pessoa\n"
                    + "[2] Cadastrar Cliente\n"
                    + "[3] Cadastrar Funcionario\n"
                    + "[4] Consultar Conta\n"
                    + "[5] Remover Pessoa\n"
                    + "[6] Sair"));

            switch (opcao2) {

                case 1:
                    //Cadastro da pessoa - Aqui � necess�rio s� cadastrar o nome;
                    nome = JOptionPane.showInputDialog("Informe o nome da pessoa: ");
                    pessoa = new Pessoa(nome);
                    System.out.println("Cadastro de: " + nome);
                    break;

                case 2:
                    //Cadastro do cliente, informando o id, o endereco e a profissão
                    //idCliente = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do cliente: "));
                    endereco = JOptionPane.showInputDialog("Informe o endereço: ");
                    profissao = JOptionPane.showInputDialog("Informe a profissão: ");
                    cliente = new Cliente(pessoa.getNome(), endereco, profissao);
                    System.out.println(cliente);

                    //buscar o id para depois cadastrar a conta
                    //O cliente cadastrado informará o número da conta, o saldo inicial e o tipo da conta
                    //String entrada = JOptionPane.showInputDialog("Informe o n�mero da conta: ");
                    //numero = Long.parseLong(entrada);
                    String entrada = JOptionPane.showInputDialog("Informe o saldo inicial: ");
                    saldo = Double.parseDouble(entrada);
                    if (conta.setSaldo(saldo)) {
                        System.out.println("Saldo: R$ " + saldo);
                    } else {
                        saldo = 0;
                        System.out.println("Saldo negativo");
                        saldo = Double.parseDouble(JOptionPane.showInputDialog("Saldo negativo, informe novamente o saldo: "));
                    }
                    entrada = JOptionPane.showInputDialog("Informe o tipo da conta: ");
                    String tipo = (entrada);
                    //Fechar conta se o saldo for positivo
                    conta = new Conta(saldo, tipo, cliente);

                    // pessoaDao.cadastrar(pessoa);
                    int operacao = 0;
                    while (operacao != 2) {
                        //Aqui � necess�rio escolher alguma op��o
                        entrada = JOptionPane.showInputDialog("Informe a opção desejada\n "
                                + "[1] Depositar\n"
                                + "[2] Sacar\n"
                                + "[3] Sair");
                        operacao = Integer.parseInt(entrada);

                        switch (operacao) {

                            case 1:
                                //� necess�rio adicionar o valor do dep�sito para somar com o saldo
                                entrada = JOptionPane.showInputDialog("Valor do Depósito");
                                double valorDeposito = Double.parseDouble(entrada);
                                System.out.println("\nDep�sito: R$ " + valorDeposito);
                                conta.depositar(valorDeposito);
                                System.out.println(conta);
                                break;

                            case 2:
                                //Aqui necessário adicionar o valor de saque para diminuir com o saldo
                                entrada = JOptionPane.showInputDialog("Valor do Saque");
                                double valorSaque = Double.parseDouble(entrada);
                                System.out.println("\nSaque: R$ " + valorSaque);
                                if (conta.sacar(valorSaque)) {
                                    System.out.println(conta);
                                } else {
                                    System.out.println("Saldo insuficiente");
                                }
                                //crud.insert(pessoa, cliente, funcionario, conta);
                                break;
                        }
                    }
                    //Aqui está cadastrando no banco a pessoa, cliente e conta.
                    //Atualizar também os depósitos e saques
                    pessoaDao.cadastrar(pessoa);
                    clienteDao.cadastrar(cliente);
                    contaDao.cadastrar(conta);
                    contaDao.atualizar(conta);
                    //em.merge(conta);  // em.persist(conta);
                    em.getTransaction().commit();
                    break;

                case 3:
                    //Cadastro do funcionario, informando a sua função
                    // idFuncionario = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do funcionario: "));
                    funcao = JOptionPane.showInputDialog("Informe a função do funcionário: ");
                    funcionario = new Funcionario(pessoa.getNome(), funcao);
                    System.out.println(funcionario);

                    //Aqui está cadastrando o funcionário no banco
                    funcionarioDao.cadastrar(funcionario);
                    em.getTransaction().commit();
                    break;

                case 4:
                    //Consultar a conta, informando o nome do cliente, aparecerá no console os dados do mesmo
                    String consultar;
                    nome = (JOptionPane.showInputDialog("Informe o nome do cliente: "));
                    // cliente = new Cliente(nome);
                    // clienteDao.buscarPorNome(nome);

                    //SE for para bucar a pessoa deve ser pessoaDao
                   //Aqui está buscando no banco o nome informado e se encontrado apresentará o mesmo
                    System.out.println(clienteDao.buscarPorNome(nome));
                    em.getTransaction().commit();
                    break;
                case 5:
                    //Deletar a pessoa
                    //Deve informar o id da pessoa para excluí-lo da tabela
                    String deletar;
                    idPessoa = Integer.parseInt(JOptionPane.showInputDialog("Informe o id da pessoa para ser excluído: "));
                    pessoa = new Pessoa(idPessoa);

                    //Aqui está removendo a pessoa, deve informar o id da pessoa
                    pessoaDao.remover(pessoa);
                    // System.out.println(clienteDao.remover(cliente));
                    em.getTransaction().commit();
                    break;

            }
        }
        em.getTransaction().commit();
        em.close();
        //break;
    }
}
//}
//}
