package br.edu.utfpr.dao;

import br.edu.utfpr.poo2hibernate3008.Cliente;
import br.edu.utfpr.poo2hibernate3008.Conta;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Analice
 */
public class ContaDao {

    private EntityManager em;

    public ContaDao(EntityManager em) {
        this.em = em;
    }

    //CREATE TABLE & INSERT
    public void cadastrar(Conta conta) {//Cliente cliente
        // this.em.merge(cliente);
        this.em.persist(conta);
    }
    
    //UPDATE
    public void atualizar(Conta conta) {
        this.em.merge(conta);
    }

    //DELETE
    public void remover(Conta conta){
        conta = em.merge(conta);
        this.em.remove(conta);
    }
    
    //SELECT
    public Conta buscarId (int id){
         return em.find(Conta.class, id);
     }
     
     public List<Conta>buscaTodos(){
         String jpql = "SELECT conta From Conta conta";
         return em.createQuery(jpql, Conta.class).getResultList();
     }

      //SELECT FILTER
     public List<Conta> buscarPorNome(String nome){
         String jpql = "SELECT conta From Conta conta WHERE conta.nome = ?1";
         return em.createQuery(jpql, Conta.class)
                 .setParameter(1, nome).getResultList();
     }

}

