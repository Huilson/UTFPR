package br.edu.utfpr.dao;

import br.edu.utfpr.poo2hibernate3008.Cliente;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Analice
 */
public class ClienteDao {

    private EntityManager em;

    public ClienteDao(EntityManager em) {
        this.em = em;
    }

    //CREATE TABLE & INSERT
    public void cadastrar(Cliente c) {
        this.em.persist(c);
    }

    //UPDATE
    public void atualizar(Cliente c) {
        this.em.merge(c);
    }
    
    //DELETE
    public void remover(Cliente c){
        c = em.merge(c);
        this.em.remove(c);
    }
    
     public Cliente buscarId (int id){
         return em.find(Cliente.class, id);
     }
     
     public List<Cliente>buscaTodos(){
         String jpql = "SELECT c From Cliente c";
         return em.createQuery(jpql, Cliente.class).getResultList();
     }

      //SELECT FILTER
     public List<Cliente> buscarPorNome(String nome){
         String jpql = "SELECT c From Cliente c WHERE c.nome = ?1";
         return em.createQuery(jpql, Cliente.class)
                 .setParameter(1, nome).getResultList();
     }
}