package br.edu.utfpr.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Analice
 */

public class EntityManagerJPA {
       //private EntityManager em;
    public static final EntityManagerFactory EMF = Persistence.createEntityManagerFactory("ContaBancaria");//unidade de persistência
    public static EntityManager getEntityManager() {
        return EMF.createEntityManager();
    }        
}
