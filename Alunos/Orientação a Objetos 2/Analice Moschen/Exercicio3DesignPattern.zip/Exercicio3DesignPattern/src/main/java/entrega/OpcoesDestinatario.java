package entrega;

/**
 *
 * @author Analice
 */
public class OpcoesDestinatario implements Destinatario{

    @Override
    public void validarDestinatario() {
        System.out.println("Destinatário válido" +
                "\nDestinatário: YHRJDHD " + "Endereço: Rua da Lua");
    }

    /*@Override
    public void naoValidarDestinatario() {
        System.out.println("Destinatário inválido");
    }*/
}
