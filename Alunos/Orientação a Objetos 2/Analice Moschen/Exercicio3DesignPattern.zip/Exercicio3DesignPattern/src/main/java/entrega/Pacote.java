package entrega;

/**
 *
 * @author Analice
 */
public class Pacote {

    //protected Correio correio;
    private String nomeEmissor;
    private String enderecoEmissor;
    private String nomeDestinatario;
    private String enderecoDestinatario;

    public Pacote(){
    
    }
    
    public Pacote(String nomeEmissor, String enderecoEmissor, String nomeDestinatario, String enderecoDestinatario) {
        this.nomeEmissor = nomeEmissor;
        this.enderecoEmissor = enderecoEmissor;
        this.nomeDestinatario = nomeDestinatario;
        this.enderecoDestinatario = enderecoDestinatario;
    }

    public String getNomeEmissor() {
        return nomeEmissor;
    }

    public void setNomeEmissor(String nomeEmissor) {
        this.nomeEmissor = nomeEmissor;
    }

    public String getEnderecoEmissor() {
        return enderecoEmissor;
    }

    public void setEnderecoEmissor(String enderecoEmissor) {
        this.enderecoEmissor = enderecoEmissor;
    }

    public String getNomeDestinatario() {
        return nomeDestinatario;
    }

    public void setNomeDestinatario(String nomeDestinatario) {
        this.nomeDestinatario = nomeDestinatario;
    }

    public String getEnderecoDestinatario() {
        return enderecoDestinatario;
    }

    public void setEnderecoDestinatario(String enderecoDestinatario) {
        this.enderecoDestinatario = enderecoDestinatario;
    }

    

}
