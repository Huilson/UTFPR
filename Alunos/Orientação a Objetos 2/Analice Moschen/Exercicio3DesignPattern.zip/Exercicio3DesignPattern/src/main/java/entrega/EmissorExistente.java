package entrega;

/**
 *
 * @author Analice
 */
public class EmissorExistente implements Emissor {

    @Override
    public void validarEmissor() {
        System.out.println("Emissor válido"
                + "\nEmissor: RETHF46 " + "Endereço: Rua do Sol");
    }
    /*extends Correio{
    public EmissorExistente(){   
        emissor = new OpcoesEmissor();
    }*/

}
