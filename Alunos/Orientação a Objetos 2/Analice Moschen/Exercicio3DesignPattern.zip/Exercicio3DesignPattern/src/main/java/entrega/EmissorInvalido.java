package entrega;

/**
 *
 * @author Analice
 */
public class EmissorInvalido implements Emissor {

    @Override
    public void validarEmissor() {
        System.out.println("Emissor inválido");
    }
    
}
