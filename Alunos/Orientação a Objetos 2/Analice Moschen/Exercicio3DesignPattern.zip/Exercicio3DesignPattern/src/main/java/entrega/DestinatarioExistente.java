package entrega;

/**
 *
 * @author Analice
 */
public class DestinatarioExistente implements Destinatario {

    /*public DestinatarioExistente(){
        destinatario = new ();
    }*/
    @Override
    public void validarDestinatario() {
        System.out.println("Destinatário válido"
                + "\nDestinatário: YHRJDHD " + "Endereço: Rua da Lua");
    }

}
