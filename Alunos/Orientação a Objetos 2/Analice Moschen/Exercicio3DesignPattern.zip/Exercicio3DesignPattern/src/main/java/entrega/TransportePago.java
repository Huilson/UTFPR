package entrega;

import javax.swing.JOptionPane;

/**
 *
 * @author Analice
 */
public class TransportePago implements Transporte{
     String tipo;
    
    @Override
    public void validarTransporte() {
        tipo = JOptionPane.showMessageDialog("Qual é o tipo de transporte");
        System.out.println("Tipo de transporte " + tipo);
    }
}
