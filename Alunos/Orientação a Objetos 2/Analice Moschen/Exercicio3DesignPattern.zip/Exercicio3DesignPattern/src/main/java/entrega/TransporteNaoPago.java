package entrega;

/**
 *
 * @author Analice
 */
public class TransporteNaoPago implements Transporte{
    
    @Override
    public void validarTransporte() {
        System.out.println("Não foi paga a taxa de transporte");
    }
}
