package entrega;

/**
 *
 * @author Analice
 */
public class PagamentoNaoFeito implements Pagamento{
    
    @Override
    public void validarPagamento() {
        System.out.println("Pagamento não realizado");
    }
}
