package entrega;
/**
 *
 * @author Analice
 */
public interface Emissor {
    public void validarEmissor();
   // public void naoValidarEmissor();
}
