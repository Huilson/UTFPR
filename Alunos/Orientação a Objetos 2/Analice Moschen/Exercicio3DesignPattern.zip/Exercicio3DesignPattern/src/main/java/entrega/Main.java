package entrega;

/**
 *
 * @author Analice
 */
public class Main {

    public static void main(String[] args) {
        String nomeEmissor;
        String enderecoEmissor;
        String nomeDestinatario;
        String enderecoDestinatario;

        Correio correio = new Correio() {};
        //Pacote pacote = new Pacote(nomeEmissor, enderecoEmissor, nomeDestinatario, enderecoDestinatario);
    
        Pacote pacote = new Pacote("Analice", "Rua Caracol", "Danieli", "Rua Pereira");
        // Pacote pacote = new Pacote("Analice", "", nomeDestinatario, enderecoDestinatario);

        Emissor e = new EmissorExistente();
        e.validarEmissor();

        Destinatario d = new DestinatarioExistente();
        d.validarDestinatario();
        
        //correio.setTipoTransporte(nomeEmissor);
        correio.validarTransporte();
        correio.validarPagamento();
        //System.out.println("\nDestinatário: YHRJDHD"
        //      + "Endereço: Rua da Lua");      

       // Correio dI = new DestinatarioInvalido();
       // dI.naoValidarDestinatario();
    }

}
