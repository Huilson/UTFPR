package entrega;

/**
 *
 * @author Analice
 */
public abstract class Correio {

    protected Destinatario destinatario;
    protected Emissor emissor;
    protected Pagamento pagamento;
    protected Transporte transporte;
    private String tipoTransporte;
    
    public Correio(){
        
    }
    
    
    public void validarDestinatario() {
        destinatario.validarDestinatario();
    }

    public void validarEmissor() {
        emissor.validarEmissor();
    }

    public void validarPagamento() {
        pagamento.validarPagamento();
    }
    
    public void validarTransporte(){
        transporte.validarTransporte();
    }

    public String getTipoTransporte() {
        return tipoTransporte;
    }

    public void setTipoTransporte(String tipoTransporte) {
        this.tipoTransporte = tipoTransporte;
    }
    
    

}
