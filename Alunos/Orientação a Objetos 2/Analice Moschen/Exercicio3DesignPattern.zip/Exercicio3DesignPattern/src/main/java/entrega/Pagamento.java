package entrega;
/**
 *
 * @author Analice
 */
public interface Pagamento {
    public void validarPagamento();
    
}
