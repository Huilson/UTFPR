package entrega;

/**
 *
 * @author Analice
 */
public class PagamentoPago implements Pagamento{
    
    @Override
    public void validarPagamento() {
        System.out.println("Pagamento realizado");
    }
}
