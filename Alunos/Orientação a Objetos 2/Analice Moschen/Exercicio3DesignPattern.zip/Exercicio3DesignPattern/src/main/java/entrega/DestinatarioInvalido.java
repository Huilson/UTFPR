package entrega;

/**
 *
 * @author Analice
 */
public class DestinatarioInvalido implements Destinatario {

    @Override
    public void validarDestinatario() {
        System.out.println("Destinatário inválido");
    }
}
