package entrega;

/**
 *
 * @author Analice
 */
public class OpcoesEmissor implements Emissor {

    @Override
    public void validarEmissor() {
        System.out.println("Emissor válido"
                + "\nEmissor: RETHF46 " + "Endereço: Rua do Sol");
    }

   // @Override
    //public void naoValidarEmissor() {
      //  System.out.println("Emissor inválido");
    //}

}
