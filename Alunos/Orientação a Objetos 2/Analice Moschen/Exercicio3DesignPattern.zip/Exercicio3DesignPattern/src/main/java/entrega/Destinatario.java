package entrega;

/**
 *
 * @author Analice
 */
public interface Destinatario {

    public void validarDestinatario();

}
