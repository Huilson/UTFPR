package entrega;

/**
 *
 * @author Analice
 */
public interface Transporte {
    public void validarTransporte();
}