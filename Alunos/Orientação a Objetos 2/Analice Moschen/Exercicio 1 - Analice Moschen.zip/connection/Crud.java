package connection;

import conta.Conta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import pessoa.Cliente;
import pessoa.Funcionario;
import pessoa.Pessoa;

/**
 *
 * @author Analice
 */
public class Crud {

    private PreparedStatement pstm;
    private ResultSet rs;

    public void createTable() throws SQLException {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {
           
            String pessoa = "CREATE TABLE IF NOT EXISTS pessoa ("
                    + "idPessoa SERIAL PRIMARY KEY, "
                    + "nome VARCHAR(50) "
                    + ")";

            String funcionario = "CREATE TABLE IF NOT EXISTS funcionario ("
                    + "idFuncionario SERIAL PRIMARY KEY, "
                    + "nomefunc VARCHAR(50), "
                    + "funcao VARCHAR(255), "
                    + "CONSTRAINT fk_idFuncionario FOREIGN KEY (idFuncionario) REFERENCES pessoa (idPessoa) "
                    + ")";

            String cliente = "CREATE TABLE IF NOT EXISTS cliente ("
                    + "idCliente SERIAL PRIMARY KEY, "
                    + "nomecli varchar(50), "
                    + "endereco varchar(255), "
                    + "profissao varchar(255), "
                    + "CONSTRAINT fk_idCliente FOREIGN KEY (idCliente) REFERENCES pessoa (idPessoa) "
                    + ")";

            String conta = "CREATE TABLE IF NOT EXISTS conta ("
                    + "numero INTEGER PRIMARY KEY, "
                    + "saldo numeric(10,1), "
                    + "tipo varchar(255), "
                    + "idCli integer, "
                    //+ "nomec varchar(50), "
                    + "CONSTRAINT fk_idCli FOREIGN KEY (idCli) REFERENCES cliente (idCliente) "
                    //+ "CONSTRAINT fk_nomec FOREIGN KEY (nomec) REFERENCES cliente (nomecli) "
                    + ")";

            pstm = conn.prepareStatement(pessoa);
            pstm.execute();

            pstm = conn.prepareStatement(funcionario);
            pstm.execute();

            pstm = conn.prepareStatement(cliente);
            pstm.execute();

            pstm = conn.prepareStatement(conta);
            pstm.execute();

            pstm.close();
        } catch (Exception e) {
            System.out.println("Erro");
            e.printStackTrace();
        }
    }

    /*void addElemento() {
        Connection conn = ConnectionFactory.recuperaConexao();

        String pessoa = "INSERT INTO pessoa(nome)"
                + "VALUES (?)";
        
        String cli
                = "INSERT INTO cliente(nome, endereco, profissao)"
                + "VALUES (?, ?, ?)";

        String func
                = "INSERT INTO funcionario(nome, funcao)"
                + "VALUES (Pedro, Atendente)";
        
        String conta 
                = "INSERT INTO conta(numero, saldo, tipo, nomec)"
                + "VALUES (?, ?, ?, ?)";
        //preparo uam query para enviar ao BD
    }*/
    
    public void insert(Pessoa pessoa, Cliente cliente, Funcionario funcionario, Conta conta) {
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {

            pstm = conn.prepareStatement("INSERT INTO pessoa (nome) "
                    + "values (?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstm.setString(1, pessoa.getNome());
            pstm.execute();
            rs = pstm.getGeneratedKeys();

            if (rs.next()) {
                pessoa.setIdPessoa(rs.getInt("idPessoa"));
                // JOptionPane.showMessageDialog("Id da Pessoa:" + pessoa.getIdPessoa());
            }
            
            /* INSERT DO CLIENTE*/
            pstm = conn.prepareStatement("INSERT INTO cliente (nome, endereco, profissao) "
                    + "values (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);

            
            pstm.setString(1, cliente.getNome());//inserir o nome
            pstm.setString(2, cliente.getEndereco());//inserir o endereco
            pstm.setString(3, cliente.getProfissao());//inserir a profissao
            pstm.execute();
            rs = pstm.getGeneratedKeys();

            /* INSERT DO FUNCIONARIO*/
            pstm = conn.prepareStatement("INSERT INTO funcionario (nome, funcao) "
                    + "values (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);

            pstm.setString(1, funcionario.getNome());//inserir o nome
            pstm.setString(2, funcionario.getFuncao());//inserir a função do funcionário
            pstm.execute();
            rs = pstm.getGeneratedKeys();

            /* INSERT DA CONTA*/
            pstm = conn.prepareStatement("INSERT INTO conta (saldo, numero, tipo) "
                    + "values (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);

            pstm.setDouble(1, conta.saldo());//inserir o saldo inicial
            pstm.setLong(2, conta.getNumero());//inserir 
            pstm.setString(3, conta.getTipo());
            pstm.execute();
            rs = pstm.getGeneratedKeys();

            conn.close();

        } catch (Exception e) {
            System.out.println("Erro");
            e.printStackTrace();
        }

    }
    
    private final String LISTA = "SELECT  conta.*, cliente.nomecli, conta.idcli "
            + "FROM conta, cliente "
            + "WHERE conta.idcli = cliente.idcliente ";
    
    //Consultar a conta
    public List<Conta> searchFilter(int idCliente) {
        List<Conta> lista = new ArrayList<>();
        try ( Connection conn = ConnectionFactory.recuperaConexao()) {

            pstm = conn.prepareStatement(LISTA + " AND idCli LIKE ? ORDER BY idCli");
            pstm.setInt(1, '%' + idCliente + '%');

            rs = pstm.executeQuery();

            while (rs.next()) {

                Cliente cliente = new Cliente();
                cliente.setIdCliente(rs.getInt("idCliente"));
                cliente.setNome(rs.getString("nomeCli"));

                Conta conta = new Conta();
                conta.setNumero(rs.getLong("numero"));
                conta.setSaldo(rs.getDouble("saldo"));
                conta.setTipo(rs.getString("tipo"));
                conta.setCliente(cliente);
                lista.add(conta);
            }
            return lista;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return new ArrayList<>();
        }

    }
}
