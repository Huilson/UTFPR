package principal;

import connection.ConnectionFactory;
import connection.Crud;
import conta.Conta;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputValidation;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import pessoa.Cliente;
import pessoa.Funcionario;
import pessoa.Pessoa;

public class Principal {

    public static void main(String[] args) throws SQLException {

        //Connection conn = ConnectionFactory.recuperaConexao();
        Crud crud = new Crud();
        crud.createTable();
        String nome;
        String profissao;
        String funcao;
        String endereco;
        int idCliente;
        int idFuncionario;
        int idPessoa;
        long numero;
        double saldo;

     
        Pessoa pessoa = new Pessoa();
        Funcionario funcionario = new Funcionario();
        Cliente cliente = new Cliente();
        Conta conta = new Conta();

        //Escolher uma opção
        int opcao = 0;

        while (opcao != 1) {

            opcao = Integer.parseInt(JOptionPane.showInputDialog("Informe a opção desejada\n "
                    + "[1] Cadastrar Pessoa\n"));

            switch (opcao) {
                case 1:
                    //Cadastro da pessoa - Aqui é necessário só cadastrar o nome;
                    nome = JOptionPane.showInputDialog("Informe o nome da pessoa: ");
                    idPessoa = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ID da pessoa: "));
                    pessoa = new Pessoa(idPessoa, nome);
                    System.out.println("Cadastro de: " + nome);

                    int opcao2 = 0;
                    while (opcao2 != 3) {
                        opcao2 = Integer.parseInt(JOptionPane.showInputDialog("Informe a opção desejada\n "
                                + "[1] Cadastrar Cliente\n"
                                + "[2] Cadastrar Funcionario\n"
                                + "[3] Consultar Conta\n"
                                + "[4] Sair"));

                        switch (opcao2) {

                            case 1:
                                //Cadastro do cliente, informando o id, o endereco e a profissão
                                idCliente = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do cliente: "));
                                endereco = JOptionPane.showInputDialog("Informe o endereço: ");
                                profissao = JOptionPane.showInputDialog("Informe a profissão: ");
                                cliente = new Cliente(idCliente, nome, endereco, profissao);
                                System.out.println(cliente);

                                //O cliente cadastrado informará o número da conta, o saldo inicial e o tipo da conta
                                String entrada = JOptionPane.showInputDialog("Informe o número da conta: ");
                                numero = Long.parseLong(entrada);
                                entrada = JOptionPane.showInputDialog("Informe o saldo inicial: ");
                                saldo = Double.parseDouble(entrada);
                                if (conta.setSaldo(saldo)) {
                                    System.out.println("Saldo: R$ " + saldo);
                                } else {
                                    saldo = 0;
                                    System.out.println("Saldo negativo");
                                    saldo = Double.parseDouble(JOptionPane.showInputDialog("Saldo negativo, informe novamente o saldo: "));
                                }
                                entrada = JOptionPane.showInputDialog("Informe o tipo da conta: ");
                                String tipo = (entrada);
                                //Fechar conta se o saldo for positivo
                                conta = new Conta(numero, saldo, tipo, cliente);

                                int operacao = 0;
                                while (operacao != 2) {
                                    //Aqui é necessário escolher alguma opção
                                    entrada = JOptionPane.showInputDialog("Informe a opção desejada\n "
                                            + "[1] Depositar\n"
                                            + "[2] Sacar\n"
                                            + "[3] Sair");
                                    operacao = Integer.parseInt(entrada);

                                    switch (operacao) {

                                        case 1:
                                            //É necessário adicionar o valor do depósito para somar com o saldo
                                            entrada = JOptionPane.showInputDialog("Valor do Depósito");
                                            double valorDeposito = Double.parseDouble(entrada);
                                            System.out.println("\nDepósito: R$ " + valorDeposito);
                                            conta.depositar(valorDeposito);
                                            System.out.println(conta);
                                            break;

                                        case 2:
                                            //É necessário adicionar o valor de saque para diminuir com o saldo
                                            entrada = JOptionPane.showInputDialog("Valor do Saque");
                                            double valorSaque = Double.parseDouble(entrada);
                                            System.out.println("\nSaque: R$ " + valorSaque);
                                            if (conta.sacar(valorSaque)) {
                                                System.out.println(conta);
                                            } else {
                                                System.out.println("Saldo insuficiente");
                                            }
                                            crud.insert(pessoa, cliente, funcionario, conta);
                                            break;
                                    }
                                }
                                break;

                            case 2:
                                //Cadastro do funcionario, informando o id e a sua função
                                idFuncionario = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do funcionario: "));
                                funcao = JOptionPane.showInputDialog("Informe a função: ");
                                funcionario = new Funcionario(nome, idFuncionario, funcao);
                                System.out.println(funcionario);
                                break;

                            case 3:
                                //Consultar a conta
                                idCliente = Integer.parseInt(JOptionPane.showInputDialog("Informe o id do cliente: "));
                                List<Conta> consulta = crud.searchFilter(idCliente);
                                System.out.println("Informações da conta: " + consulta);

                                break;
                        }
                    }
                    crud.insert(pessoa, cliente, funcionario, conta);
                    break;
            }
        }
    }
}
