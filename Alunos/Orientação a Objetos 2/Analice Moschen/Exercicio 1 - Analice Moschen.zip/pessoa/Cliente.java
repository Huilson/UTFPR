package pessoa;

/**
 *
 * @author Analice
 */
public class Cliente extends Pessoa{
    
    
    private int idCliente;
    private String endereco;
    private String profissao;

    public Cliente(){    
    }

    public Cliente(int idCliente, String nome, String endereco, String profissao) {
        super(nome);
        this.idCliente = idCliente;
        this.endereco = endereco;
        this.profissao = profissao;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    /*public Cliente(String nome, String endereco, String profissao) {
        super(nome);
        this.endereco = endereco;
        this.profissao = profissao;
    }*/

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    @Override
    public String toString() {
        return "\n| ID: " + idCliente + " | Cliente: " + super.getNome() 
                + "\n| Endereco: " + endereco 
                + "\n| Profissão: " + profissao;
    }
    
    
}
