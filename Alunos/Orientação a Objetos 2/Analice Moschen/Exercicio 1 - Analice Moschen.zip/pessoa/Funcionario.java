package pessoa;

/**
 *
 * @author Analice
 */

public class Funcionario extends Pessoa{
    
    private int idFuncionario;
    private String funcao;

    public Funcionario() {
    }

    public Funcionario(String nome, int idFuncionario, String funcao) {
        super(nome);
        this.idFuncionario = idFuncionario;
        this.funcao = funcao;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    /*public Funcionario(String nome, String funcao) {
        super(nome);
        this.funcao = funcao;
    }*/

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    @Override
    public String toString() {
        return "Funcionária: " + super.getNome() + " | ID: " + idFuncionario + " | Função: " + funcao;
    }
            
}
