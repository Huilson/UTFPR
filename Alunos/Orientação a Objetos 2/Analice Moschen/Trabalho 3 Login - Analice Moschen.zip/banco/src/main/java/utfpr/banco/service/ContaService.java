package utfpr.banco.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import utfpr.banco.model.Conta;
import utfpr.banco.repository.ContaRepository;

/**
 *
 * @author Analice
 */
@Service
public class ContaService {

    @Autowired
    ContaRepository contaRepository;

    public Conta getContaSacar(Conta conta, double valor) throws RuntimeException {
        double saldo = conta.getSaldo();

        if (valor <= saldo) {
            conta.setSaldo(saldo - valor);
            contaRepository.save(conta);
            return conta;
        } else {
            throw new RuntimeException("Conta não encontrada ou saldo insuficiente " + conta);
        }
    }
    
    public Conta getContaDepositar(Conta conta, double valor) throws RuntimeException {
        double saldo = conta.getSaldo();

        if (valor > 0) {
            conta.setSaldo(saldo + valor);
            contaRepository.save(conta);
            return conta;
        } else {
            throw new RuntimeException("Conta não encontrada ou saldo insuficiente " + conta);
        }
    }
    
    public void deleteContaById(String id) {
        contaRepository.deleteById(id);
    }
}
