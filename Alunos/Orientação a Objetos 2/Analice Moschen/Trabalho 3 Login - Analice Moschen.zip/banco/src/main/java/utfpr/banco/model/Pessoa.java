//package utfpr.banco.model;
//
//
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//import org.springframework.data.mongodb.core.mapping.Field;
//
///**
// *
// * @author Analice
// */
////@Entity
////@Table(name="pessoa")
//@Document
//public class Pessoa {
//    
////    private Funcionario funcionario;
////    private Cliente cliente;
//    
////    @GeneratedValue (strategy = GenerationType.AUTO)
////    @Column(name="id");
//    @Id
//    private String idPessoa;
//    
//    @Field("nome")
//    private String nome;
//
//    public Pessoa() {
//    }
//    
//    public Pessoa(String nome) {
//        this.nome = nome;
//    }
//
//    public String getIdPessoa() {
//        return idPessoa;
//    }
//
//    public void setIdPessoa(String idPessoa) {
//        this.idPessoa = idPessoa;
//    }
//    
//    public String getNome() {
//        return nome;
//    }
//
//    public void setNome(String nome) {
//        this.nome = nome;
//    }
//
////    public Funcionario getFuncionario() {
////        return funcionario;
////    }
////
////    public void setFuncionario(Funcionario funcionario) {
////        this.funcionario = funcionario;
////    }
////
////    public Cliente getCliente() {
////        return cliente;
////    }
////
////    public void setCliente(Cliente cliente) {
////        this.cliente = cliente;
////    }
//
////    @Override
////    public String toString() {
////        return "Pessoa" + " cliente=" + cliente
////                + "nome" + nome ;
////    }
//
//    
//}
//
