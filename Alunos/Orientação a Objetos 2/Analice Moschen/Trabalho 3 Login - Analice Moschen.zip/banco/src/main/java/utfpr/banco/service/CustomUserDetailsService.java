package utfpr.banco.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import utfpr.banco.model.Cliente;
import utfpr.banco.model.Role;
import utfpr.banco.repository.ClienteRepository;
import utfpr.banco.repository.RoleRepository;

/**
 *
 * @author Analice
 */
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder encoder;

    public Cliente findUserByNome(String nome) {
        return clienteRepository.findByNome(nome);
    }

    public void saveUser(Cliente cliente) {
        cliente.setPassword(encoder.encode(cliente.getPassword()));
        Role userRole = roleRepository.findByRole("USER");
        cliente.setRoles(new HashSet<>(Arrays.asList(userRole)));
        clienteRepository.save(cliente);
    }

    @Override
    public UserDetails loadUserByUsername(String nome) throws UsernameNotFoundException {
        Cliente cliente = clienteRepository.findByNome(nome);

        if (cliente != null) {
            List<GrantedAuthority> authorities = getUserAuthority(cliente.getRoles());
            return buildUserForAuthentication(cliente, authorities);
        } else {
            throw new UsernameNotFoundException("Error, user not found");
        }
    }

    private List<GrantedAuthority> getUserAuthority(Set<Role> userRoles) {
        Set<GrantedAuthority> roles = new HashSet<>();
        userRoles.forEach((role) -> {
            roles.add(new SimpleGrantedAuthority(role.getRole()));
        });
        List<GrantedAuthority> grantedAuthority = new ArrayList<>(roles);

        return grantedAuthority;
    }

    private UserDetails buildUserForAuthentication(Cliente cliente, List<GrantedAuthority> authorities) {
        return new org.springframework.security.core.userdetails.User(cliente.getNome(), cliente.getPassword(), authorities);
    }

}
