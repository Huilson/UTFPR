//package utfpr.banco.model;
//
//import javax.persistence.JoinColumn;
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//
///**
// *
// * @author Analice
// */
//@Document
////@Table(name="funcionario")
//public class Funcionario {
//    //implements Serializable
//
//    private String funcao;
//    
//    @JoinColumn(name = "idPes")
//    private Pessoa pessoa;
//
//    public Funcionario() {
//    }
//
//    public Funcionario(String nome, String funcao) {// int idFuncionario
////        super(nome);
//        this.funcao = funcao;
//    }
//
//    public String getFuncao() {
//        return funcao;
//    }
//
//    public void setFuncao(String funcao) {
//        this.funcao = funcao;
//    }
//
//    public Pessoa getPessoa() {
//        return pessoa;
//    }
//
//    public void setPessoa(Pessoa pessoa) {
//        this.pessoa = pessoa;
//    }
//    
//    
//    
//
//    @Override
//    public String toString() {
//        return "Funcionario: " + pessoa.getNome() + " | ID: " + pessoa.getIdPessoa() + " | Funcao: " + funcao;
//    }
//}
