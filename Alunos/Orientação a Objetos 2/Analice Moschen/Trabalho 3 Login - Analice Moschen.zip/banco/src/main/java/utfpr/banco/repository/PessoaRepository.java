//package utfpr.banco.repository;
//
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.stereotype.Repository;
//import utfpr.banco.model.Pessoa;
//
///**
// *
// * @author Analice
// */
//@Repository
//public interface PessoaRepository extends MongoRepository<Pessoa, Object> {
//    Pessoa findByNome(String comparar);
//}
