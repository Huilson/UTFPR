package utfpr.banco.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import utfpr.banco.model.Role;

/**
 *
 * @author Analice
 */
public interface RoleRepository extends MongoRepository<Role, String>{
    Role findByRole(String role);
}
