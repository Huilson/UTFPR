package utfpr.banco.controller;

import java.io.FileNotFoundException;
import java.util.List;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import utfpr.banco.model.Conta;
import utfpr.banco.repository.ContaRepository;
import utfpr.banco.service.ReportService;

/**
 *
 * @author Analice
 */
@Controller
public class ReportController {
    
     //Essa Autowired indica um ponto onde a injeção automática deverá ser aplicada

    @Autowired
    private ContaRepository contaRepository;

    @Autowired
    private ReportService reportService;
    
    //Criado o caminho par ao navegador entender e acessar os diretórios
    @GetMapping("/getContas")
    public List<Conta> getContas(){
        return contaRepository.findAll();
    }
    
    //Aqui é necessário passar na URL o valor da variável format para o método export
    @GetMapping("/report/{format}")
    public String genetaredReport(@PathVariable String format) throws FileNotFoundException, JRException{
        return reportService.exportReport(format);
    }
    
}
