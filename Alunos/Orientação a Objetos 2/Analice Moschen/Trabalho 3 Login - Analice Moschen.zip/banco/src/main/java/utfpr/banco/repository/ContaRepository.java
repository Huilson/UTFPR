package utfpr.banco.repository;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import utfpr.banco.model.Conta;

/**
 *
 * @author Analice
 */
@Repository
//ContaRepository está utilizando o MongoRepository que possui os métodos que precisarei usar
public interface ContaRepository extends MongoRepository<Conta, String>{
//        List<Conta> findById(String id);
        Conta findBynumero(Long numero);

}
