package utfpr.banco.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import utfpr.banco.dto.NovaConta;
import utfpr.banco.model.Cliente;
import utfpr.banco.model.Conta;
import utfpr.banco.repository.ClienteRepository;
import utfpr.banco.repository.ContaRepository;
import utfpr.banco.service.ClienteService;
import utfpr.banco.service.ContaService;
//import utfpr.banco.service.ContaService;

/**
 *
 * @author Analice
 */
@Controller
@RequestMapping("/index")
public class BancoController {

    @Autowired
    private ContaRepository contaRepository;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ContaService contaService;

    @GetMapping
//    ("/index")
    public String index(Model model) {
        //a interface MONGODB REPOSITORY  encontra todos os documento
        List<Cliente> clientes = clienteRepository.findAll();
        model.addAttribute("clientes", clientes);//atribui os dados de cada pedido na view

        List<Conta> conta = contaRepository.findAll();
        model.addAttribute("conta", conta);

        clientes.toString();
        return "index";
    }

    @PostMapping("salvar")
    //ou atualizacao
    public String salvar(@ModelAttribute("cliente") Cliente cliente) {
        clienteRepository.save(cliente);
        return "redirect:/index";
    }

//   Atualização do cliente, podendo atulizar nome, endereço e profissão
    @GetMapping("/formularioAtualizarCliente/{id}")
    public String formularioAtualizarCliente(@PathVariable(value = "id") String id, Model model) {
        Cliente cliente = clienteService.getClienteById(id);
        model.addAttribute("cliente", cliente);
        return "atualizacao/formularioAtualizarCliente";
    }

//    Método depositar ;
//    @GetMapping("/depositar/{idConta}")
//    public String depositar(@PathVariable(value = "idConta") String idConta, Model model) {
//        Conta conta = contaService.getContaDepositar(idConta);
////        conta.depositar();
//        model.addAttribute("conta", conta);
//        return "/depositar";
//    }
    @GetMapping("depositar")
    public String valorDepositar() {
        return "depositar";
    }

    @PostMapping("valorDeposito")
    public String deposito(@RequestParam(value = "campoValor") double deposito, Model model, @RequestParam(value = "numero") Long numero) {
        Conta conta = contaRepository.findBynumero(numero);
        model.addAttribute("conta", contaService.getContaDepositar(conta, deposito));
        return "redirect:/index";
    }

    @GetMapping("sacar")
    public String valorSacar() {
        return "sacar";
    }

    //É necessário 
    @PostMapping("valorSaque")
    public String saque(@RequestParam(value = "campoValor") double saque, Model model, @RequestParam(value = "numero") Long numero) {
        Conta conta = contaRepository.findBynumero(numero);
        model.addAttribute("conta", contaService.getContaSacar(conta, saque));
        return "redirect:/index";
    }


    @PostMapping("salva")
    public String salva(@ModelAttribute("conta") Conta conta) {
        contaRepository.save(conta);
        return "redirect:/index";
    }

    //Excluir o cliente - utilizando o id que está sendo passado deleteClienteById criado no ClienteService
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable(value = "id") String id, RedirectAttributes ra) {
        clienteService.deleteClienteById(id);
        ra.addFlashAttribute("danger", "Cliente excluído com sucesso!");
        return "redirect:/index";
    }

    //Excluir a conta - utilizando o id que está sendo passado deleteContaById criado na ContaService
    @GetMapping("/excluirConta/{id}")
    public String excluirConta(@PathVariable(value = "id") String id) {
        contaService.deleteContaById(id);
        return "redirect:/index";
    }

    @GetMapping("pesquisaNome")
    public String pesquisaNome() {
        return "pesquisaNome";
    }

    @PostMapping("pesquisaCompleta")
    public String pesquisa(@RequestParam(value = "campoPesquisa") String campoPesquisa, Model model) {
        model.addAttribute("clientes", clienteRepository.findByNome(campoPesquisa));
        return "pesquisaCompleta";
    }
//
//    @GetMapping("/{id}")
//    public String buscar(@PathVariable("id") String id, Model model) {
//        Cliente cliente = clienteRepository.findById(id).orElseThrow();
//        model.addAttribute("clientes", cliente);
//        return "index";
//    }

}
