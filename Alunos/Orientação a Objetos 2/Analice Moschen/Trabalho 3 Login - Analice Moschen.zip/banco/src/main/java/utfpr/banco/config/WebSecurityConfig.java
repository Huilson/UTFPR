package utfpr.banco.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import utfpr.banco.model.Cliente;
import utfpr.banco.model.Role;
import utfpr.banco.service.CustomUserDetailsService;

/**
 *
 * @author Analice
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private BCryptPasswordEncoder BCryptPasswordEncoder;

    @Autowired
    CustomizeAuthenticationSuccessHandler handler;

//    @Autowired
//    Cliente cliente;
    
//    @Autowired
//    List<Role> roles = new ArrayList<>();

    @Bean
    public UserDetailsService mongoUserDetails() {
        return new CustomUserDetailsService();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        UserDetailsService userDetailsService = mongoUserDetails();
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(BCryptPasswordEncoder);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/").permitAll()
                .antMatchers("/login").permitAll()
                .antMatchers("/signup").permitAll()
                .antMatchers("/index/**").hasAuthority("ADMIN").anyRequest()
                .authenticated().and().csrf().disable().formLogin().successHandler(handler)
                .loginPage("/login").failureUrl("/login?error=true")
                .usernameParameter("nome")
                .passwordParameter("password")
                .and().logout()
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/").and().exceptionHandling();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
                .antMatchers("/resources/**", "/static/**", "/css/**", "/js/**", "/images/**");
    }

//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                .authorizeHttpRequests((requests) -> requests
////                .antMatchers("/", "/index").permitAll()
//                .anyRequest().authenticated()
//                )
//                .formLogin((form) -> form
//                .loginPage("/login")
//                .permitAll()
//                )
//                .logout((logout) -> logout.permitAll());
//
//        return http.build();
//    }
    //utilizar esse
//    @Bean
//    public UserDetailsService userDetailsService() {
//        cliente = new Cliente();
//        
//        cliente.setNome("adm");
//        cliente.setPassword("123");
////        roles.add(new Role("ADMIN"));
//        cliente.setRoles((Set<Role>) roles);
//
//        UserDetails user
//                = User.withDefaultPasswordEncoder()
//                        //                        .username("ana")
//                        //                        .password("ana");
//                        .username(cliente.getNome())
//                        .password(BCryptPasswordEncoder.encode(cliente.getPassword()))
//                        .roles(cliente.getRoles((Set<Role>) roles))
//                        .build();
//
//        return new InMemoryUserDetailsManager(user);
//    }
}
