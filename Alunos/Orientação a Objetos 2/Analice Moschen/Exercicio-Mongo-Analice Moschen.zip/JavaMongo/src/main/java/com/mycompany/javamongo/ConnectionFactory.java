package com.mycompany.javamongo;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Analice
 */

public class ConnectionFactory {
   public static Connection recuperaConexao(){
       try {
           System.out.println("\nCriando conexão!\n");
           return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Aula2", "postgres", "postgres");
       } catch (Exception e) {
           System.out.println("ERROS...");
           e.printStackTrace();
           return null;
       }
   }
}
