package com.mycompany.javamongo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Analice
 */

@Entity
@Table(name="funcionario")
public class Funcionario extends Pessoa implements Serializable{
    
    private String funcao;

    public Funcionario() {
    }

    public Funcionario(String nome, String funcao) {// int idFuncionario
        super(nome);
        this.funcao = funcao;
    }

    /*public Funcionario(String nome, String funcao) {
        super(nome);
        this.funcao = funcao;
    }*/

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    @Override
    public String toString() {
        return "Funcionario: " + super.getNome() + " | ID: " + super.getIdPessoa() + " | Funcao: " + funcao;
    }
            
}
