package com.mycompany.javamongo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author Analice
 */
@Entity
@Table(name="cliente")
public class Cliente extends Pessoa implements Serializable{
    
    private String endereco;
    private String profissao;
 
    public Cliente(){    
    }

    public Cliente(String nome, String endereco, String profissao) {
        super(nome);
        //this.idCliente = idCliente;
        this.endereco = endereco;
        this.profissao = profissao;
    }

    /*public Cliente(String nome, String endereco, String profissao) {
        super(nome);
        this.endereco = endereco;
        this.profissao = profissao;
    }*/

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    @Override
    public String toString() {
        return "\n| ID: " + super.getIdPessoa() + " | Cliente: " + super.getNome() 
                + "\n| Endereco: " + endereco 
                + "\n| Profissão: " + profissao;
    }
    
    
}
