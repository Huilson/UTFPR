package com.mycompany.javamongo;

import java.text.DecimalFormat;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
//import pessoa.Cliente;

@Entity
@Table(name = "conta")
public class Conta {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long numero;
    private double saldo;
    private String tipo;
    @ManyToOne
    private Cliente cliente;

    public Conta() {

    }

    public Conta(long numero, double saldo, String tipo, Cliente cliente) {
        this.numero = numero;
        this.saldo = saldo;
        this.tipo = tipo;
        this.cliente = cliente;

        //Tipo de conta: Poupan�a ou Corrente
    }

    /*public Conta(double saldo, String tipo, Cliente cliente) {
        //this.numero = numero;
        this.saldo = saldo;
        this.tipo = tipo;
        this.cliente = cliente;
    }*/
    public long getNumero() {
        return numero;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double saldo() {
        return saldo;
    }

    public boolean setSaldo(double s) {
        /*if (s >= 0) {
            saldo = s;
            return true;

        } else {
            saldo = 0;
        }*/
        if (s <= 0) {
            //saldo = 0;
            return false;

        } else if (saldo > 0) {
            saldo = s;
        }
        return true;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /*Se o valor informado pelo cliente para o dep�sito
    for maior que 0, o valor ser� somado com o saldo, retornando o saldo atual*/
    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
        }
    }

    /*Se o valor informado pelo cliente para sacar
     for maior que saldo, n�o ser� poss�vel fazer o saque, s
    sendo necess�rio informar outro  valor.
    Mas se o valor existir na conta ser� diminu�do com o saldo
    retonando o saldo atual*/
    public boolean sacar(double valor) {
        if (valor > saldo) {
            return false;
        } else if (valor > 0) {
            saldo -= valor;
        }
        return true;
    }

    /*public boolean saldoPositivo(double saldo){
        if (saldo > 0){
             System.out.println(entrada);
             } else {
        return "Saldo insuficiente";
     
    }*/
    @Override
    public String toString() {
        DecimalFormat formatador = new DecimalFormat("R$ #, ##0.00");
        String saldoFormatado = formatador.format(saldo);
        /*return ("Saldo da conta" + numero ": " + saldoFormatado);*/
        return "\nConta de " + cliente.getNome()
                + "\nN�mero da conta: " + numero
                + "\nTipo: " + tipo
                + "\nSaldo da conta: " + saldoFormatado;
    }

}
