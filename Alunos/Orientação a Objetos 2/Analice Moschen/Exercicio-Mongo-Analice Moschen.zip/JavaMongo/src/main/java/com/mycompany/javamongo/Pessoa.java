package com.mycompany.javamongo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.bson.Document;

/**
 *
 * @author Analice
 */

@Entity
@Table(name="pessoa")

public class Pessoa {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    @Column(name="id")
    private int idPessoa;
    private String nome;

    public Pessoa() {
    }

    /*public Pessoa(int idPessoa, String nome) {
        this.nome = nome;
    }*/

    
    public Pessoa(String nome) {
        this.nome = nome;
    }

    public int getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    
}
