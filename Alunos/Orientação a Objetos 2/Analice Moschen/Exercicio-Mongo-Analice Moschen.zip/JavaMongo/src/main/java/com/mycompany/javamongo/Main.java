package com.mycompany.javamongo;

//import br.edu.utfpr.util.EntityManagerJPA;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.JOptionPane;
import org.bson.Document;

/**
 *
 * @author Analice
 */
public class Main {

    public static void main(String[] args) throws SQLException {

        //Connection conn = ConnectionFactory.recuperaConexao();
        MongoClient client = new MongoClient();

        MongoDatabase db = client.getDatabase("ContaBanco");
        //escolher coleção
      /*  MongoCollection<Document> pes = db.getCollection("pessoa");
        MongoCollection<Document> cli = db.getCollection("cliente");
        MongoCollection<Document> cont = db.getCollection("conta");
        MongoCollection<Document> func = db.getCollection("conta");*/

        CrudMongo crud = new CrudMongo();

        String nome;
        String profissao;
        String funcao;
        String endereco;
        int idCliente;
        int idFuncionario;
        int idPessoa;
        long numero;
        double saldo;
        
        Pessoa pessoa = new Pessoa();
        Funcionario funcionario = new Funcionario();
        Conta conta = new Conta();
        Cliente cliente = new Cliente();

       /* Document novaPessoateste = null;
        Document novoCliente = null;
        Document novaConta = null;
        Document novoFunc = null;*/

        /*pes.insertOne(novaPessoateste);
        cli.insertOne(novoCliente);
        cont.insertOne(novaConta);
        func.insertOne(novoFunc);*/
        
        //Escolher uma opção
        int opcao = 0;

        while (opcao != 1) {

            opcao = Integer.parseInt(JOptionPane.showInputDialog("Informe a opcao desejada\n "
                    + "[1] Cadastrar Pessoa\n"));

            switch (opcao) {
                case 1:
                    //Cadastro da pessoa - Aqui é necessario cadastrar o nome;
                    nome = JOptionPane.showInputDialog("Informe o nome da pessoa: ");
                    // idPessoa = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ID da pessoa: "));
                    pessoa = new Pessoa(nome);
                    System.out.println("Cadastro de: " + nome);
//                    pessoa.insertOne(novaPessoateste);
                    int opcao2 = 0;
                    while (opcao2 != 3) {
                        opcao2 = Integer.parseInt(JOptionPane.showInputDialog("Informe a opcao desejada\n "
                                + "[1] Cadastrar Cliente\n"
                                + "[2] Cadastrar Funcionario\n"
                                + "[3] Consultar Conta\n"
                                + "[4] Sair"));

                        switch (opcao2) {

                            case 1:
                                //Cadastro do cliente, informando o id, o endereco e a profissão
                                //idCliente = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do cliente: "));
                                endereco = JOptionPane.showInputDialog("Informe o endere�o: ");
                                profissao = JOptionPane.showInputDialog("Informe a profiss�o: ");
                                cliente = new Cliente(nome, endereco, profissao);
                                System.out.println(cliente);
                               // cli.insertOne(novoCliente);

                                //buscar o id para depois cadastrar a conta
                                //O cliente cadastrado informar� o n�mero da conta, o saldo inicial e o tipo da conta
                                String entrada = JOptionPane.showInputDialog("Informe o n�mero da conta: ");
                                numero = Long.parseLong(entrada);
                                String entradaa = JOptionPane.showInputDialog("Informe o saldo inicial: ");
                                saldo = Double.parseDouble(entradaa);
                                if (conta.setSaldo(saldo)) {
                                    System.out.println("Saldo: R$ " + saldo);
                                } else {
                                    saldo = 0;
                                    System.out.println("Saldo negativo");
                                    saldo = Double.parseDouble(JOptionPane.showInputDialog("Saldo negativo, informe novamente o saldo: "));
                                }
                                entrada = JOptionPane.showInputDialog("Informe o tipo da conta: ");
                                String tipo = (entrada);
                                //Fechar conta se o saldo for positivo
                                conta = new Conta(numero, saldo, tipo, cliente);
                                //cont.insertOne(novaConta);
                                crud.inserts(pessoa, cliente, conta);

                                int operacao = 0;
                                while (operacao != 2) {
                                    //Aqui � necess�rio escolher alguma op��o
                                    entrada = JOptionPane.showInputDialog("Informe a opção desejada\n "
                                            + "[1] Depositar\n"
                                            + "[2] Sacar\n"
                                            + "[3] Sair");
                                    operacao = Integer.parseInt(entrada);

                                    switch (operacao) {

                                        case 1:
                                            //� necess�rio adicionar o valor do dep�sito para somar com o saldo
                                            entrada = JOptionPane.showInputDialog("Valor do Dep�sito");
                                            double valorDeposito = Double.parseDouble(entrada);
                                            System.out.println("\nDep�sito: R$ " + valorDeposito);
                                            conta.depositar(valorDeposito);
                                            System.out.println(conta);
                                            break;

                                        case 2:
                                            //� necess�rio adicionar o valor de saque para diminuir com o saldo
                                            entrada = JOptionPane.showInputDialog("Valor do Saque");
                                            double valorSaque = Double.parseDouble(entrada);
                                            System.out.println("\nSaque: R$ " + valorSaque);
                                            if (conta.sacar(valorSaque)) {
                                                System.out.println(conta);
                                            } else {
                                                System.out.println("Saldo insuficiente");
                                            }
                                            //crud.insert(pessoa, cliente, funcionario, conta);
                                            break;
                                    }
                                }
                                break;

                            case 2:
                                //Cadastro do funcionario, informando o id e a sua fun��o
                                // idFuncionario = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do funcionario: "));
                                funcao = JOptionPane.showInputDialog("Informe a fun��o: ");
                                funcionario = new Funcionario(nome, funcao);
                                System.out.println(funcionario);
                                crud.insertFuncionario(pessoa, funcionario);
                                //func.insertOne(novoFunc);
                                break;

                            case 3:
                                //Consultar a conta
                                String consultar;
                                nome = (JOptionPane.showInputDialog("Informe o nome do cliente: "));
                               // consultar = (nome);
                                //List<Conta> consulta = crud.searchFilter(idCliente);
                                pessoa = new Pessoa(nome);
                                crud.consultar(pessoa);
                              //  System.out.println("Informa��es da conta: " + consultar);
                                break;
                        }
                    }
                    break;
            }
        }
    }
}
