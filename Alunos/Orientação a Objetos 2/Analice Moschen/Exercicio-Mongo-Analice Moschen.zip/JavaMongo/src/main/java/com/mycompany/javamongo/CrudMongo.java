package com.mycompany.javamongo;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Aggregates.limit;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.bson.Document;

/**
 *
 * @author Analice
 */
public class CrudMongo {

    //  public static void main(String[] args) {
    /*  MongoClient client = new MongoClient();

        MongoDatabase db = client.getDatabase("ContaBanco");

        //escolher coleção
        MongoCollection<Document> pes = db.getCollection("pessoa");
        MongoCollection<Document> cliente = db.getCollection("cliente");
        MongoCollection<Document> conta = db.getCollection("conta");
        //private MongoCollection<Document> func = db.getCollection("funcionario");*/
    private MongoClient client = new MongoClient();

    private MongoDatabase db = client.getDatabase("ContaBanco");

    //escolher coleção
    private MongoCollection<Document> pes = db.getCollection("pessoa");
    private MongoCollection<Document> cliente = db.getCollection("cliente");
    private MongoCollection<Document> conta = db.getCollection("conta");
    private MongoCollection<Document> func = db.getCollection("funcionario");
    
    /*Document novaPessoateste = (new Document("_id", 5)
                .append("nome", "Janaina"));
        pessoa.insertOne(novaPessoateste);*/
 /* Document pessoa2 = new Document("_id", 2)
                .append("nome", "Danieli")
                .append("funcionario", Arrays.asList(new Document()
                        .append("funcao", "Gerente")
                ));

        pes.insertOne(pessoa2);
    }*/
    
 /* Document pessoa2 = new Document("_id", 7)
                .append("nome", "Alice")
                .append("cliente", Arrays.asList(new Document()
                        .append("endereco", "Rua Pereira")
                        .append("profissao", "Médica")
                        .append("conta", Arrays.asList(new Document()
                                .append("numero", 12345)
                                .append("saldo", 100)
                                .append("tipo", "Poupança")
                        ))));

        pes.insertOne(pessoa2);

        //update
        pes.updateOne(Filters.eq("nome", "Danieli"),
                new Document("$set", new Document("nome", "Mariazinha")));

        //delete
        pes.deleteOne(Filters.eq("nome", "Janaina"));
        System.out.println(pes);

        //consulta simples
        Document consulta = pes.find().first();
        System.out.println(pes);*/
    
   
    public void inserts(Pessoa pessoa, Cliente cliente, Conta conta) {

        Document pessoaGerada = pes.find().sort(new Document("_id", -1)).first();
        pessoaGerada.get("_id");
        int pessoaG = (int) pessoaGerada.get("_id");
        pessoa.setIdPessoa(pessoaG);
        // int pessoaG = Integer.parseInt((String) pessoaGerada.get("_id"));
        Document novaPessoa = new Document("_id", pessoa.getIdPessoa()+1)
                .append("nome", pessoa.getNome())
                .append("cliente", Arrays.asList(new Document()
                        .append("endereco", cliente.getEndereco())
                        .append("profissao", cliente.getProfissao())
                        .append("conta", Arrays.asList(new Document()
                                .append("numero", conta.getNumero())
                                .append("saldo", conta.saldo())
                                .append("tipo", conta.getTipo())
                        ))));
        pes.insertOne(novaPessoa);
    }

    public void insertFuncionario(Pessoa pessoa, Funcionario funcionario) {
        Document pessoaGerada2 = pes.find().sort(new Document("_id", -1)).first();
        pessoaGerada2.get("_id");
        int pessoaG = (int) pessoaGerada2.get("_id");
        pessoa.setIdPessoa(pessoaG);
        // int pessoaG = Integer.parseInt((String) pessoaGerada.get("_id"));
        Document novaPessoa = new Document("_id", pessoa.getIdPessoa()+1)
                .append("nome", pessoa.getNome())
                .append("funcionario", Arrays.asList(new Document()
                        .append("funcao", funcionario.getFuncao())
                ));
        pes.insertOne(novaPessoa);
    }

    /*  Document novoCliente;
        novoCliente =  cliente.find().sort(new Document("_id", -1).first
                .append("endereco", "Rua Marte")
                .append("profissao", "Engenheira"));
        conta.insertOne(novoCliente);
    
//inserir conta
     /*Document novaConta = conta.find().sort(new Document("_id", -1)).first()
                .append("numero", 12345)
                .append("saldo", 100)
                .append("tipo", "Poupança");

        conta.insertOne(novaConta);*/
 /*Document novaPessoateste = (new Document("_id", 5)
            .append("nome", "Janaina"));
    pessoa.insertOne(novaPessoateste);

    // Document clientenovo = pessoa.find().sort(new Document("_id", -1)).first()
                .append("endereco", "Rua Boa")
                .append("profissao", "Professora");

        cliente.insertOne(clientenovo);*/
 /*===============================*/
 
//update
    public void update() {
        pes.updateOne(Filters.eq("nome", "Danieli"),
                new Document("$set", new Document("nome", "Juarez")));
    }

    //delete
    public void delete() {
        pes.deleteOne(Filters.eq("nome", "Ana"));
        System.out.println(pes);
    }

    //consulta simples
    public void consulta() {
        Document consulta = pes.find().first();
        System.out.println(pes);
    }

    public void consultar(Pessoa pessoa) {
        MongoCursor<Document> resultados = pes.find(Filters.eq("nome", pessoa.getNome())).iterator();

        while (resultados.hasNext()) {
            System.out.println(resultados.next());
        }

    }
}
        //}
