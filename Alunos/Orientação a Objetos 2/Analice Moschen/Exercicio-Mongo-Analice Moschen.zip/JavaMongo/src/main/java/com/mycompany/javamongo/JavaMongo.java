package com.mycompany.javamongo;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.Date;
import org.bson.Document;

/**
 *
 * @author Analice
 */
public class JavaMongo {

    public static void main(String[] args) {
        //estabelece conexão
        MongoClient cliente = new MongoClient();

        //escolher uma coleção
        MongoDatabase db = cliente.getDatabase("testeMongo");

        //escolher coleção
        MongoCollection<Document> aluno = db.getCollection("aluno");

        //consulta simples
        /*Document consulta = aluno.find().first();
        System.out.println(consulta);*/
        //consulta com iterator
        /*MongoCursor<Document> resultados = aluno.find
        (Filters.eq("semestre", 4)).iterator();
        while(resultados.hasNext()){
            System.out.println(resultados.next());
        }*/
        
        //inserir
        Document novoAluno = new Document("_id", 5)
                .append("nome", "Fulano")
                .append("ra", 145623)
                .append("email", "fulano@utfpr.edu.br")
                .append("semestre", 6)
                .append("disciplinas", Arrays.asList(new Document()
                        .append("nome", "Orientação a Objetos")
                        .append("professor", "Huilson José Lorenzi")
                        .append("data_inicio", new Date(2022, 10, 11))
                        .append("data_final", new Date(2022, 12, 23)),
                        new Document()
                                .append("nome", "Orientação a Objetos")
                                .append("professor", "Huilson José Lorenzi")
                                .append("data_inicio", new Date(2022, 10, 11))
                                .append("data_final", new Date(2022, 12, 23))));
        aluno.insertOne(novoAluno);

        //update
        aluno.updateOne(Filters.eq("nome", "Fulano"),
                new Document("$set", new Document("nome", "Joana")));
        
        //delete
        aluno.deleteOne(Filters.eq("nome", "Joana"));

    }

}
