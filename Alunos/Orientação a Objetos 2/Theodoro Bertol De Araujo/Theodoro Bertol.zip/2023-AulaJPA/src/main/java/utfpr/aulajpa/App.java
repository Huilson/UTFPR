package utfpr.aulajpa;

import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import utfpr.aulajpa.dao.AlunoDAO;
import utfpr.aulajpa.dao.DisciplinaDAO;
import utfpr.aulajpa.model.Aluno;
import utfpr.aulajpa.model.Disciplina;
import utfpr.aulajpa.util.Factory;

//Aluno Theo Bertol
public class App {

    public static void main(String[] args) {

        // Como possuo um factory posso instanciar quantos managers forem precisos
        EntityManager em = Factory.getEntityManager();

        AlunoDAO alunoDAO = new AlunoDAO(em);
        DisciplinaDAO disDAO = new DisciplinaDAO(em);
        Scanner scanner = new Scanner(System.in);

        // Opção para entrada de dados do usuário
        int opcao = 0;

        // Instancia um objeto
        Disciplina dis = new Disciplina("Sistemas Distribuídos", 12);
        // Aluno aluno = new Aluno("José", 3, 4.9, dis);

        // Estabelece conecção com o banco
        em.getTransaction().begin();

        // Instancia para managed
        // alunoDAO.salvar(aluno);
        // Instancia para removed
        // alunoDAO.excluir(aluno);
        // Instancia para merge
        // alunoDAO.atualizar(aluno);
        // salva as alterações
        // em.getTransaction().commit();
        while (opcao != 5) {

            System.out.println("Digite uma opção:");

            System.out.println("1 - Salvar Aluno ");
            System.out.println("2 - Excluir Aluno");
            System.out.println("3 - Atualizar Aluno");
            System.out.println("4 - Buscar Aluno por disciplina");
            System.out.println("5 - Sair");

            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {

                case 1:
                    System.out.println("Informe o nome do aluno:\n");
                    String nomeAluno = scanner.nextLine();
                    scanner.nextLine();

                    System.out.println("Informe o RA do aluno:\n");
                    int raAluno = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Informe a média do aluno:\n");
                    double mediaAluno = scanner.nextDouble();
                    scanner.nextLine();

                    System.out.println("Informe o id da disciplina dele:\n");
                    long idDisciplina = scanner.nextLong();
                    scanner.nextLine();

                    DisciplinaDAO disDao2 = new DisciplinaDAO(em);
                    Disciplina disciplina = disDao2.buscaDisciplina(idDisciplina);

                    Aluno aluno = new Aluno(nomeAluno, raAluno, mediaAluno, disciplina);
                    alunoDAO.salvar(aluno);

                    System.out.println("Aluno Cadastrado!");

                    break;

                case 2:
                    System.out.println("Digite o ID do Aluno: ");
                    Long id = Long.parseLong(scanner.nextLine());

                    em.getTransaction().begin();

                    Aluno alunoExcluido = alunoDAO.buscaAluno(id);

                    alunoDAO.excluir(alunoExcluido);

                    em.getTransaction().commit();

                    System.out.println("Aluno excluído com sucesso!");

                    break;

                case 3:
                    System.out.println("Digite o ID do Aluno: ");
                    Long idAtualizar = Long.parseLong(scanner.nextLine());

                    System.out.println("Digite o novo nome do Aluno: ");
                    String novoNome = scanner.nextLine();

                    System.out.println("Digite o novo RA do Aluno: ");
                    int novoRA = Integer.parseInt(scanner.nextLine());

                    System.out.println("Digite a nova Média final do Aluno: ");
                    double novaMedia = Double.parseDouble(scanner.nextLine());

                    Aluno alunoAtualizar = alunoDAO.buscaAluno(idAtualizar);

                    alunoAtualizar.setNome(novoNome);
                    alunoAtualizar.setRA(novoRA);
                    alunoAtualizar.setMedia(novaMedia);

                    em.getTransaction().begin();

                    alunoDAO.atualizar(alunoAtualizar);

                    em.getTransaction().commit();

                    System.out.println("Aluno atualizado com sucesso!");

                    break;

                case 4:
                    System.out.println("Digite o nome da Disciplina: ");
                    String nomeDisiciplinaBusca = scanner.nextLine();

                    List<Aluno> alunos = alunoDAO.buscaDisciplina(nomeDisiciplinaBusca);

                    for (Aluno a : alunos) {
                        System.out.println(a.getNome() + " - " + a.getRA());
                    }

                    break;

                case 5:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida!");

            }
        }

//        List<Aluno> rs = alunoDAO.buscaDisciplina("Sistemas Distribuídos");
//        rs.forEach(a -> System.out.println(a.getNome() + " com o RA: " + a.getRA()));

        em.getTransaction().commit();
        em.close();
    }
}
