package com.testeunidade.app.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ServiceDadosTest {
   
    @Test
    public void testMedia1() {
        System.out.println("media");
        double num1 = 2.0;
        double num2 = 4.0;
        ServiceDados instance = new ServiceDados();
        double expResult = 3.0;
        double result = instance.media(num1, num2);
        assertEquals(expResult, result);
    }
        @Test
    public void testMedia2() {
        System.out.println("media");
        double num1 = 4.5;
        double num2 = 8.0;
        ServiceDados instance = new ServiceDados();
        double expResult = 6.25;
        double result = instance.media(num1, num2);
        assertEquals(expResult, result);
    }
        @Test
    public void testMedia3() {
        System.out.println("media");
        double num1 = 10.0;
        double num2 = 9.0;
        ServiceDados instance = new ServiceDados();
        double expResult = 9.5;
        double result = instance.media(num1, num2);
        assertEquals(expResult, result);
    }
    
}
