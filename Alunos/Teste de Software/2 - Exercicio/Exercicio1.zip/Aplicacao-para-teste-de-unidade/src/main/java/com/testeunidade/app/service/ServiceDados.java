package com.testeunidade.app.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceDados {
    public double media(double num1, double num2){
        return (num1 + num2)/2;
    }
}
