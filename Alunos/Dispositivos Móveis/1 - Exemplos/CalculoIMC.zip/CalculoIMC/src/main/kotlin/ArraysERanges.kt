fun main() {
    //label do contructor precisar estar na ordem certa
    val p1 = Pessoa("Huilson", 90.1, 1.62, 0.0)

    //label instanciado você pode organizar na ordem que desejar
    val p2 = Pessoa(nome = "Analice", imc = 0.0, altura=1.68, peso=59.1)

//    var pessoa:Pessoa? = null
//
//    pessoa?.let {
//        it.imc.toString()
//    }
//    if (pessoa != null) {
//        println(pessoa.imc)
//    }

    p1.calculoIMC()
    println(p1.imc)

    if(p2.engordar(11.1)){
        println(p2.peso)
    }else{
        println("Rosquinhas não engordam")
    }

    val salarios:DoubleArray = DoubleArray(4)
    salarios[0] = 120.50
    salarios[1] = 20.00
    salarios[2] = 99.99
    salarios[3] = 3.00

    val salarios2 = doubleArrayOf(120.50, 20.00, 999.99, 3.00)
    /*
        var maior = 0.0
        for(salario in salarios2){
            if(salario > maior)
                maior = salario
        }
        maior = salarios2.max()
        println(maior)

        var menor = Double.MIN_VALUE
        salarios2.forEach { salario ->
            if (salario < menor)
                menor = salario
        }
        menor = salarios2.min()
        println(menor)

        var media = salarios2.average()
        println(media)
        println()

        //retorna true se todos os elementos do array forem maior que 100
        var verifica = salarios2.all { it > 100.00 }
        println(verifica)
        println()

        //retorna true se pelo menos um elemento for maior que 100
        var verificaUM = salarios2.any { it > 100.00}
        println(verificaUM)
        println()

        var maiores = salarios2.filter { it > 100.00 }//filtra os elementos maiores que 100
        println(maiores)
        println()

        var busca = salarios.find { it == 20.00 }//retorna o primeiro elemento que respeitar a condição
        println(busca)*/

    for(i in salarios2.indices){
        println(i)
    }

    println(salarios2.contentToString())

    //RANGES
    val serie = 1..10//vai 1 a 10
    val ate = 1.until(10)//vai 1 a 9

    val regressivo = 10 downTo 1

    val margem = 1000..5000
    val pontoParada = 200

    val alfabeto = "a".."z"

    if(pontoParada in margem){
        println("Tenho esse numero")
    }else{
        println("Não tenho esse numero")
    }
}