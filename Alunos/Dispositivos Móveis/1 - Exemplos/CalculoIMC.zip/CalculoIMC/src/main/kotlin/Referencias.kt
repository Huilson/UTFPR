fun referencia(){
    var x = 10
    var y = x

    println("Valor de x: $x")
    println("Valor de y: $y")

//    val maria = Pessoa()
//    maria.nome = "Maria"
//
//    val pedro = maria
//    pedro.nome = "Pedro"
//
//    println("O nome de Maria é: ${maria.nome}")
//    println("O nome de Pedro é: ${pedro.nome}")
}