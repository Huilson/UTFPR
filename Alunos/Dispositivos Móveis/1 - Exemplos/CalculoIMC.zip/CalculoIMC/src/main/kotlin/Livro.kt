data class Livro (
    val titulo: String,
    val autor: String,
    val anoPublicao: Int,
    val editora: String?
)
