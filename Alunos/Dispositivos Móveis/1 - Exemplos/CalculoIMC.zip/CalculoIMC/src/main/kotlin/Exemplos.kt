fun main() {
//O VAR permite que você altere o valor da sua variavel
    var pessoa = "Huilson"
    var imc = 0.0

//O VAL não permite que você altere o valor da sua variavel
    val nome: String = "Huilson"
    val peso = 90.2
    val altura = 1.62


//Para tipar uma variavel usasse :
//as variaveis em Kotlin não são fortemente tipadas
//Sempre sera preciso inicializar as variaveis
    println("O nome da nossa pessoa é: $nome")
//Kotlin é uma linguagem menos verbosa


    println("Seu peso é $peso")
    println("Sua altura é $altura")

    imc = peso / (altura * altura)
    println("Seu IMC é $imc")

    if (imc < 18.5) {
        println("Você está muito magrinho")
    } else if (imc > 24.9) {
        println("Você está muito gordinho")
    } else
        println("Você está bem")

    when {
        imc <= 18.5 -> println("Você está muito magrinho")
        imc >= 24.9 -> println("Você está muito gordinho")
        else -> println("Você está bem")
    }

//i in 0..10 para fazer um FOR normal
//i in 10 downTo 0 para far um FOR de decremento
//use o step para pular passo
    for (i in 10 downTo 0 step 2) {
        println("Contagem regressiva: $i")
    }
    var i = 5;
    while (i >= 0) {
        println("Contagem regressiva: $i")
        i--
    }
}