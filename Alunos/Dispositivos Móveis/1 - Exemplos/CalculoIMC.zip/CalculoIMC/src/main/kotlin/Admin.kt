class Admin(
    idAdmin: Int,
    password: Int,
    role: String
): User (id = idAdmin, role = role, senha = password){

    fun atribuirId(): Int{
        return id +1
    }

    //ISSO É UMA PROPRETY
    val atrubuirId: Int get() = id+1
}