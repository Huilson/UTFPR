class Pessoa(
    var nome: String,
    var peso: Double,
    val altura: Double,
    var imc: Double
) {
    /*constructor(nome: String, peso: Double, altura: Double, imc: Double){
        this.nome = nome
        this.peso = peso
        this.altura = altura
        this.imc = imc
    }*/

    fun calculoIMC() {
        this.imc = this.peso / (this.altura * this.altura)
    }

    fun engordar(valor: Double): Boolean {
        if (valor > 10) {
            println("Você não pode engordar tanto")
            return false
        } else {
            peso += valor
            return true
        }
    }
}