import java.math.BigDecimal
import java.math.RoundingMode

fun main(){
    var salarios = Array<BigDecimal>(5) { BigDecimal.ZERO }
    salarios[0] = "1000.00".toBigDecimal()
    salarios[1] = "2000.00".toBigDecimal()
    salarios[2] = "3000.00".toBigDecimal()
    salarios[3] = "4000.00".toBigDecimal()
    salarios[4] = "5000.00".toBigDecimal()

    println(salarios.contentToString())

    val aumento = "1.5".toBigDecimal()
    val salarios2: Array<BigDecimal> = salarios.map { salario ->
        if(salario < "3999.99".toBigDecimal()){
            salario + "2000.00".toBigDecimal()
        }else{
            (salario * aumento).setScale(2, RoundingMode.UP)
        }
    }.toTypedArray()

    println("Salarios com aumento:")
    println(salarios2.contentToString())

    var soma = intArrayOf(1, 2, 3).sum()

    var salariosSomados = salarios2.somatoria()
    println(salariosSomados)

    val salariosOrdenados = salarios2.sorted()
    val salariosMenores = salariosOrdenados.take(3)
    println(salariosMenores)
    val salariosMaiores = salariosOrdenados.takeLast(3)
    println(salariosMaiores)
}

fun Array<BigDecimal>.somatoria(): BigDecimal {
    return this.reduce {acumulador, valor -> acumulador + valor}
}

fun Array<BigDecimal>.media(): BigDecimal {
    return if(this.isEmpty()){
        BigDecimal.ZERO
    }else{
        this.somatoria() / this.size.toBigDecimal()
    }
}
//CRIE UMA LOGICA ONDE OS SALARIOS QUE NAO RECEBERAM 2000 REAIS DE AUMENTO
//RECEBAM O MINIMO DE 2000 REAIS

//FAÇA UMA FUNÇÃO EXTENDIDA PARA A MEDIA IGUAL NOS FIZEMOS PARA A SOMATORIA