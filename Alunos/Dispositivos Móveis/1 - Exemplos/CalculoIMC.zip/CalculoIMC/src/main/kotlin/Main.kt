fun main(){
    val livro1 = Livro(
        titulo = "Sociedade do Anel",
        autor = "J. R. R. Tolkien",
        anoPublicao = 1954,
        editora = "Martins Fontes"
    )
    val livro2 = Livro(
        titulo = "Eragon",
        autor = "Christopher Paolini",
        anoPublicao = 2002,
        editora = "Rocco"
    )
    val livro3 = Livro(
        titulo = "A Captura",
        autor = "Kathryn Lasky",
        anoPublicao = 2010,
        editora = "A Fundamento"
    )
    val livro4 = Livro(
        titulo = "O Nome do Vento",
        autor = "Patrick Rothfuss",
        anoPublicao = 2007,
        editora = "Arqueiro"
    )

    val livros: MutableList<Livro> = mutableListOf(livro1, livro2, livro3, livro4)

    livros.add(
        Livro(
            titulo = "As Duas Torres",
            autor = "J. R. R. Tolkien",
            anoPublicao = 1978,
            editora = "Martins Fontes"
        )
    )

    println(livros)
    println()
    livros.imprimiLista()

    var ordenados  = livros.sortedBy { it.anoPublicao }
    println(ordenados.imprimiLista())

    livros.filter { it.autor == "J. R. R. Tolkien" }.sortedBy { it.anoPublicao }.imprimiLista()

    livros.filter { it.autor.startsWith("P")}.sortedBy { it.autor }.imprimiLista()

}
fun List<Livro>.imprimiLista(){
    val textFormat = this.joinToString ( separator = "\n" ){
        "- ${it.titulo} de ${it.autor} no ano ${it.anoPublicao}"
    }
    println("## LISTA ##")
    println(textFormat)
}