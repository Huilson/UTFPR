open class User(
    var id: Int,
    var senha: Int,
    val role: String
) {
    fun auntencia(senha: Int): Boolean{
        return this.senha == senha
    }
}