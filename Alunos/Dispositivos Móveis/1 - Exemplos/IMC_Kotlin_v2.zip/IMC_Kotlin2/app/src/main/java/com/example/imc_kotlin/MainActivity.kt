package com.example.imc_kotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.imc_kotlin.adapter.ListaAdapter
import com.example.imc_kotlin.dao.PessoaDao
import com.example.imc_kotlin.model.Pessoa
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(R.layout.activity_main) {
    val dao = PessoaDao()
    val adapter = ListaAdapter(context = this, pessoas = dao.findAll())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configAdapter()
        configFab()
        //o RecyclerView precisa de um gerenciador
        //rview.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        adapter.refresh(dao.findAll())
    }

    fun configAdapter(){
        val rview = findViewById<RecyclerView>(R.id.rview)
        rview.adapter = adapter
    }

    fun configFab(){
        val fab = findViewById<FloatingActionButton>(R.id.fabAddPerson)
        fab.setOnClickListener {
            val intent = Intent(this, FormPessoaActivity::class.java)
            startActivity(intent)
        }
    }
}