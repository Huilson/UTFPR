package com.example.imc_kotlin.dao

import com.example.imc_kotlin.model.Pessoa

class PessoaDao {
    fun add (pessoa: Pessoa){
        pessoas.add(pessoa)
    }
    //Para não enviar a referência direta via MutableList, vamos converter
    //para List, assim só é feita a cópia do valores
    fun findAll(): List<Pessoa>{
        return pessoas.toList()
    }

    companion object{
        private val pessoas = mutableListOf<Pessoa>()
    }
}