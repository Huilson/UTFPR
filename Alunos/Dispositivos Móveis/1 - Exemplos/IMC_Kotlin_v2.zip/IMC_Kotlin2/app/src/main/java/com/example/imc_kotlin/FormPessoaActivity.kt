package com.example.imc_kotlin

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.imc_kotlin.dao.PessoaDao
import com.example.imc_kotlin.model.Pessoa

class FormPessoaActivity : AppCompatActivity(R.layout.form_pessoa){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val butao = findViewById<Button>(R.id.butao)
        butao.setOnClickListener {
            val camponome = findViewById<EditText>(R.id.campo_nome)
            val nome = camponome.text.toString()

            //Problema de conversão com campo vazios ou nulos
            val campoaltura = findViewById<EditText>(R.id.campo_altura)
            val altura = campoaltura.text.toString().toDouble()

            //Problema de conversão com campo vazios ou nulos
            val campopeso = findViewById<EditText>(R.id.campo_peso)
            val peso = campopeso.text.toString().toDouble()

            val pessoa = Pessoa(
                nome = nome,
                peso = peso,
                altura = altura,
                imc = peso/(altura*altura)
            )
            Log.i("FormPessoaActivity","OnCreate: $pessoa")
            PessoaDao().add(pessoa)
            finish()
        }
    }
}