package com.eamais.imc2.dialog

import android.content.Context
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import com.eamais.imc2.databinding.FormImgDialogBinding
import com.eamais.imc2.extentions.loadImag

class FormImgDialog (private val context: Context){
    fun showDialog(whenImageloaded:(imagem : String) -> Unit) {
        val bind = FormImgDialogBinding.inflate(LayoutInflater.from(context))
        bind. formImgButton.setOnClickListener {
            val url = bind.formImgUri.text.toString()
            bind.formImgImage.loadImag(url)

        }
        AlertDialog.Builder(context)
            .setView(bind.root)
            .setPositiveButton("Ok"){_,_->
                val url = bind.formImgUri.text.toString()
                whenImageloaded(url)
            }
            .setNegativeButton("Cancelar"){_,_->}
            .show()
    }
}