package com.eamais.imc2.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.eamais.imc2.model.Pessoa

@Dao
interface PessoaDao {

    @Query("SELECT * FROM Pessoa")
    fun buscaTodos(): List<Pessoa>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun salva(vararg pessoa: Pessoa)

    @Update
    fun atualiza(vararg pessoa: Pessoa)

    @Delete
    fun deleta(vararg pessoa: Pessoa)

    @Query("SELECT * FROM Pessoa WHERE id =  :id")
    fun buscaId(id: Long) : Pessoa?
}