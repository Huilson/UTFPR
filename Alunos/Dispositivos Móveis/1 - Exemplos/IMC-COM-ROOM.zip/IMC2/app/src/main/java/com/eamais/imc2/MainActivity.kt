package com.eamais.imc2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.eamais.imc2.adapter.ListaAdapter
import com.eamais.imc2.database.AppDatabase
import com.eamais.imc2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val adapter =  ListaAdapter(context = this)
    private val binding by lazy{
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        configRecyclerView()
        configFloatingActionButton()
    }

    override fun onResume() {
        super.onResume()
        val db = AppDatabase.instancia(this)
        val pessoaDao = db.pessoaDao()
        adapter.refreshAll(pessoaDao.buscaTodos())
    }

    private fun configFloatingActionButton() {
        val fab = binding.fab
        fab.setOnClickListener {
            //intent para registrar uma pessoa, add uma nova activity para a pilha de execução
            val intent = Intent(this, FormPessoaActivity::class.java)
            startActivity(intent)
        }
    }

    private fun configRecyclerView() {
        val rview = binding.rview
        rview.adapter = adapter
        adapter.click = { pessoa ->
            val intent = Intent(
                this, DetailPessoaActivity::class.java
            ).apply {
                putExtra(CHAVE_PESSOA, pessoa.id)
            }
            startActivity(intent)
        }
    }
}