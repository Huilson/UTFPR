package com.eamais.imc2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.eamais.imc2.database.AppDatabase
import com.eamais.imc2.database.PessoaDao
import com.eamais.imc2.databinding.ActivityFormPessoaBinding
import com.eamais.imc2.dialog.FormImgDialog
import com.eamais.imc2.extentions.loadImag
import com.eamais.imc2.model.Pessoa

class FormPessoaActivity : AppCompatActivity() {
    private val binding by lazy{
        ActivityFormPessoaBinding.inflate(layoutInflater)
    }
    private val pessoaDao : PessoaDao by lazy{
        val db = AppDatabase.instancia(this)
        db.pessoaDao()
    }
    private var url: String?= null
    private var idPessoa = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val botao = binding.botao
        botao.setOnClickListener {
            val campoNome = binding.editNome
            val nome = campoNome.text.toString()

            //problema de conversão se o campo estiver vazio
            val campoPeso = binding.editPeso
            val peso = campoPeso.text.toString().toDouble()

            //problema de conversão se o campo estiver vazio
            val campoAltura = binding.editAltura
            val altura = campoAltura.text.toString().toDouble()

            val pessoa = Pessoa(
                id = idPessoa,
                nome = nome,
                peso = peso,
                altura = altura,
                imc = peso/(altura * altura),
                image = url
            )
            Log.i("Form_Pessoa_Activity", "OnCreate: $pessoa")
            val db = AppDatabase.instancia(this)
            val pessoaDao = db.pessoaDao()
            if (idPessoa > 0){
                pessoaDao.atualiza(pessoa)
            } else{
                pessoaDao.salva(pessoa)
            }
            pessoaDao.salva(pessoa)
            finish()
        }
        idPessoa = intent.getLongExtra(CHAVE_PESSOA, 0L)

        binding.editImage.setOnClickListener {
            FormImgDialog(this).showDialog{
                imagem -> url = imagem
                binding.editImage.loadImag(url)
            }
        }
    }

    override fun onResume() {
        super.onResume()
            pessoaDao.buscaId(idPessoa)?.let {
                preencheCampos(it)
        }
    }

    private fun preencheCampos(it: Pessoa) {
        title = "Editar Pessoa"
        url = it.image
        binding.editImage.loadImag(it.image)
        binding.editNome.setText(it.nome)
        binding.editPeso.setText(it.peso.toString())
        binding.editAltura.setText(it.altura.toString())
    }
}