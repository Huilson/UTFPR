package com.eamais.imc2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.eamais.imc2.database.AppDatabase
import com.eamais.imc2.databinding.ActivityDetailPessoaBinding
import com.eamais.imc2.extentions.loadImag
import com.eamais.imc2.model.Pessoa
import kotlin.math.roundToLong

class DetailPessoaActivity : AppCompatActivity() {
    private var pessoaId: Long = 0L
    private var pessoa: Pessoa? = null
    private val binding by lazy {
        ActivityDetailPessoaBinding.inflate(layoutInflater)
    }
    private val pessoaDao by lazy {
        val db = AppDatabase.instancia(this)
        db.pessoaDao()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val db = AppDatabase.instancia(this)
        val pessoaDao = db.pessoaDao()
        when (item.itemId) {
            R.id.menu_delete -> {
                Log.i("DetailPessoaActivity", "OnOptionsItemSelected: remover")
                pessoa?.let { pessoaDao.deleta(it) }
                finish()
            }

            R.id.menu_editar -> {
                Log.i("DetailPessoaActivity", "OnOptionsItemSelected: editar")
                Intent(this, FormPessoaActivity::class.java).apply {
                    putExtra(CHAVE_PESSOA, pessoaId)
                    startActivity(this)
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        pessoaId = intent.getLongExtra(CHAVE_PESSOA, 0L)
    }

    override fun onResume() {
        super.onResume()
        pessoa = pessoaDao.buscaId(pessoaId)
        pessoa?.let {
            preencheCampos(it)
        } ?: finish()
    }

    private fun preencheCampos(pessoa: Pessoa) {
        with(binding) {
            detailImage.loadImag(pessoa.image)
            detailImc.text = pessoa.imc.roundToLong().toString()
            detailNome.text = pessoa.nome
            detailAltura.text = pessoa.altura.toString()
            detailPeso.text = pessoa.peso.toString()
        }
    }
}