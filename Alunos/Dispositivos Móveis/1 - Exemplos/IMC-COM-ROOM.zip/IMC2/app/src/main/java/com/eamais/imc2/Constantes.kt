package com.eamais.imc2

    const val CHAVE_PESSOA = "pessoaId"
