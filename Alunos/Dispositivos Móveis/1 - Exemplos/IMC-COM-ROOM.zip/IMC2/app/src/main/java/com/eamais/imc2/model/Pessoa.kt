package com.eamais.imc2.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity
@Parcelize
data class Pessoa (
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val nome: String,
    val peso: Double,
    val altura: Double,
    val imc: Double,
    val image: String? = null
    ) : Parcelable
