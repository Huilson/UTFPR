package com.eamais.imc2.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.eamais.imc2.model.Pessoa

@Database(entities = [Pessoa::class], version = 1)
abstract class AppDatabase: RoomDatabase() {
    abstract fun pessoaDao(): PessoaDao

    companion object {
        fun instancia(context: Context) : AppDatabase{
            return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                "imc.db"
            ).allowMainThreadQueries().build()
        }
    }
}