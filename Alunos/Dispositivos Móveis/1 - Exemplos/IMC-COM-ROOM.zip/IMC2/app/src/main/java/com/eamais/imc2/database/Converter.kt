package com.eamais.imc2.database

import androidx.room.TypeConverter
import java.util.Date

class Converter {
    @TypeConverter
    fun deTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateParaTimestamp(date: Date?): Long? {
        return date?.time?.toLong()
    }
}