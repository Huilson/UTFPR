package com.eamais.imc2.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.eamais.imc2.R
import com.eamais.imc2.databinding.ListaPessoasBinding
import com.eamais.imc2.extentions.loadImag
import com.eamais.imc2.model.Pessoa

import java.text.NumberFormat
import java.util.Locale

class ListaAdapter (
    pessoas: List<Pessoa> = emptyList(),
    private val context: Context,
    var click: (pessoa: Pessoa) -> Unit = {})
    : RecyclerView.Adapter<ListaAdapter.ViewHolder>() {

    private val pessoas = pessoas.toMutableList()

    //Inner Class
    //É o viewHolder quem busca a view que precisamos para trabalhar
    inner class ViewHolder(private val binding: ListaPessoasBinding):
        RecyclerView.ViewHolder(binding.root) {
        private lateinit var pessoa: Pessoa
        init {
            itemView.setOnClickListener {
                if(::pessoa.isInitialized){
                    click(pessoa)
                }
            }
        }

        fun bind(pessoa: Pessoa) {
            this.pessoa = pessoa
            val nome = binding.nome
            val altura = binding.altura
            val peso = binding.peso
            val imc = binding.imc
            val image = binding.imageView

            nome.text = pessoa.nome
            altura.text = pessoa.altura.toString()
            peso.text = pessoa.peso.toString()
            imc.text = pessoa.imc.toString()
            image.loadImag(pessoa.image)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListaPessoasBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = pessoas.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pessoa = pessoas[position]
        holder.bind(pessoa)
    }

    fun refreshAll(pessoas: List<Pessoa>) {
        this.pessoas.clear()
        this.pessoas.addAll(pessoas)
        notifyDataSetChanged()
    }
}