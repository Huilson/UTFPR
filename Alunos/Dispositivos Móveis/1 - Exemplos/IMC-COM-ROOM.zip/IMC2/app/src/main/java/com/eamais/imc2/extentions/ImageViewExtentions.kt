package com.eamais.imc2.extentions

import android.widget.ImageView
import coil.load
import com.eamais.imc2.R

fun ImageView.loadImag(url: String? = null){
    load(url){
        fallback(R.drawable.erro)
        error(R.drawable.erro)
        placeholder(R.drawable.loading)
    }
}