package com.example.imc_kotlin.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.imc_kotlin.R
import com.example.imc_kotlin.databinding.ListaPessoaBinding
import com.example.imc_kotlin.extentions.tentaCarregaImage
import com.example.imc_kotlin.model.Pessoa

class ListaAdapter(
    pessoas: List<Pessoa>,
    private val context: Context
) : RecyclerView.Adapter<ListaAdapter.ViewHolder>() {

    private val pessoas = pessoas.toMutableList()

    //inner class
    class ViewHolder(binding: ListaPessoaBinding) : RecyclerView.ViewHolder(binding.root) {
        private val nome = binding.nome
        private val peso = binding.peso
        private val altura = binding.altura
        private val imc = binding.imc
        private val image = binding.imageView

        fun bind(pessoa: Pessoa) {
            nome.text = pessoa.nome
            peso.text = pessoa.peso.toString()
            altura.text = pessoa.altura.toString()
            imc.text = pessoa.imc.toString()
            //Tratemento nulo
            //Opção 1
//            val visivel = if (image != null)
//                View.VISIBLE
//            else
//                View.GONE
//            image.visibility = visivel

            //Opção 2
            image.tentaCarregaImage(pessoa.image)
        }
    }

    //Essa função é responsável por pegar cada VIEW e fazer o processo chamado
    //BINDING para que possamos trabalhar com aquela view
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListaPessoaBinding
            .inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    //tamanho da nossa lista no ViewHolder
    override fun getItemCount(): Int = pessoas.size

    //Esse método inidica qual o item que se encontra selecionado, qual é o seu VIEWHOLDER
    //e qual é o indice (posição)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pessoa = pessoas[position]

        holder.bind(pessoa)
        Log.i("Adapter", "onBindViewHolder: $pessoa")
    }

    fun refresh(pessoas: List<Pessoa>) {
        //Usar o clear evita que o dados sejam duplicados(a não que você use um SET/MAP)
        this.pessoas.clear()
        this.pessoas.addAll(pessoas)
        notifyDataSetChanged()//avisa o Adapter para reexecutar todos os passos
        //então verifica tudo e adiciona a nova pessoa
    }
}