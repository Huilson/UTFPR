package com.example.imc_kotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.imc_kotlin.adapter.ListaAdapter
import com.example.imc_kotlin.dao.PessoaDao
import com.example.imc_kotlin.databinding.ActivityMainBinding
import com.example.imc_kotlin.model.Pessoa
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    val dao = PessoaDao()
    val adapter = ListaAdapter(context = this, pessoas = dao.findAll())
    private val binding by lazy{
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        configAdapter()
        configFab()
        Log.i("MainActivity","OnCreate: Estado criado")
        //o RecyclerView precisa de um gerenciador
        //rview.layoutManager = LinearLayoutManager(this)
    }

    override fun onStart() {
        super.onStart()
        Log.i("MainActivity","OnStart: Estado iniciado")
    }

    override fun onResume() {
        super.onResume()
        adapter.refresh(dao.findAll())
        Log.i("MainActivity","OnResume: $dao")
        Log.i("MainActivity","OnResume: Estado resumido")
    }

    override fun onPause() {
        super.onPause()
        Log.i("MainActivity","OnPause: Estado pausado")
    }

    override fun onStop() {
        super.onStop()
        Log.i("MainActivity","OnStop: Estado parado")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("MainActivity","OnDestroy: Estado destruído")
    }

    fun configAdapter(){
        val rview = binding.rview
        rview.adapter = adapter
    }

    fun configFab(){
        val fab = binding.fabAddPerson
        fab.setOnClickListener {
            val intent = Intent(this, FormPessoaActivity::class.java)
            startActivity(intent)
        }
    }
}