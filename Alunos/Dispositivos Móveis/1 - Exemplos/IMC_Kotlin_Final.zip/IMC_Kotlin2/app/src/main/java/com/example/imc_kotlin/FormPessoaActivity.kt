package com.example.imc_kotlin

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.example.imc_kotlin.dao.PessoaDao
import com.example.imc_kotlin.databinding.FormImageDialogBinding

import com.example.imc_kotlin.databinding.FormPessoaBinding
import com.example.imc_kotlin.dialog.FormImgDialog
import com.example.imc_kotlin.extentions.tentaCarregaImage
import com.example.imc_kotlin.model.Pessoa

class FormPessoaActivity : AppCompatActivity(R.layout.form_pessoa){
    private var url: String? = null

    private val binding by lazy{
        FormPessoaBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val butao = binding.butao
        butao.setOnClickListener {
            val camponome = binding.campoNome
            val nome = camponome.text.toString()

            //Problema de conversão com campo vazios ou nulos
            val campoaltura = binding.campoAltura
            val altura = campoaltura.text.toString().toDouble()

            //Problema de conversão com campo vazios ou nulos
            val campopeso = binding.campoPeso
            val peso = campopeso.text.toString().toDouble()

            val pessoa = Pessoa(
                nome = nome,
                peso = peso,
                altura = altura,
                imc = peso/(altura*altura),
                image = url
            )
            Log.i("FormPessoaActivity","OnCreate: $pessoa")
            PessoaDao().add(pessoa)
            finish()
        }
        binding.campoImage.setOnClickListener {
            FormImgDialog(this).mostraDialog(){
                imagem -> url = imagem
                binding.campoImage.tentaCarregaImage(url)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.i("FormPessoaActivity","OnResume: Estado resumido")
    }

    override fun onPause() {
        super.onPause()
        Log.i("FormPessoaActivity","OnPause: Estado pausado")
    }

    override fun onStop() {
        super.onStop()
        Log.i("FormPessoaActivity","OnStop: Estado parado")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("FormPessoaActivity","OnDestroy: Estado destruído")
    }
}