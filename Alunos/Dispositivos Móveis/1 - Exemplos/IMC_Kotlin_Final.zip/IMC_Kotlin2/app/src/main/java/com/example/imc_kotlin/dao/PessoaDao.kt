package com.example.imc_kotlin.dao

import android.util.Log
import com.example.imc_kotlin.model.Pessoa

class PessoaDao {
    fun add (pessoa: Pessoa){
        pessoas.add(pessoa)
        Log.i("PessoaDao","Add: $pessoa")
    }
    //Para não enviar a referência direta via MutableList, vamos converter
    //para List, assim só é feita a cópia do valores
    fun findAll(): List<Pessoa>{
        return pessoas.toList()
    }

    companion object{
        private val pessoas = mutableListOf<Pessoa>(        )
    }
}