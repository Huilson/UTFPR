package com.example.imc_kotlin.dialog

import android.content.Context
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import com.example.imc_kotlin.databinding.FormImageDialogBinding
import com.example.imc_kotlin.extentions.tentaCarregaImage

class FormImgDialog(private val context: Context) {
    fun mostraDialog(quandoCarregaImagem:(imagem: String) -> Unit) {
        val bind = FormImageDialogBinding.inflate(LayoutInflater.from(context))
        bind.formDialogBtn.setOnClickListener {
            val url = bind.campoUri.text.toString()
            bind.formDialogImg.tentaCarregaImage(url)
        }

        AlertDialog.Builder(context)
            .setView(bind.root)
            .setPositiveButton("OK") { _, _ ->
                val url = bind.campoUri.text.toString()
                quandoCarregaImagem(url)
            }
            .setNegativeButton("Cancel") { _, _ -> }
            .show()
    }
}