package com.example.imc_kotlin.extentions

import android.widget.ImageView
import coil.load
import com.example.imc_kotlin.R

fun ImageView.tentaCarregaImage(url: String? = null){
    load(url){
        fallback(R.drawable.falha)
        error(R.drawable.falha)
        placeholder(R.drawable.loading)
    }
}