package com.example.imc_kotlin.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.imc_kotlin.R
import com.example.imc_kotlin.model.Pessoa

class ListaAdapter (
    private val pessoas: List<Pessoa>,
    private val context: Context
        ): RecyclerView.Adapter<ListaAdapter.ViewHolder>(){

    //inner class
    class ViewHolder(view: View):RecyclerView.ViewHolder(view){
        fun bind(pessoa: Pessoa){
            //Precisamos de uma referência de view, mas nosso adapter e nosso viewHolder
            //não possuem uma referência de view, mas o nosso ReclycerView tem
            val nome = itemView.findViewById<TextView>(R.id.nome)
            nome.text = pessoa.nome
            val peso = itemView.findViewById<TextView>(R.id.peso)
            peso.text = pessoa.peso.toString()
            val altura = itemView.findViewById<TextView>(R.id.altura)
            altura.text = pessoa.altura.toString()
            val imc = itemView.findViewById<TextView>(R.id.imc)
            imc.text = pessoa.imc.toString()
        }
    }

    //Essa função é responsável por pegar cada VIEW e fazer o processo chamado
    //BINDING para que possamos trabalhar com aquela view
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        //O Inflater cria uma view exclusiva apartir de um layout (nesse caso o layout do LISTA_PESSOA)
        val inflater = LayoutInflater.from(context)

        //para inflar uma VIEW precisamos de dois parametros, o layout da view desejada, e
        //o ViewGroup(no nosso caso o ROOT) e se isso vai ser anexado ao nosso ROOT
        //NUNCA ANEXAR!!! Setar sempre como false
        val view = inflater.inflate(R.layout.lista_pessoa, parent, false)
        return ViewHolder(view)
    }

    //tamanho da nossa lista no ViewHolder
    override fun getItemCount(): Int = pessoas.size

    //Esse método inidica qual o item que se encontra selecionado, qual é o seu VIEWHOLDER
    //e qual é o indice (posição)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pessoa = pessoas[position]
        holder.bind(pessoa)
    }
}