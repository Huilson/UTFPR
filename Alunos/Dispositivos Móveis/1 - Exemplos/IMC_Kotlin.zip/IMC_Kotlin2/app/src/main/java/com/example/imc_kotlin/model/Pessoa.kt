package com.example.imc_kotlin.model

class Pessoa (
    var nome: String,
    var peso: Double,
    var altura: Double,
    var imc: Double
        )