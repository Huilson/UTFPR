package com.example.imc_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.imc_kotlin.adapter.ListaAdapter
import com.example.imc_kotlin.model.Pessoa

class MainActivity : AppCompatActivity(R.layout.activity_main) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rview = findViewById<RecyclerView>(R.id.rview)
        rview.adapter = ListaAdapter(context = this, pessoas = listOf(
            Pessoa(nome = "Huilson", peso = 82.5, altura = 1.72, imc = 0.0),
            Pessoa(nome = "Rodrigo", peso = 120.0, altura = 1.71, imc = 0.0)
        ))
        //o RecyclerView precisa de um gerenciador
        rview.layoutManager = LinearLayoutManager(this)
    }
}