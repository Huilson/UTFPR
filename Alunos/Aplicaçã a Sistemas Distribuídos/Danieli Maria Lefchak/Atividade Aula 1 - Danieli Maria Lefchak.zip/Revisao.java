/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ExAula1908;

import java.time.LocalTime;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Revisao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Scanner scan = new Scanner(System.in);//Função que declara uma variavel para ler meu teclado
        
        String msg = scan.nextLine();//le uma string
        int num = scan.nextInt();//le um inteiro
        double doub = scan.nextDouble();//le um double
        
        System.out.println(msg);
        System.out.println(num);
        System.out.println(doub);
        
        msg = String.valueOf(num);
        num = (int)doub;
        
        System.out.println(num);*/
        Scanner scan = new Scanner(System.in);
        Pessoa pes1 = new Pessoa();
        Pessoa pes2 = new Pessoa();
        
        Disciplina dis;

        System.out.println("Aluno\n");
        System.out.println("Nome: "); 
        String fulano = scan.nextLine();
        System.out.println("Cpf: ");
        String cpf = scan.nextLine();
        System.out.println("Idade: ");
        int idade = scan.nextInt();
        System.out.println("Peso: ");
        float peso = scan.nextFloat();
        System.out.println("Sexo: ");
        boolean sexo = scan.nextBoolean();
        pes1 = new Aluno(fulano, cpf, idade, peso, sexo);
        System.out.println("\n"+pes1.toString()+"\n");
        
        scan = new Scanner(System.in);
        System.out.println("Professor\n");
        System.out.println("Nome: "); 
        fulano = scan.nextLine();
        System.out.println("Cpf: ");
        cpf = scan.nextLine();
        System.out.println("Idade: ");
        idade = scan.nextInt();
        System.out.println("Peso: ");
        peso = scan.nextFloat();
        System.out.println("Sexo: ");
        sexo = scan.nextBoolean();
        pes2 = new Professor(fulano, cpf, idade, peso, sexo);
        System.out.println("\n"+pes2.toString()+"\n");
        
        scan = new Scanner(System.in);
        System.out.println("Disciplina\n");
        System.out.println("Nome: "); 
        String nmDis = scan.nextLine();
        System.out.println("Horario: "); 
        float hr = scan.nextFloat();
        dis = new Disciplina(nmDis, pes1, hr, pes2);

        System.out.println(dis.toString());
    }
    
    
}
