/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExAula1908;

import java.time.LocalTime;

/**
 *
 * @author danie
 */
public class Disciplina {
    String nome;
    Pessoa aluno;
    float hora;
    Pessoa professor;

    public Disciplina() {
    }

    public Disciplina(String nome, Pessoa aluno, float hora, Pessoa professor) {
        this.nome = nome;
        this.aluno = aluno;
        this.hora = hora;
        this.professor = professor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pessoa getAluno() {
        return aluno;
    }

    public void setAluno(Pessoa aluno) {
        this.aluno = aluno;
    }

    public float getHora() {
        return hora;
    }

    public void setHora(float hora) {
        this.hora = hora;
    }

    public Pessoa getProfessor() {
        return professor;
    }

    public void setProfessor(Pessoa professor) {
        this.professor = professor;
    }

    @Override
    public String toString() {
        return "O aluno(a) " + aluno + ",\n Está matriculado na disciplina de " + nome +  ", no horario " + hora 
                + ", \n ministrada pelo professor(a) " + professor;
    }
    
    
    
}
