/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExAula1908;

/**
 *
 * @author danie
 */
public class Pessoa {
    String nome;
    String cpf;
    int idade;
    float peso;
    boolean sexo;

    public Pessoa() {
    }

    public Pessoa(String nome, String cpf, int idade, float peso, boolean sexo) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.peso = peso;
        this.sexo = sexo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public boolean getSexo() {
        return sexo;
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    @Override
    public String toString() {
        return " Nome: " + nome + ", cpf: " + cpf + ", idade: " + idade + ", peso: " + peso + ", sexo: " + sexo;
    }
    
    void irFacul(){
        System.out.println("Aluno foi a faculdade");
    }
}
