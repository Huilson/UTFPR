/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExAula1908;

/**
 *
 * @author danie
 */
public class Professor extends Pessoa{
    int Matricula;

    public Professor() {
    }

    public Professor(String nome, String cpf, int idade, float peso, boolean sexo) {
        super(nome, cpf, idade, peso, sexo);
    }
    
    public int getMatricula() {
        return Matricula;
    }

    public void setMatricula(int Matricula) {
        this.Matricula = Matricula;
    }
    
    @Override
    void irFacul(){
        System.out.println("Professor foi a faculdade");
    }
}
