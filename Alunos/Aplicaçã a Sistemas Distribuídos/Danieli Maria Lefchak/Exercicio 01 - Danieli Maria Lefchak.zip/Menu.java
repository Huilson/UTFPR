/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CaixaEletronico;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class Menu {
    Terminal t = new Terminal();
    Conta c = new Conta();
    Transacao ts = new Transacao();
    String nome;
    int id;
    double saldo;
    double saque;
    double valDep;
    ArrayList<Conta> lista = new ArrayList();

    public void painelMenu() {
        int x = 0;

        while (x != 1) {//enquanto o x for diferente de 1 ele ira fazer esse menu
            int opc = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha uma opcao:\n"
                    + "1 - Criar Conta;\n2 - Depositar;\n3 - Sacar;\n4 - Consultar\n"));

            switch (opc) {//opcao escolhida pelo usuario
                case 1:
                    lista.add(criaConta());//insere a conta que foi retornada do metodo criaConta em um arraylist
                    System.out.println(imprimeArray());//clama o metodo que imprime os dados da conta cadastrada
                    break;
                case 2:
                    depositarDinheiro();//chama o metodo que faz um deposito

                    break;
                case 3:
                    sacarDinheiro();//chama o metodo que faz o saque

                    break;
                case 4:
                    consultaDinheiro();//chama o metodo que mostra o dados da conta

                    break;
                default:
                    JOptionPane.showConfirmDialog(null, "Opcao invalida", "Opcao", JOptionPane.WARNING_MESSAGE);//se não forem escolhidas nenhuma das opções informadas
                    //ira mostrar está mensagem de erro
                    
                    break;
            }
            
            x = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite 1 para sair", "Sair", JOptionPane.INFORMATION_MESSAGE));
            //se o usuario desejar ou não sair do looping ele deve informar a opção
        }
    }

    public Conta criaConta() {//metodo que cria uma conta retornando ela
        nome = JOptionPane.showInputDialog(null, "Informe o nome: ");//recebe o nome digitado pelo usuario
        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o id: "));//recebe o id digitado pelo usuario
        saldo = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o saldo: "));//recebe o saldo digitado pelo usuario
        c = new Conta(nome, id, saldo);//cria a conta
        
        return c;//retorna a conta criada
    }

    public String imprimeArray() {//metodo que imprime o que esta no arraylist
        String saida = "";
        for (Conta con : lista) {//a variavel con vai receber o que esta dentro da variavel lista
            saida += con + "\n";//saida vai receber o que esta dentro de conta um por um dos dados até ter todos 
        }
        return saida;//retorna a string saida que recebeu todas as informações contidas em con
    }

    public void depositarDinheiro() {//metodo que faz o deposito na conta do valor informado pelo cliente
        valDep = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor que deseja depositar: "));
        //recebe o valor de deposito digitado pelo usuario
        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe seu id: "));
        //recebe o id da conta informado pelo usuario
        
        for (Conta con : lista) {//percorre o arraylist
            if(id==con.getId()){//faz a verificação para fazer o deposito somente no id informado
                double nvValDep = ts.depositaDin(valDep, id, con.getSaldo());
                //recebe o valor que o metodo depositaDin irá retornar
                con.setSaldo(nvValDep);
                //seta o novo saldo na conta do id informado
                System.out.println(nvValDep);
                //mostra o saldo novo na tela
            }
        }   
    }

    public void sacarDinheiro() {//metodo que faz o saque na conta com o valor informado pelo cliente
        saque = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor que deseja sacar: "));
        //recebe o valor de saque digitado pelo usuario
        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe seu id: "));
        //recebe o id da conta informado pelo usuario
        t = new Terminal(20000.00, 500.00);
         //cria um novo objeto terminal que ira receber o saldo da conta e o limite de saque no terminal
         
        for (Conta con : lista) {//percorre o arraylist
            if (id == con.getId()) {//faz a verificação para fazer o saque somente no id informado
              
                try {
                    t.setDinInterno(ts.verificaTerminal(saque, t.getDinInterno(), t.getLimite()));
                    //seta o novo saldo no terminal após tirar o valor que o usuário informou dele
                    System.out.println(t.toString());
                    //imprime o novo saldo que há dentro do terminal
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                c.setSaldo(ts.sacaDin(saque, id, con.getSaldo()));
                //seta o novo saldo na conta após realizar o saque do valor que o usuário informou
                System.out.println(con.getSaldo());
                //imprime o novo saldo da conta
            }
        }
    }

    public void consultaDinheiro() {
        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe seu id: "));
        //recebe o id da conta informado pelo usuario
        for (Conta con : lista) {//percorre o arraylist
            if (id == con.getId()) {//faz a verificação para fazer consulta somente no id informado
                try {
                    ts.consultaSaldo(id, con.getNome(), con.getSaldo());
                    //chama o metodo consulta passando as informações da conta que 
                    //será consultada por parametro

                } catch (Exception e) {
                    double valTemp = t.getDinInterno() + saque;
                    t.setDinInterno(valTemp);
                    System.out.println(t.toString());
                    System.out.println(e.getMessage());
                }
            }
        }
    }
}
