/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CaixaEletronico;

import java.util.Locale;
/**
 *
 * @author danie
 */
public class CaixaEletronico {

    public static void main(String[] args) {
        Menu main = new Menu();
        main.painelMenu(); 
    }
}
