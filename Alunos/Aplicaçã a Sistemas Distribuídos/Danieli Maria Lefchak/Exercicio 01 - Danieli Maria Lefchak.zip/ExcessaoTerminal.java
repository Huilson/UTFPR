/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CaixaEletronico;

/**
 *
 * @author danie
 */
public class ExcessaoTerminal extends RuntimeException{
    public ExcessaoTerminal(String mensagem){
        super(mensagem);
    }
}
