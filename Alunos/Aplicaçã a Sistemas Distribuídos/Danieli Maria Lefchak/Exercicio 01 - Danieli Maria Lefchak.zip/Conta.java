/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CaixaEletronico;

/**
 *
 * @author danie
 */
public class Conta {
    private String nome;
    private int id;
    private double saldo;

    public Conta() {
    }
    
    public Conta(String nome, int id, double saldo) {
        this.nome = nome;
        this.id = id;
        this.saldo = saldo;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Conta{" + "nome=" + nome + ", id=" + id + ", saldo=" + saldo + '}';
    }
}
