/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CaixaEletronico;

/**
 *
 * @author danie
 */
public class Terminal {
    private double dinInterno;
    private double limite;

    public Terminal() {
    }
    
    public Terminal(double dinInterno, double limite) {
        this.dinInterno = dinInterno;
        this.limite = limite;
    }

    public double getDinInterno() {
        return dinInterno;
    }

    public void setDinInterno(double dinInterno) {
        this.dinInterno = dinInterno;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    @Override
    public String toString() {
        return "Terminal{" + "dinInterno=" + dinInterno + ", limite=" + limite + '}';
    }
}
