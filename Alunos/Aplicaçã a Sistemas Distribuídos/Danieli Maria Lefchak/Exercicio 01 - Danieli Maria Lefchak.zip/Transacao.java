/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CaixaEletronico;

/**
 *
 * @author danie
 */
public class Transacao {
    //metodo que valida o saque no terminal recebendo por parametro o valor do saque, o valor exitente no terminal e o limite do dia
    public double verificaTerminal(double saque, double dinInterno, double limite){
        //se o saque for menor ou igual ao valor existente no terminal e o saque for menor ou igual ao limite
        //ele iria realizar o saque no terminal
        if(saque <= dinInterno && saque <= limite){
            System.out.println("Sacando dinheiro do terminal");
            
            return dinInterno - saque;
        } else{
            //caso contrario ele irá cair na excessao que ira mostrar a mensagem
            throw new ExcessaoTerminal("Limite ou não há dinheiro suficiente para o saque");
        }
    }
    
    //metodo que realiza o saque na conta recebendo por parametro o valor do saque, o id da conta e o saldo da conta
    public double sacaDin(double saque, int id_conta, double saldo){
        //se o saque for menor ou igual ao saldo existente na conta
        //ele iria realizar o saque na conta
        if(saque<=saldo){
            System.out.println("Sacando dinheiro");
            double val = saldo-saque;
            //percebi que ele estava pegando lixo de memoria quando estava testando essa parte de saque e 
            //então resolvi criar um novo atributo/variavel que ira receber o valor do saque
            return val;
        } else {
            //caso contrario ele irá cair na excessao que ira mostrar a mensagem
            throw new ExcessaoTerminal("Não foi possivel sacar o dinheiro");
        } 
    }
    
    //metodo que realiza o deposito na conta recebendo por parametro o valor do deposito, o id da conta e o saldo da conta
    public double depositaDin(double deposito, int id_conta, double saldo){
        System.out.println("Depositando dinheiro");
        //realiza o deposito do valor informado e retorna o novo saldo
        double valDep = deposito + saldo;
        return valDep;
    }
    
    //metodo que realiza a consulta na conta recebendo por parametro o id da conta, o nome do usuario e o saldo da conta
    public void consultaSaldo(int id_conta, String nome, double saldo){
        System.out.println("Conta: " + id_conta + " \nNome: " + nome + " \nSaldo: " + saldo + "\n");
    }
}
