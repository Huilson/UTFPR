package com.adcaixaeletronico;

/**
 *
 * @author Analice
 */

public class Transacao {

    double verificaTerminal(double saque, double dinInterno, double limite) {
        if (saque <= dinInterno && saque <= limite) {
            System.out.println("Tirando dinheiro do terminal");
            return dinInterno - saque;
        } else {
            throw new ExcessaoTerminal("Limite excedido ou não há dinheiro suficiente para realizar o saque!");
        }
    }

    //Métodos
    double sacaDin(double saque, int id_conta, double saldo) {
        double novoSaldo;//atributo para receber o valor de saldo - saque
        if (saque <= saldo) {
            System.out.println("\nSacando dinheiro...");
            novoSaldo = saldo - saque;
            return novoSaldo;
        } else {
            throw new ExcessaoTerminal("Não foi possível sacar o dinheiro");
            //return saldo;
        }
    }

    double depositoDin(double deposito, int id_conta, double saldo) {
        double novoSaldo;//attributo que recebe o valor de deposito + saldo
        System.out.println("\nDepositando dinheiro...");
        novoSaldo = deposito + saldo;
        return novoSaldo;
    }

    void consultaSaldo(int id_conta, String nome, double saldo) {
        System.out.println("Conta: " + id_conta + "\nNome: " + nome + "\nSaldo: " + saldo);
    }
}
