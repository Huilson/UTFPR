package com.adcaixaeletronico;

import java.util.Scanner;

/**
 *
 * @author Analice
 */

public class CaixaEletronico {

    public static void main(String[] args) {
        Menu m = new Menu();      
        m.opcoesMenu(); 
    }
    
}
