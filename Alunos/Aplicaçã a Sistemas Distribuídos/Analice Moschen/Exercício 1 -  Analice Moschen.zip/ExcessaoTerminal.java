package com.adcaixaeletronico;

/**
 *
 * @author Analice
 */

public class ExcessaoTerminal extends RuntimeException{
    public ExcessaoTerminal(String mensagem){
        super(mensagem);
    }
}
