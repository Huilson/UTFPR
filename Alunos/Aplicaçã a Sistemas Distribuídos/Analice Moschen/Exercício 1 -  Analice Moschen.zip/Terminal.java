package com.adcaixaeletronico;

/**
 *
 * @author Analice
 */

public class Terminal {
    
    //Atributos
    double dinInterno;
    double limite;

    //Constructor
    public Terminal(){
        
    }
    
    public Terminal(double dinInterno, double limite) {
        this.dinInterno = dinInterno;
        this.limite = limite;
    }
    
    //Get e Set
    public double getDinInterno() {
        return dinInterno;
    }

    public void setDinInterno(double dinInterno) {
        this.dinInterno = dinInterno;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    @Override
    public String toString() {
        return "\nTerminal" + "\nDinheiro Interno: " + dinInterno + "\nlimite: " + limite;
    }
    
}
