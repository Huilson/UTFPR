package com.adcaixaeletronico;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Analice
 */
public class Menu {

    //Terminal t = new Terminal();
    Terminal terminal = new Terminal(10000.00, 600.00);//Saldo da conta e limite
    Conta conta = new Conta();
    Transacao ts = new Transacao();
    ArrayList<Conta> listaConta = new ArrayList();
    String nome;
    String entrada;
    double deposito;
    double saque;
    int id;
    double saldo;

    /*String nome = "Analice";
    int id = 1;
    double saldo = 100.00;
    double saque = 200.00;*/
    public void opcoesMenu() {

        int i = 0;
        while (i != 1) {
            //Scanner menu = new Scanner(System.in);
            //Escolher uma opção
            int opcao = Integer.parseInt(JOptionPane.showInputDialog("Informe a opção desejada\n "
                    + "1 - Cadastrar cliente\n"
                    + "2 - Depositar\n"
                    + "3 - Sacar\n"
                    + "4 - Consultar conta\n"));
            //int opcao = menu.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Cadastrar Cliente");
                    listaConta.add(criarConta());
                    break;

                case 2:
                    System.out.println("\nDepositar");
                    depositar();
                    break;

                case 3:
                    System.out.println("\nSacar");
                    sacar();
                    break;

                case 4:
                    System.out.println("\nConsultar Conta");
                    consultar();
                    break;

                default:
                    System.out.print("\nOpção Inválida, tente novamente...");
                    break;
            }
        }
    }

    public Conta criarConta() {
        // O cliente/pessoa deve informar o seu nome, o id e o saldo
        nome = JOptionPane.showInputDialog("Informe o nome do cliente: ");
        id = Integer.parseInt(JOptionPane.showInputDialog("Informe o ID: "));
        saldo = Double.parseDouble(JOptionPane.showInputDialog("Informe o saldo inicial "));

        conta = new Conta(nome, id, saldo);//dados da Conta
        System.out.println(conta);//Apresentar a conta no console
        return conta;
    }

    public void sacar() {
        saque = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor de saque: "));//Guarda o valor do saque informado
        id = Integer.parseInt(JOptionPane.showInputDialog("Informe o seu ID: "));//
        System.out.println("\nSaque de R$ " + saque);//Mostra o valor de saque

        for (Conta c : listaConta) {
            if (id == c.getId()) {//Se o id informado for existente, será sacado dinheiro da conta
                try {
                    terminal.setDinInterno(ts.verificaTerminal(saque, terminal.getDinInterno(), terminal.getLimite()));
                    System.out.println(terminal);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                
                c.setSaldo(ts.sacaDin(saque, id, c.getSaldo()));//
                System.out.println("R$ " + c.getSaldo());//Apresentar o novo saldo
            } else {
                //Essa mensagem será apresentada caso o ID informado não existir.
                System.out.println("Esse ID não existe! Não foi possível realizar o saque de " + saque);
            }
        }
    }

    public void depositar() {
        //É necessário adicionar o valor do depósito para somar com o saldo
        deposito = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor de depósito: "));//Guarda o valor do depósito informado
        id = Integer.parseInt(JOptionPane.showInputDialog("Informe o seu ID: "));
        System.out.println("\nDepósito de R$ " + deposito);//Apresenta o valor de depósito

        for (Conta c : listaConta) {
            if (id == c.getId()) {//Se o id informado for existente, será depositado o valor na conta
                double novoSaldo = ts.depositoDin(deposito, id, c.getSaldo());
                c.setSaldo(novoSaldo);
                System.out.println("R$ " + novoSaldo);
            } else {
                //Essa mensagem será apresentada caso o ID informado não existir.
                System.out.println("Esse ID não existe! Não foi possível realizar o depósito de " + deposito);
            }
        }
    }

    public void consultar() {
        id = Integer.parseInt(JOptionPane.showInputDialog("Informe o seu ID: "));//Informar o id para fazer a comparação

        for (Conta c : listaConta) {
            if (id == c.getId()) {
                ts.consultaSaldo(id, c.getNome(), c.getSaldo());
            } else {
                System.out.println("Esse ID não existe! Não foi possível consultar a conta!");
            }
        }
    }

}
