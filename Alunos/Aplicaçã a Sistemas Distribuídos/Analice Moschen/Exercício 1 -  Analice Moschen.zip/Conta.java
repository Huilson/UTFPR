package com.adcaixaeletronico;

/**
 *
 * @author Analice
 */

public class Conta {

    String nome;
    int id;
    double saldo;

    //Constructor
    public Conta() {

    }

    public Conta(String nome, int id, double saldo) {
        //Atributos
        this.nome = nome;
        this.id = id;
        this.saldo = saldo;
    }

    //Get e Set
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "\nConta de " + nome + "\nID:" + id + "\nSaldo: R$ " + saldo;
    }

}
