package utfpr.aulaudp;
        
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ServidorUDP {

    private DatagramSocket ds; //Socket para estabelecer a comunicação
    private byte[] buffer = new byte [10000]; //Array de buffer que levará a mensagem serializada

    public ServidorUDP(DatagramSocket ds) {
        this.ds = ds;
    }
    
    public Pessoa dadosPessoa() throws IOException, ClassNotFoundException {
        
        while(true){
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
            ds.receive(datagram);

            //Converte os bytes recebidos para o objeto
            byte[] bytesRecebidos = datagram.getData();
            ByteArrayInputStream streamByte = new ByteArrayInputStream(bytesRecebidos);
            ObjectInputStream objetoStream = new ObjectInputStream(streamByte);
            
            //Desserializando o objeto
            Pessoa pessoaRecebida = (Pessoa) objetoStream.readObject();
            objetoStream.close();
            
            System.out.println("Dados recebidos");
            System.out.println("Nome: " + pessoaRecebida.getNome());
            System.out.println("Altura: " + pessoaRecebida.getAltura());
            System.out.println("Peso: " + pessoaRecebida.getPeso());
            String imc = String.format("%.2f", pessoaRecebida.getPeso() / (pessoaRecebida.getAltura() * pessoaRecebida.getAltura()));
            imc = imc.replace(',', '.');
            System.out.println("IMC: " + imc);

            byte[] sendData = imc.getBytes();

            DatagramPacket respostaDatagram = new DatagramPacket(sendData, sendData.length, datagram.getAddress(), datagram.getPort());
            ds.send(respostaDatagram);
                    
            bytesRecebidos = new byte[10000];
            
            return pessoaRecebida;
        }
        
    }
    
    public static void main(String[] args) throws SocketException, UnknownHostException, IOException, ClassNotFoundException{
        DatagramSocket ds = new DatagramSocket(8081);
        ServidorUDP servidor = new ServidorUDP(ds);
        System.out.println("O servidor subiu!");
        servidor.dadosPessoa();
    }
}
