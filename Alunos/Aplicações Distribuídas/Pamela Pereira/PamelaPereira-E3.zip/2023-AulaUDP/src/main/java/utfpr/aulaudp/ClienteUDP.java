package utfpr.aulaudp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class ClienteUDP {
    
    private DatagramSocket ds; //Socket para estabelecer a comunicação
    private byte[] buffer; //Array de buffer que levará a mensagem serializada
    private InetAddress ip; //É o endereço do cliente/servidor

    public ClienteUDP(DatagramSocket ds, InetAddress ip) {
        this.ds = ds;
        this.ip = ip;
    }
    
    public Pessoa dadosPessoa() throws IOException, ClassNotFoundException {
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("Pamela");
        pessoa.setAltura(1.60);
        pessoa.setPeso(85.00);
        
        while(true){
            
            //Serializando o objeto em bytes
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            ObjectOutputStream pessoaStream = new ObjectOutputStream(byteStream);
            pessoaStream.writeObject(pessoa);
            pessoaStream.flush();
            byte[] sendData = byteStream.toByteArray();
            pessoaStream.close();
            
            //Enviando os bytes por DatagramPacket
            DatagramPacket pacoteEnvio = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("localhost"), 8081);
            ds.send(pacoteEnvio);
            
            //Limpar buffer
            sendData = new byte[1024];
            
            //Receber a resposta do servidor
            DatagramPacket pacoteRecebido = new DatagramPacket(sendData, sendData.length);
            ds.receive(pacoteRecebido);
            
            String imc = new String (pacoteRecebido.getData(), 0, pacoteRecebido.getLength(), "UTF-8");
            double imcConvertido = Double.parseDouble(imc);
            pessoa.setImc(imcConvertido);
            
            System.out.println(pessoa.getNome());
            System.out.println(pessoa.getAltura());
            System.out.println(pessoa.getPeso());
            System.out.println("ICM calculado");
            System.out.println(pessoa.getImc());
            
            return pessoa;
        }
    }
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        DatagramSocket ds = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        ClienteUDP cliente = new ClienteUDP(ds, ip);
        
        System.out.println("O cliente se conectou!");
        
        cliente.dadosPessoa();
    }
    
}
