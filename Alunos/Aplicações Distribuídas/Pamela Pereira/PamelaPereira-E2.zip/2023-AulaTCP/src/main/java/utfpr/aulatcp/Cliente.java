package utfpr.aulatcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //Estabelece uma conexão com o servidor local ouvindo na porta 8080
        Socket socket = new Socket("127.0.0.1", 8080);
        
        //Permite o cliente informar seus dados
        Scanner entrada = new Scanner(System.in);
        
        //O objeto pessoa utilizado no exercicio
        Pessoa pessoa = new Pessoa();
        
        //Serialização do objeto com ObjectOutputStream para enviar ao servidor
        ObjectOutputStream entradaPessoa = new ObjectOutputStream(socket.getOutputStream());
        
        //O usuário informa os dados da pessoa
        System.out.println("Informe o nome da pessoa: ");
        pessoa.setNome(entrada.nextLine());
        System.out.println("Informe a idade da pessoa: ");
        pessoa.setIdade(entrada.nextInt());
        entrada.nextLine();
        System.out.println("Informe o peso da pessoa: ");
        pessoa.setPeso(Double.parseDouble(entrada.nextLine()));
        System.out.println("Informe a altura da pessoa: ");
        pessoa.setAltura(Double.parseDouble(entrada.nextLine()));
        
        
        //Serialização e envio para o servidor
        entradaPessoa.writeObject(pessoa);
        
        //Definir os stream de saída de dados (Para conversa)
        //DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        
        ObjectInputStream imcPessoa = new ObjectInputStream(socket.getInputStream());
        Pessoa imc = (Pessoa) imcPessoa.readObject();
        
        System.out.printf("" + pessoa.getNome() + ", seu IMC é: %.2f \n", (imc.getImc()));
        
        if (imc.getImc() < 18.5){
            System.out.println("Você está abaixo do Peso!");
        }
        else if (imc.getImc() >= 18.5 && imc.getImc() <= 24.9){
            System.out.println("Você está com o Peso Normal!");
        }
        else if (imc.getImc() >= 25 && imc.getImc() <= 29.9){
            System.out.println("Você está com sobrepeso!");
        }
        else if (imc.getImc() >= 30 && imc.getImc() <= 34.9){
            System.out.println("Você está com Obesidade Grau I!");
        }
        else if (imc.getImc() >= 35 && imc.getImc() <= 40){
            System.out.println("Você está com Obesidade Grau II!");
        }
        else {
            System.out.println("Você está com Obesidade Grau III!");
        }
        
        //O metodo writeUTF envia uma mensagem/String para o servidor
        //Vale lembrar que essa mensagem é serializada automaticamente em byte pela linguagem JAVA
        //saida.writeUTF("Oi servidor!");
        
        //Definir o stream de entrada de dados (Para ouvir)
        //DataInputStream entrada = new DataInputStream(socket.getInputStream());

        //Quando recebo a mensagem ela está em bytes, para deserializar a mensagem ou uma string usamos readUTF()
        //String novaMensagem = entrada.readUTF();
        //System.out.println(novaMensagem);
        
        //Ao encerrar fecha tudo, seguindo a ordem da pilha
        imcPessoa.close();
        entradaPessoa.close();
        socket.close();
    }
}
