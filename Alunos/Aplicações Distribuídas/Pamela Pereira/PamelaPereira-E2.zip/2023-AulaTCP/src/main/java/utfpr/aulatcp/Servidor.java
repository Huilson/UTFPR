package utfpr.aulatcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Servidor {

    public static void main(String[] args) throws IOException, ClassNotFoundException{
        //Definir o ServerSocket (porta de conexao)
        ServerSocket serverSocket = new ServerSocket(8080);
        System.out.println("O servidor está ouvindo na porta 8080");
        
        //Abrir a comunicação (ou seja, ficar ouvindo)
        Socket socket = serverSocket.accept();
        
        //Mostrar o IP do cliente que vai estar conectado
        System.out.println("Um cliente se conectou: " +socket.getInetAddress().getHostAddress());
        
        //Definir um stream de entrada para o servidor (Para ouvir)
        //DataInputStream entrada = new DataInputStream(socket.getInputStream());
        ObjectInputStream entradaPessoa = new ObjectInputStream(socket.getInputStream());
        Pessoa dadosPessoa = (Pessoa) entradaPessoa.readObject();

        System.out.println("Dados recebidos: ");
        System.out.println("Nome: " + dadosPessoa.getNome());
        System.out.println("Idade: " + dadosPessoa.getIdade());
        System.out.println("Altura: " + dadosPessoa.getAltura());
        System.out.println("Peso: " + dadosPessoa.getPeso());

        dadosPessoa.setImc(dadosPessoa.getPeso() / (dadosPessoa.getAltura() * dadosPessoa.getAltura()));
        
        //Quando recebo a mensagem ela está em bytes, para deserializar a mensagem ou uma string usamos readUTF()
        //String mensagem = entrada.readUTF();
        //System.out.println(mensagem);
        
        //Definir uma stream de saida para o servidor (Para conversar)
        //DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        //String novaMensagem = "Oi cliente, eu sou o servidor!";
        //saida.writeUTF(novaMensagem);
        ObjectOutputStream saidaPessoa = new ObjectOutputStream(socket.getOutputStream());
        saidaPessoa.writeObject(dadosPessoa);
        
        //Ao terminar a conversa fecha tudo
        saidaPessoa.close();
        entradaPessoa.close();
        socket.close();
        serverSocket.close();
    }
}
