package org.example;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //Define serversocket
        ServerSocket serversocket = new ServerSocket(8080);
        System.out.println("O servidor esta ouvindo na porta 8080");

        //Abre a comunicação
        Socket socket = serversocket.accept();

        //Mostrar o IP do cliente que vai estar conectado
        System.out.println("Um cliente se conectou: " + socket.getInetAddress().getHostAddress());


        ObjectInputStream entrada  = new ObjectInputStream(socket.getInputStream());
        Pessoa pessoa = (Pessoa) entrada.readObject();

        //Calcula o IMC
        pessoa.setImc(pessoa.getPeso() / (pessoa.getAltura() * pessoa.getAltura()));

        ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
        saida.writeObject(pessoa);

        //Ao terminar a conversa fecha tudo, seguindo a ordem da pilha
        saida.close();
        entrada.close();
        socket.close();
        serversocket.close();

    }
}
