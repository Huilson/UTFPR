package org.example;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Cliente {
    public static void main(String[] args) throws IOException,ClassNotFoundException{
        //Conexão com o servidor na porta 8080
        Socket socket = new Socket("127.0.0.1", 8080);

        //Para conversa definimos o stream de saída de dados
        ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
        Pessoa pessoa = new Pessoa("Lucas",23,83,1.80);
        saida.writeObject(pessoa);


        //Para ouvir definimos o stream de entrada de dados
        ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
        pessoa = (Pessoa) entrada.readObject();


        if (pessoa.getImc() < 16) {
            System.out.println("Magreza grave");
        } else if (pessoa.getImc() < 17) {
            System.out.println( "Magreza moderada");
        } else if (pessoa.getImc() < 18.5) {
            System.out.println( "Magreza leve");
        } else if (pessoa.getImc() < 25) {
            System.out.println( "Saudável");
        } else if (pessoa.getImc() < 30) {
            System.out.println( "Sobrepeso");
        } else if (pessoa.getImc() < 35) {
            System.out.println( "Obesidade Grau I");
        } else if (pessoa.getImc() < 40) {
            System.out.println( "Obesidade Grau II(severa)");
        } else {
            System.out.println( "Obesidade Grau III(mórbida)");
        }

        //Fecha tudo seguindo a ordem da pilha
        entrada.close();
        saida.close();
        socket.close();
    }
}
