package utfpr.exercicio2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
               
        ServerSocket serverSocket = new ServerSocket(8080);
        System.out.println("O servidor esta ouvindo na porta 8080");
        
        Socket socket = serverSocket.accept();
        System.out.println("Um cliente se conectou: " + socket.getInetAddress().getHostAddress());

        ObjectInputStream entradaDados = new ObjectInputStream(socket.getInputStream());    
        ObjectOutputStream saidaDados = new ObjectOutputStream(socket.getOutputStream()); 
        
        Pessoa pessoa = (Pessoa)entradaDados.readObject();
        String resultado = pessoa.resultadoImc(pessoa.getPeso(), pessoa.getAltura());        
        System.out.println("Resultado: "+ resultado);
        
        saidaDados.writeObject(pessoa);
        
        entradaDados.close();
        saidaDados.close();
        socket.close();
    }  
}
