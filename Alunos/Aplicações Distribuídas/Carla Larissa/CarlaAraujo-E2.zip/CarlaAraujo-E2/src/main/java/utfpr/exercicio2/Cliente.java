package utfpr.exercicio2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Pessoa pessoa = new Pessoa(); 
        Scanner scan = new Scanner(System.in); 
        
        Socket socket = new Socket("127.0.0.1",8080);
        
        ObjectOutputStream saidaDados = new ObjectOutputStream(socket.getOutputStream());        
        ObjectInputStream entradaDados = new ObjectInputStream(socket.getInputStream());
        
        System.out.println("Informe seu nome: ");
        pessoa.setNome(scan.next());
        System.out.println("Informe sua idade: ");
        pessoa.setIdade(scan.nextInt());
        System.out.println("Informe seu peso: ");
        pessoa.setPeso(scan.nextDouble());
        System.out.println("Informe sua altura: ");
        pessoa.setAltura(scan.nextDouble());
        
        saidaDados.writeObject(pessoa);        
        Pessoa p = (Pessoa)entradaDados.readObject();
        
        System.out.println("Nome: " + p.getNome()+" Idade: " + p.getIdade()+" Peso: "+p.getPeso()+" Altura: "+p.getAltura());
        
        entradaDados.close();
        saidaDados.close();
        socket.close();
    }
    
}
