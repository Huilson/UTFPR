
package utfpr.jogodaforca;

import java.util.Scanner;



public class Hud {
    
    private JogoDaForca jogo; 
    
    Scanner scanner = new Scanner (System.in);
    char op;
    private char pernad = '/';
    private char pernae = '\\';
    private char tronco = '|';
    private char cabeca = '0';
    private char bracod = '-';
    private char bracoe = '-';
    private char chute = ' ';
    
    private String boneco ="/ \\" +
                           "-|-\n"+
                            "0\n";
    
    private void criarLinhas( int i )
    {
        for (int j = 0; j < i; j++)
            System.out.println();
    }
    
    public void mostraChutes ()
    {
        String chutes = jogo.getChutes();
        chutes.codePoints().forEach(codePoint -> {
            char c = (char) codePoint;
            System.out.print(c + " ");
        });
    }
    
    //Tela inicial do jogo, constroi a classe das regras de negócio do jogo e seta seus parâmetros
    public void telaInicial(){
        jogo = new JogoDaForca();
        System.out.println("Escolha a dificuldade do jogo (1-Facil, 2-Medio ou 3-Dificil):");
        int op = scanner.nextInt();
        jogo.setDificuldade(op);
        jogo.sorteiaPalavra();
        jogo.populaTracos();
    }
    
    //método que imprime os componentes da forca a cada tentativa, desenho (a fazer) e palavras
    public void imprimeForca()
    {
        System.out.println("Numero de tentativas restantes: " + jogo.getTentativas() );
        System.out.print("Chutes dados >> ");
        mostraChutes();
        criarLinhas(1);
        
        
        
        /*char[] boneco = new char[this.boneco.length()];
        this.boneco.getChars(0, this.boneco.length(), boneco, 0);
        for (int j = 6; j > jogo.getTentativas() ; j--) {
            if ( boneco[j] == '\n' )
            {
                System.out.println(boneco[j]);
                j--;   
            }
            System.out.print(boneco[j]);
        }
        System.out.println();*/
        
        String tracos = jogo.getTracos();
        tracos.codePoints().forEach(codePoint -> {
            char c = (char) codePoint;
            System.out.print(c + " ");
        });
        
        //System.out.println(jogo.getTracos());
    }
    
    //método apenas para ler chute na na stream system
    public void leChute()
    {
        System.out.println("\nChute: ");
        chute = scanner.next().charAt(0);
    }
    
    //telaDoJogo porém este é o fluxo principal do jogo, regido pelos elementos da tela
    public void telaDoJogo()
    {
        System.out.println(op == 's' || op == 'S' ? "Comecando novamente" : "");
        do
        {
            telaInicial();
            while ( !jogo.isGanho() && !jogo.isDerrotado() )
            {
                this.imprimeForca();
                this.leChute();
                jogo.verificaAcerto( chute );
            }
            if ( jogo.isGanho() )
            {
                
                //System.out.println("A palavra era " + jogo.getPalavraSorteada());
                this.imprimeForca();
                criarLinhas(1);
                System.out.println("Parabéns você venceu!");
                System.out.println("Continuar jogando? (s) ou (n)");
                op = scanner.next().charAt(0);
            } else
            {
                criarLinhas(1);
                System.out.println("Que pena, você perdeu.");
                System.out.println("Deseja jogar novamente? (s) ou (n)");
                op = scanner.next().charAt(0);
            }
        }while(op == 's' || op == 'S');
    }
}
