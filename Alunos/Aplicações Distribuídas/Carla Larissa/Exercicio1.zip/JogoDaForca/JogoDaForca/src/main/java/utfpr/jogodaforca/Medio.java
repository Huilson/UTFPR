
package utfpr.jogodaforca;

public enum Medio {
    dificil, 
    newton, 
    passeio, 
    boboca, 
    garrafa, 
    cerveja, 
    teclado, 
    loteria, 
    cadeira, 
    cozinha, 
    janela
}
