
package utfpr.jogodaforca;

public enum Dificil {
    paralelepipedo, 
    interruptor, 
    projetor, 
    felicidade, 
    facilidade, 
    apartamento, 
    caminhão, 
    computador, 
    jaguatirica, 
    capilaridade, 
    eletronica, 
    software, 
    
}
