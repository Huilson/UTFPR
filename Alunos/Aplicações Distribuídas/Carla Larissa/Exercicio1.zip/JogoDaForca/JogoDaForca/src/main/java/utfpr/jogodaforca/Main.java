
package utfpr.jogodaforca;
import java.util.Arrays;
import java.util.List;
import java.util.Random; 

public class Main {

    public static void main(String[] args) {
        
        Hud hud = new Hud();
        //hud.telaInicial(); chamada agora ocorre no fluxo do jogo
        hud.telaDoJogo();
        System.exit(0);
    }
}
