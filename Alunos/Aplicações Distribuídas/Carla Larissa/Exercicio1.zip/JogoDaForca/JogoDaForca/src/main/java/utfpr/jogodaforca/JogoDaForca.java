package utfpr.jogodaforca;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class JogoDaForca {
    private int dificuldade, tentativas = 6, acertos;
    private int tentativasMax;
    private String palavraSorteada;
    private String tracos = "";
    private boolean ganho = false;
    private boolean derrotado = false;
    String chutes = "";
    Random gerador = new Random(); 
    
    public static final int FACIL = 1;
    public static final int MEDIO = 2;
    public static final int DIFICIL = 3;

    public String getChutes() {
        return chutes;
    }

    public void setChutes(String chutes) {
        this.chutes = chutes;
    }
    
    public String getTracos() {
        return tracos;
    }

    public boolean isGanho() {
        return ganho;
    }

    public void setGanho(boolean ganho) {
        this.ganho = ganho;
    }

    public boolean isDerrotado() {
        return derrotado;
    }

    public void setDerrotado(boolean derrotado) {
        this.derrotado = derrotado;
    }
        
    public JogoDaForca ()
    {
    }
    
    public int getAcertos() {
        return acertos;
    }

    public void setAcertos(int acertos) {
        this.acertos = acertos;
    }
    
    public int getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(int dificuldade) {
        this.dificuldade = dificuldade;
    }

    public int getTentativas() {
        return tentativas;
    }

    public void setTentativas(int tentativas) {
        this.tentativas = tentativas;
    }

    public String getPalavraSorteada() {
        return palavraSorteada;
    }

    public void setPalavraSorteada(String palavraSorteada) {
        this.palavraSorteada = palavraSorteada;
    }
    
    
    public void populaTracos()
    {
        for (int i = 0 ; i < palavraSorteada.length() ; i++)
            tracos += "_";
    }
    
    //sorteia a palavra usando o método do professor, que é transformar um enum em uma lista e sorteia a partir dela
    public void sorteiaPalavra ()
    {
        
        switch (this.dificuldade)
        {
            // usa constante declarada no inicio para controle da dificuldade
            case  FACIL:
                List<Facil> listFacil = Arrays.asList(Facil.values());
                int i = gerador.nextInt(listFacil.size() - 1);
                palavraSorteada = listFacil.get(i).toString();
                //System.out.println("Palavra sorteada: " + listFacil.get(i).toString());
                break;
            case MEDIO:
                List<Medio> listMedio = Arrays.asList(Medio.values());
                i = gerador.nextInt(listMedio.size() - 1);
                palavraSorteada = listMedio.get(i).toString();
//                System.out.println("Palavra sorteada: " + listMedio.get(i).toString());
                break;
            case DIFICIL:
                List<Dificil> listDificil = Arrays.asList(Dificil.values());
                i = gerador.nextInt(listDificil.size() - 1);
                palavraSorteada = listDificil.get(i).toString();
//                System.out.println("Palavra sorteada: " + listDificil.get(i).toString());
                break;
        }
    }
    
    //Método completo para adicionar acertos e erros
    public void verificaAcerto( char chute )
    {
        //Cria vetor de caractere que sera itera e representa a string que guarda a exibicao da palavra (com underlines)
        char[] t = new char[palavraSorteada.length()];
        tracos.getChars(0, palavraSorteada.length(), t, 0);
        tracos = new String();
        
        //Monta nova string de acordo com a logica
        int j = 0;
        for (int i = 0 ; i < palavraSorteada.length() ; i++) {
            //se acerto entra no if e coloca a letra encontrada
            if( chute == palavraSorteada.charAt(i) && t[i] == '_')
            {
                j++;
                this.acertos++;
                t[i] = chute;
            }
            //senao simplesmente coloca um '_'
                tracos += (String.valueOf(t[i]));
        }
        //se acertos desta classe é igual o tamanho da palavra sorteada o jogo foi ganho
        if ( acertos == palavraSorteada.length() )
            this.ganho = true;
        
        //se tentativas chegarem a um o jogo foi perdido
        if ( j == 0 )
        {
            chutes += chute;
            if ( this.tentativas-- == 1 )
                this.derrotado = true;
        }
    }
}
