package utfpr.aulaudp;

import java.io.Serializable;

public class PessoaUDP implements Serializable {

    private String nome;
    private int idade;
    private double peso;
    private double altura;

    public PessoaUDP() {
    }

    public PessoaUDP(double peso, double altura) {
        this.peso = peso;
        this.altura = altura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public String resultadoImc(double peso, double altura) {
        double imc;

        imc = (peso / (altura * altura));

        if (imc < 20) {
            return " Usuário considerado: Magro";
        } else if (imc >= 20 && imc <= 24) {
            return "Usuário considerado: Normal";
        } else if (imc >= 25 && imc <= 29) {
            return "Usuário considerado: Acima do Peso";
        } else if (imc >= 30 && imc <= 34) {
            return "Usuário considerado: Obeso";
        } else {
            return "Usuário considerado: Muito Obeso";
        }
    }
    
    @Override
    public String toString() {
        return "PessoaUDP{" + "nome=" + nome + ", idade=" + idade + ", peso=" + peso + ", altura=" + altura + '}';
    }

}
