package utfpr.aulaudp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;


public class ClienteUDP {

    private final DatagramSocket ds;//socket para estabelecer a comunicação
    private byte[] buffer = new byte[65535];;//array de buffer que levará a mensagem serializada
    private final InetAddress ip; //e o endereço do cliente servidor
    Scanner scan = new Scanner(System.in);
    PessoaUDP pessoaUdp = new PessoaUDP();
    
    public ClienteUDP(DatagramSocket ds, InetAddress ip) {
        this.ds = ds;
        this.ip = ip;
    }
    
    public void conversa () throws IOException{
        
        while (true) {    

            //entrada de dados pelo usário
            System.out.println("Informe seu nome: ");
            pessoaUdp.setNome(scan.next());
            System.out.println("Informe sua idade: ");
            pessoaUdp.setIdade(scan.nextInt());
            System.out.println("Informe seu peso: ");
            pessoaUdp.setPeso(scan.nextDouble());
            System.out.println("Informe sua altura: ");
            pessoaUdp.setAltura(scan.nextDouble());
            
            //fluxo de saída que os dados são gravados em uma matriz de bytes
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            //ObjectOutputStream grava tipos de dados de objetos em um OutputStream
            ObjectOutputStream os = new ObjectOutputStream(outputStream);     
            //writeObject é usado para gravar um objeto no fluxo
            os.writeObject(pessoaUdp);
            //String msg = "Nome: " + pessoaUdp.getNome() + " Idade: "+ pessoaUdp.getIdade()+" Peso: "
                 //+pessoaUdp.getPeso() + " Altura: "+pessoaUdp.getAltura();
                 
            //Os dados podem ser recuperados usando toByteArray()
            buffer = outputStream.toByteArray();
            
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length, ip,8081);
            
            ds.send(datagram);
            
            ds.receive(datagram);
            
            String msgRecebida = new String(datagram.getData(),0,datagram.getLength());
            System.out.println("O servidor disse: "+ msgRecebida);
        }
    }
    
    public static void main(String[] args) throws IOException{
         
        DatagramSocket ds = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        ClienteUDP client = new ClienteUDP(ds, ip);        
        System.out.println("O servidor subiu!");     
        client.conversa();
    }

}
