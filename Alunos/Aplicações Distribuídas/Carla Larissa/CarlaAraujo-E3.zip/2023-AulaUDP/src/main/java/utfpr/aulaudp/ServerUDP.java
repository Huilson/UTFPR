package utfpr.aulaudp;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class ServerUDP {

    private final DatagramSocket ds;//socket para estabelecer a comunicação
    private byte[] buffer = new byte[65535];//array de buffer que levará a mensagem serializada
    //InetAddress ip; //e o endereço do cliente servidor
    PessoaUDP pessoaUdp = new PessoaUDP();
    
    public ServerUDP(DatagramSocket ds) {
        this.ds = ds;
    }

    public void conversa() throws IOException {

        while (true) {
            
            //criando um pacote de datagramas nao estamos estabelecendo a conexao mas sim 
            //enviando o pacote para alguem que pode estar ouvindo ou nao
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
            
            //espera um pacote de datagramas
            ds.receive(datagram);
            
            //é preciso deserializar o datagram
            String msgRecebida = new String(datagram.getData(),0,datagram.getLength());
            System.out.println("O cliente disse: "+msgRecebida);

            //ByteArrayInputStream contém um buffer interno que contém bytes que podem ser lidos do fluxo
            ByteArrayInputStream in = new ByteArrayInputStream(buffer);
            //ObjectInputStream desserializa dados primitivos e objetos previamente escritos 
            ObjectInputStream is = new ObjectInputStream(in);
   
            try {
                //readObjecté usado para ler um objeto do fluxo
                pessoaUdp = (PessoaUDP) is.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
              
            String resultado =  pessoaUdp.resultadoImc(pessoaUdp.getPeso(), pessoaUdp.getAltura());        
            //exibir o resultado
            buffer = resultado.getBytes();
            
            //todo o datagrama possui em seu cabeçalho o endereço de origem do packet
            InetAddress ip = datagram.getAddress(); 
            int porta = datagram.getPort(); 
            //para retornarmos a mensagem para o cliente precisamos reescrever nosso datagrama
            //com as informações de ip e porta, o antigo datagrama será coletado pelo garbage collector da jvm 
            //e a informação sera perdida
            datagram = new DatagramPacket(buffer, buffer.length, ip, porta);

            //envia o pacote com o destino descrito no cabeçalho do packet 
            ds.send(datagram);
 
        }//fim while
    }

    public static void main(String[] args) throws SocketException, UnknownHostException, IOException{
        
        DatagramSocket ds = new DatagramSocket(8081);
        //InetAddress ip = new InetAddress.getByName("localhost");
        ServerUDP server = new ServerUDP(ds);
        System.out.println("O servidor subiu!");    
        server.conversa();   
    }
}
