/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utfpr.ad_tcp_socket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.xml.crypto.Data;
import utfpr.ad_tcp_socket.Pessoa;

/**
 *
 * @author josea
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8080);
          
            Socket socket = serverSocket.accept();
            System.out.println("Cliente se conectou!");
            
            ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
            Pessoa pessoa = (Pessoa) entrada.readObject();            
            
            pessoa.setImc(pessoa.getPeso() / (pessoa.getAltura() * pessoa.getAltura()));           
            
            ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
            saida.writeObject(pessoa);
            
            socket.close();
            serverSocket.close();
            
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
  
}