/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utfpr.ad_tcp_socket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author josea
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
                
        Socket socket = new Socket("127.0.0.1",8080);        
        
        ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
        Pessoa pessoa = new Pessoa("José",87, 1.75,35,0);
        saida.writeObject(pessoa);  
               
        ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
        Pessoa pessoaRecebida = (Pessoa) entrada.readObject();                
        
        double imc = pessoaRecebida.getImc();
        
        if (imc < 18.5) {
            System.out.println("O IMC do "+pessoa.getNome()+ " é de " + imc+" considerado Abaixo do Peso");            
        } else if (imc < 25) {
            System.out.println("O IMC do "+pessoa.getNome()+ " é de " + imc+" considerado com o peso Normal");            
        } else if (imc < 30) {
            System.out.println("O IMC do "+pessoa.getNome()+ " é de " + imc+" considerado Sobrepeso");            
        } else {
            System.out.println("O IMC do "+pessoa.getNome()+ " é de " + imc+" considerado com Obesidade");            
        } 
        entrada.close();
        saida.close();
        socket.close();
        
        
    }
    
}
