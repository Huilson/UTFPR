/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.jogodaforca;
import java.util.Arrays;
    import java.util.Random;
    import java.util.Scanner;
    

/**
 *
 * @author Jefferson
 */




public class JogoDaForca {
    
    // Lista de palavras definidas
    private static String[] PLVR_FACIL = {
        "SONHO","COMUM","CLAVA","TEMER","VIL","REU","EMO","BRIO","BREU","NOIA" };
                  
    private static String[] PLVR_MEDIO = {
        "HESITAR","AFERIR","FATICO","NOMADE","IDONEA","ARAUTO","PROLIXO","LUXURIA","TRAFEGO","MONTURO",
        "ZEBRADO","WALKMAN","MODESTIA","REPUDIAR","HEPATICO"};
                
    private static final String[] PLVR_DIFICIL = {
        "PNEUMOULTRAMICROSCOPICOSSILICOVULCANOCONIOTICO","INCONSTITUCIONALMENTE","MULTIDIMENSIONALIDADE",
        "OPORTUNIDADE","NOMENCLATURA","CORDIALIDADE","EGOCENTRISMO",
        "CONVALIDAÇAO","MANUFATURADO","ANTECIPADAMENTE","IDEOLOGICAMENTE",
        "NEOCOLONIALISMO","CONSUBSTANCIADO","IMPERMEABILIZANTE","ELETROCARDIOGRAMA",
        "EXTRAJUDICIALMENTE","REPRESENTATIVIDADE","CONTEMPORANEAMENTE",
        "ESPECIALMENTE","ORIGINALMENTE" };    

    private static final int FACIL = 5;
    private static final int MEDIO = 10;
    private static final int DIFICIL = 20;

    // Adiciona as palavras nas Dificuldades
    private static void adicionarPalavra(String novaPalavra, int dificuldade) {
    
        switch (dificuldade) {

        case 1:
            PLVR_FACIL = Arrays.copyOf(PLVR_FACIL, PLVR_FACIL.length + 1);
            PLVR_FACIL[PLVR_FACIL.length - 1] = novaPalavra;
        break;
        
        case 2:
            PLVR_MEDIO = Arrays.copyOf(PLVR_MEDIO, PLVR_MEDIO.length + 1);
            PLVR_MEDIO[PLVR_MEDIO.length - 1] = novaPalavra;
        break;
        
        }  
        
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Bem-vindo ao Jogo da Forca!");
        System.out.println("Escolha a dificuldade:");
        System.out.println("1 - Fácil");
        System.out.println("2 - Médio");
        System.out.println("3 - Difícil");
        int dificuldade = scanner.nextInt();

        int maxTentativas = 0;      
        String palavraEscolhida = "";       
        
        System.out.println("Deseja inserir novas palavras?");
        System.out.println("1 - Sim");
        System.out.println("2 - Não");
        int nPlv = scanner.nextInt();
        
        if (nPlv == 1){
            for (int i = 0; i < 5; i++) {
                System.out.println("Digite a palavra #" + (i + 1) + ":");
                String novaPalavra = scanner.next().toUpperCase();
                adicionarPalavra(novaPalavra,dificuldade);
            } 
        };
        
        // Define as tentativas maximas e a Palavra
        switch (dificuldade) {

        case 1:
            maxTentativas = FACIL;  
            palavraEscolhida = PLVR_FACIL[random.nextInt(PLVR_FACIL.length)].toUpperCase();
        break;

        case 2:
            maxTentativas = MEDIO;
            palavraEscolhida = PLVR_MEDIO[random.nextInt(PLVR_MEDIO.length)].toUpperCase();

        break;

        case 3:
         maxTentativas = DIFICIL;
         palavraEscolhida = PLVR_DIFICIL[random.nextInt(PLVR_DIFICIL.length)].toUpperCase();

        break; 

        }
        
        // Cria uma copia da string com _ substituindo os caracteres
        StringBuilder palavraAtual = new StringBuilder("_".repeat(palavraEscolhida.length()));
        StringBuilder letrasUsadas = new StringBuilder();
        int tentativas = 0;

        while (tentativas < maxTentativas) {
            System.out.println("\nPalavra: " + palavraAtual);
            System.out.println("Letras usadas: " + letrasUsadas);
            System.out.println("Tentativas restantes: " + (maxTentativas - tentativas));
            
            // Possibilita a tentativa de acertar a palavra
            if ((tentativas >= 3 && dificuldade == 1) ||
                (tentativas >= 5 && dificuldade == 2) ||
                (tentativas >= 10 && dificuldade == 3)) {

                System.out.println("Gostaria de tentar acertar a palavra?\n1 - Sim\n2 - Não");
                int tPlv = scanner.nextInt();
                //System.out.print("Digite a Palavra: ");
                if (tPlv == 1) {
                    System.out.println("Digite a Palavra: ");
                    String plvDig = scanner.next().toUpperCase();

                    if (plvDig.equalsIgnoreCase(palavraEscolhida)) {
                        System.out.println("\nParabéns! Você acertou a palavra: " + palavraEscolhida);
                        break;
                    } else {
                        System.out.println("\nInfelizmente está incorreto, a palavra era: " + palavraEscolhida);
                        break;
                    }
                }
            }         
            
            
            System.out.print("Digite uma letra: ");
            char palpite = scanner.next().toUpperCase().charAt(0);

            if (letrasUsadas.indexOf(String.valueOf(palpite)) != -1) {
                System.out.println("Você já tentou essa letra!");
                continue;
            }

            letrasUsadas.append(palpite).append(" ");

            if (palavraEscolhida.indexOf(palpite) != -1) {
                for (int i = 0; i < palavraEscolhida.length(); i++) {
                    if (palavraEscolhida.charAt(i) == palpite) {
                        palavraAtual.setCharAt(i, palpite);
                    }
                }
                if (palavraAtual.toString().equals(palavraEscolhida)) {
                    System.out.println("\nParabéns! Você acertou a palavra: " + palavraEscolhida);
                    break;
                }
            } else {
                System.out.println("Letra incorreta.");
                tentativas++;
            }
        }

        if (tentativas == maxTentativas) {
            System.out.println("\nSuas tentativas acabaram! A palavra era: " + palavraEscolhida);
        }

        scanner.close();
    }


           
       
    }
    

