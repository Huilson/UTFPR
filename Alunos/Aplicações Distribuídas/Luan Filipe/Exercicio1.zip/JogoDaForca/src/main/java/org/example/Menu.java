package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {
    public void startMenu(){
        while ( true ) {
            Scanner sc = new Scanner( System.in );
            System.out.println( "Escolhe uma opção: \n" +
                "1 - Novo jogo" +
                "\n0 - Sair" );

            switch ( sc.nextInt( ) ) {
                case 1:
                    System.out.println("Começando novo jogo..." );
                    break;
                case 0:
                    System.out.println("Obrigado por jogar!" );
                    return;
                default:
                    System.out.println("Opção inválida." );
                    continue;

            }

            final String palavra = sorteiaPalavra( );

            if(palavra == null){
                System.out.println("Obrigado por jogar!" );
                return;
            }

            List palavraQuebrada = new ArrayList<>( );
            List progressoAdivinhacao = new ArrayList<>( );

            //Adicionando a palavra sorteada a uma lista e completando a lista de adivinhação com ""
            for ( int i = 0; i < palavra.length( ); i++ ) {
                palavraQuebrada.add( palavra.substring( i, i + 1 ) );
                progressoAdivinhacao.add( "_" );
            }

            // Chama a função para executar o jogo
            playGame( palavra, palavraQuebrada, progressoAdivinhacao );

        }
    }

    private static void playGame( String palavra, List palavraQuebrada, List progressoAdivinhacao ) {

        int maxTentativas = 7;
        String letrasJaUsadas = "";

        // Imprimindo a quantidade de campos da palavra sorteada
        for ( Object i : progressoAdivinhacao ) {
            System.out.print( i + " " );
        }

        Scanner sc = new Scanner( System.in );

        //loop da adivinhação do jogador
        while ( maxTentativas > 0 ) {

            System.out.print( "\nEscolha uma letra (ou tente adivinhar a palavra): " );
            String letra = sc.nextLine( );

            //Comparando para apenas uma letra
            if ( letra.length( ) == 1 ) {

                if ( letrasJaUsadas.contains( letra ) ) {
                    System.out.println( "A letra " + letra + " já foi informada." );
                    continue;
                }

                letrasJaUsadas += letra + " ";
                // Verifica a existencia da letra dentro da palavra sorteada:
                if ( palavra.contains( letra ) ) {//caso a palavra contenha a letra, passa para a proxima parte

                    for ( int i = 0; i < palavra.length( ); i++ ) {
                        //Percorre cada letra da palavra com substrings
                        //caso a letra esteja na palavra,
                        //Altera o mesmo index no progresso de adivinhação
                        //Substituindo-o pela letra
                        if ( palavra.substring( i, i + 1 ).equals( letra ) ) {
                            progressoAdivinhacao.set( i, letra );
                        }
                    }
                    //O Progresso de adivinhacao contem o caracter _ em letras que nao foram adivinhadas
                    //caso o progresso de adivinhacao nao contenha nenhum _, mostra a vitoria do jogador
                    if(!progressoAdivinhacao.toString().contains( "_" )){
                        System.out.println( "VOCÊ VENCEU!!! A palavra era: "+palavra );
                        return;
                    }
                    System.out.println( "Você acertou uma letra!!\n" );
                } else {
                    maxTentativas--;
                    if ( maxTentativas == 0 ) {
                        System.out.println( "Você perdeu! :(" );
                        System.out.println( "A palavra era: " + palavra );
                        continue;
                    }
                    System.out.println( "Você errou :(\n" );
                }

                //Comparando para palavra completa (letra = palavra adivinhada pelo jogador)
            } else if ( letra.length( ) > 1 && letra.length( ) == palavra.length( ) ) {
                if ( palavra.equals( letra ) ) {
                    System.out.println( "VOCÊ VENCEU!!! A palavra era: "+palavra );
                    return;
                } else {
                    System.out.println( "Palavra Incorreta!" );
                    maxTentativas--;
                }
            } else { //Caso tenha inserido mais de uma letra ou uma palavra que não seja do tamanho correto, informa um erro
                System.out.println( "Digite uma letra, ou uma palavra com o tamanho correto!" );
                continue;
            }

            //Imprime como está a palavra
            System.out.println( "Progresso na adivinhação: " );
            for ( Object i : progressoAdivinhacao ) {
                System.out.print( i + " " );
            }

            // Chama a função que imprime a forca
            desenharPessoaNaForca( maxTentativas );

            // Mostra quantas vidas o jogador ainda tem
            System.out.println( "Você tem mais " + maxTentativas + " vidas! " );

            System.out.println( "------------ Letras já usadas ---------------" );
            System.out.println( letrasJaUsadas );
            System.out.println( "---------------------------------------------" );
        }
    }

    private static String sorteiaPalavra( ) {
        Scanner sc = new Scanner( System.in );
        System.out.println( "Escolhe uma dificuldade: \n" +
            "1 - Fácil\n" +
            "2 - Médio\n" +
            "3 - Dificil\n" +
            "0 - Sair" );

        //Instanciando classe sorteadora
        Sorteador sort = new Sorteador( );
        String palavra = "";


        switch ( sc.nextInt( ) ) {
            case 1:
                palavra = sort.geraPalavra( "facil" );
                break;
            case 2:
                palavra = sort.geraPalavra( "medio" );
                break;
            case 3:
                palavra = sort.geraPalavra( "dificil" );
                break;
            case 0:
                return null;
            default:
                System.out.println( "Escolha uma opção válida." );
        }

        return palavra;
    }

    private static void desenharPessoaNaForca( int tentativa ) {

        //Passa por cada linha do desenho e desenha as partes necessarias do personagem a partir das tentativas

        System.out.println( "\n" );
        System.out.println( " _______" );
        System.out.println( " |     |" );

        if ( tentativa <= 6 ) {
            System.out.println( " |     O" );
        }
        if ( tentativa == 6 ) {
            System.out.println( " |      " );
        }
        if ( tentativa == 5 ) {
            System.out.println( " |     |" );
            System.out.println( " |     |" );
        }
        if ( tentativa == 4 ) {
            System.out.println( " |    /|" );
            System.out.println( " |     |" );
        }
        if ( tentativa <= 3 ) {
            System.out.println( " |    /|\\" );
            System.out.println( " |     |" );
        }
        if ( tentativa == 2 ) {
            System.out.println( " |    / " );
        }
        if ( tentativa <= 1 ) {
            System.out.println( " |    / \\" );
        }

        System.out.println( " |      " );
        System.out.println( "_|______________" );
        System.out.println( );

        if ( tentativa == 0 ) {
            System.out.println( "VOCÊ MORREU! " );
        }

    }

}
