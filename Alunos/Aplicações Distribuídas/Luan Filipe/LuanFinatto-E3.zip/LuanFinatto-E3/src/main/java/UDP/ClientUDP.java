/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

/**
 * @author luanf
 */
public class ClientUDP {

    // Declara o socket para envio UDP
    private DatagramSocket ds;

    // Declara um array de bytes que receberá a mensagem serializada que será enviada
    private byte[] buffer;

    // Declara a variavel para o ip de envio
    private InetAddress ip;

    public ClientUDP( DatagramSocket ds, InetAddress ip ) {
        this.ds = ds;
        this.ip = ip;
    }


    public static void main( String[] args ) throws IOException {
        DatagramSocket ds = new DatagramSocket( );
        InetAddress ip = InetAddress.getByName( "localhost" );
        ClientUDP client = new ClientUDP( ds, ip );

        client.conversar( );
    }

    private void conversar( ) throws IOException {
        Scanner scan = new Scanner( System.in );

        // Looping para conversar mais de uma vez
        while ( true ) {
            System.gc( );
            Pessoa p = new Pessoa( );

            // Declarando os dados da pessoa
            System.out.println( "\n--------------------\nCadastro de Pessoa:" );
            System.out.print( "Nome: " );
            p.setNome( scan.next( ) );

            System.out.print( "Altura (use ',' em vez de '.' : " );
            p.setAltura( scan.nextDouble( ) );

            System.out.print( "Peso (use ',' em vez de '.' : " );
            p.setPeso( scan.nextDouble( ) );

            // Vai juntar os dois dados em uma unica String para enviar em uma unica mensagem,
            // depois no servidor ele separa os dois para calcular
            String mensagem = p.getAltura( ) + "-" + p.getPeso( );

            // Serializa a mensagem para enviar
            buffer = mensagem.getBytes( );

            // Criando e enviando o datagram
            DatagramPacket datagram = new DatagramPacket( buffer, buffer.length, ip, 8081 );
            ds.send( datagram );

            // Fica esperando o retorno do servidor
            ds.receive( datagram );

            // Recebe o IMC calculado do servidor e seta ele na pessoa
            String mensagemRecebida = new String( datagram.getData( ), 0, datagram.getData( ).length );
            p.setImc( Double.parseDouble( mensagemRecebida ) );

            // Imprime a pessoa com o IMC
            System.out.print( "\n---------- Pessoa Cadastrada -------" +
                "\nNome: " + p.getNome( )
                + "\nAltura: " + p.getAltura( )
                + "\nPeso: " + p.getPeso( )
                + "\nIMC: " + p.getImc( ) + " - " );

            verificaImc( p.getImc() );

        }
    }

    private void verificaImc(Double imc) {
        if(imc < 18.5){
            System.out.println("Pessoa abaixo do peso" );
        }else if(imc < 24.9){
            System.out.println("Pessoa com peso normal" );
        }else if(imc < 29.9){
            System.out.println("Pessoa com sobrepeso" );
        }else if(imc < 34.9){
            System.out.println("Pessoa com obesidade grau |" );
        }else if(imc < 39.9){
            System.out.println("Pessoa com obesidade grau ||" );
        }else if(imc > 40){
            System.out.println("Pessoa com obesidade grau |||" );
        }
    }

}
