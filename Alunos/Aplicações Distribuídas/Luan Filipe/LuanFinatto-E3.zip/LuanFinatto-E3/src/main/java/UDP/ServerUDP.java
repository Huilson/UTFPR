/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 * @author luanf
 */
public class ServerUDP {
    private DatagramSocket ds;//socket de envio udp
    private byte[] buffer = new byte[ 256 ];//array de bytes que receberá a mensagem serializada a ser enviada

    public ServerUDP( DatagramSocket ds ) {
        this.ds = ds;
    }

    public static void main( String[] args ) throws UnknownHostException, SocketException, IOException {
        //Criando o socket e instanciando o servidor
        DatagramSocket ds = new DatagramSocket( 8081 );
        ServerUDP server = new ServerUDP( ds );

        server.conversar( );
    }

    private void conversar( ) throws IOException {

        System.out.println( "Servidor iniciado, aguardando mensagem do cliente..." );

        // Looping para conversar mais de uma vez
        while ( true ) {

            // Cria o datagram e fica esperando a mensagem
            DatagramPacket dg = new DatagramPacket( buffer, buffer.length );
            ds.receive( dg );

            // Deserializa o datagram recebido do cliente
            String mensagemRecebida = new String( dg.getData( ), 0, dg.getLength( ) );

            // Separando o peso e a altura em dois valores separados para calcular
            String[] mensagemSeparada = mensagemRecebida.split( "-" );

            // Extraindo valores do peso e altura
            System.out.println( "Mensagem Recebida: " );
            System.out.println( "Altura: " + mensagemSeparada[ 0 ] );
            System.out.println( "Peso: " + mensagemSeparada[ 1 ] );
            Double altura = Double.parseDouble( mensagemSeparada[ 0 ] );
            Double peso = Double.parseDouble( mensagemSeparada[ 1 ] );

            // Calculando o IMC, tranforma em String e depois em um buffer de bytes
            Double imcPessoa = peso / ( altura * altura );
            String msg = Double.toString( imcPessoa );
            buffer = msg.getBytes( );

            // Reescreve o datagram com a mensagem a ser enviada de volta ao cliente,
            // pegando o ip e a porta do datagram recebido
            dg = new DatagramPacket( buffer, buffer.length, dg.getAddress( ), dg.getPort( ) );

            // Envia a mensagem / datagram
            ds.send( dg );
        }

    }

}
