package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Servidor {
    public static void main( String[] args ) throws ClassNotFoundException {
        try {
            ServerSocket serverSocket = new ServerSocket( 6900 );
            System.out.println( "ServerSocket ouvindo porta 6900" );

            System.out.println( "Aceitando comunicação..." );
            Socket socket = serverSocket.accept( );

            //Printando o IP do cliente que se conectou
            System.out.println( "Cliente conectado: " + socket.getInetAddress( ).getHostAddress( ) );

            // Definindo um stream de entrada para os dados
            DataInputStream entrada = new DataInputStream( socket.getInputStream( ) );
            ObjectInputStream in = new ObjectInputStream( entrada );

            // Lendo os dados da pessoa na entrada
            Pessoa pessoa = ( Pessoa ) in.readObject( );

            System.out.println("Dados recebidos no servidor: " +
                "\nNome da pessoa: " + pessoa.getNome() +
                "\nPeso: " + pessoa.getPeso() +
                "\nAltura: " + pessoa.getAltura() +
                "\nIdade: " + pessoa.getIdade());

            System.out.println("Caculando o IMC da pessoa...");
            pessoa.setImc( pessoa.getPeso( ) / ( pessoa.getAltura( ) * pessoa.getAltura( ) ) );

            // Montando um stream de saida para os dados
            DataOutputStream saida = new DataOutputStream( socket.getOutputStream( ) );
            ObjectOutputStream out = new ObjectOutputStream( saida );

            // Mandando a pessoa para calcular o IMC no cliente
            out.writeObject( pessoa );

            // Fechando as conexões após terminar o processo
            saida.close( );
            entrada.close( );
            socket.close( );
            serverSocket.close( );

        } catch ( Exception ex ) {
            Logger.getLogger( Servidor.class.getName( ) ).log( Level.SEVERE, null, ex );
        }
    }
}