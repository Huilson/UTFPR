package org.example;

import java.io.Serializable;


public class Pessoa implements Serializable {
    private String nome;
    private Double peso;
    private Double altura;
    private Number idade;
    private Double imc;

    public Pessoa( ) {
    }

    public Pessoa( String nome, Double peso, Double altura, Number idade) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
        this.idade = idade;
    }

    public String getNome( ) {
        return nome;
    }

    public void setNome( String nome ) {
        this.nome = nome;
    }

    public Double getPeso( ) {
        return peso;
    }

    public void setPeso( Double peso ) {
        this.peso = peso;
    }

    public Double getAltura( ) {
        return altura;
    }

    public void setAltura( Double altura ) {
        this.altura = altura;
    }

    public Number getIdade( ) {
        return idade;
    }

    public void setIdade( Number idade ) {
        this.idade = idade;
    }

    public Double getImc( ) {
        return imc;
    }

    public void setImc( Double imc ) {
        this.imc = imc;
    }
}
