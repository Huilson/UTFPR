package org.example;

import java.io.*;
import java.net.Socket;

public class Cliente {
    public static void main( String[] args ) throws IOException, ClassNotFoundException {
        Socket socket = new Socket( "localhost", 6900 );

        DataOutputStream saida = new DataOutputStream(socket.getOutputStream());

        //Inicializando uma nova pessoa para enviar ao servidor
        Pessoa pessoa = new Pessoa("Luan", 78.5, 1.79, 21);
        ObjectOutputStream out = new ObjectOutputStream(saida);
        System.out.println("Enviando cliente para o servidor... ");

        out.writeObject(pessoa);

        // Criando stream de entrada de dados
        DataInputStream entrada = new DataInputStream(socket.getInputStream());
        ObjectInputStream in = new ObjectInputStream(entrada);

        System.out.println("Pessoa recebida de volta no cliente." );
        // Lendo o obj do tipo pessoa recebido do servidor
        pessoa = (Pessoa)in.readObject();



        System.out.println("Dados recebidos no cliente, com IMC: " +
            "\nNome da pessoa: " + pessoa.getNome() +
            "\nPeso: " + pessoa.getPeso() +
            "\nAltura: " + pessoa.getAltura() +
            "\nIdade: " + pessoa.getIdade() +
            "\nIMC: "+ pessoa.getImc());

        // Verifica o IMC do cliente
        verificaImc( pessoa.getImc( ) );

        // Fechando as conexões após terminar o processo
        entrada.close();
        saida.close();
        socket.close();
    }

    public static void verificaImc(Double imc) {
        if(imc < 18.5){
            System.out.println("Pessoa abaixo do peso" );
        }else if(imc < 24.9){
            System.out.println("Pessoa com peso normal" );
        }else if(imc < 29.9){
            System.out.println("Pessoa com sobrepeso" );
        }else if(imc < 34.9){
            System.out.println("Pessoa com obesidade grau |" );
        }else if(imc < 39.9){
            System.out.println("Pessoa com obesidade grau ||" );
        }else if(imc > 40){
            System.out.println("Pessoa com obesidade grau |||" );
        }
    }
}