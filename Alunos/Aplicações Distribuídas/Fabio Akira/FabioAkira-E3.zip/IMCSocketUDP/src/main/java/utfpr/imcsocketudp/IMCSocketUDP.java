/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package utfpr.imcsocketudp;

/**
 *
 * @author fack2
 */
public class IMCSocketUDP {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
