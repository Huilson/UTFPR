/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utfpr.imcsocketudp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

public class Servidor {
    
    
    public static void main(String[] args) throws SocketException, UnknownHostException, IOException, ClassNotFoundException{
        
        try{
            //Cria um datagram para receber os pacotes na porta X
            DatagramSocket ds = new DatagramSocket(8081);
            //buffer para armazenar os dados recebidos
            byte[] buffer = new byte[1024];
            //Cria um datagram para receber os dados
            DatagramPacket datagramRecebido = new DatagramPacket(buffer, buffer.length);
            //recebe o pacote
            ds.receive(datagramRecebido);
            //converte os bytes recebidos em um objeto, no caso aqui Pessoa
            ByteArrayInputStream byteStream = new ByteArrayInputStream(buffer);
            ObjectInputStream objectInput = new ObjectInputStream(byteStream);
            Pessoa pessoaRecebida = (Pessoa) objectInput.readObject();
            //calcula o imc
            double imc = pessoaRecebida.getPeso()/(pessoaRecebida.getAltura()*pessoaRecebida.getAltura());
            
            //Todo datagram possui em seu cabeçalho o endereço e porta de origem
            InetAddress ip = datagramRecebido.getAddress();
            int porta = datagramRecebido.getPort();
            //converte o imc em string
            String enviar = Double.toString(imc);
            //converte a string em um array de bytes
            byte[] sendData = enviar.getBytes();
            //cria um datagram de envio
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ip, porta);
            //envia o pacote
            ds.send(sendPacket);
            //encerra a conexão
            ds.close();
            
            
        }catch(IOException e){
            e.printStackTrace();
        }
    
    }
    
}