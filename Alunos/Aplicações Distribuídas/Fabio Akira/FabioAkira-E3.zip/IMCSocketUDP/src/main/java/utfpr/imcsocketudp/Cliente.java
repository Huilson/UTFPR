/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utfpr.imcsocketudp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class Cliente {
        
     
    
    public static void main(String[] args) throws IOException {
               
        try{
            //Cria um datagram para enviar pacotes            
            DatagramSocket ds = new DatagramSocket();
            //obtem o endereço do servidor
            InetAddress ip = InetAddress.getByName("localhost");
            //Cria um objeto pessoa
            Pessoa pessoa = new Pessoa();
        
            //Pegar os dados
            LerDados lerDados = new LerDados();
            pessoa = lerDados.PegarDados();
            
            //Converte o objeto Pessoa em bytes usando serialização
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            ObjectOutputStream objectOutput = new ObjectOutputStream(byteStream);
            objectOutput.writeObject(pessoa);
            byte[] sendData = byteStream.toByteArray();
            //Cria um datagram que contém os dados a serem enviados
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ip, 8081);
            //Envia o pacote
            ds.send(sendPacket);
            //buffer para armazenar os dados recebidos
            byte[] receiveData = new byte[512];
            //Cria um datagram para receber os dados
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            //recebe o pacote
            ds.receive(receivePacket);
            //converte os bytes recebidos em uma string e depois em double
            String valorRecebidoStg = new String(receivePacket.getData(),0, receivePacket.getLength());
            double valorRecebido = Double.parseDouble(valorRecebidoStg);
            //seta o imc
            pessoa.setImc(valorRecebido);
            //mostra os dados
            pessoa.imprimir();
            //encerra conexão
            ds.close();
        
        }catch(IOException e){
            e.printStackTrace();
        }
        
    }
    
}