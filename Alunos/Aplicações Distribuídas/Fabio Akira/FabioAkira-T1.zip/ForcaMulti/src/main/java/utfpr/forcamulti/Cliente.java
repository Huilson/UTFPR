
package utfpr.forcamulti;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;



public class Cliente {
    private static final String IP = "localhost";
    private static final int PORTA = 8080;
    //private String nome;sa
    

    public static void main(String[] args) throws IOException {
                               
        Socket socket = new Socket(IP,PORTA);
        
        ServidorConexao serverOut = new ServidorConexao(socket);
        
        //BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
        
        new Thread(serverOut).start();
        
        System.out.println("Digite seu nome de usuário: ");
        String username = keyboard.readLine();
        out.println(username);
        
        
        while(true){
            System.out.println("> ");
            String command = keyboard.readLine();
            if (command.equalsIgnoreCase("Escolha o nível de dificuldade:\n1 - Fácil\n2 - Médio\n3 - Difícil ")) {
                // O jogador deve escolher o nível e enviar a escolha ao servidor
                String nivelEscolhido = keyboard.readLine();
                out.println(nivelEscolhido);
            }else{
                
                out.println(command);
            }
        }
    }
    
}
