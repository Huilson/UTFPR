package utfpr.forcamulti;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class ForcaServidor {
    private static ArrayList<ClienteHandler> clientes = new ArrayList<>();
    private static Map<ClienteHandler, Integer> vidasPorJogador = new HashMap<>();
    private static Map<ClienteHandler, Integer> pontuacaoPorJogador = new HashMap<>();
    private static int numeroTotalJogadores = 2;
    private static ExecutorService pool = Executors.newFixedThreadPool(numeroTotalJogadores);
    public static int numeroJogadores=0;
    private static int jogadorAtual = 0;
    private static int jogadorMorto = 0;
    private static int rodada = 0;
    private static boolean jogoEmAndamento=false;    
    private static String palavraAdivinhar;
    private static StringBuilder palavraAdivinhada;
    private static String nivelDificuldade = "";
    private static Palavras palavra = new Palavras();
    private static Set<Character> letrasDigitadas = new HashSet<>();
    
    public static String getNivelDificuldade() {
        return nivelDificuldade;
    }

    public static int getNumeroJogadores() {
        return numeroJogadores;
    }

    public static int getJogadorAtual() {
        return jogadorAtual;
    }

    public static void main(String[] args) throws IOException {
        try (ServerSocket servidor = new ServerSocket(8080)) {
            
            System.out.println("Servidor Online. Esperando jogador");
            while(true){
                Socket cliente = servidor.accept();
                numeroJogadores++;
                ClienteHandler clienteThread = new ClienteHandler(cliente, clientes);
                clientes.add(clienteThread);
                System.out.println("Jogador conectado");
                
                pool.execute(clienteThread);
                //espera todos jogadores se conectar
                if(clientes.size()>=numeroTotalJogadores && !jogoEmAndamento){
                    if (nivelDificuldade.isEmpty()) {
                        // primeiro jogador escolhe o nível de dificuldade
                        clientes.get(rodada).solicitarNivelDificuldade(rodada);
                        
                    } 
                }
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        
    }

    public static synchronized void iniciarJogo() {
        if(!jogoEmAndamento){
            letrasDigitadas.clear();
            jogoEmAndamento=true;
            //escolher a palavra
            palavraAdivinhar = palavra.sorteador(Integer.parseInt(nivelDificuldade));
            palavraAdivinhada = conversorCaracteres(palavraAdivinhar);
            //inicia as vidas
            int vidasIniciais = 6;
            for (ClienteHandler jogador : clientes) {
                vidasPorJogador.put(jogador, vidasIniciais);
                pontuacaoPorJogador.put(jogador, 0);
            }
            //inicia o jogos para os clientes
            for(ClienteHandler cliente: clientes){
                cliente.iniciarJogo();
            }
        }
    }
    //faz a verificação do chute
    public static synchronized void processarChute(String chute, ClienteHandler cliente){
        if(jogoEmAndamento && cliente == clientes.get(jogadorAtual)){
            if(chute.length()==1 && Character.isLetter(chute.charAt(0))){
                char letra = chute.toLowerCase().charAt(0);

                // verificar se chute já foi chutado
                if(letrasDigitadas.contains(letra)){
                    cliente.enviarMensagem("A letra '" + letra + "' já foi chutada. Escolha outra letra.");
                
                }else{
                    //adiciona a letra chutada na lista de letras chutadas
                    letrasDigitadas.add(letra);
                    //faz a verificação se a palavra contém a letra chutada, se não tiver,
                    //diminui a vida e faz o tratamento de quantas vidas restam
                    if(!acertoDeCaracteres(letra)){
                        int vidaRestante = vidasPorJogador.get(cliente);
                        vidaRestante -= 1;
                        vidasPorJogador.put(cliente, vidaRestante);
                        cliente.vidasDoJogador(vidasPorJogador.get(cliente));
                        if(vidaRestante==0){
                            cliente.enviarMensagem("Você perdeu todas as vidas!");
                            jogadorMorto += 1;
                        }
                    }else{
                        //jogador acertou a letra, soma a pontuação
                        int vidaRestante = vidasPorJogador.get(cliente);
                        int pontuacaoAtual = pontuacaoPorJogador.get(cliente);
                        pontuacaoPorJogador.put(cliente, pontuacaoAtual + 1);
                        cliente.enviarMensagem("Você tem "+pontuacaoPorJogador.get(cliente)+" pontos e "+vidaRestante+" vida(s)");
                    }
                    //informa a letra chutada e quem chutou para todos os jogadores
                    for(ClienteHandler clienteAtual: clientes){
                        clienteAtual.notificarResultadoChute(letra, jogadorAtual+1);
                    }
                    if(jogoTerminou()){
                        rodada++;
                        if(rodada<numeroTotalJogadores){
                            for(ClienteHandler clienteAtual: clientes){
                                //System.out.println(jogadorAtual+" r "+rodada);
                                int jog=jogadorAtual+1;
                                clienteAtual.notificarResultadoFinal(jog, palavraAdivinhar.equals(palavraAdivinhada.toString()));
                            }   
                        }else{
                            jogoEmAndamento=false;
                        }
                    }else{
                        //passa a vez para o próximo jogador
                        //e verifica se ele tem vida
                        jogadorAtual = (jogadorAtual+1)%clientes.size();
                        if(vidasPorJogador.get(clientes.get(jogadorAtual))==0){
                            if(jogadorMorto==1){
                                jogadorAtual = (jogadorAtual+1)%clientes.size();
                            }else{
                                if(jogadorMorto==numeroTotalJogadores){
                                    //se todos jogadores morrerem
                                    cliente.mensagemTodos("Todos jogadores perderam. ");
                                    encerrarServidor(); 
                                }
                                for (int i = 0; i < clientes.size(); i++) {
                                    //procura próximo jogador com vida
                                    ClienteHandler jogador = clientes.get(i);
                                    int vidasRestantes = vidasPorJogador.get(jogador);
                                    if (vidasRestantes != 0) {
                                        jogadorAtual = i;
                                    }
                                }
                            }        
                        }
                        //notifica o próximo jogador
                        clientes.get(jogadorAtual).notificarChute(letrasDigitadas,palavraAdivinhada.toString());
                    }
                }
            }else{
                cliente.enviarMensagem("Letra inválida.");
            }
            
        }
    }
    //Verifica se o jogo terminou comparando a palavra sorteada com a palavra adivinhada
    public static synchronized boolean jogoTerminou() {
        if(palavraAdivinhar.equals(palavraAdivinhada.toString())){
            return true;
        }else{
            return false;
        }
    }

    public static synchronized void iniciarNovaPartida() {
        jogadorAtual = rodada;
        nivelDificuldade = ""; // Limpe o nível de dificuldade anterior
        clientes.get(jogadorAtual).solicitarNivelDificuldade(jogadorAtual);
    }


    //Recebe a palavra sorteada e retorna  uma string de resposta contendo "_" do tamanho da palavra
    public static StringBuilder conversorCaracteres(String palavra){ 
        char[] tracos = palavra.toCharArray(); //Converter para array de char
        StringBuilder palavraEscondida = new StringBuilder();
        for (char c : tracos) {
            //System.out.print("_ "); //imprimi espaçado os "_"
            palavraEscondida.append("_"); //Adiciona "_" na variável de resposta
        }
        return palavraEscondida; //Retorna a variável de resposta
    }

    
    //Verifica se a palavra sorteada contém a letra digitada e atualiza na variável resposta caso contenha
    public static boolean acertoDeCaracteres(char d){
        char[] espacos = palavraAdivinhar.toCharArray(); //converte para um array de char
        boolean achou = false;
        //percorre a palavra para verificar se contém a letra digitada
            for (int c = 0; c < palavraAdivinhar.length(); c++) { 
                    //Caso encontre a letra, atualiza a a variável de resposta com a letra na posição correta
                if (d == espacos[c]) {
                    palavraAdivinhada.setCharAt(c, espacos [c]);
                    achou=true;
                }
            }
            return achou; //retorna a resposta
    }

    public static synchronized void processarNivelDificuldade(String nivel, ClienteHandler cliente) {
        if (cliente == clientes.get(jogadorAtual)) {
            // Verifique se o nível escolhido é válido (fácil, médio, difícil)
            if (nivel.equalsIgnoreCase("1") || nivel.equalsIgnoreCase("2") || nivel.equalsIgnoreCase("3")) {
                nivelDificuldade = nivel;
                // Inicie o jogo com o nível escolhido
                iniciarJogo();
            } else {
                // Nível inválido, solicite novamente
                clientes.get(jogadorAtual).solicitarNivelDificuldade(jogadorAtual);
            }
        }
    }

    public static synchronized void encerrarServidor() {
        // Encerrar todos os clientes
        for (ClienteHandler jogador : clientes) {
            jogador.encerrarCliente();
        }
        
        // Encerrar a pool de threads
        pool.shutdownNow();
    }

}
