
package utfpr.forcamulti;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ClienteHandler implements Runnable {
    private Socket cliente;
    private BufferedReader in;
    private PrintWriter out;
    private ArrayList<ClienteHandler> clientes;
    private String nome;
    private boolean meuTurno = false;
    //private int jogadorAtual = 0;
    
    public ClienteHandler(Socket cliente, ArrayList<ClienteHandler> clientes) throws IOException {
        this.cliente = cliente;
        this.clientes = clientes;
        in = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
        out = new PrintWriter(cliente.getOutputStream(),true);
        this.nome = in.readLine();
    }
       

    @Override
    public void run() {
        try{
            out.println("Bem vindo "+nome+" ao jogo da forca. Você é o jogador "+ForcaServidor.getNumeroJogadores());
            
            while(true){
                String request = in.readLine();
                if(ForcaServidor.getNivelDificuldade().isEmpty()){
                    ForcaServidor.processarNivelDificuldade(request, this);
                }else{
                    if(meuTurno){
                        ForcaServidor.processarChute(request,this); 
                    }
                }
                
            }
        } catch (IOException ex) {
            Logger.getLogger(ClienteHandler.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            out.close();
            try {
                in.close();
            } catch (IOException ex) {
                Logger.getLogger(ClienteHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void mensagemTodos(String msg) {
        for (ClienteHandler aCliente: clientes){
            aCliente.out.println(msg);
        }
    }

    public void enviarMensagem(String mensagem) {
        out.println(mensagem); // Envia a mensagem para o cliente
    }

    public void iniciarJogo() {
        meuTurno = true;
        if(clientes.get(ForcaServidor.getJogadorAtual())==this){
            //O primeiro jogador vai começar
            out.println("O jogo começou! E é a sua vez");
        }else{
            //os outros jogadores esperam
            out.println("O jogo começou! Aguarde a sua vez");
        }
    }

    public void notificarResultadoChute(char letra, int jogador) {
        //informa o jogador e o chute
        out.println("O jogador "+jogador+" chutou a letra "+letra);;
    }


    public void notificarChute(Set<Character> letrasDigitadas, String palavraAdivinhada) {
        //informa a palavra adivinhada, todas as letras chutadas e indica o jogador que é a sua vez
        out.println("\nPalavra: "+palavraAdivinhada+"\nLetras chutadas: "+letrasDigitadas+"\nSua vez de chutar!\n");
    }


    public void notificarResultadoFinal(int jogadorAtual, boolean equals) {
        //informa que o jogador ganhou
        out.println("O jogador "+jogadorAtual+" ganhou!");
        ForcaServidor.iniciarNovaPartida();
    }
    
    public void solicitarNivelDificuldade(int index) {
        //pede para o primeiro jogador informar o nível do jogo
        if (clientes.get(index) == this) {
            out.println("Escolha o nível de dificuldade:\n1 - Fácil\n2 - Médio\n3 - Difícil ");
            // Aguarde a resposta do jogador e processe a escolha
        }
    }

    public void vidasDoJogador(int qtdVidas) {
        out.println("-------------------------------------------------");
        out.println("A LETRA ESCOLHIDA NÃO EXISTE NA PALAVRA SORTEADA.");
        out.println("             VOCÊ PERDEU UMA VIDA.");
        out.println("                 VIDA ATUAL: " + qtdVidas);
        out.println("-------------------------------------------------");
        if (qtdVidas == 5) {
            out.println("  +---+");
            out.println("  |   |");
            out.println("  O   |");
            out.println("      |");
            out.println("      |");
            out.println("      |");
            out.println("=========");
        }
        else if (qtdVidas == 4) {
            out.println("  +---+");
            out.println("  |   |");
            out.println("  O   |");
            out.println("  |   |");
            out.println("      |");
            out.println("      |");
            out.println("=========");
        }
        else if (qtdVidas == 3) {
            out.println("  +---+");
            out.println("  |   |");
            out.println("  O   |");
            out.println(" /|   |");
            out.println("      |");
            out.println("      |");
            out.println("=========");
        }
        else if (qtdVidas == 2) {
            out.println("  +---+");
            out.println("  |   |");
            out.println("  O   |");
            out.println(" /|\\  |");
            out.println("      |");
            out.println("      |");
            out.println("=========");
        }
        else if (qtdVidas == 1){
            out.println("  +---+");
            out.println("  |   |");
            out.println("  O   |");
            out.println(" /|\\  |");
            out.println(" /    |");
            out.println("      |");
            out.println("=========");
        }
        else if (qtdVidas == 0) {
            out.println("  +---+");
            out.println("  |   |");
            out.println("  O   |");
            out.println(" /|\\  |");
            out.println(" / \\  |");
            out.println("      |");
            out.println("=========");
        }
        out.println("-------------------------------------------------");
    

    }  

    public void encerrarCliente() {
        try {
            in.close();
            out.close();
            cliente.close();
        } catch (IOException e) {
            // Lida com exceções se ocorrerem ao fechar os recursos do cliente
            e.printStackTrace();
        }
        // interromper a thread do cliente
        Thread.currentThread().interrupt();
    }

    public void notificarResultadoChutePalavra(String palavra, int jogador) {
        out.println("O jogador "+jogador+" chutou a palavra "+palavra);
    }

    public void processarEscolha(String escolha) {
        if (escolha.equalsIgnoreCase("1")) {
            // O jogador escolheu chutar uma letra
            // Implemente a lógica para chutar uma letra
        } else if (escolha.equalsIgnoreCase("2")) {
            // O jogador escolheu chutar a palavra inteira
            // Implemente a lógica para chutar a palavra inteira
        } else {
            enviarMensagem("Escolha inválida. Digite 'letra' ou 'palavra'.");
        }
    }
}
