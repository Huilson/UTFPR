
package utfpr.forcamulti;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

//atualiza as mensagens para todos clientes
public class ServidorConexao implements Runnable {
    
    private Socket socket;
    private BufferedReader in;
 
    public ServidorConexao(Socket socket) throws IOException {
        this.socket = socket;
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    @Override
    public void run() {
        try {
            while(true){
                String respostaServidor = in.readLine();
                if(respostaServidor == null) break;
                System.out.println(respostaServidor);
            }    
        } catch (IOException ex) {
            Logger.getLogger(ServidorConexao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                in.close();
            } catch (IOException ex) {
                Logger.getLogger(ServidorConexao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    } 
}