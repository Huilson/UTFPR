
package com.mycompany.sockettcp;

import java.util.Scanner;

public class LerDados {
    Scanner ler = new Scanner(System.in);
    
    Pessoa pessoa = new Pessoa();
    //Pegar os dados e armazenar
    public Pessoa PegarDados(){
        System.out.println("\nNome: ");
        pessoa.setNome(ler.next());
        System.out.println("\nPeso: ");
        pessoa.setPeso(ler.nextDouble());
        System.out.println("\nAltura: ");
        pessoa.setAltura(ler.nextDouble());
        System.out.println("\nIdade: ");
        pessoa.setIdade(ler.nextInt());
        pessoa.setImc(0); //iniciando o imc como zero, pois o servidor que irá calcular
        
        return pessoa;
    }
}
