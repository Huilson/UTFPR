package com.mycompany.sockettcp;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Cliente {
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Socket socket = new Socket("127.0.0.1", 8080);
        
        Pessoa pessoa = new Pessoa();
        
        //Pegar os dados
        LerDados lerDados = new LerDados();
        pessoa = lerDados.PegarDados();
        
        //Definir os stream de saida de objeto
        ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
        //Envia o objeto
        saida.writeObject(pessoa);
        
        //Definir o stream de entrada de dados (para ouvir)
        DataInputStream entrada = new DataInputStream(socket.getInputStream());
        
        //Armazena o dados que veio na stream
        Double imc = entrada.readDouble();
        
        //Atribui o imc 
        pessoa.setImc(imc);
        
        pessoa.imprimir();

        //Ao encerrar fecha tudo, seguindo a ordem da pilha
        entrada.close();
        saida.close();
        socket.close();
    }
}
