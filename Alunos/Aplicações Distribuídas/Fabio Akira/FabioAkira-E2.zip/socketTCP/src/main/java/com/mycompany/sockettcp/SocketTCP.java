/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sockettcp;

/**
 *
 * @author fack2
 */
public class SocketTCP {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
