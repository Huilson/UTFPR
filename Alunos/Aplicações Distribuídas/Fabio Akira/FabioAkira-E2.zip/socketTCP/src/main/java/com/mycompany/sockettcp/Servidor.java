package com.mycompany.sockettcp;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //Definir o serverSocket(porta de conexao)
        ServerSocket serversocket = new ServerSocket(8080);
        System.out.println("O servidor esta ouvindo na porta 8080");
        
        //Abrir a comunicacao
        Socket socket = serversocket.accept();
        
        //Mostrar o ip do cliente que vai estar conectado
        System.out.println("Um cliente se conectou: "+socket.getInetAddress().getHostAddress());
        
        //Definir um stram de entrada
        ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
        
        //Quando recebo a mensagem ela esta em byte, para deserializar a mensagem
        //ou uma string usamos o metodo readUTF()
        Pessoa pessoa = (Pessoa) entrada.readObject();
        
        //Calculo do imc
        Double imc = pessoa.getPeso()/(pessoa.getAltura()*pessoa.getAltura());
        
        //Definir um stream de saida para o servidor (para conversar)
        DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        //envia o dado
        saida.writeDouble(imc);
        //Ao terminar a conversa fecha tudo
        saida.close();
        entrada.close();
        socket.close();
        serversocket.close();
        
        
    }
    
}
