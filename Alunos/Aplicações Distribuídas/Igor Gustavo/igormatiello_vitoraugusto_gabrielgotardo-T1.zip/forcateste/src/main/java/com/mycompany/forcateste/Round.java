/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forcateste;

import java.util.List;

/**
 *
 * @author Igor
 */
public class Round {
   
    private String palavraEscolhida;
    private String dica1;
    private String dica2;
    private String dica3;
    private String letrasUsadas;
    private Integer posicaoPalavra;
    private Integer pontuacaoAcerto;
    private Integer nivel;
    private Integer tentavivas;

    public Round() {
    }

    public Integer getNivel() {
        return nivel;
    }

    public void setNivel(Integer nivel) {
        this.nivel = nivel;
    }

    public Integer getTentavivas() {
        return tentavivas;
    }

    public void setTentavivas(Integer tentavivas) {
        this.tentavivas = tentavivas;
    }

    

   
    public String getPalavraEscolhida() {
        return palavraEscolhida;
    }

    public void setPalavraEscolhida(String palavraEscolhida) {
        this.palavraEscolhida = palavraEscolhida;
    }

    public String getDica1() {
        return dica1;
    }

    public void setDica1(String dica1) {
        this.dica1 = dica1;
    }

    public String getDica2() {
        return dica2;
    }

    public void setDica2(String dica2) {
        this.dica2 = dica2;
    }

    public String getDica3() {
        return dica3;
    }

    public void setDica3(String dica3) {
        this.dica3 = dica3;
    }

    public String getLetrasUsadas() {
        return letrasUsadas;
    }

    public void setLetrasUsadas(String letrasUsadas) {
        this.letrasUsadas = letrasUsadas;
    }

    public Integer getPosicaoPalavra() {
        return posicaoPalavra;
    }

    public void setPosicaoPalavra(Integer posicaoPalavra) {
        this.posicaoPalavra = posicaoPalavra;
    }

    public Integer getPontuacaoAcerto() {
        return pontuacaoAcerto;
    }

    public void setPontuacaoAcerto(Integer pontuacaoAcerto) {
        this.pontuacaoAcerto = pontuacaoAcerto;
    }
    
}
