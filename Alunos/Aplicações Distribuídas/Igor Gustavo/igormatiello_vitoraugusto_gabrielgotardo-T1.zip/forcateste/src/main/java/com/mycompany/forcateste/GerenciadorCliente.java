package com.mycompany.forcateste;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GerenciadorCliente implements Runnable {

    private Socket socket;
    public static String mensagemDaVez;
    public static String usernameDaVez;
    private Scanner scanner = new Scanner(System.in);

    public static Integer pontuacao = 0;

    /*Criamos um array para cada instância dessa clase, o objetivo principal
    desse array é ficar de olho em cada cliente, para quando um cliente
    mandar uma mensagem possamos percorrer o array e mandar a mensagem
    para todos os outros clientes do array*/
    public static ArrayList<GerenciadorCliente> clientes = new ArrayList<>();

    //Buffer de entrada e saida
    private BufferedReader receber;
    private BufferedWriter enviar;
    //private String apelido;
    private Integer score;
    private Boolean ativo;
    private Integer vidas;
    private Integer posicaoTurno;
    private Boolean possivelChutar;

    // Socket[addr=/192.168.0.138,port=8082,localport=51006]
    // Socket[addr=/192.168.0.138,port=8082,localport=51007]
    private String username;

    public GerenciadorCliente(Socket socket) {
        try {
            this.socket = socket;
            //Stream e buffer para leitura e escrita na rede
            this.receber = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.enviar = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            //Ao atribuir um valor para a String username, ela será lida pelo buffer
            this.username = receber.readLine();

            //verifica se ja tem username igual
            for (int n = 0; n < clientes.size(); n++) {
                if (this.username.equals(clientes.get(n).getUsername())) {
                    this.username = this.username + "_repetido";
                }
            }
            this.posicaoTurno = clientes.size();
            if (clientes.size() < 3) {

                clientes.add(this);
                this.setScore(0);
                if (clientes.size() < 2) {
                    transmitir("Aguarde um instante...mais jogadores devem se conectar para iniciarmos");
                }
            }
            if (clientes.size() == 2) {
                transmitir("Prepare-se o jogo iniciara em breve...");
                iniciarJogo(clientes);
            }

            //igor - deixar apenas um numero especifico de jogadores ou tempo 
            // mandar lista para o adaptador quando deve começar o jogo
        } catch (IOException e) {
            fechaTudo(socket, receber, enviar);
        }//fim do tryCatch
    }//fim do construtor

    @Override
    public void run() {

        String msg;
        while (socket.isConnected()) {
            try {
                //System.out.println("Leitura!");

                
                msg = receber.readLine();
                //transmitir("log igor teste:" + msg);
                System.out.println("LOG: usuario " + username + " digitou a mensagem: " + msg);
                
                //metodo que verifica se o usuario é o usuario da vez
                
                enviaMsg(msg, username);

                
                //System.out.println("estou lendo ----- run");
                //System.out.println("username: " + username);
                //System.out.println("msg: " + msg);
                //System.out.println("Jogador da vez: " + getUsernameDaVez());
                //System.out.println("Mensagem da vez: " + getMensagemDaVez());
                // transmitir("entrou no if de mandar mensagem   " + msg);
                //igor - essa pegue a mensagem de um cliente e manda para todos
                //mandar mensagem que o cliente para o servidor/jogo
                //nao mandar para os outros clientes
                //transmitir(msg);
                //quando vem mensagem do cliente e sera impresso para todos
            } catch (IOException e) {
                fechaTudo(socket, receber, enviar);
            }
        }//fim while
    }

    //trocada para enviar para todos os clientes
    private void transmitir(String msg) {
        //Para cada cliente no loop do while no método RUN cria-se uma iteração
        for (GerenciadorCliente cliente : clientes) {//for each entre todos os clientes
            try {
                //if(!cliente.username.equals(username)){//ignora o cliente que envio a mensagem
                cliente.enviar.write(msg);//Serialização da mensagem e envio pela rede
                cliente.enviar.newLine();//Quando o cliente apertar ENTER o programa entede
                //que a mensagem foi finalizada, dessa forma o buffer se adapta ao tamanho
                //da mensagem e não fica sobrecarregado, e depois de enviado se esvazia automaticamente
                cliente.enviar.flush();
                //}//fim IF
            } catch (IOException e) {
                fechaTudo(socket, receber, enviar);
            }
        }//fim do FOR

        //igor- metodo que envia para todos os clientes
        //criar outro metodo para enviar para um cliente somente 
    }

    //metodo para enviar mensagem para somente um usuario
    private void transmitirParaEspecifico(String msg, String nome) {
        //Para cada cliente no loop do while no método RUN cria-se uma iteração
        for (GerenciadorCliente cliente : clientes) {//for each entre todos os clientes
            try {
                if (cliente.username.equals(nome)) {//ignora o cliente que envio a mensagem
                    cliente.enviar.write(msg);//Serialização da mensagem e envio pela rede
                    cliente.enviar.newLine();//Quando o cliente apertar ENTER o programa entede
                    //que a mensagem foi finalizada, dessa forma o buffer se adapta ao tamanho
                    //da mensagem e não fica sobrecarregado, e depois de enviado se esvazia automaticamente
                    cliente.enviar.flush();
                }//fim IF
            } catch (IOException e) {
                fechaTudo(socket, receber, enviar);
            }
        }//fim do FOR

        //igor- metodo que envia para todos os clientes
        //criar outro metodo para enviar para um cliente somente 
    }

    public void iniciarJogo(List<GerenciadorCliente> jogadores) {
        // Verifique a quantidade de jogadores
        List<Round> rounds = new ArrayList<>();
        //BancoDePalavras banco = new BancoDePalavras();
        //popularListas();
        List<String> faceis = new ArrayList<>();
        List<String> medias = new ArrayList<>();
        List<String> dificieis = new ArrayList<>();
        List<String> dicaFaceis1 = new ArrayList<>();
        List<String> dicaDificieis1 = new ArrayList<>();
        List<String> dicaMedias1 = new ArrayList<>();

        //adiiconar palavras as listas de palavras da forca
        //adiciona dicas na mesma posicao
        faceis.add("uva");
        dicaFaceis1.add("Pequena fruta redonda");

        faceis.add("coco");
        dicaFaceis1.add("Fruta marron por fora e branca por dentro");

        faceis.add("limao");
        dicaFaceis1.add("Fruta amarela e ácida");

        faceis.add("pera");
        dicaFaceis1.add("Fruta de casca fina");

        faceis.add("manga");
        dicaFaceis1.add("Fruta originaria da india");

        faceis.add("kiwi");
        dicaFaceis1.add("Fruta pequena e peluda");

        medias.add("lontra");
        dicaMedias1.add("Animal aquatico");

        medias.add("girafa");
        dicaMedias1.add("Animal com pescoço longo");

        medias.add("leao");
        dicaMedias1.add("Rei da selva");

        medias.add("tigre");
        dicaMedias1.add("Animal listrado");

        medias.add("esquilo");
        dicaMedias1.add("Animal pequeno e marron");

        medias.add("raposa");
        dicaMedias1.add("Fox em ingles");

        medias.add("zebra");
        dicaMedias1.add("Animal listrado preto e branco");

        medias.add("camelo");
        dicaMedias1.add("Animal do deserto");

        medias.add("macaco");
        dicaMedias1.add("Primate ágil");

        medias.add("panda");
        dicaMedias1.add("Urso preto e branco");

        dificieis.add("retrato");
        dicaDificieis1.add("Imagem de uma pessoa ou objeto");

        dificieis.add("computador");
        dicaDificieis1.add("Máquina usada para processar dados");

        dificieis.add("telefone");
        dicaDificieis1.add("Dispositivo de comunicação");

        dificieis.add("teclado");
        dicaDificieis1.add("Relaciona com digitar");

        dificieis.add("microfone");
        dicaDificieis1.add("expandir voz");

        dificieis.add("tesoura");
        dicaDificieis1.add("Pode cortar");

        mensagemDaVez = null;
        //setUsernameDaVez(" ");

       
        for (int i = 0; i < jogadores.size(); i++) {
//inicia o round
//numero de rounds é o numero de jogadores
            Round roundAtual = new Round();

            rounds.add(roundAtual);
            transmitir("Lista de jogadores:");
            //inicia com uma listagem do status do jogo
            for (int i2 = 0; i2 < jogadores.size(); i2++) {
                jogadores.get(i2).setVidas(5);

                transmitir("--------------------------");
                transmitir("Username: " + jogadores.get(i2).getUsername());
                transmitir("Posição do Turno: " + jogadores.get(i2).getPosicaoTurno());
                transmitir("Vidas: " + jogadores.get(i2).getVidas());
                transmitir("Score: " + jogadores.get(i2).getScore());
                transmitir("--------------------------");

            }

            //setLetrasDigitadasNaRodada("");
            setPossivelChutar(false);

            transmitir("Inicio do round " + (i + 1));

            Boolean continuarPerguntando = true;
            String nivelDigitado = "";
            setMensagemDaVez("");

            //escolhe o jogador da vez para escolher o nivel
            //setSocketDaVez(jogadores.get(i).getSocket());
            setUsernameDaVez(jogadores.get(i).getUsername());
            transmitirParaEspecifico(
                    jogadores.get(i).getUsername() + " voce deve escolher o nivel: 1- facil  2 - medio 3 -dificil ", jogadores.get(i).getUsername());

           //faz verificacao infinita para que o jogador digite um nivel correto
            while (continuarPerguntando) {
                //formatarMensagemCliente(username, getMensagemDaVez());
                //String msg = receber.readLine(); 
                //System.out.println("mensagem do cliente: " + this.mensagemDaVez);

                //System.out.println("nome jogador da vez " + jogadores.get(i).getUsername());
                //nivelDigitado = getMensagemDaVez();
                //transmitir("Nivel escolhido: " + getMensagemDaVez());
                if (this.mensagemDaVez.equals("1") || this.mensagemDaVez.equals("2") || this.mensagemDaVez.equals("3")) {
                    System.out.println("LOG: usuario conseguiu selecionar nivel");
                    continuarPerguntando = false; // Sai do loop se o nível for válido
                }

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(GerenciadorCliente.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

            //usuario conseguiu digitar o nivel
            nivelDigitado = this.mensagemDaVez;
            transmitir("Jogador " + jogadores.get(i).getUsername() + " escolheu o nivel: " + nivelDigitado);

            mensagemDaVez = null;

            //roundAtual = obterPalavraAleatoria(Integer.getInteger(nivelDigitado));
            List<String> lista = new ArrayList<>();
            List<String> dicas1 = new ArrayList<>();

            //System.out.println("dentro do obterPalavraAleatoria, get nivel: " + Integer.getInteger(nivelDigitado));
            lista.clear();
            dicas1.clear();

            //salva a pontuacao do round
            if (nivelDigitado.equals("2")) {
                roundAtual.setPontuacaoAcerto(2);
                this.pontuacao = 2;
            } else if (nivelDigitado.equals("3")) {
                roundAtual.setPontuacaoAcerto(3);
                this.pontuacao = 3;
            } else {
                roundAtual.setPontuacaoAcerto(1);
                this.pontuacao = 1;

            }
            transmitir("Pontuacao do round: " + this.pontuacao);

            //alimenta as listas
            switch (nivelDigitado) {
                case "1":
                    lista = faceis;
                    dicas1 = dicaFaceis1;

                    break;
                case "2":
                    lista = medias;
                    dicas1 = dicaMedias1;

                    break;
                case "3":
                    lista = dificieis;
                    dicas1 = dicaDificieis1;

                    break;
                default:
                    throw new IllegalArgumentException("Nível de dificuldade inválido");
            }

            //escolhe uma palavra aleatoria
            Random random = new Random();
            int indiceAleatorio;
            String palavraAleatoria;
            // do {
            indiceAleatorio = random.nextInt(lista.size());
            palavraAleatoria = lista.get(indiceAleatorio);
            System.out.println("LOG: escolheu uma palavra aleatoria: " + palavraAleatoria);
            // } while (!palavraAleatoria.equals("")); // Verifica se a palavra está vazia

            //System.out.println("saiu do while do round");
            roundAtual.setPosicaoPalavra(indiceAleatorio);
            roundAtual.setPalavraEscolhida(palavraAleatoria);
            roundAtual.setDica1(dicas1.get(indiceAleatorio));

            lista.set(indiceAleatorio, "");
            palavraAleatoria = "";

            //apagar depois
            //transmitir("Palavra escolhida: " + roundAtual.getPalavraEscolhida());
            //transmitir("Dica escolhida: " + roundAtual.getDica1());
            roundAtual.setLetrasUsadas("");

            Boolean continuarJogando = true;
            
            //while que segue ate alguem acertar ou todos perderem as vidas
            while (continuarJogando) {

                for (int j = 0; j < jogadores.size(); j++) {

                    if (continuarJogando) {

                        //inicia a thread para receber mensagem
                        Thread thread = new Thread(this);
                        thread.start();

                        //transmitir("Rodada " + j + " iniciando");
                        for (int i3 = 0; i3 < jogadores.size(); i3++) {

                            transmitir("\nUsername: " + jogadores.get(i3).getUsername());
                            //transmitir("Posição do Turno: " + jogadores.get(i3).getPosicaoTurno());
                            transmitir("Vidas: " + jogadores.get(i3).getVidas());
                            transmitir("Score: " + jogadores.get(i3).getScore() + "\n");
                        }
                        transmitir("Estado atual do round: " + ocultarPalavra(roundAtual.getPalavraEscolhida(), roundAtual.getLetrasUsadas()));
                        transmitir("Letras usadas: " + roundAtual.getLetrasUsadas());
                        //transmitir("Pontuacao de acerto do round: " + nivelDigitado);

                        //valida se o usuario tem vidas
                        if (jogadores.get(j).getVidas() > 0) {

                            transmitirParaEspecifico("\nEscolha uma letra nao escolhida ou digite (dica) para receber uma dica", jogadores.get(j).getUsername());

                            possivelChutar = contarCaracteresComuns(roundAtual.getLetrasUsadas(), roundAtual.getPalavraEscolhida()) >= 3;

                            //verifica se é possivel chutar uma palavra
                            if (possivelChutar) {
                                transmitirParaEspecifico("Se quiser pode digitar a palavra para tentar um chute", jogadores.get(j).getUsername());

                            } else {
                                transmitirParaEspecifico("Ainda não é possível chutar uma palavra", jogadores.get(j).getUsername());
                            }

                            this.usernameDaVez = jogadores.get(j).getUsername();

                            System.out.println("LOG: usuario que deve jogar: " + this.usernameDaVez);

                            continuarPerguntando = true;
                            this.mensagemDaVez = "";

                            //validacao de entrada
                            while (continuarPerguntando) {
                                //formatarMensagemCliente(username, getMensagemDaVez());
                                //String msg = receber.readLine(); 
                                //System.out.println("LOG: mensagem do cliente: " + this.mensagemDaVez);

                                //System.out.println("nome jogador da vez " + jogadores.get(i).getUsername());
                                //nivelDigitado = getMensagemDaVez();
                                //transmitir("Nivel escolhido: " + getMensagemDaVez());
                                if (!this.mensagemDaVez.equals("") && !this.mensagemDaVez.equals(" ")) {
                                    System.out.println("LOG: usuario conseguiu digitar um chute");
                                    continuarPerguntando = false; // Sai do loop se o nível for válido
                                }
                                try {
                                    Thread.sleep(2000);
                                } catch (InterruptedException ex) {
                                    Logger.getLogger(GerenciadorCliente.class.getName()).log(Level.SEVERE, null, ex);
                                }

                            }
                            String letraEscolhida = this.mensagemDaVez;

                            
                            //validacao de entrada
                            while (!letraEscolhida.matches("^[a-zA-Z\\s]*$")) {
                                letraEscolhida = this.mensagemDaVez;
                                transmitirParaEspecifico("Por favor, digite novamente: ", jogadores.get(j).getUsername());
                                try {
                                    Thread.sleep(10000); // 10 segundos de pausa
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
//validacao de entrada
                            while (roundAtual.getLetrasUsadas().contains(letraEscolhida)) {
                                letraEscolhida = this.mensagemDaVez;
                                transmitirParaEspecifico("Por favor, digite alguma letra não digitada anteriormente: ", jogadores.get(j).getUsername());
                                try {
                                    Thread.sleep(10000); // 10 segundos de pausa
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }

                            letraEscolhida = this.mensagemDaVez;

                            /*while ((!letraEscolhida.matches("^[a-zA-Z\\s]*$")) && ((!possivelChutar && !letraEscolhida.equals("dica")) && letraEscolhida.length() > 1)) {

                                transmitirParaEspecifico("Por favor, digite novamente: ", jogadores.get(j).getUsername());

                                System.out.println("LOG: usario " + jogadores.get(j).getUsername() + " digitou algo invalido");
                            }
                            while (roundAtual.getLetrasUsadas().contains(letraEscolhida)) {

                                transmitirParaEspecifico("Por favor, digite alguma letra não digitada anteriormente: ", jogadores.get(j).getUsername());

                                System.out.println("LOG: usario " + jogadores.get(j).getUsername() + " digitou uma letra ja digitada");
                            }*/
                            
                            //algumas verificações de letra digitada pelo usuario
                            if (!possivelChutar && letraEscolhida.length() > 1 && !letraEscolhida.equals("dica") && !letraEscolhida.equals("DICA")) {
                                letraEscolhida = Character.toString(letraEscolhida.charAt(0));
                                System.out.println("LOG: nova letra escolhida: " + letraEscolhida);
                            }
                            if (letraEscolhida.equals("DICA")) {
                                letraEscolhida = "dica";
                            }

                            if (!possivelChutar) {
                                letraEscolhida = letraEscolhida.toLowerCase();
                            }

                            
                            System.out.println("LOG: usuario conseguiu chutar: " + letraEscolhida);
                            this.mensagemDaVez = null;
                            this.usernameDaVez = null;

                            // Remoção de espaços em branco da letraEscolhida
                            //letraEscolhida = letraEscolhida.replaceAll("\s", "");
                            
                            
                            //metodo que faz a analise doque o usuario digitou
                            
                            //if se ele digitou dica
                            if (letraEscolhida.equals("dica")) {
                                transmitirParaEspecifico("Dica: " + roundAtual.getDica1(), jogadores.get(j).getUsername());

                                //vidas
                                jogadores.get(j).setVidas(jogadores.get(j).getVidas() - 1);

                            } else if (!possivelChutar || letraEscolhida.length() < 2) {
//if para quando ele digitar uma letra
                                //if (!banco.verificarLetraNaPalavra(letraEscolhida, roundAtual.getLetrasUsadas())) {
                                if (verificarLetraNaPalavra(roundAtual.getPalavraEscolhida(), letraEscolhida)) {
                                    roundAtual.setLetrasUsadas(roundAtual.getLetrasUsadas() + letraEscolhida);
                                    //setLetrasDigitadasNaRodada(getLetrasDigitadasNaRodada() + letraEscolhida);
                                    transmitir("O jogador " + jogadores.get(j).getUsername() + " acertou a letra " + letraEscolhida);
                                } else {
                                    //setLetrasDigitadasNaRodada(getLetrasDigitadasNaRodada() + letraEscolhida);
                                    roundAtual.setLetrasUsadas(roundAtual.getLetrasUsadas() + letraEscolhida);

                                    //vidas
                                    jogadores.get(j).setVidas(jogadores.get(j).getVidas() - 1);

                                    transmitir("O jogador " + jogadores.get(j).getUsername() + " errou a letra " + letraEscolhida);

                                }

                                //verifica se todas as letras foram descobertas
                                if (palavraDescoberta(roundAtual.getPalavraEscolhida(), roundAtual.getLetrasUsadas())) {
                                    transmitir("PALAVRA DESCOBERTA PELO JOGADOR: "
                                            + jogadores.get(j).getUsername() + ".... PALAVRA ERA: " + roundAtual.getPalavraEscolhida());
                                    jogadores.get(j).setScore(jogadores.get(j).getScore() + this.pontuacao);
                                    continuarJogando = false;
                                }
                            } else {

                                //codigo que entra quando ele digitar uma palavra como chute
                                transmitir("jogador " + jogadores.get(j).getUsername()
                                        + " chutou a palavra: " + letraEscolhida);
                                if (!letraEscolhida.equals(roundAtual.getPalavraEscolhida())) {

                                    //vidas
                                    jogadores.get(j).setVidas(jogadores.get(j).getVidas() - 1);

                                } else {
                                    jogadores.get(j).setScore(jogadores.get(j).getScore() + this.pontuacao);
                                    transmitir("JOGADOR " + jogadores.get(j).getUsername()
                                            + " ACERTOU A PALAVRA: " + letraEscolhida);
                                    continuarJogando = false;
                                }
                            }
                        } else {
                            transmitirParaEspecifico("VOCÊ PERDEU AS VIDAS ", jogadores.get(j).getUsername());
                        }
                    }
                    //verifica se todos perderam as vidas
                    if (jogadores.get(0).getVidas() == 0 && jogadores.get(1).getVidas() == 0) {
                        continuarJogando = false;
                        transmitir("OS DOIS JOGADORES PERDERAM AS VIDAS... NOVO ROUND SE INICIARA");
                    }
                }

            }

            //passa para o proximo round
            setPossivelChutar(false);
            roundAtual.setLetrasUsadas("");
            roundAtual = null;

        }
        mostrarResultadoFinal(jogadores);
    }

    //metodo que lista pontuacao
    public void mostrarResultadoFinal(List<GerenciadorCliente> jogadores) {
        // Ordenar a lista de jogadores com base na pontuação (do maior para o menor)
        jogadores.sort((jogador1, jogador2) -> jogador2.getScore().compareTo(jogador1.getScore()));

        transmitir("RANKING DE JOGADORES:");

        for (int i = 0; i < jogadores.size(); i++) {
            GerenciadorCliente jogador = jogadores.get(i);
            transmitir("Posição " + (i + 1) + ": " + jogador.getUsername() + " - Score: " + jogador.getScore());
        }
    }

    public void removerCliente() {
        clientes.remove(this);
        transmitir("SERVIDOR: " + username + " saiu da sala!");
    }

    public void fechaTudo(Socket socket, BufferedReader receber, BufferedWriter enviar) {
        try {
            if (socket != null) {
                socket.close();
            }
            if (enviar != null) {
                enviar.close();
            }
            if (receber != null) {
                receber.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//fim fechaTudo

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public Integer getVidas() {
        return vidas;
    }

    public void setVidas(Integer vidas) {
        this.vidas = vidas;
    }

    public Integer getPosicaoTurno() {
        return posicaoTurno;
    }

    public void setPosicaoTurno(Integer posicaoTurno) {
        this.posicaoTurno = posicaoTurno;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMensagemDaVez() {
        return mensagemDaVez;
    }

    public void setMensagemDaVez(String mensagemDaVez) {
        this.mensagemDaVez = mensagemDaVez;
    }

    public Boolean getPossivelChutar() {
        return possivelChutar;
    }

    public void setPossivelChutar(Boolean possivelChutar) {
        this.possivelChutar = possivelChutar;
    }

    public String getUsernameDaVez() {
        return usernameDaVez;
    }

    public void setUsernameDaVez(String usernameDaVez) {
        this.usernameDaVez = usernameDaVez;
    }

    private void enviaMsg(String msg, String user) {

        if (user == this.usernameDaVez) {
            this.mensagemDaVez = msg;
            System.out.println("LOG (validacao de mensagem): Usuario " + this.usernameDaVez + " digitou " + this.mensagemDaVez);
//To change body of generated methods, choose Tools | Templates.
        }
    }

    public boolean verificarLetraNaPalavra(String palavra, String letra) {
        return palavra.contains(letra);
    }

    public String ocultarPalavra(String palavra, String letrasUsadas) {
        StringBuilder palavraOcultada = new StringBuilder();

        for (int i = 0; i < palavra.length(); i++) {
            char letra = palavra.charAt(i);
            if (letrasUsadas.contains(String.valueOf(letra))) {
                palavraOcultada.append(letra + " ");
            } else {
                palavraOcultada.append(" _ ");
            }
        }

        return palavraOcultada.toString();
    }

    public int contarCaracteresComuns(String str1, String str2) {
        int contador = 0;

        // Percorre cada caractere da segunda string
        for (int i = 0; i < str2.length(); i++) {
            char caractere = str2.charAt(i);

            // Verifica se o caractere está presente na primeira string
            if (str1.contains(String.valueOf(caractere))) {
                contador++;
            }
        }

        return contador;
    }

    public boolean palavraDescoberta(String palavra, String letrasUsadas) {
        for (int i = 0; i < palavra.length(); i++) {
            char letra = palavra.charAt(i);
            if (!letrasUsadas.contains(String.valueOf(letra))) {
                return false;
            }
        }
        return true;
    }

}
