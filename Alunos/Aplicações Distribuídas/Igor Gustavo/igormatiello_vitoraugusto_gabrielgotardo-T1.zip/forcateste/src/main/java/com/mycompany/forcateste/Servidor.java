package com.mycompany.forcateste;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    private ServerSocket socket;

    public Servidor(ServerSocket socket) {
        this.socket = socket;
    }
    
    //List<String> usern
    
    public void iniciarSessao() throws IOException{
        while(!socket.isClosed()){
            /*Nesse ponto o servidor aguar uma coneção
            quando um cliente se conecta o .accept retorna um socket*/
            //O cliente usa o Objeto conecao para se conectar
            Socket conecao = socket.accept();
            System.out.println("Um cliente se conectou!");
            
         
            GerenciadorCliente gc = new GerenciadorCliente(conecao);
            
            /*Uma tread pode receber um objeto que contenha a interface
            RUNNABLE, a thread ficará responsável por rodar essa instância
            de forma separada e independente do resto do código*/
            Thread t = new Thread(gc);
            t.start();
        }//fim while
    }//fim iniciarSessao
    
    public void fecharSessao() throws IOException{
        if(socket != null){
            socket.close();
        }
    }
    
    public static void main(String[] args) throws IOException{
        ServerSocket socket = new ServerSocket(8082);//Seto a porta
        Servidor servidor = new Servidor(socket);//Instâncio um objeto
        System.out.println("Servidor subiu!");
        servidor.iniciarSessao();//Chamo o método de iniciar a sessão
    }
}