/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forcateste;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Igor
 */
import java.util.List;
import java.util.Random;

public class BancoDePalavras {

    public List<String> faceis = new ArrayList<>();
    public List<String> medias = new ArrayList<>();
    public List<String> dificieis = new ArrayList<>();
    public List<String> dicaFaceis1 = new ArrayList<>();
   
    public List<String> dicaDificieis1 = new ArrayList<>();
   
    public List<String> dicaMedias1 = new ArrayList<>();
 
  

    public Round obterPalavraAleatoria(Integer nivel) {
        List<String> lista = new ArrayList<>();
        List<String> dicas1 = new ArrayList<>();
        
        System.out.println("dentro do obterPalavraAleatoria, get nivel: " + nivel);
        Round round = new Round();
        round.setPontuacaoAcerto(nivel);
        switch (nivel) {
            case 1:
                lista = faceis;
                dicas1 = dicaFaceis1;
               
                break;
            case 2:
                lista = medias;
                dicas1 = dicaMedias1;
                
                break;
            case 3:
                lista = dificieis;
                dicas1 = dicaDificieis1;
                
                break;
            default:
                throw new IllegalArgumentException("Nível de dificuldade inválido");
        }

        Random random = new Random();
        int indiceAleatorio;
        String palavraAleatoria;
        do {
            indiceAleatorio = random.nextInt(lista.size());
            palavraAleatoria = lista.get(indiceAleatorio);
        } while (!palavraAleatoria.equals("")); // Verifica se a palavra está vazia

        round.setPosicaoPalavra(indiceAleatorio);
        round.setPalavraEscolhida(palavraAleatoria);
        round.setDica1(dicas1.get(indiceAleatorio));
        

        lista.set(indiceAleatorio, "");
        return round;
    }

    public void popularListas() {
        // Popule as listas com palavras e dicas aqui
        faceis.add("maça");
        dicaFaceis1.add("Fruta vermelha");
       
        faceis.add("banana");
        dicaFaceis1.add("Fruta amarela");
        
        faceis.add("laranja");
        dicaFaceis1.add("Fruta cítrica");
        
        faceis.add("uva");
        dicaFaceis1.add("Pequena fruta redonda");
        
        faceis.add("morango");
        dicaFaceis1.add("Pequena fruta vermelha");
        
        faceis.add("abacaxi");
        dicaFaceis1.add("Fruta tropical");
        
        faceis.add("limão");
        dicaFaceis1.add("Fruta amarela e ácida");
       
        faceis.add("pera");
        dicaFaceis1.add("Fruta de casca fina");
        
        faceis.add("manga");
        dicaFaceis1.add("Fruta tropical");
        
        faceis.add("kiwi");
        dicaFaceis1.add("Fruta pequena e peluda");
        
        medias.add("elefante");
        dicaMedias1.add("Animal gigante terrestre");
       
        medias.add("girafa");
        dicaMedias1.add("Animal com pescoço longo");
       
        medias.add("leao");
        dicaMedias1.add("Rei da selva");
        
        medias.add("tigre");
        dicaMedias1.add("Animal listrado");  

        medias.add("hipopótamo");
        dicaMedias1.add("Animal aquático");
        
        medias.add("rinoceronte");
        dicaMedias1.add("Animal de pele grossa");
        
        medias.add("zebra");
        dicaMedias1.add("Animal listrado preto e branco");
        
        medias.add("camelo");
        dicaMedias1.add("Animal do deserto");
       
        medias.add("macaco");
        dicaMedias1.add("Primate ágil");
        
        medias.add("panda");
        dicaMedias1.add("Urso preto e branco");
        
        dificieis.add("retrato");
        dicaDificieis1.add("Imagem de uma pessoa ou objeto");
      
        dificieis.add("computador");
        dicaDificieis1.add("Máquina usada para processar dados");
       
        dificieis.add("telefone");
        dicaDificieis1.add("Dispositivo de comunicação");
        
        dificieis.add("avião");
        dicaDificieis1.add("Meio de transporte aéreo");
       
        dificieis.add("livro");
        dicaDificieis1.add("Contém texto e imagens");
       
    }


}
