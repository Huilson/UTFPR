
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author Igor
 */
public class ServerUDP {

    /**
     * @param args the command line arguments
     */
    private DatagramSocket ds;
    private byte[] buffer = new byte[256];

    public ServerUDP(DatagramSocket ds) {
        this.ds = ds;
    }

    public void conversa() throws IOException {
        while (true) {
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
            ds.receive(datagram);

            String pesoRecebido = new String(datagram.getData(), 0, datagram.getLength());
            double pesoReal = Double.parseDouble(pesoRecebido);

            datagram = new DatagramPacket(buffer, buffer.length);
            ds.receive(datagram);

            String alturaRecebida = new String(datagram.getData(), 0, datagram.getLength());
            double alturaReal = Double.parseDouble(alturaRecebida);

            double imc = pesoReal / (alturaReal * alturaReal);

            String imcString = Double.toString(imc);
            byte[] imcBytes = imcString.getBytes();

            DatagramPacket imcPacket = new DatagramPacket(imcBytes, imcBytes.length, datagram.getAddress(), datagram.getPort());
            ds.send(imcPacket);

        }

    }

    public static void main(String[] args) throws SocketException {
        try ( DatagramSocket ds = new DatagramSocket(8081)) {
            ServerUDP server = new ServerUDP(ds);
            System.out.println("O servidor subiu!");
            server.conversa();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
