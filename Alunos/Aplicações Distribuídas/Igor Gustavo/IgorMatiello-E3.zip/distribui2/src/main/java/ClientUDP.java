
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.DecimalFormat;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author Igor
 */
public class ClientUDP {

    /**
     * @param args the command line arguments
     */
      private DatagramSocket ds;

    public ClientUDP(DatagramSocket ds) {
        this.ds = ds;
    }

    public void conversa() throws IOException {
        Scanner scan = new Scanner(System.in);

        while (true) {
            Pessoa pessoa = new Pessoa();

            System.out.println("Escreva seu nome:");
            pessoa.setNome(scan.next());

            System.out.println("Escreva seu peso:");
            pessoa.setPeso(scan.nextDouble());

            System.out.println("Escreva sua altura:");
            pessoa.setAltura(scan.nextDouble());

            byte[] pesoBytes = Double.toString(pessoa.getPeso()).getBytes();
            DatagramPacket pesoPacket = new DatagramPacket(pesoBytes, pesoBytes.length, InetAddress.getLocalHost(), 8081);
            ds.send(pesoPacket);

            byte[] alturaBytes = Double.toString(pessoa.getAltura()).getBytes();
            DatagramPacket alturaPacket = new DatagramPacket(alturaBytes, alturaBytes.length, InetAddress.getLocalHost(), 8081);
            ds.send(alturaPacket);

            byte[] imcBuffer = new byte[256];
            DatagramPacket imcPacket = new DatagramPacket(imcBuffer, imcBuffer.length);
            ds.receive(imcPacket);

            String mensagemRecebida = new String(imcPacket.getData(), 0, imcPacket.getLength());
            System.out.println("O servidor calculou o IMC: " + mensagemRecebida);
        }
    }

    public static void main(String[] args) {
        try (DatagramSocket ds = new DatagramSocket()) {
            ClientUDP cliente = new ClientUDP(ds);
            System.out.println("O cliente está pronto!");
            cliente.conversa();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
