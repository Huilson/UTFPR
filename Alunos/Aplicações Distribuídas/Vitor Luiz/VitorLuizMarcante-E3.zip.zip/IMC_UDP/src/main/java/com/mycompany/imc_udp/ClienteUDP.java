package com.mycompany.imc_udp;

/**
 *
 * @author Vitor
 */
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ClienteUDP {
    private DatagramSocket ds;
    private byte[] buffer = new byte [256];//array de buffer que para mensagem
    private InetAddress ip ;
    
    public ClienteUDP(DatagramSocket ds, InetAddress ip) {
        this.ds = ds;
        this.ip = ip;
    }
    
    public void conversa(double altura, double peso, PessoaUDP pessoa) throws IOException{
        Scanner scan = new Scanner (System.in);
        
        String msg = String.valueOf(peso);
        buffer = msg.getBytes();
        DatagramPacket datagram = new DatagramPacket(buffer, buffer.length, ip, 8081);
        ds.send(datagram);

        msg = String.valueOf(altura);
        buffer = msg.getBytes();
        datagram = new DatagramPacket(buffer, buffer.length, ip, 8081);
        ds.send(datagram);
        
        ds.receive(datagram);

        String msgRecebida = new String(datagram.getData(), 0, datagram.getLength());
        System.out.println("IMC:" + msgRecebida);
        double imc = Double.parseDouble(msgRecebida);
        
        pessoa.setImc(imc);
    }
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {   
        Scanner scanner = new Scanner(System.in);
        DatagramSocket ds = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        ClienteUDP  client = new ClienteUDP(ds, ip);
        
        //Nova pessoa 
        PessoaUDP pessoa = new PessoaUDP();
        System.out.print("nome: ");
        pessoa.setNome(scanner.nextLine());
        System.out.print("idade: ");
        pessoa.setIdade(scanner.nextInt());
        scanner.nextLine();
        System.out.print("peso (kg): ");
        pessoa.setPeso(scanner.nextDouble());
        scanner.nextLine();
        System.out.print("altura (cm): ");
        pessoa.setAltura(Double.parseDouble(scanner.nextLine()));
        
        client.conversa(pessoa.getAltura(), pessoa.getPeso(), pessoa);

        System.out.println( pessoa.getClassificacaoIMC());

    }
}
