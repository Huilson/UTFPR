/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.imc_udp;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

/**
 *
 * @author Vitor
 */
public class ServidorUDP {
    private PessoaUDP pessoa;
    private DatagramSocket ds;//socket para estabelecer comunicação

    private byte[] buffer = new byte[256];//array de buffer que para enviar mensagem

    public ServidorUDP(DatagramSocket ds) {
        this.ds = ds;
    }

    public void conversa() throws IOException {
        Scanner scan = new Scanner(System.in);
        double altura = 0;
        double peso = 0;
       
        DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);

        ds.receive(datagram);

        //deserializar o datagram
        String msgRecebida = new String(datagram.getData(), 0, datagram.getLength());

        peso = Double.parseDouble(msgRecebida);

        ds.receive(datagram);

        msgRecebida = new String(datagram.getData(), 0, datagram.getLength());

        altura = Double.parseDouble(msgRecebida);

        System.out.println("Altura: " + altura);
        System.out.println("Peso: " + peso);

        //cabeçalho
        InetAddress ip = datagram.getAddress();
        int porta = datagram.getPort();

        String msg = String.valueOf(calcularIMC(peso, altura));
        buffer = msg.getBytes();

        datagram = new DatagramPacket(buffer, buffer.length, ip, porta);

        //Envia o pacote 
        ds.send(datagram);

    }

    //conta do IMC
    public double calcularIMC(double peso, double altura) {
        return  (double) (peso / (altura * altura)) * 10000;
        //Multiplico pq a altura eu estou informando em CM
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        DatagramSocket ds = new DatagramSocket(8081);
        ServidorUDP server = new ServidorUDP(ds);
        server.conversa();
    }
}

