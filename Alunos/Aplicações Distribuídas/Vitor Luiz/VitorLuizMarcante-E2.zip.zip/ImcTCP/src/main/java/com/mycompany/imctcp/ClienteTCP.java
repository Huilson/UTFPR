/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.imctcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Vitor Marcante
 */
public class ClienteTCP {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
        Socket socket = new Socket("127.0.0.1",8080); 
     
        Scanner scanner = new Scanner(System.in);

        Pessoa pessoa = new Pessoa();

        System.out.print("Digite seu nome: ");
        pessoa.setNome(scanner.nextLine());

        System.out.print("Digite sua altura: ");
        pessoa.setAltura(Double.parseDouble(scanner.nextLine()));

        System.out.print("Digite sua idade: ");
        pessoa.setIdade(Integer.parseInt(scanner.nextLine()));

        System.out.print("Digite seu peso: ");
        pessoa.setPeso(Double.parseDouble(scanner.nextLine()));
        
        
        ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());

        saida.writeObject(pessoa);
        

      ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());
      
       pessoa = (Pessoa)entrada.readObject();
        System.out.println("imc = "+ pessoa.getImc());
        if (pessoa.getImc() < 18.5){
            System.out.println("Abaixo do pesso");
        }
        else if(pessoa.getImc()>= 18.5 && pessoa.getImc()< 25){
            System.out.println("Peso normal");
        }
        else if(pessoa.getImc()>= 25 && pessoa.getImc()< 30){
            System.out.println("Acima do peso");
        }
        else if(pessoa.getImc()>= 30 && pessoa.getImc()< 35){
            System.out.println("Obesidade grau I");
        }
        else if(pessoa.getImc()>= 35 && pessoa.getImc()< 40){
            System.out.println("Obesidade grau II");
        }
        else {
            System.out.println("Obesidade grau III");
        }
        
        entrada.close();
        saida.close();
        socket.close();
    }
}
