package org.example.View;

import javax.swing.*;

public class TelaPrincipal {
    private JTextField textField1;
    private JTextField textField2;
    private JButton iniciarButton;
}
