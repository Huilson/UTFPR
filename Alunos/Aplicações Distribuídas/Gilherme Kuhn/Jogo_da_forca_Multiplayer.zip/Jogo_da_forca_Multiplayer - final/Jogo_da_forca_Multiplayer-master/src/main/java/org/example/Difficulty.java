package org.example;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}
