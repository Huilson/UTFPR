package com.server.servidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
