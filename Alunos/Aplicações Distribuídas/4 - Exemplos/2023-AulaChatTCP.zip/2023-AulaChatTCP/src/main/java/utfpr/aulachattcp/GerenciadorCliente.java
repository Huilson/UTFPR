package utfpr.aulachattcp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

class GerenciadorCliente implements Runnable{
    private Socket socket;
    
    /*Criamos um array para cada instância dessa clase, o objetivo principal
    desse array é ficar de olho em cada cliente, para quando um cliente
    mandar uma mensagem possamos percorrer o array e mandar a mensagem
    para todos os outros clientes do array*/
    public static ArrayList<GerenciadorCliente> clientes = new ArrayList<>();
    
    //Buffer de entrada e saida
    private BufferedReader receber;
    private BufferedWriter enviar;
    
    private String username;

    public GerenciadorCliente(Socket socket) {
        try{
        this.socket = socket;
        //Stream e buffer para leitura e escrita na rede
        this.receber = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.enviar = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        //Ao atribuir um valor para a String username, ela será lida pelo buffer
        this.username = receber.readLine();
        clientes.add(this);
        }catch(IOException e){
            fechaTudo(socket, receber, enviar);
        }//fim do tryCatch
    }//fim do construtor

    @Override
    public void run() {
        /*Toda vez que estamos ouvindo alguma mensagem nosso programa
        bloqueia o restante do código, porém precisamos ser capaz
        de continuar a enviar mensagens e ainda assim ficar ouvindo,
        para isso precisamos trabalhar com THREADS, do qual são capazes
        de executar o nosso código em blocos*/
        String msg;
        while(socket.isConnected()){
            try{
                msg = receber.readLine();
                transmitir(msg);
            }catch(IOException e){
                fechaTudo(socket, receber, enviar);
            }
        }//fim while
    }

    private void transmitir(String msg) {
        //Para cada cliente no loop do while no método RUN cria-se uma iteração
        for(GerenciadorCliente cliente : clientes){//for each entre todos os clientes
            try{
                if(!cliente.username.equals(username)){//ignora o cliente que envio a mensagem
                    cliente.enviar.write(msg);//Serialização da mensagem e envio pela rede
                    cliente.enviar.newLine();//Quando o cliente apertar ENTER o programa entede
                    //que a mensagem foi finalizada, dessa forma o buffer se adapta ao tamanho
                    //da mensagem e não fica sobrecarregado, e depois de enviado se esvazia automaticamente
                    cliente.enviar.flush();
                }//fim IF
            }catch(IOException e){
               fechaTudo(socket, receber, enviar); 
            }
        }//fim do FOR
    }
    
    public void removerCliente(){
        clientes.remove(this);
        transmitir("SERVIDOR: " +username+ " saiu da sala!");
    }
    
    public void fechaTudo(Socket socket, BufferedReader receber, BufferedWriter enviar){
        try{
            if(socket != null){
                socket.close();
            }
            if(enviar != null){
                enviar.close();
            }
            if(receber != null){
                receber.close();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }//fim fechaTudo
}