/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.conexao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author benalian42
 */
public class ConexaoUDP {
    
    private DatagramSocket socket;
    private DatagramPacket pacote;
    private InetAddress destino;
    private ByteArrayOutputStream saidaByteArray;
    private ObjectOutputStream saidaObjeto;
    private ObjectInputStream entradaObjeto;
    
    
    public void inicializaConexao (String ip, int porta) throws UnknownHostException, SocketException
    {
        destino = InetAddress.getByName( ip );
        socket = new DatagramSocket (porta,destino);
    }
    
    public void mandaMensagem ( Object mensagem ) throws IOException
    {
        saidaByteArray = new ByteArrayOutputStream();
        saidaObjeto = new ObjectOutputStream(saidaByteArray);
    }
    
    public void fecharSocket () throws IOException
    {
        socket.close();
    }
}