
package br.edu.utfpr.hud;
import br.edu.utfpr.jogo.Facil;
import java.util.Arrays;
import java.util.List;
import java.util.Random; 

public class Main {

    public static void main(String[] args) {
    
    }
}
