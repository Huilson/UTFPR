package br.edu.utfpr.jogo;

import br.edu.utfpr.jogo.Facil;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class JogoDaForca {
    private int dificuldade, tentativas = 6, acertos;
    private int tentativasMax;
    private String palavraSorteada;
    private String tracos = "";
    private boolean ganho = false;
    private boolean derrota = false;
    Random gerador = new Random(); 
    
    public static final int FACIL = 1;
    public static final int MEDIO = 2;
    public static final int DIFICIL = 3;

    public String getTracos() {
        return tracos;
    }

    public boolean isGanho() {
        return ganho;
    }

    public void setGanho(boolean ganho) {
        this.ganho = ganho;
    }

    public boolean isDerrotado() {
        return derrota;
    }

    public void setDerrotado(boolean derrotado) {
        this.derrota = derrotado;
    }
        
    public JogoDaForca ()
    {
    }
    
    public int getAcertos() {
        return acertos;
    }

    public void setAcertos(int acertos) {
        this.acertos = acertos;
    }
    
    public int getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(int dificuldade) {
        this.dificuldade = dificuldade;
    }

    public int getTentativas() {
        return tentativas;
    }

    public void setTentativas(int tentativas) {
        this.tentativas = tentativas;
    }

    public String getPalavraSorteada() {
        return palavraSorteada;
    }

    public void setPalavraSorteada(String palavraSorteada) {
        this.palavraSorteada = palavraSorteada;
    }
    
    
    public void populaTracos()
    {
        for (int i = 0 ; i < palavraSorteada.length() ; i++)
            tracos += "_";
    }
    
    public void sorteiaPalavra ()
    {
        
        switch (this.dificuldade)
        {
            case  FACIL:
                List<Facil> listFacil = Arrays.asList(Facil.values());
                int i = gerador.nextInt(listFacil.size() - 1);
                palavraSorteada = listFacil.get(i).toString();
                System.out.println("Palavra sorteada: " + listFacil.get(i).toString());
                break;
            case MEDIO:
                List<Medio> listMedio = Arrays.asList(Medio.values());
                i = gerador.nextInt(listMedio.size() - 1);
                palavraSorteada = listMedio.get(i).toString();
                System.out.println("Palavra sorteada: " + listMedio.get(i).toString());
                break;
            case DIFICIL:
                List<Dificil> listDificil = Arrays.asList(Dificil.values());
                i = gerador.nextInt(listDificil.size() - 1);
                palavraSorteada = listDificil.get(i).toString();
                System.out.println("Palavra sorteada: " + listDificil.get(i).toString());
                break;
        }
    }
    
    public void verificaAcerto( char chute )
    {
        char[] t = new char[palavraSorteada.length()];
        tracos.getChars(0, palavraSorteada.length(), t, 0);
        tracos = new String();
        
        int j = 0;
        for (int i = 0 ; i < palavraSorteada.length() ; i++) {
            
            if( chute == palavraSorteada.charAt(i) && t[i] == '_')
            {
                j++;
                this.acertos++;
                t[i] = chute;
            }
                tracos += (String.valueOf(t[i]));
        }
        
        if ( acertos == palavraSorteada.length() )
            this.ganho = true;
        
        if ( j == 0 )
        {
            if ( this.tentativas-- == 1 )
                this.derrota = true;
        }
    }
}
