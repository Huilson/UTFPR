/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.jogo;

import java.util.Queue;

/**
 *
 * @author karla
 */
public class Rodada extends JogoDaForca {
    
    private Queue<Jogador> jogadores;
    private Jogador turno;
    private Dica dica;
    
    public void JogoDaForca (){
        
    }
    
    public void enfileirarJogador ()
    {
    
    }
    
    public void desinfileirarJogador ()
    {
    
    }
    //dificuldade
    //turno
    //dica
    //palavra sorteada
    //jogadores
    //qtde chutes 
    //score
    //qtde vidas
}
