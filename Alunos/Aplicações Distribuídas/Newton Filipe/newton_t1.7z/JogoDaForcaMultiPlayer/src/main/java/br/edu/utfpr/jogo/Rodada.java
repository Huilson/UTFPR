/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.jogo;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author karla
 */
public class Rodada extends JogoDaForca {
    
    private List<Jogador> jogadores;
    private Jogador turno, proprio;
    private Dica dica;
    
    public Rodada ( String apelido )
    {
        super();
        jogadores = new ArrayList<Jogador>();
        
        proprio = new Jogador (apelido);
        jogadores.add(proprio);
        
        
    }
    
    public void enfileirarJogador ()
    {
    
    }
    
    public void desinfileirarJogador ()
    {
    
    }

    public Jogador getProprio() {
        return proprio;
    }
    public void setProprio(Jogador proprio) {
        this.proprio = proprio;
    }
    
    public List<Jogador> getJogadores() {
        return jogadores;
    }
    public void setJogadores( List<Jogador> jogadores ) {
        this.jogadores = jogadores;
    }
    
    //dificuldade
    //palavra sorteada
    //jogadores
    //qtde chutes 
    //score
    //qtde vidas

    

    
}
