
package br.edu.utfpr.jogo;

public enum Facil {
    sorte,
    azar,
    amor,
    odio,
    feliz,
    mouse,
    casa, 
    gato, 
    dia, 
    noite, 
    sol, 
    lua, 
    limao, 
    
}
