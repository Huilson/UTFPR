
package br.edu.utfpr.jogo;

public enum Dificil {
    paralelepipedo, 
    interruptor, 
    projetor, 
    felicidade, 
    facilidade, 
    apartamento, 
    caminhão, 
    computador, 
    jaguatirica, 
    capilaridade, 
    eletronica, 
    software,    
}
