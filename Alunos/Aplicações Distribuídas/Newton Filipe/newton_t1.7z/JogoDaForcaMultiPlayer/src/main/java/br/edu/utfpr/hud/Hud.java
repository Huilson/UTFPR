
package br.edu.utfpr.hud;

import br.edu.utfpr.jogo.JogoDaForca;
import java.util.Scanner;

public class Hud {
    private JogoDaForca jogo = new JogoDaForca();
    
    public void telaInicial(){
        System.out.println("Escolha a dificuldade do jogo (1-Facil, 2-Medio ou 3-Dificil: ");
        Scanner scanner = new Scanner (System.in); 
        int op = scanner.nextInt();
        jogo.setDificuldade(op);
    }
}
