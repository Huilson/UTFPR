/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.utfpr.conexao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.BindException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author benalian42
 */
public class ConexaoUDP {
    
    private DatagramSocket socket;
    private DatagramPacket pacote;
    private InetAddress destino;
    private ByteArrayOutputStream saidaByteArray;
    private ObjectOutputStream saidaObjeto;
    private ObjectInputStream entradaObjeto;
    private int porta;
    
    //inicializa conexao em uma porta valida
    public void inicializaSocket ( String ip ) throws UnknownHostException, SocketException
    {
        destino = InetAddress.getByName( ip );
        socket = new DatagramSocket ();
    }
    
    public void mandaMensagem ( Object mensagem ) throws IOException
    {
        //serializa mensagem
        saidaByteArray = new ByteArrayOutputStream();
        saidaObjeto = new ObjectOutputStream(saidaByteArray);
        
        //manda mensagem
        //pacote = new DatagramPacket (  );
        //socket.send();
    }
    
    public void fecharSocket () throws IOException
    {
        socket.close();
    }
}