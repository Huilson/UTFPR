Projeto desenvolvido para a matéria de Desenvolvimento de Aplicações Distribuídas.
