/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TCP;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aluno
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException {
        try {
            ServerSocket serversocket = new ServerSocket(9090);
            System.out.println("ouvindo porta 8080");
            
            //Abrir Comunicação
            
            Socket socket = serversocket.accept();
            
            //Mostrar o ip do cliente que vai conectar
            
            System.out.println("Um cliente se conectou: " + socket.getInetAddress().getHostAddress());
            
            // definir um stream de entrada 
            
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            ObjectInputStream in = new ObjectInputStream(entrada);
            Pessoa pessoa = (Pessoa)in.readObject();
            
            pessoa.setImc(pessoa.getPeso() / (pessoa.getAltura() * pessoa.getAltura()));
            
            System.out.println("recebido no serv: " + pessoa.getNome() + " peso " +
                pessoa.getPeso() + " altura " + pessoa.getAltura() + " calculando imc");
            
            //saida
            DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
            ObjectOutputStream out = new ObjectOutputStream(saida);
            
            out.writeObject(pessoa);
            
            //fechar tudo apos a conversa            
            saida.close();
            entrada.close();
            socket.close();
            serversocket.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
