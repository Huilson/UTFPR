/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class ClientUDP {

    private  DatagramSocket ds;//socket de envio udp
    private  byte[] buffer;//array de bytes que receberá a mensagem serializada a ser enviada
    private  InetAddress ip;//ip de envio

    public ClientUDP(DatagramSocket ds, InetAddress ip) {
        this.ds = ds;
        this.ip = ip;
    }
    
    

    public static void main(String[] args) throws IOException {
       DatagramSocket ds = new DatagramSocket();
       InetAddress ip = InetAddress.getByName("localhost");
       ClientUDP client = new ClientUDP(ds, ip);
       
        
        client.conversar();
    }

     private void conversar() throws IOException{
         Scanner scan = new Scanner(System.in);
        
         while(true){
              System.gc();
            Pessoa p = new Pessoa();
            
            //Definindo atributos da pessoa
             System.out.println("Digite o nome: ");
            p.setNome(scan.next());
            
            System.out.println("Digite a altura: ");
            p.setAltura(scan.nextDouble());
            
            System.out.println("Digite o peso:");
            p.setPeso(scan.nextDouble());
            
            //Serializando a string
            //Junta altura e peso em uma string, separados por um pipe, e envia
            String msg = p.getAltura()+"|"+ p.getPeso();
            buffer = msg.getBytes();
            
            //criando datagram
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length, ip, 8081);
            
            //enviado datagram
            ds.send(datagram);
            
            //espera um pacote
            ds.receive(datagram);
            
            //Recebendo o imc
            String msgRecebida = new String(datagram.getData(), 0, datagram.getData().length);
             
            //Transformando o imc em valor double e adicionando a pessoa
            p.setImc(Double.parseDouble(msgRecebida));
            
            System.out.println("Pessoa de nome: " + p.getNome() 
                     + "\naltura: " + p.getAltura() 
                     + "\npeso: " + p.getPeso()
                     + "\nimc: " + p.getImc());
            
        }
    }
    
}
