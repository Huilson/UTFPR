/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class ServerUDP {

    private  DatagramSocket ds;//socket de envio udp
    private  byte[] buffer = new byte[256];//array de bytes que receberá a mensagem serializada a ser enviada

    public ServerUDP(DatagramSocket ds) {
        this.ds = ds;
    }

    
    public static void main(String[] args) throws UnknownHostException, SocketException, IOException {
        DatagramSocket ds = new DatagramSocket(8081);
       ServerUDP server = new ServerUDP(ds);
       
      System.out.println("certo! Esperando cliente");
        server.conversar();
        
    }
    
    private void conversar() throws IOException{
        
        while(true){
            DatagramPacket datagram = new DatagramPacket(buffer, buffer.length);
             
             
            //espera um pacote
            ds.receive(datagram);
            
            //Deserializando o datagram recebido
           String msgRecebida = new String(datagram.getData(), 0, datagram.getLength());
           //Quebrando o peso em altura em dois valores separados (split por |)
             System.out.println("msgRecebida: " + msgRecebida);
           String[] msgQuebrada = msgRecebida.split("\\|");
           
           //Extraindo valores double do peso e altura
             System.out.println("altura: " + msgQuebrada[0]);
             System.out.println("peso: " + msgQuebrada[1]);
           double altura = Double.parseDouble(msgQuebrada[0]);
           double peso = Double.parseDouble(msgQuebrada[1]);
           
           //efetuando calculo
           double imcPessoa = peso / (altura*altura);
           
           //extraindo ip e porta do datagram recebido
           InetAddress ip = datagram.getAddress();
           int porta = datagram.getPort();
           
           //transformando o imc como string em buffer
           String msg = Double.toString(imcPessoa);
           buffer = msg.getBytes();
           
           //datagram que retornará informações ao cliente
            datagram  = new DatagramPacket(buffer, buffer.length, ip, porta);
           
            
            //enviado datagram
            ds.send(datagram);
        }
              
    }
    
}
