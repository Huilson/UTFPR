/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TCP;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author Aluno
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Socket socket = new Socket("localhost", 9090);

        //criando output
        DataOutputStream saida = new DataOutputStream(socket.getOutputStream());

        //enviando
        Pessoa pessoa = new Pessoa("Jose", 70.9, 1.70, 19);
        ObjectOutputStream out = new ObjectOutputStream(saida);
        System.out.println("Enviando cliente pro serv: " + pessoa.getNome() + " peso " +
                pessoa.getPeso() + " altura " + pessoa.getAltura());
        
        out.writeObject(pessoa);

        //criando input
        DataInputStream entrada = new DataInputStream(socket.getInputStream());
        ObjectInputStream in = new ObjectInputStream(entrada);
        pessoa = (Pessoa)in.readObject();
        
        System.out.println("recebido no serv: " + pessoa.getNome() + 
                " peso " + pessoa.getPeso() + " altura " + pessoa.getAltura() + "imc " + pessoa.getImc());


        //fechar tudo apos a conversa 
        entrada.close();
        saida.close();
        socket.close();
    }

}
