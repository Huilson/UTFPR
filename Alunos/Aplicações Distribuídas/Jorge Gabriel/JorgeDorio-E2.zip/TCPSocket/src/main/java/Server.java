import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345); // Criar um servidor na porta 12345

            while (true) {
                System.out.println("Esperando conexão...");
                Socket socket = serverSocket.accept(); // Aceitar conexão do cliente

                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

                Person person = (Person) in.readObject(); // Receber objeto Pessoa do cliente

                // Calcula o IMC
                person = updateIMC(person);

                out.writeObject(person); // Enviar objeto Pessoa atualizado de volta ao cliente

                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Person updateIMC(Person person) {
        person = new Person(person.getName(), person.getAge(), person.getWeight(), person.getHeight());
        return person;
    }
}
