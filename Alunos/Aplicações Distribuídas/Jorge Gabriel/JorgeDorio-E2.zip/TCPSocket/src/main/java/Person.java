import java.io.Serializable;

public class Person implements Serializable {
    private String name;
    private int age;
    private double weight;
    private double height;
    private double bmi;

    public Person(String name, int age, double weight, double height) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.bmi = calculateBMI();
    }

    private double calculateBMI() {
        return weight / (height * height);
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }

    public double getBMI() {
        return bmi;
    }
}
