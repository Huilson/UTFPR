import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345); // Conectar ao servidor na porta 12345

            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            // Preencher informações da pessoa
            String name = "Jorge";
            int age = 21;
            double weight = 97;
            double height = 1.84;

            Person person = new Person(name, age, weight, height);

            out.writeObject(person); // Enviar objeto Pessoa para o servidor

            // Receber objeto atualizado do servidor
            Person updatedPerson = (Person) in.readObject();

            System.out.println("BMI: " + updatedPerson.getBMI());

            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
