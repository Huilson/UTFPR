import java.util.Scanner;
import java.util.Random;
import java.util.HashSet;

public class HangmanGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Dicionário de palavras
        String[] words = {"BACAXI", "BANANA", "MORANGO", "LARANJA", "UVA", "MELANCIA"};

        // Defina dificuldade e palavra aleatória
        System.out.println("Escolha a dificuldade: FACIL, MEDIO, DIFICIL");
        String difficulty = scanner.next().toUpperCase();
        String chosenWord = chooseWord(words, difficulty, random);

        // Configuração inicial
        int lives = 6;
        HashSet<Character> usedLetters = new HashSet<>();
        StringBuilder currentWord = new StringBuilder();
        for (int i = 0; i < chosenWord.length(); i++) {
            currentWord.append("_");
        }

        // Ciclo principal do jogo
        while (lives > 0 && currentWord.toString().contains("_")) {
            displayHUD(lives, usedLetters, currentWord.toString());
            displayHangman(lives);

            System.out.println("Digite uma letra: ");
            char letter = scanner.next().toUpperCase().charAt(0);

            if (usedLetters.contains(letter)) {
                System.out.println("Você já usou essa letra.");
                continue;
            }

            usedLetters.add(letter);

            if (chosenWord.contains(String.valueOf(letter))) {
                for (int i = 0; i < chosenWord.length(); i++) {
                    if (chosenWord.charAt(i) == letter) {
                        currentWord.setCharAt(i, letter);
                    }
                }
            } else {
                lives--;
                System.out.println("Letra não encontrada na palavra. Vidas restantes: " + lives);
            }
        }

        // Exibe resultado final
        if (lives > 0) {
            System.out.println("Parabéns, você adivinhou a palavra: " + chosenWord);
        } else {
            System.out.println("Suas tentativas acabaram. A palavra era:" + chosenWord);
        }

        scanner.close();
    }

    public static String chooseWord(String[] words, String difficulty, Random random) {
        String word = "";
        if (difficulty.equals("FACIL")) {
            word = words[random.nextInt(words.length)];
            while (word.length() > 5) {
                word = words[random.nextInt(words.length)];
            }
        } else if (difficulty.equals("MEDIO")) {
            word = words[random.nextInt(words.length)];
            while (word.length() <= 5 || word.length() > 8) {
                word = words[random.nextInt(words.length)];
            }
        } else if (difficulty.equals("DIFICIL")) {
            word = words[random.nextInt(words.length)];
            while (word.length() <= 8) {
                word = words[random.nextInt(words.length)];
            }
        }
        return word;
    }

    public static void displayHUD(int lives, HashSet<Character> usedLetters, String currentWord) {
        System.out.println("Vidas restantes: " + lives);
        System.out.print("Letras usadas: ");
        for (char letter : usedLetters) {
            System.out.print(letter + " ");
        }
        System.out.println("\nPalavra atual: " + currentWord);
    }

    public static void displayHangman(int lives) {
        System.out.println("  _______");
        System.out.println(" |       |");

        if (lives < 6) {
            System.out.println(" |       O");
        } else {
            System.out.println(" |");
        }

        if (lives < 4) {
            if (lives == 3) {
                System.out.println(" |      /|\\");
            } else if (lives == 2) {
                System.out.println(" |      /|");
            } else {
                System.out.println(" |       |");
            }
        } else {
            System.out.println(" |");
        }

        if (lives < 2) {
            if (lives == 1) {
                System.out.println(" |      /");
            } else {
                System.out.println(" |");
            }
        } else {
            System.out.println(" |");
        }

        System.out.println("_|_");
    }
}
