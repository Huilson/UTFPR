import java.util.Scanner;
import java.util.Random;

public class HangmanGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Dicionário de palavras
        String[] words = {"BACAXI", "BANANA", "MORANGO", "LARANJA", "UVA", "MELANCIA", "CARAMBOLA"};

        // Define dificuldade e palavra aleatória
        System.out.println("Escolha a dificuldade: FACIL, MEDIO, DIFICIL");
        String difficulty = scanner.next().toUpperCase();
        String chosenWord = chooseWord(words, difficulty, random);

        // Configuração inicial
        int lives = 6;
        String usedLetters = "";
        String currentWord = "";
        for (int i = 0; i < chosenWord.length(); i++) {
            currentWord += "_";
        }

        // Ciclo principal do jogo
        while (lives > 0 && currentWord.contains("_")) {
            displayHUD(lives, usedLetters, currentWord);

            System.out.println("Digite uma letra: ");
            char letter = scanner.next().toUpperCase().charAt(0);

            if (usedLetters.indexOf(letter) != -1) {
                System.out.println("Você já usou essa letra.");
                continue;
            }

            usedLetters += letter;

            boolean letterFound = false;
            char[] newCurrentWordArray = currentWord.toCharArray();

            for (int i = 0; i < chosenWord.length(); i++) {
                if (chosenWord.charAt(i) == letter) {
                    newCurrentWordArray[i] = letter;
                    letterFound = true;
                }
            }

            if (!letterFound) {
                lives--;
                System.out.println("Letra não encontrada na palavra. Vidas restantes: " + lives);
            }

            currentWord = new String(newCurrentWordArray);
        }

        // Exibe resultado final
        if (lives > 0) {
            System.out.println("Parabéns, você adivinhou a palavra: " + chosenWord);
        } else {
            System.out.println("Suas tentativas acabaram. A palavra era:" + chosenWord);
        }

        scanner.close();
    }

    public static String chooseWord(String[] words, String difficulty, Random random) {
        String word = "";
        if (difficulty.equals("FACIL")) {
            word = words[random.nextInt(words.length)];
            while (word.length() > 5) {
                word = words[random.nextInt(words.length)];
            }
        } else if (difficulty.equals("MEDIO")) {
            word = words[random.nextInt(words.length)];
            while (word.length() <= 5 || word.length() > 8) {
                word = words[random.nextInt(words.length)];
            }
        } else if (difficulty.equals("DIFICIL")) {
            word = words[random.nextInt(words.length)];
            while (word.length() <= 8) {
                word = words[random.nextInt(words.length)];
            }
        }
        return word;
    }

    public static void displayHUD(int lives, String usedLetters, String currentWord) {
        System.out.println("Vidas restantes: " + lives);
        System.out.print("Letras usadas: ");
        for (int i = 0; i < usedLetters.length(); i++) {
            System.out.print(usedLetters.charAt(i) + " ");
        }
        System.out.println("\nPalavra atual: " + currentWord);
    }
}
