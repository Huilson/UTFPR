package utfpr.UDPSocket;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        DatagramSocket socket = null;
        Scanner sc = new Scanner(System.in);
        try {
            socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName("localhost"); // Endereço do servidor
            int serverPort = 1234; // Porta do servidor

            // Recebe os dados da pessoa
            People p = new People();
            System.out.println("Insira o nome:");
            p.setName(sc.next());
            System.out.println("Insira a idade:");
            p.setAge(sc.nextInt());
            System.out.println("Insira o peso em kg:");
            p.setWeight(sc.nextInt());
            System.out.println("Insira a altura em cm:");
            p.setHeight(sc.nextInt());

            // Compila e converte os dados para bytes
            String data = p.getName() + "|" + p.getAge() + "|" + p.getWeight() + "|" + p.getHeight();
            byte[] dataInBytes = data.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(dataInBytes, dataInBytes.length, serverAddress, serverPort);
            socket.send(sendPacket);

            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            socket.receive(receivePacket);
            String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println(response);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                // Fecha a conexão
                socket.close();
            }
        }
    }
}
