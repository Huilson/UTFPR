package utfpr.UDPSocket;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        DatagramSocket socket = null;

        try {
            socket = new DatagramSocket(1234); // Porta do servidor
            byte[] receiveData = new byte[1024];

            while (true) {
                // Recebe o pacote
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);

                // Separa os dados
                String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength());
                String[] dataParts = receivedData.split("\\|");

                if (dataParts.length == 4) {
                    // Monta a pessoa
                    People p = new People();
                    p.setName(dataParts[0]);
                    p.setAge(Integer.parseInt(dataParts[1]));
                    p.setWeight(Integer.parseInt(dataParts[2]));
                    p.setHeight(Integer.parseInt(dataParts[3]));

                    double imc = calcIMC(p.getWeight(), p.getHeight());

                    // Cria resposta
                    String response = "Seu IMC é: " + imc;
                    byte[] responseData = response.getBytes();

                    // Captura o endereço do cliente
                    InetAddress clientAddress = receivePacket.getAddress();
                    int clientPort = receivePacket.getPort();

                    // Cria pacote de resposta
                    DatagramPacket sendPacket = new DatagramPacket(responseData, responseData.length, clientAddress, clientPort);

                    // Envia resposta
                    socket.send(sendPacket);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                // Fecha a conexão
                socket.close();
            }
        }
    }

    public static double calcIMC(double weight, double height) {
        height = (float) height / 100;
        return weight / (height * height);
    }
}
