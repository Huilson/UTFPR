/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetotcpdistribuidas;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class Pessoa implements Serializable{

    private final String nome;
    private final double peso;
    private final double altura;
   private  double imc = 0;

    public Pessoa(String nome, double peso, double altura, double imc) {
    this.nome = nome;
    this.peso = peso;
    this.altura = altura;
    this.imc = imc;

    }
    
    public String getNome() {
        return nome;
    }

    public double getPeso() {
        return peso;
    }

    public double getAltura() {
        return altura;
    }

    public double getImc() {
        return imc;
    }

    public void setImc(double imc) {
        this.imc = imc;
    }


}