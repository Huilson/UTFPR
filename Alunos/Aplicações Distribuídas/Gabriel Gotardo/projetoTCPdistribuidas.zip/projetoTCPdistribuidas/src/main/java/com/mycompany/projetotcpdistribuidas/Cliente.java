/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.projetotcpdistribuidas;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        Socket socket = new Socket("127.0.0.1", 8080);

        //Definir os Stream de saída de dados
        DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        saida.writeUTF("Oi servidor");

        //Definir o stream de entrada de dados (para ouvir)
        DataInputStream entrada = new DataInputStream(socket.getInputStream());
        String novaMensagem = entrada.readUTF();
        System.out.println(novaMensagem);

        // Criar o peso e etc, depois mando para o SOCKET
        //OBJECTINPUTSTREAM E OBJECTOUTPUTSTREAM
        String nome = "Gabriel";
        System.out.println("Nome: " + nome);
        double peso = 72.8;
        System.out.println("Peso: " + peso);
        double altura = 1.71;
        System.out.println("Altura: " + altura);
        double imc = 0;
        System.out.println("IMC: " + imc);

        Pessoa pessoa = new Pessoa(nome, peso, altura, imc);
   //     System.out.println("Pessoa: " + pessoa.getNome());

        // Enviar a pessoa via ObjectOutputStream
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        objectOutputStream.writeObject(pessoa);
        objectOutputStream.flush();

        //receber pessoa dnv
        ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
        Pessoa pessoaRecebida = (Pessoa) objectInputStream.readObject();
        System.out.println("IMC Recebido1: " + pessoaRecebida.getImc());

        if (pessoaRecebida.getImc() < 18.5) {
            System.out.println("Abaixo do peso");
        } else if (pessoaRecebida.getImc() > 18.4 && imc < 25) {
            System.out.println("Peso normal");
        } else if (pessoaRecebida.getImc() > 24.99 && imc < 30) {
            System.out.println("Acima do peso");
        } else if (pessoaRecebida.getImc() > 29.99) {
            System.out.println("Obesidade");
        }

        objectOutputStream.close();
        objectInputStream.close();
        entrada.close();
        saida.close();
        socket.close();
    }

}
