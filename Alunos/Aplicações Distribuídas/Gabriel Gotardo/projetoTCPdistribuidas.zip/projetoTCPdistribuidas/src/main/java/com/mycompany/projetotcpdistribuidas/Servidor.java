/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.projetotcpdistribuidas;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ServerSocket serversocket = new ServerSocket(8080);
        System.out.println("O servidor está ouvindo na porta 8080");

        // Abrir a comunicação (ficar ouvindo a resposta)
        Socket socket = serversocket.accept();

        // Mostrar o IP do cliente que vai estar conectado
        System.out.println("Um cliente se conectou: " + socket.getInetAddress().getHostAddress());

        // Definir um stream de entrada para o servidor
        DataInputStream entrada = new DataInputStream(socket.getInputStream());
        // Quando recebo a mensagem ela esta em bytes, para deserializar a mensagem
        // ou uma string usamos o método readUTF()
        String mensagem = entrada.readUTF();
        System.out.println(mensagem);

        DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        String novaMensagem = "Oi cliente, eu sou o servidor";
        saida.writeUTF(novaMensagem);

        // Receber a pessoa via ObjectInputStream
        ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
        Pessoa pessoaRecebida = (Pessoa) objectInputStream.readObject();
        String nome = pessoaRecebida.getNome();
        double peso = pessoaRecebida.getPeso();
        double altura = pessoaRecebida.getAltura();
        double imc = peso / (altura * altura);

        System.out.println("Nome: " + nome);
        System.out.println("Altura: " + peso);
        System.out.println("Peso: " + altura);
        pessoaRecebida.setImc(imc);
        System.out.println("IMC: " + pessoaRecebida.getImc());
        
        // Enviar a pessoa de volta via ObjectOutputStream
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        objectOutputStream.writeObject(pessoaRecebida);
        objectOutputStream.flush();

        // Fechar os streams e o socket
        objectOutputStream.close();
        objectInputStream.close();
        saida.close();
        entrada.close();
        socket.close();
        serversocket.close();
    }
}