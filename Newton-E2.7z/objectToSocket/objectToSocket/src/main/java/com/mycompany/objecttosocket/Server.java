/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.objecttosocket;

import java.io.IOException;
import java.net.ServerSocket;
import java.io.*;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Newton Huner
 */

class Imc
{
    String imc; float nImc;
    public Imc(float peso, float altura)
    {
        resultadoImc(peso, altura);
    }
    public void resultadoImc(float peso, float altura) {
        double imc;

        imc =    (peso / (altura * altura));

        if (imc < 20) {
        this.imc = " Usuário considerado: Magro";
        } else if (imc >= 20 && imc <= 24) {
        this.imc = "Usuário considerado: Normal";
        } else if (imc >= 25 && imc <= 29) {
        this.imc = "Usuário considerado: Acima do Peso";
        } else if (imc >= 30 && imc <= 34) {
        this.imc = "Usuário considerado: Obeso";
        } else {
        this.imc = "Usuário considerado: Muito Obeso";

        }
    }
}

public class Server {

    ServerSocket server;
    Imc imc;
    public Server() {
        try {
            server = new ServerSocket(7777);
            while (true)
            {
                System.out.println("Esperando conexao agora");
                Socket clisocket = server.accept();
                System.out.println("Conexao estabelecida por " + clisocket.getInetAddress().getHostAddress());

                InputStream inputStream = clisocket.getInputStream();

                ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
                Pessoa p = (Pessoa) objectInputStream.readObject();

                imc = new Imc(p.peso, p.altura);
                OutputStream outputStream = clisocket.getOutputStream();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

                objectOutputStream.writeObject(imc);
                objectOutputStream.flush();
                objectOutputStream.close();
                clisocket.close();
            }
            
        } catch (IOException ex) {
            System.out.println("print(\"Server fez poo poo\\n\");");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main (String[] args)
    {
        Server s = new Server();
    }

}
