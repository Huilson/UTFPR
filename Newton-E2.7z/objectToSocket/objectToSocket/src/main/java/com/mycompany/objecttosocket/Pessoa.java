/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.objecttosocket;

import java.io.Serializable;

/**
 *
 * @author benalian42
 */
class Pessoa implements Serializable
{
    String nome;
    float peso;
    float altura;
    
    public Pessoa (String nome, float peso, float altura)
    {
        this.nome = nome; 
        this.peso = peso;
        this. altura = altura;
    }
}
