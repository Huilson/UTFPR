/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.objecttosocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Scanner;

class Client {
    Scanner s = new Scanner(System.in);
    String n;
    float a,p;
    char continuar = 's';
    Socket meuSocket;
    ObjectInputStream meuIn;
    ObjectOutputStream conversorOut;
    ObjectInputStream conversorIn;
    
    public Client () throws ClassNotFoundException
    {
        
        try {    
                while ( continuar == 's' )
                {
                    System.out.println("Digite o seu nome:");
                    n = s.next();
                    System.out.println("Digite a sua altura:");
                    a = s.nextFloat();
                    System.out.println("Digite o seu peso:");
                    p = s.nextFloat();
                    
                    meuSocket = new Socket("127.0.0.1",7777);
                    meuSocket.connect(new InetSocketAddress ( InetAddress.getByName("localhost"),7777 ));
                    System.out.println("Conexao estabelecida em " + meuSocket.getRemoteSocketAddress());
                    
                    OutputStream saida = meuSocket.getOutputStream();             
                    conversorOut = new ObjectOutputStream(saida);
                    conversorOut.writeObject(new Pessoa (n,p,a));
                    
                    Imc c;
                    InputStream entrada = meuSocket.getInputStream();             
                    conversorIn = new ObjectInputStream(entrada);
                    c = (Imc) conversorIn.readObject();
                    
                    System.out.println("Seu imc eh " + c.nImc + "e voce eh " + c.imc);
                    System.out.println("Continuar?");
                    continuar = s.next().charAt(0);
                }

            } catch (IOException ex) {
                System.out.println("print(\"ero\\n\");");
            }
    }
}

public class Cliente {

    public static void main(String[] args) throws ClassNotFoundException {
        
        Client cliente = new Client();
        
    }
}
